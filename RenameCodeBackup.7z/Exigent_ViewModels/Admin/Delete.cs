﻿
namespace Exigent_ViewModels.Admin
{
    public class Delete
    {
        public string Multiple { get; set; }
        public int ID { get; set; }
        public int UnitID { get; set; }
        public int? RoomID { get; set; }
        public int? MenuLineID { get; set; }
        public int? FunctionalAreaID { get; set; }
        public string TableName { get; set; }
        public string Action { get; set; }
        public string Area { get; set; }
        public string Controller { get; set; }
        public string DbContext { get; set; }
        public int? GeoId { get; set; }
        public string param { get; set; }
        public string Geo { get; set; }
        public string AppliedCid { get; set; }
        public int EquipMentId { get; set; }
        public bool Encrpted { get; set; }
        public int ProjectId { get; set; }
        public int? SITId { get; set; }
    }
}
