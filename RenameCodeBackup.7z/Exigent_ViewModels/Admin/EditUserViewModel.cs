﻿using Exigent.MVCHelpers.CustomAttribute;
using Exigent_ViewModels.DropDowns;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web;
using System.Web.Mvc;
using Exigent.Common.Constants;
using Exigent.ViewModels.Common;

namespace Exigent_ViewModels.Admin
{
    public class EditUserViewModel
    {
        public int? Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid email address")]
        //[DataType(DataType.EmailAddress)]
        [StringLength(100, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "Email")]
        public string Email { get; set; }


        [StringLength(100, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "User Name")]
        [Required(ErrorMessage = CommonConstants.Required)]
        public string UserName { get; set; }

        public bool IsMobileRequest { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(50, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "Full Name")]
        public string FullName { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [Display(Name = "User Role")]
        public int RoleId { get; set; }

        public List<int> RoleIds { get; set; }

        //public List<RolesViewModel> RoleList { get; set; }
        public List<SelectListItem> RoleList { get; set; }

        //[Required(ErrorMessage = CommonConstants.Required)] //TODO: Uncomment this
        [Display(Name = "User Access")]
        public List<int> UserAccessString { get; set; }

        public List<UserAccessViewModel> UserAccessList { get; set; }

        public List<int> BusinessUnitIds { get; set; }
        public List<KeyValuePair<int, string>> BusinessUnitList { get; set; }

        public List<int> MatterTypeIds { get; set; }
        public List<System.Web.Mvc.SelectListItem> MatterTypeList { get; set; }

        [Display(Name = "User Image")]
        [ValidateFile]
        public HttpPostedFileBase File { get; set; }

        public string OriginalImage { get; set; }

        public string ThumbImage { get; set; }

        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }


        public List<SelectListItem> UserTypes { get; set; }
        public List<SelectListItem> Office { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [Display(Name = "User Type")]
        public int UserTypeId { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [Display(Name = "Office")]
        public int OfficeId { get; set; }

        public int LawFirm_ID { get; set; }
        public string LawFirm { get; set; }


        public List<System.Web.Mvc.SelectListItem> Dashboards { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [Display(Name = "Default Dashboard")]
        public int DefaultDashboardID { get; set; }

        public string DefaultDashboard { get; set; }

		// added props to hold user associated LPAs & BUs
		public List<Users_BusinessUnit_ViewModel> UserBusinessUnits { get; set; }
		public List<Users_LPA_ViewModel> User_LPAs { get; set; }
	}
}
