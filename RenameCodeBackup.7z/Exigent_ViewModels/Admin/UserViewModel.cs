﻿using System.ComponentModel.DataAnnotations;

namespace Exigent_ViewModels.Admin
{
    public class UserViewModel
    {
        [Required]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }

        public int UserId { get; set; }

        public string SessionId { get; set; }

        public bool LoggedIn { get; set; }
    }

    public class UserLoggedInPathViewModel
    {
        public string Action { get; set; }
        public string Controller { get; set; }
        public string Area { get; set; }
    }
}
