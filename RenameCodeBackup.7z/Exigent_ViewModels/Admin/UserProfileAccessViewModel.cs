﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
   public class UserProfileAccessViewModel
    {
        public int ID { get; set; }
        public int UserId { get; set; }
        public string OTP { get; set; }
        public string OTPURL { get; set; }
        public Nullable<System.DateTime> Expiration { get; set; }
        public bool IsActive { get; set; }
        public System.DateTime Created { get; set; }
    }
}
