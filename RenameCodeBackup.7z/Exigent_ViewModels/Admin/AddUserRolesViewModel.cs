﻿
namespace Exigent_ViewModels.Admin
{
    public class CreateUserRolesViewModel
    {
        //[Required]
        //public string Name { get; set; }
        //[Required]
        //public bool IsActive { get; set; }

    }
}
