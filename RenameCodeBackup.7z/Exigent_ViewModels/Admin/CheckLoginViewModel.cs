﻿
namespace Exigent_ViewModels.Admin
{
   public class CheckLoginViewModel
    {
        public int UserId { get; set; }
        public string SessionId { get; set; }
        public bool LoggedIn { get; set; }

    }
}
