﻿using Exigent_ViewModels.DropDowns;
using Exigent.MVCHelpers.CustomAttribute;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web;
using Exigent.ViewModels.Common;
using Exigent.Common.Constants;


namespace Exigent_ViewModels.Admin
{
    public class AddUserViewModel
    {
        public int? Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid email address")]
        //[DataType(DataType.EmailAddress)]
        [StringLength(100, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [StringLength(100, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "User Name")]
        [Required(ErrorMessage = CommonConstants.Required)]
        public string UserName { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [DataType(DataType.Password)]
        [StringLength(100, ErrorMessage = "The Password must be 6-14 characters long.", MinimumLength = 6)]
        [RegularExpression("(?=^.{6,}$)(?=.*\\d)(?=.*[!@#$%^&*]+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$", ErrorMessage = "Password must be 6-14 characters in length containing at least one Uppercase, one Lowercase, one Number and one Special Letter.")]
        [Display(Name = "Password")]
        public string Password { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [DataType(DataType.Password)]
        [StringLength(100, ErrorMessage = "The Password must be 6-14 characters long.", MinimumLength = 6)]
        [RegularExpression("(?=^.{6,}$)(?=.*\\d)(?=.*[!@#$%^&*]+)(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$", ErrorMessage = "Password must be 6-14 characters in length containing at least one Uppercase, one Lowercase, one Number and one Special Letter.")]
        [Display(Name = "Confirm Password")]
        [Compare("Password", ErrorMessage = "Passwords do not match")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(50, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "Full Name")]
        public string FullName { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [Display(Name = "User Role")]
        public int RoleId { get; set; }
        public int hdRoleId { get; set; }
        public List<int> RoleIds { get; set; }

        //public List<RolesViewModel> RoleList { get; set; }
        public List<System.Web.Mvc.SelectListItem> RoleList { get; set; }

        //[Required(ErrorMessage = CommonConstants.Required)] //TODO: Uncomment this
        [Display(Name = "User Access")]
        public List<int> UserAccessString { get; set; }
        public List<UserAccessViewModel> UserAccessList { get; set; }

        public List<int> BusinessUnitIds { get; set; }
        public List<KeyValuePair<int,string>> BusinessUnitList { get; set; }

        public List<int> MatterTypeIds { get; set; }
        public List<System.Web.Mvc.SelectListItem> MatterTypeList { get; set; }

        //[Required(ErrorMessage = "Please Upload File")]
        [Display(Name = "Upload File")]
        [ValidateFile]
        public HttpPostedFileBase File { get; set; }

        public string OriginalImage { get; set; }

        public string ThumbImage { get; set; }
        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }

        public List<System.Web.Mvc.SelectListItem> UserTypes { get; set; }
        public List<System.Web.Mvc.SelectListItem> Office { get; set; }
        [Required(ErrorMessage = "Please Select User Type")]
        [Display(Name = "User Type")]
        public int UserTypeId { get; set; }

        public string UserType { get; set; }

        [Required(ErrorMessage = "Please Select Office")]
        [Display(Name = "Office")]
        public int OfficeId { get; set; }

        public string OfficeName { get; set; }

        public string SecurityStamp { get; set; }
		public int LawFirm_ID { get; set; }
        public string LawFirm { get; set; }

        public List<System.Web.Mvc.SelectListItem> Dashboards { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [Display(Name = "Default Dashboard")]
        public int DefaultDashboardID { get; set; }

        public string DefaultDashboard { get; set; }

		// added props to hold user associated LPAs & BUs
		public List<Users_BusinessUnit_ViewModel> UserBusinessUnits { get; set; }
		public List<Users_LPA_ViewModel> User_LPAs { get; set; }
	}


    public class UserAccessViewModel
    {
        public int Id { get; set; }

        public int Rights { get; set; }

        public int RoleId { get; set; }

        public AccessDashboardViewModel AccessDashboard { get; set; }

        public RoleViewModel User { get; set; }
    }
}