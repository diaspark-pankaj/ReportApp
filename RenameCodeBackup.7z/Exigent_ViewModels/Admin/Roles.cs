﻿using System.ComponentModel.DataAnnotations;

namespace Exigent_ViewModels.UsersRolesPermissions
{
    class Roles
    {
        [Required]
        public virtual string Name { get; set; }
        
        public virtual bool IsActive { get; set; }
    }
}
