﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
namespace Exigent_ViewModels.Admin
{
    public class SelectedUserViewModel
    {
        public int Id { get; set; }

        public String UserName { get; set; }

    }
}
