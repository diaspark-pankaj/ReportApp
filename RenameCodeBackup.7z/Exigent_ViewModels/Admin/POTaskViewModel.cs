﻿
namespace Exigent.ViewModels.Admin
{
    public class POTasksViewModel
    {
        public string POContact { get; set; }
        public string LeadLawyer { get; set; }
        public string ClientLead { get; set; }
        public string Date { get; set; }
        public string OrderNumber { get; set; }
        public string PO_Number { get; set; }
        public string PurchaseRequestReference { get; set; }
        public string CostCentre { get; set; }
        public string GLAccount { get; set; }
        public string LegalDiscipline { get; set; }
        public string Vatable_Amount { get; set; }
        public string NonVatable_Amount { get; set; }
        public string Non_Vatable_Amount { get; set; }
        public decimal Total_Amount { get; set; }
        public decimal Purchase_Total { get; set; }
        public string Vendor { get; set; }
        public string Comments { get; set; }
        public string Subject { get; set; }
        public string Url { get; set; }
        public bool IsSend { get; set; }
        public string Status { get; set; }
        public int Id { get; set; }
        public string Assigned_To { get; set; }
        public int Assigned_To_ID { get; set; }
        public string Instruction { get; set; }
        public string PoNumber { get; set; }
        public string BusinessUnit { get; set; }
        public string MatterName { get; set; }
        public string Matter_Reference { get; set; }
        public bool IsSendToLead { get; set; }
        public int Days { get; set; }
        public string ReminderMessage { get; set; }
        public decimal? D_Vatable_Amount { get; set; }
        public decimal? D_NonVatable_Amount { get; set; }
        public string CreatedDate { get; set; }
        public string CreatedUser { get; set; }
        public string CurrentDate { get; set; }
        public string PODate { get; set; }
        public string Payment_Clearance_Number { get; set; }
        public decimal? Payment_Clearance_Value { get; set; }
        public string Matter_Title { get; set; }
    }
}
