﻿using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Exigent_ViewModels.Admin
{

    public class RoleViewModel
    {
        [Required(ErrorMessage = "Role Name is Required")]
        [StringLength(100, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "Role Name")]
        public string Name { get; set; }
        public int Id { get; set; }
        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }
        public string CompanyId { get; set; }
        public bool IsSystem { get; set; }
        public ICollection<AppActivityViewModel> Activities { get; set; }
        public string Description { get; set; }
        public ICollection<AppActivityViewModel> ActivityTree { get; set; }
        public ICollection<RoleAccessViewModel> RoleAccessList { get; set; }
        public RoleViewModel()
        {
            Activities = new List<AppActivityViewModel>();
            ActivityTree = new List<AppActivityViewModel>();
        }

    }
    public class RoleListViewModel
    {
        public List<RoleViewModel> RoleList { get; set; }
        public string searchField { get; set; }

    }

    public class AppActivityViewModel
    {
        public int Id { get; set; }

        [Required]
        public virtual string Value { get; set; }

        [Required]
        public virtual string Text { get; set; }

        public virtual int? ParentId { get; set; }

        [Required]
        public virtual int SortOrder { get; set; }

        [Required]
        public virtual bool IsActive { get; set; }
        [Required]
        public virtual bool CheckedValue { get; set; }

        public virtual ICollection<AppActivityViewModel> ChilddAppActivityViewModel { get; set; }

    }
    public class RoleAccessViewModel
    {
        public int Id { get; set; }
        public Nullable<int> DashBoardId { get; set; }
        public Nullable<int> RoleId { get; set; }

        public virtual AccessDashboardViewModel AccessDashboard { get; set; }
        public virtual RoleViewModel Role { get; set; }
    }
}
