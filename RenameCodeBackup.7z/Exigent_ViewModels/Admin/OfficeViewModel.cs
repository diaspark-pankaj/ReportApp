﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Admin
{
     public class OfficeViewModel
    {

        public int Id { get; set; }
        public Nullable<int> CountryId { get; set; }
        public string OfficeName { get; set; }
        public bool IsActive { get; set; }
    }
}
