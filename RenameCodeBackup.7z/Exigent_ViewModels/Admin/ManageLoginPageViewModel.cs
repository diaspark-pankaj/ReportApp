﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Admin
{
    public class ManageLoginPageViewModel
    {
        public int Id { get; set; }
        public string File { get; set; }
        public string NotificationBoardMessage { get; set; }
        public Nullable<System.DateTime> Created { get; set; }
    }
}
