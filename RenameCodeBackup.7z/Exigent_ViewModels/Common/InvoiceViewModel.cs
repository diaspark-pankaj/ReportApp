﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web;

namespace Exigent.ViewModels.Common
{
    public class InvoiceViewModel
    {
        public int ID { get; set; }  public int InvoiceId { get; set; }
		
        [Required(ErrorMessage = CommonConstants.Required)]
		public int Instruction_ID { get; set; }

		public string Instruction_Reference { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string Invoice_Number { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        [DisplayFormat(DataFormatString = "{0:MMM dd yyyy}", ApplyFormatInEditMode = true)]
        public Nullable<System.DateTime> Invoice_Date { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<decimal> Invoice_Total { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<decimal> PreVat_Total { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<decimal> Attorney_Fee { get; set; }
        //[Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<decimal> Attorney_HDSA { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<decimal> Advocate_Fee { get; set; }
       // [Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<decimal> Advocate_HDSA { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<decimal> C3rd_Party_Fee { get; set; }
        //[Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<decimal> C3rd_Party_HDSA { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<decimal> Disbursement_Total { get; set; }
        public string Advocate_Recommendation { get; set; }
		public int Vendor_ID { get; set; }
        public string Vendor { get; set; }
        public Nullable<System.DateTime> Created { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string Invoice_Type { get; set; }
        public HttpPostedFileBase InvoiceFile { get; set; }
        public HttpPostedFileBase TimesheetFile { get; set; }
        public HttpPostedFileBase DisbursementFile { get; set; }
        public HttpPostedFileBase SubCostFile { get; set; }        
        public Nullable<decimal> Disbursement_Inv_Total { get; set; }
        public List<System.Web.Mvc.SelectListItem> VendorLawyerList { get; set; }
        public bool TsFile { get; set; }
        public string Invoice_Status { get; set; }
        public string GRVNumber { get; set; }
        public string Costcentre { get; set; }
        public string PONumber { get; set; }
        public string LeadLawyer { get; set; }
        public string RejectionReason { get; set; }
        public string ApprovalDate { get; set; }
        public string Comments { get; set; }
        public string VatNo { get; set; }
        public string MatterStatus { get; set; }
        public string MatterReference { get; set; }
        public string MatterTitle { get; set; }
        public string Email { get; set; }
        public string EmailCC { get; set; }
        public string InvoiceDate { get; set; }
        public string User { get; set; }
        public string Url { get; set; }
        public string UrlDocs { get; set; }
        public string ReminderMessage { get; set; }
        public string UrlVendor { get; set; }
        public string Matter_Reference { get; set; }
        public string lstInvoiceFee { get; set; }
        public decimal TotalFee { get; set; }
        public string ReferenceNumber { get; set; }
        public List<InvoiceFeeDetailViewModel> lstInvoiceFeeDtl { get; set; }
        public string InvoiceFileName { get; set; }
        public string TimeFileName { get; set; }
        public string DisFileName { get; set; }
        public string SubFileName { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
		public int Currency_ID { get; set; }
        public string CurrencyCode { get; set; }
        public string GRV_Received { get; set; }
        public string GRV_Number { get; set; }
        public string Payment_Date { get; set; }
        public DateTime? GRV_Received_Date { get; set; }
        public DateTime? Sent_Payment_Date { get; set; }
        public string BillingEntity { get; set; }
        public string UpdatedByFullName { get; set; }
        public string LawFirm { get; set; }
        public Nullable<decimal> PreVat_Total_InvCur { get; set; }
        public string CurrencySymbol { get; set; }
    }
    public class InvoiceDocumentViewModel
    {
        public string FileName { get; set; }
        public string URL { get; set; }
        public string DocsName { get; set; }
        public string Type { get; set; }
		public string Invoice_Number { get; set; }
    }
    public class InvoiceFeeDetailViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public string Race { get; set; }
		public int? VendorLawer_ID { get; set; }
		public VendorLawyerViewModel VendorLawyer { get; set; }
		public Nullable<decimal> Rate { get; set; }
        public Nullable<decimal> Total { get; set; }
        public string InvoiceNo { get; set; }
    }
    public class ExternalInvoiceViewModel
    {
        public string Instruction_Reference { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
		public int Instruction_ID { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
		public int? Vendor_ID { get; set; }
        public string Vendor { get; set; }

        public string Description { get; set; }
        
        [Required(ErrorMessage = CommonConstants.Required)]
		public int? BusinessUnit_ID { get; set; }
        public string BusinessUnit { get; set; }

		public int? Matter_ID { get; set; }
        public string Matter_Reference { get; set; }

		[DisplayFormat(DataFormatString = "{0:MMM dd yyyy}", ApplyFormatInEditMode = true)]
        public Nullable<System.DateTime> Invoice_Date { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string Invoice_Number { get; set; }
        
        //[Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(@"^[+-]?((\d+(\.\d*)?)|(\.\d+))$", ErrorMessage = "Only Numbers allowed")]
        public Nullable<decimal> Invoice_Total { get; set; }

        [RegularExpression(@"^[+-]?((\d+(\.\d*)?)|(\.\d+))$", ErrorMessage = "Only Numbers allowed")]
        public Nullable<decimal> PreVat_Total { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [DisplayFormat(DataFormatString = "{0:MMM dd yyyy}", ApplyFormatInEditMode = true)]
        public Nullable<System.DateTime> Payment_Date { get; set; }
    }
}
