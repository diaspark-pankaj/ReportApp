﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class CurrencyConverterViewModel
    {
        //public Double Amount { get; set; }
        //public string FromCurrency { get; set; }
        //public string ToCurrency { get; set; }

        public bool success { get; set; }
        public string terms { get; set; }
        public string privacy { get; set; }
        public string result { get; set; }

    }
}
