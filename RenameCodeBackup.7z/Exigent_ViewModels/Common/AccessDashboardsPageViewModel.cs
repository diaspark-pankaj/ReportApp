﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
   public class AccessDashboardPageViewModel
    {
       public AccessDashboardPageViewModel()
        {
            // to do..
        }
        public int ID { get; set; }
        public int DashboardID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public Nullable<int> SortOrder { get; set; }
        public Nullable<bool> IsActive { get; set; }

        public string PageURL { get; set; }

        public string ImageURL { get; set; }

       // this property tells, that this menu item is for display in dropdown menu list.
        public bool IsDropdown { get; set; }

        public bool HasAdminAccess { get; set; }

        public bool HasGLAccess { get; set; }
        public bool HasRAAccess { get; set; }
        public bool HasVendorAccess { get; set; }

        public bool HasAccessToAll { get; set; }

        public virtual AccessDashboardViewModel AccessDashboard { get; set; }
    }
}
