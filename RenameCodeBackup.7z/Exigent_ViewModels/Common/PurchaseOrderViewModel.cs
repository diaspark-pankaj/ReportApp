﻿using Exigent.Common.Constants;
using Exigent_ViewModels.Admin;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Exigent.ViewModels.Common
{
    public class PurchaseOrderViewModel
    {
        public PurchaseOrderViewModel()
        {
            this.PO_Tasks = new HashSet<POTaskViewModel>();
        }
    
        public int ID { get; set; }
        public string Status { get; set; }
		public int Instruction_ID { get; set; }
		public string Instruction_Reference { get; set; }
		public int? Vendor_ID { get; set; }
		public string Vendor { get; set; }
        public string PO_Number { get; set; }
        public string Cost_Centre { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string GL_Account { get; set; }

        public string GroupWideSplit { get; set; }
        public Nullable<decimal> Vatable_Amount { get; set; }
        public Nullable<decimal> Non_Vatable_Amount { get; set; }
        public Nullable<System.DateTime> Created { get; set; }
        public string Created_By { get; set; }
    
        public InstructionViewModel External_Instructions { get; set; }
        public ICollection<POTaskViewModel> PO_Tasks { get; set; }
        public VendorViewModel Vendor1 { get; set; }
    }
}
