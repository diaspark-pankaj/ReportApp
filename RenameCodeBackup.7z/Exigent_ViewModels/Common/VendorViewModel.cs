﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Exigent.ViewModels.Common
{
    public class VendorViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Company_Name { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Category { get; set; }

        //[Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid email address")]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Email { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Color { get; set; }

        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }
    }

    public class VendorListViewModel
    {
        public VendorListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<VendorViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<VendorViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }

	public class VendorLawyerViewModel
	{
		public int Id { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
		public int ? Vendor_ID { get; set; }

        
        //[StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public VendorViewModel Vendor { get; set; }

        public string Vendor1 { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Lawyer { get; set; }

        [StringLength(3, ErrorMessage = "Maximum allowed characters upto 3")]
        public string HDSA { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(@"^[+-]?((\d+(\.\d*)?)|(\.\d+))$", ErrorMessage = "Only Numbers allowed")]
        public decimal Rate { get; set; }

        public List<System.Web.Mvc.SelectListItem> VendorList { get; set; }
    }

    public class VendorLawyerListViewModel
    {
        public VendorLawyerListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<VendorLawyerViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<VendorLawyerViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }

    public class LegalDesciplineViewModel
    {
        public int Id { get; set; }

		public int Vendor_ID { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Vendor { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
		public int Legal_Discipline_ID { get; set; }
		        
        //[StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Legal_Discipline { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Business_Unit { get; set; }

		public int BusinessUnit_ID { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid email address")]
        //[DataType(DataType.EmailAddress)]
        [StringLength(100, ErrorMessage = "Maximum allowed characters upto 100")]
        public string Email { get; set; }
                
        public List<System.Web.Mvc.SelectListItem> LegalDisciplineList { get; set; }

        //public List<System.Web.Mvc.SelectListItem> LegalDisciplineList { get; set; }
        public List<System.Web.Mvc.SelectListItem> VendorList { get; set; }
        public List<System.Web.Mvc.SelectListItem> BusinessUnitList { get; set; }
    }

    public class LegalDesciplineListViewModel
    {
        public LegalDesciplineListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<LegalDesciplineViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<LegalDesciplineViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }
}
