﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Exigent.ViewModels.Common
{
    public class PeoplePickerViewModel
    {
        public PeoplePickerViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<BusinesUnitViewModel>();
        }

        public int ID { get; set; }

        [Required(ErrorMessage = "Full Name is Required")]
        [StringLength(50, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "Full Name")]
        public string Full_Name { get; set; }

        [Required(ErrorMessage = "Email is Required")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid email address")]
        [StringLength(100, ErrorMessage = "Maximum allowed characters upto 100")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        public String SearchField { get; set; }
        public Dictionary<string, object> RustyData;
        public List<BusinesUnitViewModel> EntityList { get; set; }
    }

    public class PeoplePickerListViewModel
    {
        public PeoplePickerListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<PeoplePickerViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<PeoplePickerViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }
}
