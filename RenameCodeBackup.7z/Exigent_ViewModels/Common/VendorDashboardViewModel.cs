﻿
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Exigent.ViewModels.Common
{
    public class VendorDashboardViewModel
    {
        public InstructionListViewModel InstructionList { get; set; }
        public OutstandingInvoicesListViewModel OutstandingInvoiceList { get; set; }
        public RejectedInvoicesListViewModel RejectedInvoicesList { get; set; }
        public SearchInvoiceListViewModel SearchInvoiceList { get; set; }

        public int VendorId { get; set; }
        public string VendorName { get; set; }
        public List<SelectListItem> VendorList { get; set; }
    }

    public class OutstandingInvoicesListViewModel
    {
        public OutstandingInvoicesListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<OutstandingInvoicesViewModel> OutstandingInvoiceList { get; set; }
        public int RecordCount { get; set; }
        public Dictionary<string, object> RustyData; public bool isAdmin { get; set; }
    }

    public class RejectedInvoicesListViewModel
    {
        public RejectedInvoicesListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<RejectedInvoicesViewModel> RejectedInvoicesList { get; set; }
        public int RecordCount { get; set; }
        public Dictionary<string, object> RustyData;
    }

    public class RejectedInvoicesViewModel
    {
        public string Matter_Reference { get; set; }
        public string Instruction_Reference { get; set; }
        public string Business_Unit { get; set; }
        public string Billing_Entity { get; set; }
        public string Vendor { get; set; }
        public string Invoice_Number { get; set; }
        public string Invoice_Status { get; set; }
        public string PreVat_Total { get; set; }
        public decimal PreVat_Total_InvCur { get; set; }
        public string CurrencySymbol { get; set; }
        public string Rejection_Date { get; set; }
        public string Rejection_Reason { get; set; }
    }

    public class OutstandingInvoicesViewModel
    {
        public string Matter_Reference { get; set; }
        public string Instruction_Reference { get; set; }
        public string Business_Unit { get; set; }
        public string Billing_Entity { get; set; }
        public string Vendor { get; set; }
        public string Invoice_Number { get; set; }
        public string Invoice_Status { get; set; }
        public decimal PreVat_Total { get; set; }
        public decimal PreVat_Total_InvCur { get; set; }
        public string CurrencySymbol { get; set; }
        public int Days { get; set; }
        public string Detailed_Status { get; set; }
    }

    public class SearchInvoiceListViewModel
    {
        public SearchInvoiceListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<SearchInvoiceViewModel> SearchInvoiceList { get; set; }
        public int RecordCount { get; set; }
        public Dictionary<string, object> RustyData;
        [Required(ErrorMessage = CommonConstants.Required)]
        public String SearchField { get; set; }
        public bool isAdmin { get; set; }
        public BUApprovalEnum ApprovalType { get; set; }
    }

    public class SearchInvoiceViewModel : InvoiceAuditViewModel
    {
        public SearchInvoiceViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public string Matter_Reference { get; set; }
        public string Instruction_Reference { get; set; }
        public string Business_Unit { get; set; }
        public string Billing_Entity { get; set; }
        public string Vendor { get; set; }
        public string Invoice_Number { get; set; }
        public string Invoice_Status { get; set; }
        public decimal PreVat_Total { get; set; }
        public decimal PreVat_Total_InvCur { get; set; }        
        public string Assigned_To { get; set; }
        public string Matter_Name { get; set; }
        public int Days { get; set; }
        public string ReminderMessage { get; set; }
        public string Lead_Lawyer { get; set; }
        public string Matter_Status { get; set; }
        public string Vat_Number { get; set; }
        public string Payment_Clearance_Number { get; set; }
        public string Invoice_Total { get; set; }
        public decimal Invoice_Total_InvCur { get; set; }
        public string CurrencySymbol { get; set; }
        public Nullable<decimal> InvoiceTotal { get; set; }
        public int ID { get; set; }
        public string InvoiceDate { get; set; }
        public string Highlighted_Issues { get; set; }
        public int GrvId { get; set; }
        public int AppId { get; set; }
        public bool isAdmin { get; set; }
        public bool isMail { get; set; }
        public string Status { get; set; }
        public string PO_Number { get; set; } public string Non_Vatable_Amount { get; set; }
        public string Vatable_Amount { get; set; }
        public string Url { get; set; }
        public Dictionary<string, object> RustyData;
        public int RecordCount { get; set; }
        public string FileName { get; set; }
        public int SystemType_ID { get; set; }
        public List<InvoiceTimesheetsViewModel> InvoiceTimesheetsListVM { get; set; }
    }

    public class InvoiceAuditViewModel
    {
        public string Comments { get; set; }
        public int InvoiceId { get; set; }
        public bool IsSend { get; set; }
        public string CandidateAttorney { get; set; }
        public string SeniorAssociate { get; set; }
        public string Associate { get; set; }
        public string SalariedPartner { get; set; }
        public string Partner { get; set; }
        public string Advocate { get; set; }
        public string InvoiceContains { get; set; }
        public string NotReflected { get; set; }
        public string Cost_Centre { get; set; }
        public string GL_AccountNo { get; set; }
        public string GroupWideSplit { get; set; }
    }
}
