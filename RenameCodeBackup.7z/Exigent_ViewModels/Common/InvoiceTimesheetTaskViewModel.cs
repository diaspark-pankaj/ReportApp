﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class InvoiceTimesheetTaskViewModel
    {
        public int ID { get; set; }
        public string Task { get; set; }        
        public string MatterName { get; set; }
        public string Matter_Reference { get; set; }
        public string AssignedTo { get; set; }
        public string Url { get; set; }
    }
}
