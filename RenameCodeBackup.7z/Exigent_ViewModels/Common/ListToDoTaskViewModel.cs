﻿using Exigent.Common.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.Common
{
   public class ListToDoTaskViewModel
    {
       public List<ToDoTaskViewModel> ToDoList { get; set; }
       public TaskType TaskTypeFilter { get; set; }
       public ToDoTaskPeriod ToDoTaskPeriodFilter { get; set; }

       public string ToDoTimeSpan { get; set; }

      
    }
}
