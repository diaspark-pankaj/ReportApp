﻿
namespace Exigent_ViewModels.Common
{
    public class DrawImageViewModel
    {
        public string ImageStoragePath { get; set; }
        public string ImageName { get; set; }
        public int UnitID { get; set; }
        public string ImageDataUrl { get; set; }
        public int PId { get; set; }
        public string ScreenPath { get; set; }

        public bool IsMobileRequest { get; set; }
    }

}
