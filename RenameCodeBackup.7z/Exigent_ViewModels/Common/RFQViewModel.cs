﻿
using Exigent.Common.Constants;
using System;
using System.ComponentModel.DataAnnotations;
namespace Exigent.ViewModels.Common
{
    public class RFQViewModel
    {
        public int ID { get; set; }
        public string Status { get; set; }
        public string Matter_Reference { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string Background_To_Request { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string Services_Required { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        [DisplayFormat(DataFormatString = AppConstants.DATEFORMAT_SERVER, ApplyFormatInEditMode = true)]
        public DateTime? To_Respond_By { get; set; }
        public string ToRespondBy { get; set; }
        public string Date { get; set; }
		public int Assigned_To_ID { get; set; }
        public string Assigned_To { get; set; }
        public int Days { get; set; }
        public string Url { get; set; }
        public string MatterName { get; set; }
        public string LegalDiscipline { get; set; }
        public string Business_Unit { get; set; }        
        public string To_Respond { get; set; }
        public int type { get; set; }
        public string Comments { get; set; }
        public string Reassign { get; set; }
		public int Reassign_To_ID { get; set; }
        public int RfqId { get; set; }
        public string RejectedBy { get; set; }
		public int RejectedBy_ID { get; set; }
        public string Lead { get; set; }
        public string BusinessUnit { get; set; }
        public bool IsUserRFQ { get; set; }
    }
}
