﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Exigent.ViewModels.Common
{
    public class POTaskViewModel
    {
        public POTaskViewModel()
        { 
            // to do..
        }

        public int ID { get; set; }
        public Nullable<int> PurchaseOrderID { get; set; }
        public string Status { get; set; }
        public string Assigned_To { get; set; }
		public int? Assigned_To_ID { get; set; }
		public Nullable<System.DateTime> Created { get; set; }
        public Nullable<System.DateTime> Complete { get; set; }
        public string Comments { get; set; }

        public virtual PurchaseOrderViewModel Purchase_Orders { get; set; }
        public virtual PeoplePickerViewModel PeoplePicker { get; set; }

        /// <summary>
        /// Being used as part for only email for now.
        /// </summary>
        public string URL { get; set; }
        public string BusinessUnit { get; set; }
        public string MatterName { get; set; }
        public string Country { get; set; }
        public string Operations { get; set; }
        public string Lead_Lawyer { get; set; }
        public string Vendor_Number { get; set; }
        public Nullable<decimal> Taxable_Amount { get; set; }
        public Nullable<decimal> Non_Taxable_Amount { get; set; }
        public string Currency { get; set; }
    }
}
