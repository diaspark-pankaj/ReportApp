﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class KeyWorkStreamViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(100, ErrorMessage = "Maximum allowed characters upto 100")]
        public string Key_Work_Stream { get; set; }
    }


    public class KeyWorkStreamListViewModel
    {
        public KeyWorkStreamListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<KeyWorkStreamViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<KeyWorkStreamViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }
}
