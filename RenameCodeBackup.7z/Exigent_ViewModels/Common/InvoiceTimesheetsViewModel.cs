﻿using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exigent.Common.Constants;

namespace Exigent.ViewModels.Common
{
    public class InvoiceTimesheetsViewModel
    {
        public int ID { get; set; }
        public Nullable<int> InvoiceID { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string Lawyer { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [DisplayFormat(DataFormatString = "{0:MMM dd yyyy}", ApplyFormatInEditMode = true)]
        public Nullable<System.DateTime> Date { get; set; }

        //[Required(ErrorMessage = "Task is Required")]
        //public string Task { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string Detail { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<decimal> Hours { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<decimal> Amount { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string Discrepancy { get; set; }

        public string Invoice_Number { get; set; }
        public List<System.Web.Mvc.SelectListItem> TaskList { get; set; }
        public List<System.Web.Mvc.SelectListItem> LawyerList { get; set; }
        public virtual InvoiceTimesheetTaskViewModel InvoiceTimesheetTaskVM { get; set; }
        public virtual InvoiceViewModel InvoiceVM { get; set; }
        public string strDate { get; set; }
    }
}
