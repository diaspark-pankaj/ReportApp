﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class BusinesUnitViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Business_Unit { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(7, ErrorMessage = "A valid color code is required")]
        public string Color { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(50, ErrorMessage = "Maximum allowed characters upto 50")]
        public string Acronym { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(100, ErrorMessage = "Maximum allowed characters upto 100")]
        public string ShortName { get; set; }
    }

    public class BusinesUnitListViewModel
    {
        public BusinesUnitListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<BusinesUnitViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<BusinesUnitViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }
}
