﻿using Exigent.Common.Constants;
using Exigent.ViewModels.Admin;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Exigent.ViewModels.Common
{
    public class MainDashboardViewModel
    {
        public MainDashboardViewModel()
        {
            this.MatterList = new MatterListViewModel();
            this.InstructionList = new InstructionListViewModel();
            this.InvoiceList = new InvoiceListViewModel();
            this.SubMatterList = new SubMatterListViewModel();
            this.PurchaseOrderIncreaseRequiredList = new PurchaseOrderIncreaseRequiredListViewModel();
            this.PendingInstructionForApprovalTaskList = new PendingInstructionForApprovalTaskViewModelList();
            this.InvoiceApprovalList = new SearchInvoiceListViewModel();
            this.POTasksList = new POTasksViewModelList();
            this.GRVTasksList = new GRVTasksViewModelList();
            this.RFQList = new RFQListViewModel();
            this.POIncreaseRequiredList = new POIncreaseRequiredViewModelList();
            this.POBalanceLowList = new POBalanceLowViewModelList();
            this.BUApprovalTaskList = new InstructionListViewModel();
            this.SubMattersViewModel = new SubMattersViewModel();
            this.DraftMattersList = new DraftMattersListViewModel();
        }

        public MatterListViewModel MatterList { get; set; }

        public DraftMattersListViewModel DraftMattersList { get; set; }
        public InstructionListViewModel InstructionList { get; set; }
        public SubMatterListViewModel SubMatterList { get; set; }

        public InvoiceListViewModel InvoiceList { get; set; }
        public RFQListViewModel RFQList { get; set; }
        public PurchaseOrderIncreaseRequiredListViewModel PurchaseOrderIncreaseRequiredList { get; set; }

        public int MatterCount { get; set; }
        public SearchInvoiceListViewModel InvoiceApprovalList { get; set; }
        public PendingInstructionForApprovalTaskViewModelList PendingInstructionForApprovalTaskList { get; set; }

        public POTasksViewModelList POTasksList { get; set; }
        public GRVTasksViewModelList GRVTasksList { get; set; }

        public POIncreaseRequiredViewModelList POIncreaseRequiredList { get; set; }

        public POBalanceLowViewModelList POBalanceLowList { get; set; }

        public string BUTimeAllocationChart { get; set; }
        public InstructionListViewModel BUApprovalTaskList { get; set; }

        public int? FilterBusinessUnit { get; set; }
        public int? FilterLegalDisciplineId { get; set; }
        public int? FilterCountryId { get; set; }
        public List<OfficeViewModel> Office { get; set; }
        public int? FilterOffice { get; set; }
        public List<BusinesUnitViewModel> BuisnessUnitList { get; set; }
        public bool IsBuSystemType { get; set; }
        public SubMattersViewModel SubMattersViewModel { get; set; }
    }


    public class InstructionDashboardViewModel
    {
        public InstructionDashboardViewModel()
        {
            PendingInstructionForApprovalTaskList = new PendingInstructionForApprovalTaskViewModelList();
            Instructions = new InstructionListViewModel();
            PendingInstructions = new InstructionListViewModel();
            Task = new PendingContactRequestTaskListViewModel();
            RFQApprovalTaskList = new RFQListViewModel();
            BUApprovalTaskList = new InstructionListViewModel();
        }
        public int PageSize { get; set; }
        public InstructionListViewModel Instructions { get; set; }
        public InstructionListViewModel PendingInstructions { get; set; }
        public PendingContactRequestTaskListViewModel Task { get; set; }
        public PendingInstructionForApprovalTaskViewModelList PendingInstructionForApprovalTaskList { get; set; }
        public RFQListViewModel RFQApprovalTaskList { get; set; }
        public InstructionListViewModel BUApprovalTaskList { get; set; }
    }

    public class SubMatterListViewModel
    {
        public SubMatterListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<SubMattersViewModel> SubMattersList { get; set; }

        /// <summary>
        /// Should be used to collect the total record count of list.
        /// </summary>
        public int RecordCount { get; set; }

        public String SearchField { get; set; }
        public Dictionary<string, object> RustyData;
        public bool HideAction { get; set; }

    }

    public class InvoiceListViewModel
    {
        public InvoiceListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<InvoiceViewModel> Invoices { get; set; }

        /// <summary>
        /// Should be used to collect the total record count of list.
        /// </summary>
        public int RecordCount { get; set; }

        public String SearchField { get; set; }
        public Dictionary<string, object> RustyData;

    }

    public class RFQListViewModel
    {
        public RFQListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<RFQViewModel> RfqVm { get; set; }
        public int RecordCount { get; set; }
        public String SearchField { get; set; }
        public Dictionary<string, object> RustyData;

    }

    public class MatterListViewModel
    {
        public MatterListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<MatterViewModel> MattersList { get; set; }

        /// <summary>
        /// Should be used to collect the total record count of list.
        /// </summary>
        public int RecordCount { get; set; }

        public String SearchField { get; set; }
        public bool IsAdmin { get; set; }
        public bool IsBu { get; set; }

        //Reportable Matters - Filter options
        [Required(ErrorMessage = "Required Field")]
        public string[] FilterByBusinessUnit { get; set; }
        [Required(ErrorMessage = "Required Field")]
        public string FilterByMatterStatus { get; set; }
        public string[] FilterByReportClassification { get; set; }
        public string[] FilterByReportClassificationCategory { get; set; }

        [Required(ErrorMessage = "Required Field")]
        public string[] FilterByCountry { get; set; }

        public string[] FilterByOffice { get; set; }
        public string[] FilterByOperation { get; set; }
        public string[] FilterByLegalDiscipline { get; set; }

        public string[] FilterBySubDiscipline { get; set; }

        public string[] FilterByReportTemplate { get; set; }

        public string[] FilterByMatterReportClassification { get; set; }

        public string[] FilterByLeadLawyer { get; set; }

        public Dictionary<string, object> RustyData;
    }

    public class DraftMattersListViewModel
    {
        public DraftMattersListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<DraftMattersViewModel> DraftMattersList { get; set; }

        /// <summary>
        /// Should be used to collect the total record count of list.
        /// </summary>
        public int RecordCount { get; set; }

        public String SearchField { get; set; }
        public bool IsAdmin { get; set; }
        public bool IsBu { get; set; }
       
        public string[] FilterByBusinessUnit { get; set; }
       
        public string FilterByMatterStatus { get; set; }
        public string[] FilterByReportClassification { get; set; }
        public string[] FilterByReportClassificationCategory { get; set; }

        public Dictionary<string, object> RustyData;
    }

    public class InstructionListViewModel
    {
        public InstructionListViewModel()
        {
            InstructionList = new List<InstructionViewModel>();
            RustyData = new Dictionary<string, object>();
        }
        public List<InstructionViewModel> InstructionList { get; set; }
        public int RecordCount { get; set; }
        public Exigent.Common.Enums.BUApprovalEnum ApprovalType { get; set; }
        [Required(ErrorMessage = "Required Field")]
        public String SearchField { get; set; }
        public Dictionary<string, object> RustyData;
    }

    public class PurchaseOrderIncreaseRequiredListViewModel
    {
        public PurchaseOrderIncreaseRequiredListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<PurchaseOrderViewModel> MattersList { get; set; }
        public String SearchField { get; set; }
        public Dictionary<string, object> RustyData;
        public bool HasBalanceLow { get; set; }
        public bool HasPOIncreaseRequired { get; set; }

    }

    public class PendingContactRequestTaskListViewModel
    {
        public PendingContactRequestTaskListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<InstructionsContactViewModel> TaskList { get; set; }
        public int RecordCount { get; set; }
        public String SearchField { get; set; }
        public Dictionary<string, object> RustyData;

    }

    public class InvoicesReadyForPaymentListViewModel
    {
        public InvoicesReadyForPaymentListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<InvoicesReadyForPaymentViewModel> InvoiceList { get; set; }

        public int RecordCount { get; set; }
        public String SearchField { get; set; }
        public Dictionary<string, object> RustyData;
        public String Status { get; set; }
    }

    public class InvoicesReadyForPaymentViewModel
    {
        public int ID { get; set; }
        public string Matter_Reference { get; set; }
        public string Instruction_Reference { get; set; }
        public string Business_Unit { get; set; }
        public string Billing_Entity { get; set; }
        public string Vendor { get; set; }
        public string Invoice_Number { get; set; }
        public string Invoice_Status { get; set; }
        public decimal? PreVat_Total { get; set; }
        public decimal? PreVat_Total_InvCur { get; set; }
        public string CurrencySymbol { get; set; }
        public string Payment_Processing_Email { get; set; }
    }

    public class InvoicesSentForPaymentListViewModel
    {
        public InvoicesSentForPaymentListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<InvoicesSentForPaymentViewModel> InvoiceList { get; set; }
        public int RecordCount { get; set; }
        public Dictionary<string, object> RustyData;
        public String Status { get; set; }
        public string Vendor { get; set; }
        public string Invoice_Number { get; set; }
    }

    public class InvoicesSentForPaymentViewModel
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Required Field")]
        public DateTime DateOfPayment { get; set; }

        public string Matter_Reference { get; set; }
        public string Type { get; set; }
        public string Instruction_Reference { get; set; }
        public string Business_Unit { get; set; }
        public string Billing_Entity { get; set; }
        public string Vendor { get; set; }
        public string Invoice_Number { get; set; }
        public string Invoice_Status { get; set; }
        public DateTime? SentForPayment { get; set; }
        public decimal? PreVat_Total { get; set; }
        public decimal? PreVat_Total_InvCur { get; set; }
        public string CurrencySymbol { get; set; }
        [StringLength(1000, ErrorMessage = "Maximum allowed characters upto 1000")]
        public string Comments { get; set; }
		[Required]
		public int? AssignedTo_ID { get; set; }
		public string AssignedTo { get; set; }
		public bool OwnRecord { get; set; }
		public bool HasAccess { get; set; }
    }

    public class PendingInstructionForApprovalTaskViewModelList
    {
        public PendingInstructionForApprovalTaskViewModelList()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<InstructionApprovalTaskViewModel> PendingInstructionForApprovalList { get; set; }
        public int RecordCount { get; set; }

        public Dictionary<string, object> RustyData;
    }

    public class POTasksViewModelList
    {

        public POTasksViewModelList()
        {
            RustyData = new Dictionary<string, object>();
            POTasksList = new List<MatterPOTaskViewModel>();
        }
        public List<MatterPOTaskViewModel> POTasksList { get; set; }
        public int RecordCount { get; set; }

        public Dictionary<string, object> RustyData;
    }

    public class MatterPOTaskViewModel
    {
        public int ID { get; set; }
        public string Instruction_Reference { get; set; }
        public string Vendor { get; set; }
        public string Status { get; set; }
    }

    public class GRVTasksViewModelList
    {
        public GRVTasksViewModelList()
        {
            RustyData = new Dictionary<string, object>();
            GRVTasksList = new List<MatterGRVTaskViewModel>();
        }
        public List<MatterGRVTaskViewModel> GRVTasksList { get; set; }
        public int RecordCount { get; set; }

        public Dictionary<string, object> RustyData;
    }
    public class MatterGRVTaskViewModel
    {
        public string Vendor { get; set; }
        public string Invoice_Number { get; set; }
        public string Status { get; set; }

    }

    public class POIncreaseRequiredViewModelList
    {
        public POIncreaseRequiredViewModelList()
        {
            RustyData = new Dictionary<string, object>();
            POIncreaseRequiredList = new List<POIncreaseRequiredViewModel>();
        }
        public List<POIncreaseRequiredViewModel> POIncreaseRequiredList { get; set; }
        public int RecordCount { get; set; }

        public Dictionary<string, object> RustyData;
    }

    public class POBalanceLowViewModelList
    {
        public POBalanceLowViewModelList()
        {
            RustyData = new Dictionary<string, object>();
            POBalanceLowList = new List<POBalanceLowViewModel>();
        }
        public List<POBalanceLowViewModel> POBalanceLowList { get; set; }
        public int RecordCount { get; set; }

        public Dictionary<string, object> RustyData;
    }



    public class POIncreaseRequiredViewModel
    {
        public int ID { get; set; }
        public string Matter_Reference { get; set; }
        public string Instruction_Reference { get; set; }
        public string Vendor { get; set; }
        public string Payment_Clearance_Number { get; set; }
        public decimal Estimated_Legal_Cost { get; set; }
        public decimal Balance { get; set; }
        public string Matter_Name { get; set; }
        public string Lead_Lawyer { get; set; }
    }

    public class POBalanceLowViewModel
    {
        public int ID { get; set; }
        public string Matter_Reference { get; set; }
        public string Instruction_Reference { get; set; }
        public string Vendor { get; set; }
        public string Payment_Clearance_Number { get; set; }
        public decimal Estimated_Legal_Cost { get; set; }
        public decimal Balance { get; set; }
    }
}
