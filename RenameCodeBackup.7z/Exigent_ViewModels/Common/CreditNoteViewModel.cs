﻿using Exigent.Common.Constants;
using Exigent.MVCHelpers.CustomAttribute;
using System;
using System.ComponentModel.DataAnnotations;
using System.Web;

namespace Exigent.ViewModels.Common
{
    public class CreditNoteViewModel
    {
        public int ID { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string Credit_Note_Number { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        [DisplayFormat(DataFormatString = "{0:MMM dd yyyy}", ApplyFormatInEditMode = true)]
        public Nullable<System.DateTime> Credit_Note_Date { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string InvoiceNumber { get; set; }
        public int Invoice_ID { get; set; }
        public int? Vendor_ID { get; set; }           
        public HttpPostedFileBase File { get; set; }        
        public string ReferenceNumber { get; set; }
        public string LawFirm { get; set; }
    }
}
