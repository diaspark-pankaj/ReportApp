﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class BUTimeRecordingViewModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string Name { get; set; }
        public string Year { get; set; }
        public string Month { get; set; }

        //public Dictionary<string, decimal> BUTimeRecord { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public int ? BusinessUnitId { get; set; }
        public string Business_Unit { get; set; }
        public List<BusinesUnitViewModel> BuisnessUnitList { get; set; }
        public List<BUTimeRecordingViewModel> EntityList { get; set; }
        public BUTimeRecordingViewModel Entitymodel { get; set; }
        public List<BUTimeRecordingViewModel> ListForCurrentMonth { get; set; }
        public List<BUTimeRecordingViewModel> ListForPreviousMonth { get; set; }
        public Dictionary<string, object> RustyData;

        [Required(ErrorMessage = CommonConstants.Required)]
        public int ? LegalDisciplineId { get; set; }
        public string Legal_Discipline { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(@"^[+-]?((\d+(\.\d*)?)|(\.\d+))$", ErrorMessage = "Only Numbers allowed")]
        public Nullable<decimal> BUTimeValue { get; set; }

        public string BusinessUnitColor { get; set; }
        
        public System.DateTime Created { get; set; }
        public int Created_By { get; set; }
        public System.DateTime Modified { get; set; }
        public int Modified_By { get; set; }
        public int UserId { get; set; }
   
   
        [Required(ErrorMessage = CommonConstants.Required)]
        public System.DateTime Date { get; set; }

        public string strDate { get; set; }
    }

    public class BUTimeAllocationChartViewModel
    {

        public Nullable<decimal> value { get; set; }

        public string Business_Unit { get; set; }

        public string color { get; set; }

    }
}
