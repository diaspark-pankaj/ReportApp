﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class DraftMattersViewModel
    {
        public int ID { get; set; }
        public string OfficeName { get; set; }
        public bool IsHighlyConfidential { get; set; }
        public string Matter_Name { get; set; }
        public int Business_Unit_ID { get; set; }
        public string Business_Unit { get; set; }
        public int? OperationId { get; set; }
        public string Operation { get; set; }
        public string Report_Classification_Category { get; set; }
        public string SubDiscipline { get; set; }
        public string LegalDiscipline { get; set; }
        public int Report_Classification_ID { get; set; }
        public string Report_Classification { get; set; }
        public int Country_ID { get; set; }
        public string Country { get; set; }
        public int Matter_Status_ID { get; set; }
        public string Matter_Status { get; set; }       
        public int Lead_Lawyer_ID { get; set; }
        public string Lead_Lawyer { get; set; }
        public string Assisting_Team_Members { get; set; }
        public string Assisting_Team_Members_IDs { get; set; }
        public int Lead_Client_ID { get; set; }
        public string Lead_Client { get; set; }
        public string Changed_Since_Last { get; set; }
        public string Context { get; set; }
        public string Matter_Description { get; set; }
        public string Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks { get; set; }
        public string Recommended_Mitigation_Steps { get; set; }
        public string Impact_On_Group_BU { get; set; }
        public string Current_Next_Step_or_Procedural_Stage { get; set; }
        public string Client_Action { get; set; }
        public string Matter_Reference { get; set; }
        public Nullable<System.DateTime> Created { get; set; }
        public Nullable<System.DateTime> Modified { get; set; }
        public string Created_By { get; set; }
        public string Modified_By { get; set; }
        public string System { get; set; }
        public int SystemType_ID { get; set; }
        public int? Last_Lawyer_Update_ID { get; set; }
        public string Last_Lawyer_Update_Name { get; set; }
        public Nullable<System.DateTime> Last_Lawyer_Update_Date { get; set; }
        public string Reportable { get; set; }
        public string ReportableStatus { get; set; }
        public DateTime? DateSentForUpdate { get; set; }
        public DateTime? DateReturned { get; set; }
        public string HODComments { get; set; }
        public string FullName { get; set; }
        public string UserName { get; set; }
        public string EmailTo { get; set; }
        public string EmailCC { get; set; }
        public string EmailURL { get; set; }
        public string Key_Work_Stream { get; set; }
        public List<int> KeyWorkStreamIDs { get; set; }
        public int Legal_Practise_Area_ID { get; set; }
        public string Legal_Practise_Area { get; set; }
        public string KeyWorkStream { get; set; }      
        public decimal? MatterCost { get; set; }
        public int? ReportableCount { get; set; }       
        public int MatterType_ID { get; set; }      
        public string MatterType { get; set; }    
        public bool isFromTimeRecord { get; set; }
        public bool IsBusinessUnit { get; set; }
        public string Url { get; set; }
        public int LegalDisciplineId { get; set; }    
        public int SubLegalDisciplineId { get; set; }
        public string ReportClassificationOptionId { get; set; }
        public int ApplicationReportTemplateId { get; set; }
        public int MatterReportClassificationOptionId { get; set; }
        public string MatterReportClassicationOptionList { get; set; }
        public List<ReportClassificationOptionVM> ReportClassificationOptionList { get; set; }
        public bool isFinalized { get; set; }

    }
}
