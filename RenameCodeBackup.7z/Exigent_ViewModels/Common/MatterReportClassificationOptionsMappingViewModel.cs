﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class MatterReportClassificationOptionsMappingViewModel
    {
        public int Id { get; set; }
        public Nullable<int> MatterId { get; set; }
        public Nullable<int> OptionId { get; set; }
    }
}
