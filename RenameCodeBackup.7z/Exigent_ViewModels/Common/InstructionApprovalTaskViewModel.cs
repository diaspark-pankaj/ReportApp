﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class InstructionApprovalTaskViewModel
    {
        public int ID { get; set; }

        public InstructionBlockViewModel Instruction { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string Instruction_Reference { get; set; }
        public string Status { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
		public int Assigned_To_ID { get; set; }

        public string Assigned_To { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(1000, ErrorMessage = "Maximum allowed characters upto 1000")]
        public string Comments { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(1000, ErrorMessage = "Maximum allowed characters upto 1000")]
        public string Rejection_Reason { get; set; }

        public DateTime Complete { get; set; }
        public DateTime Created { get; set; }

        public string Matter_Reference { get; set; }
        public int Instruction_ID { get; set; }
        public string Matter_Name { get; set; }
        public string Vendor { get; set; }

        #region Added for email purpose only

        /// <summary>
        /// Being used as part for only email for now.
        /// </summary>
        public string UserName { get; set; }
        public string Lead_Lawyer { get; set; }

        #endregion
    }
}
