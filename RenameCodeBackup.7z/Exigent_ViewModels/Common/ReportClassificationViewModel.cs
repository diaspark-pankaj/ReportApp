﻿using Exigent.Common.Constants;
using Exigent.Common.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Exigent.ViewModels.Common
{
    public class ReportClassificationViewModel
    {
        public ReportClassificationViewModel()
        {
            //SystemTypeList = new List<string>();
            //SystemTypeList.Add(SystemTypeEnum.GroupLegal.ToString());
            //SystemTypeList.Add(SystemTypeEnum.BusinessUnit.ToString());

            RCCategoryList = new List<string>();
        }

        public int ID { get; set; }

        [StringLength(20, ErrorMessage = "Maximum allowed characters upto 20")]
        public string Code { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(450, ErrorMessage = "Maximum allowed characters upto 450")]
        public string Report_Classification_Category { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(450, ErrorMessage = "Maximum allowed characters upto 450")]
        public string Report_Classification { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
      //  [StringLength(50, ErrorMessage = "Maximum allowed characters upto 50")]
        public int ? SystemType_ID { get; set; }

        public bool IsActive { get; set; }
        public int? Risk_Rating { get; set; }

        public List<SelectListItem> SystemTypeList { get; set; }

        public SystemTypeViewModel SystemType { get; set; }
        public List<string> RCCategoryList { get; set; }
    }

    public class ReportClassificationListViewModel
    {
        public ReportClassificationListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<ReportClassificationViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<ReportClassificationViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }
}
