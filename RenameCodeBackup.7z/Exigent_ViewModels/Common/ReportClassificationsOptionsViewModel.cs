﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.Common
{
   public class ReportClassificationsOptionsViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string Name { get; set; }
        public Nullable<bool> IsActive { get; set; }
        public Nullable<bool> IsReportable { get; set; }
    }

    public class ReportClassificationOptionsListViemModel
    {
        public ReportClassificationOptionsListViemModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<ReportClassificationsOptionsViewModel>();
        }
        public Dictionary<string, object> RustyData;
        public List<ReportClassificationsOptionsViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }
}
