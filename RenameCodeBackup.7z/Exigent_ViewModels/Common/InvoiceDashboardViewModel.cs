﻿using System;
using System.Collections.Generic;

namespace Exigent.ViewModels.Common
{
    public class InvoiceDashboardViewModel
    {
        public OutstandingInvoicesListViewModel OutstandingInvoiceList { get; set; }
        public SearchInvoiceListViewModel SearchInvoiceList { get; set; }
        public SearchInvoiceListViewModel InvoiceAuditList { get; set; }
        public SearchInvoiceListViewModel InvoiceApprovalList { get; set; }
        public SearchInvoiceListViewModel POTaskList { get; set; }
        public GrvTasksListViewModel GrvTasksList { get; set; }
        public GrvTasksListViewModel GrvTasksListAccount { get; set; }
        public bool isAdmin { get; set; }
        public string InvoiceStatus { get; set; }
    }
    public class GrvTasksViewModel
    {
        public string Instruction_Status { get; set; }
        public string Status { get; set; }
        public string Vendor { get; set; }
        public string Invoice_Number { get; set; }
        public string Billing_Entity { get; set; }
        public string Business_Unit { get; set; }
        public string Assigned_To { get; set; }
		public int Assigned_To_ID { get; set; }
        public string Comments { get; set; }
        public int Days { get; set; }
        public bool IsSend { get; set; }
        public int GrvId { get; set; }
    }

    /// <summary>
    /// Used in AutoMailer for Reminder emails.
    /// </summary>
    public class GrvTasksReminderViewModel
    {
        public string Vendor { get; set; }
        public string Invoice_Number { get; set; }
        public string Assigned_To { get; set; }
        public string Comments { get; set; }
        public int Days { get; set; }
        public string ReminderMessage { get; set; }
        public DateTime Created { get; set; }
        public string LeadLawyer { get; set; }
        public string MatterReference { get; set; }
        public string UrlDocs { get; set; }
        public string Url { get; set; }
    }
    
    public class GrvTasksListViewModel
    {
        public GrvTasksListViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<GrvTasksViewModel> GrvTasksList { get; set; }
        public int RecordCount { get; set; }
        public Dictionary<string, object> RustyData;
        public string SearchField { get; set; }
        public bool isAdmin { get; set; }
    }
}
