﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Exigent.ViewModels.Common
{
    public class InstructionViewModel
    {
        public InstructionViewModel()
        {
            MatterDetail = new MatterBlock();
        }
        public bool EditMatter { get; set; }
        public bool EditMode { get; set; }

        public MatterBlock MatterDetail { get; set; }

        public int ID { get; set; }

        public string Instruction_Reference { get; set; }

        public string Matter_Reference { get; set; }

        public int? Matter_ID { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(1000, ErrorMessage = "Maximum allowed characters upto 1000")]
        public string Instruction { get; set; }

        public string Status { get; set; }                              //Drop Down Selection
        public string Sent_Status { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid email address")]
        [StringLength(100, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public int? Vendor_ID { get; set; }                              //AutoComplete selection

        public string Vendor { get; set; }

        public string Billing_Entity { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public int? Billing_Entity_ID { get; set; }                      //AutoComplete selection

        [Required(ErrorMessage = CommonConstants.Required)]
        [Range(-9999999999999999.99, 9999999999999999.99, ErrorMessage = "Enter a valid numeric value.")]
        public decimal? Estimated_Legal_Cost_Vatable { get; set; }       //Numeric: Estimated Cost (Vatable)

        [Required(ErrorMessage = CommonConstants.Required)]
        [Range(-9999999999999999.99, 9999999999999999.99, ErrorMessage = "Enter a valid numeric value.")]
        public decimal? Estimated_Legal_Cost_Non_Vatable { get; set; }   //Numeric: Estimated Cost (Non-Vatable)

        [Required(ErrorMessage = CommonConstants.Required)]
        [Range(-9999999999999999.99, 9999999999999999.99, ErrorMessage = "Enter a valid numeric value.")]
        public decimal? Estimated_Legal_Cost_Vatable_Local { get; set; }       //Numeric: Estimated Cost (Vatable)

        [Required(ErrorMessage = CommonConstants.Required)]
        [Range(-9999999999999999.99, 9999999999999999.99, ErrorMessage = "Enter a valid numeric value.")]
        public decimal? Estimated_Legal_Cost_Non_Vatable_Local { get; set; }   //Numeric: Estimated Cost (Non-Vatable)

        public decimal? Legal_Cost_Vatable_Balance { get; set; }         //Numeric: Legal Cost Balance (Vatable)
        public decimal? Legal_Cost_Non_Vatable_Balance { get; set; }     //Numeric: Legal Cost Balance (Non-Vatable)

        public decimal? Outstanding_Invoices_Vatable_Amount { get; set; }         //Numeric: Calculated: Outstanding Invoices Amount (Vatable)
        public decimal? Outstanding_Invoices_Non_Vatable_Amount { get; set; }     //Numeric: Calculated: Outstanding Invoices Amount (Non-Vatable)

        public decimal? Future_Vatable_Line_Balance { get; set; }         //Numeric: Calculated: Future Line Balance (Vatable)
        public decimal? Future_Non_Vatable_Line_Balance { get; set; }     //Numeric: Calculated: Future Line Balance (Non-Vatable)

        [Required(ErrorMessage = CommonConstants.Required)]
        public string Cost_Centre { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public int? Currency_ID { get; set; }
        public string FrameworkOrder { get; set; }

        public string Confirmed { get; set; }                           //Yes / No

        public string PO_Contact { get; set; }
        public int? PO_Contact_ID { get; set; }
        public string Payment_Clearance_Number { get; set; }
        public string GRV_Contact { get; set; }
        public int? GRV_Contact_ID { get; set; }

        public string GRV { get; set; }

        public string Created_By { get; set; }
        public string Modified_By { get; set; }

        public DateTime Created { get; set; }
        public DateTime Modified { get; set; }

        //public List<SelectListItem> Billing_Entities { get; set; }
        //public List<SelectListItem> Vendors { get; set; }

        public decimal EstimatedLegalCost { get; set; }
        public decimal Balance { get; set; }
        public string Vat_Number { get; set; }
        public string Matter_Name { get; set; }
        public string System { get; set; }
        public int? SystemType_ID { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string GLAccount { get; set; }        
        public string GroupWideSplit { get; set; }

        public HttpPostedFileBase File { get; set; }
        public string FileName { get; set; }
        public string OldFileName { get; set; }
        public bool IsInvoiceExists { get; set; }

        #region Added for email purpose only

        /// <summary>
        /// Being used as part for only email for now.
        /// </summary>
        public string URL { get; set; }

        /// <summary>
        /// Being used as part for only email for now.
        /// </summary>
        public decimal Cost { get; set; }

        /// <summary>
        /// Being used as part for only email for now.
        /// </summary>
        public string Assigned_To { get; set; }

        public InvoiceListViewModel InvoiceListModel { get; set; }

        /// <summary>
        /// Showing rejection reason in pending group legal instruction list.
        /// </summary>
        public string Comments { get; set; }
        public int Days { get; set; }
        public string ReminderMessage { get; set; }

        #endregion
    }
}
