﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class IncreasePOViewModel
    {
        public IncreasePOViewModel()
        {
            // constructor code goes here...
        }
        public string Instruction_Reference { get; set; }
        public int Instruction_ID { get; set; }
        public string Matter_Reference { get; set; }
        public string Matter_Status { get; set; }
        public string Matter_Title { get; set; }
        public string Lead_Lawyer { get; set; }
        public string Vendor { get; set; }
        public int? Vendor_ID { get; set; }
        public string PO_Number { get; set; }
        public decimal? Estimated_Legal_Cost_Vatable { get; set; }
        public decimal? Estimated_Legal_Cost_Non_Vatable { get; set; }
        public decimal? Vatable_Balance { get; set; }
        public decimal? Non_Vatable_Balance { get; set; }
        public decimal? Outstanding_Invoices_Vatable_Amount { get; set; }
        public decimal? Outstanding_Invoices_Non_Vatable_Amount { get; set; }

        [Required(ErrorMessage = "* Required Field")]
        [RegularExpression(@"^[+-]?((\d+(\.\d*)?)|(\.\d+))$", ErrorMessage = "Only Numbers allowed")]
        [Display(Name = "Vatable Amount")]
        public decimal? Vatable_Amount { get; set; }
        [Required(ErrorMessage = "* Required Field")]
        [RegularExpression(@"^[+-]?((\d+(\.\d*)?)|(\.\d+))$", ErrorMessage = "Only Numbers allowed")]
        [Display(Name = "Non Vatable Amount")]
        public decimal? Non_Vatable_Amount { get; set; }

        [Required(ErrorMessage = "* Required Field")]
        [RegularExpression(@"^[+-]?((\d+(\.\d*)?)|(\.\d+))$", ErrorMessage = "Only Numbers allowed")]
        [Display(Name = "Vatable Amount")]
        public decimal? Vatable_Amount_Local { get; set; }
        [Required(ErrorMessage = "* Required Field")]
        [RegularExpression(@"^[+-]?((\d+(\.\d*)?)|(\.\d+))$", ErrorMessage = "Only Numbers allowed")]
        [Display(Name = "Non Vatable Amount")]
        public decimal? Non_Vatable_Amount_Local { get; set; }
        public bool HasFinalInvoice { get; set; }

        public int? POTaskID { get; set; }
        public string Comments { get; set; }
        public decimal? Purchase_Total { get; set; }
        public string URL { get; set; }
        public DateTime? Current_Date { get; set; }

        public string EmailTo { get; set; }
        public string EmailCC { get; set; }

        public string CurrencyCode { get; set; }
        public int? CurrencyId { get; set; }
    }
}
