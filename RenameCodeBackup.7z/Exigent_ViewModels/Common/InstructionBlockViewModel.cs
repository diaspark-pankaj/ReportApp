﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
	public class InstructionBlockViewModel
	{
		public int ID { get; set; }

		public string Instruction_Reference { get; set; }

		public string Matter_Reference { get; set; }
		public MatterBlock Matter { get; set; }
		public int Matter_ID { get; set; }
		public string Billing_Entity { get; set; }
		public int Billing_Entity_ID { get; set; }
		public string Instruction { get; set; }
		public int Vendor_ID { get; set; }
		public string Vendor { get; set; }
		public string Cost_Centre { get; set; }
		public string Payment_Clearance_Number { get; set; }
		public int Business_Unit_ID { get; set; }
		public string Business_Unit { get; set; }
        public decimal Estimated_Legal_Cost { get; set; }
    }
}
