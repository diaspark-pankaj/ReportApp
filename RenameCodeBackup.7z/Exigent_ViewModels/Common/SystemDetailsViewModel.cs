﻿
using System;
namespace Exigent.ViewModels.Common
{
    public class SystemDetailsViewModel
    {        
        public static int ID { get; set; }
        public static string URL { get; set; }
        public static string Path { get; set; }
        public static string Team { get; set; }
        public static string TeamLead { get; set; }
        public static string GRVOwner { get; set; }
        public static string InvoiceApprovalOwner { get; set; }
        public static string TimesheetCaptureOwner { get; set; }
        public static string First_Escalation { get; set; }
        public static string Second_Escalation { get; set; }
        public static string AttorneyRateChangeEmail { get; set; }
        public static Nullable<int> InvoiceApprovalOwnerID { get; set; }
        public static Nullable<int> TimesheetCaptureOwnerID { get; set; }
        public static Nullable<int> GRVOwnerID { get; set; }
        public static string SubMatterPath { get; set; }
    }
}
