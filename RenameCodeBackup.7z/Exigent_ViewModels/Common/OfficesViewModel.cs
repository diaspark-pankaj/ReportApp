﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.Common
{
    public class OfficesViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public Nullable<int> CountryId { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string OfficeName { get; set; }
        public bool IsActive { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string Country { get; set; }

    }
    public class OfficesListViewModel
    {
        public OfficesListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<OfficesViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<OfficesViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }

    public class CountriesViewModel
    {
        public int Id { get; set; }
        public string Country { get; set; }

       
    }
}
