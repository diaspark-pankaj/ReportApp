﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class CurrencyViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(3, ErrorMessage = "Maximum allowed characters upto 3")]
        public string CurrencyCode { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(30, ErrorMessage = "Maximum allowed characters upto 30")]
        public string Currency { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(3, ErrorMessage = "Maximum allowed characters upto 3")]
        public string Symbol { get; set; }
    }

    public class CurrencyListViewModel
    {
        public CurrencyListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<CurrencyViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<CurrencyViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }

    public class CountryViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(4, ErrorMessage = "Maximum allowed characters upto 4")]
        public string CntryCode { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(50, ErrorMessage = "Maximum allowed characters upto 50")]
        public string Country { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(4, ErrorMessage = "Maximum allowed characters upto 4")]
        public string ISO_CntryCode { get; set; }

        public bool IsActive { get; set; }
    }

    public class CountryListViewModel
    {
        public CountryListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<CountryViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<CountryViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }
}
