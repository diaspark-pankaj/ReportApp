﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Exigent.ViewModels.Common
{
    public class ClientCompanyViewModel
    {
        public ClientCompanyViewModel()
        {
            YesNoList = new List<string>();
            YesNoList.Add(CommonConstants.Yes.ToString());
            YesNoList.Add(CommonConstants.No.ToString());
        }

        public int Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Company_Name { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
		public int BusinessUnit_ID { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        //[StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Business_Unit { get; set; }

        public string Registration_Number { get; set; }

        public string Vat_Number { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(3, ErrorMessage = "Maximum allowed characters upto 3")]
        public string GRV { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(3, ErrorMessage = "Maximum allowed characters upto 3")]
        public string PO { get; set; }

		public int ? Payment_Processing_ID { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Payment_Processing { get; set; }

        public List<string> YesNoList { get; set; }

		public BusinesUnitViewModel BusinessUnit { get; set; }
    }

    public class ClientCompanyListViewModel
    {
        public ClientCompanyListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<ClientCompanyViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<ClientCompanyViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }
}
