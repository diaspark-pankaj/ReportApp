﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class InvoiceTimesheetCaptureTasksViewModel
    {
        public InvoiceTimesheetCaptureTasksViewModel()
        {
            RustyData = new Dictionary<string, object>();
        }
        public List<InvoiceTimesheetCaptureTasksListViewModel> TimesheetsList { get; set; }
        public String SearchField { get; set; }
        public Dictionary<string, object> RustyData;
        public int RecordCount { get; set; }
        //public virtual Invoice Invoice { get; set; }
        //public virtual PeoplePicker PeoplePicker { get; set; }
    }

    public class InvoiceTimesheetCaptureTasksListViewModel
    {
        public int ID { get; set; }
        public Nullable<int> InvoiceID { get; set; }
        public string Status { get; set; }
        public string Assigned_To { get; set; }
        public Nullable<System.DateTime> Created { get; set; }
        public Nullable<System.DateTime> Complete { get; set; }
        public string Comments { get; set; }
        public string Rejection_Reason { get; set; }
        public string Invoice_Number { get; set; }

        public InvoiceViewModel InvoiceVM { get; set; }

    }
}
