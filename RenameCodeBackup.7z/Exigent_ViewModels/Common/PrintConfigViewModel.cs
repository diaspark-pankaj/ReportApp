﻿using System.Collections.Generic;

namespace Exigent_ViewModels.Common
{

    public class PrintConfigViewModel
    {

        #region Primitive Properties

        public string PageTitle { get; set; }
        public string conceptId { get; set; }
        public int? unitId { get; set; }
        public int? pId { get; set; }
        public string PreSetName { get; set; }
        public List<PrintHeadings> LeftHeadingList;
        public List<PrintHeadings> RightHeadingList;

        public PrintConfigViewModel()
        {
            LeftHeadingList = new List<PrintHeadings>();
            RightHeadingList = new List<PrintHeadings>();
        }

        #endregion

    }

    public class PrintHeadings
    {

        #region Primitive Properties

        public string ID { get; set; }

        public string Name { get; set; }
        public string ParentName { get; set; }

        public bool IsGroupHeading { get; set; }
        /*
        private bool selected = false;
        public bool Selected
        {
            get
            {
                return selected;
            }
            set
            {
                selected = value;
            }
        }
        */
        public string Text { get; set; }
        public bool Checked { get; set; }

        #endregion

    }


    public class SelectedPrintHeadings
    {
        public SelectedPrintHeadings()
        {
        }

        public SelectedPrintHeadings(string name)
        {
            Name = name;
        }
        public string Name { get; set; }

    }
}
