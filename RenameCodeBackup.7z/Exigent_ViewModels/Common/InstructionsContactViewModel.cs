﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    /// <summary>
    /// Contact Request Task - Model Used by the list page.
    /// </summary>
    public class InstructionsContactViewModel
    {
        public int ID { get; set; }

        public string Instruction_Reference { get; set; }

        public MatterBlock Matter { get; set; }

        public string Status { get; set; }
        public string Assigned_To { get; set; }
        public int? Assigned_To_ID { get; set; }
        public DateTime Created { get; set; }

        public int Days { get; set; }
    }

    /// <summary>
    /// Contact Request Task - Model Used on task detail page.
    /// </summary>
    public class ContactRequestTaskViewModel
    {
        public int ID { get; set; }

		//*******************************************//
		//  Properties Required for Re-Assign Task   //
		//*******************************************//
		[Required(ErrorMessage = CommonConstants.Required)]
		public int Assigned_To_ID { get; set; }
		[Required(ErrorMessage = CommonConstants.Required)]
		public string Assigned_To { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string Comments { get; set; }

        //*******************************************//
        //    View Only Properties for Task Base     //
        //*******************************************//
        public string Status { get; set; }
        public string Instruction_Reference { get; set; }
        public int Instruction_ID { get; set; }
        public string Matter_Reference { get; set; }
        public string Matter_Name { get; set; }
        public string Matter_Status { get; set; }
        public string Matter_LeadLawyer { get; set; }
        public string Operation { get; set; }
        public int Vendor_ID { get; set; }
        public string Vendor { get; set; }
        public string Cost_Centre { get; set; }
        public string Billing_Entity { get; set; }

        //*******************************************//
        //   Properties Required for Complete Task   //
        //*******************************************//
        [Required(ErrorMessage = CommonConstants.Required)]
        public int? PO_Contact_ID { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string PO_Contact { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public int? GRV_Contact_ID { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string GRV_Contact { get; set; }
    }
}
