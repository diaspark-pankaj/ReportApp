﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Exigent.ViewModels.Common
{
    public class OperationViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Operation { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
		//[StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
		public int Business_Unit_ID { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string Business_Unit { get; set; }
    }

    public class OperationListViewModel
    {
        public OperationListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<OperationViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<OperationViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }
}
