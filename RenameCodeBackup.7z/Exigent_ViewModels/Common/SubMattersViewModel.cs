﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Exigent.ViewModels.Common
{
    public class SubMattersViewModel
    {
        public int Id { get; set; }
        public Nullable<int> MatterId { get; set; }
        public string ReferenceNumber { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string Name { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [DisplayFormat(DataFormatString = "{0:MMM dd yyyy}", ApplyFormatInEditMode = true)]
        public Nullable<System.DateTime> date { get; set; }

        public string hdnDate { get; set; }
        public HttpPostedFileBase File { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public Nullable<System.DateTime> FileUploadDate { get; set; }
        public Nullable<int> UploadBy { get; set; }
        public Nullable<bool> IsActive { get; set; }
    }
}
