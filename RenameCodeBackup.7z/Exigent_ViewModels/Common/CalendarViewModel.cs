﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.Common
{
  public  class CalendarViewModel
    {
      public CalendarViewModel()
      {
          TaskEvents = new List<CalendarEventViewModel>();
          HolidayList = new List<string>();
      }
      public int ProjectId { get; set; }
      public int UserId { get; set; }
      public List<string> HolidayList { get; set; }
      public List<CalendarEventViewModel> TaskEvents { get; set; }
    }
}
