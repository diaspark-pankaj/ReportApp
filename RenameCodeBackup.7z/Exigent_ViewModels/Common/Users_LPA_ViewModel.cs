﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exigent_ViewModels.Admin;
namespace Exigent.ViewModels.Common
{
	public class Users_LPA_ViewModel
	{
		public int ID { get; set; }
		public int User_ID { get; set; }
		public int LPA_ID { get; set; }

		public AddUserViewModel User { get; set; }
		public DesciplineLeadViewModel Discipline_Lead { get; set; }
	}
}
