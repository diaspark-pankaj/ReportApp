﻿using Exigent.Common.Constants;
using Exigent.Common.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Exigent.ViewModels.Common
{
    public class DesciplineLeadViewModel
    {
        public DesciplineLeadViewModel()
        {
            //SystemTypeList = new List<string>();
            //SystemTypeList.Add(SystemTypeEnum.GroupLegal.ToString());
            //SystemTypeList.Add(SystemTypeEnum.BusinessUnit.ToString());
        }

        public int ID { get; set; }

        public int? DisciplineLead_ID { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Discipline_Lead_FullName { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(255, ErrorMessage = "Maximum allowed characters upto 255")]
        public string Legal_Practice_Area { get; set; }

       [Required(ErrorMessage = CommonConstants.Required)]
        public int SystemType_ID { get; set; }

        public SystemTypeViewModel SystemType { get; set; }

        public List<SelectListItem> SystemTypeList { get; set; }
    }

    public class DesciplineLeadListViewModel
    {
        public DesciplineLeadListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<DesciplineLeadViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<DesciplineLeadViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }
}
