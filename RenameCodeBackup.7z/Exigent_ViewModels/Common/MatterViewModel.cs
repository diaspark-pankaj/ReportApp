﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Exigent.ViewModels.Common
{
    public class MatterViewModel
    {
        public int ID { get; set; }
        public string OfficeName { get; set; }
        public bool IsHighlyConfidential { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public string Matter_Name { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
		public int Business_Unit_ID { get; set; }

        public string Business_Unit { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
		public int? OperationId { get; set; }
		//[Required(ErrorMessage = CommonConstants.Required)]
        public string Operation { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string Report_Classification_Category { get; set; }

		public string SubDiscipline { get; set; }

		public string LegalDiscipline { get; set; }

		//[Required(ErrorMessage = CommonConstants.Required)]
		public int Report_Classification_ID { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
        public string Report_Classification { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
		public int Country_ID { get; set; }
        //[Required(ErrorMessage = CommonConstants.Required)]
        public string Country { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
		public int Matter_Status_ID { get; set; }

		public string Matter_Status { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
		public int Lead_Lawyer_ID { get; set; }
		//[Required(ErrorMessage = CommonConstants.Required)]
        public string Lead_Lawyer { get; set; }
        public string Assisting_Team_Members { get; set; }
		public string Assisting_Team_Members_IDs { get; set; }
		[Required(ErrorMessage = CommonConstants.Required)]
		public int Lead_Client_ID { get; set; }
		[Required(ErrorMessage = CommonConstants.Required)]
        public string Lead_Client { get; set; }
        //[Required(ErrorMessage = CommonConstants.Required)]
        public string Changed_Since_Last { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(CommonConstants.MatterRegularExp, ErrorMessage = CommonConstants.MatterInvalidCharacters)]
        public string Context { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(CommonConstants.MatterRegularExp, ErrorMessage = CommonConstants.MatterInvalidCharacters)]
        public string Matter_Description { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(CommonConstants.MatterRegularExp, ErrorMessage = CommonConstants.MatterInvalidCharacters)]
        public string Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks { get; set; }
        [RegularExpression(CommonConstants.MatterRegularExp, ErrorMessage = CommonConstants.MatterInvalidCharacters)]
        public string Recommended_Mitigation_Steps { get; set; }
        [RegularExpression(CommonConstants.MatterRegularExp, ErrorMessage = CommonConstants.MatterInvalidCharacters)]
        public string Impact_On_Group_BU { get; set; }
        [RegularExpression(CommonConstants.MatterRegularExp, ErrorMessage = CommonConstants.MatterInvalidCharacters)]
        public string Current_Next_Step_or_Procedural_Stage { get; set; }
        [RegularExpression(CommonConstants.MatterRegularExp, ErrorMessage = CommonConstants.MatterInvalidCharacters)]
        [Required(ErrorMessage = CommonConstants.Required)]
        public string Client_Action { get; set; }
        public string Matter_Reference { get; set; }
        public Nullable<System.DateTime> Created { get; set; }
        public Nullable<System.DateTime> Modified { get; set; }
        public string Created_By { get; set; }
        public string Modified_By { get; set; }
        public string System { get; set; }
		public int SystemType_ID { get; set; }
		public int? Last_Lawyer_Update_ID { get; set; }
		public string Last_Lawyer_Update_Name { get; set; }
        public Nullable<System.DateTime> Last_Lawyer_Update_Date { get; set; }

        public string Reportable { get; set; }
        public string ReportableStatus { get; set; }
        public DateTime? DateSentForUpdate { get; set; }
        public DateTime? DateReturned { get; set; }

        //[Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(1000, ErrorMessage = "Maximum allowed characters upto 1000")]
        public string HODComments { get; set; }

        public string FullName { get; set; }
        public string UserName { get; set; }
        public string EmailTo { get; set; }
        public string EmailCC { get; set; }
        public string EmailURL { get; set; }

        //[Required(ErrorMessage = CommonConstants.Required)]
        public string Key_Work_Stream { get; set; }
		public List<int> KeyWorkStreamIDs { get; set; }
		[Required(ErrorMessage = CommonConstants.Required)]
        public int Legal_Practise_Area_ID { get; set; }
        public string Legal_Practise_Area { get; set; }
        public string KeyWorkStream { get; set; }
        // added by vyom dixit, required in Matter listing to display Pre_Vat Total value per matter.
        public decimal? MatterCost { get; set; }
        public int? ReportableCount { get; set; }
		[Required(ErrorMessage = CommonConstants.Required)]
		public int MatterType_ID { get; set; }
		//[Required(ErrorMessage = CommonConstants.Required)]
        public string MatterType { get; set; }
        public PeoplePickerViewModel PeoplePickerVM { get; set; }
        public bool isFromTimeRecord { get; set; }
        public bool IsBusinessUnit { get; set; }
        public string Url { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public int LegalDisciplineId { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public int SubLegalDisciplineId { get; set; }
        public string ReportClassificationOptionId { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public int ApplicationReportTemplateId { get; set; }
        public int MatterReportClassificationOptionId { get; set; }
        public string MatterReportClassicationOptionList { get; set; }

        public DateTime? DateSendForReporting { get; set; }

        public List<ReportClassificationOptionVM> ReportClassificationOptionList { get; set; }


    }

    public class EmailViewModel
    {
        public string LeadLawyer { get; set; }
        public string LeadClient { get; set; }
        public string Team { get; set; }
        public string Vendor { get; set; }
        public string User { get; set; }
        public string DisciplineLead { get; set; }
    }

    public class ReportClassificationOptionVM
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public bool IsChecked { get; set; }
        public bool IsReportable { get; set; }
    }
}
