﻿using Exigent_ViewModels.Admin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class AccessDashboardViewModel
    {
        public AccessDashboardViewModel()
        {
            AcessDashboardPages = new List<AccessDashboardPageViewModel>();
        }
    
        public int ID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public Nullable<int> SortOrder { get; set; }
        public Nullable<bool> IsActive { get; set; }

        public List<AccessDashboardPageViewModel> AcessDashboardPages { get; set; }

        public List<UserAccessViewModel> UserAccess { get; set; }

        public string DashboardURL { get; set; }
    }
}
