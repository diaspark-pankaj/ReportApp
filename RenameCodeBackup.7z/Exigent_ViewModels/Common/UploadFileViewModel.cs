﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.Common
{
   public class UploadFileViewModel
    {
       public string UploadDocumentDirPath { get; set; }
    }
}
