﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class TimeRecordingViewModel
    {
        public int ID { get; set; }

        //public int Vendor_Lawyer_ID { get; set; }

		public int Lead_Lawyer_ID { get; set; }

		[Required(ErrorMessage = CommonConstants.Required)]
        public string Name { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [DisplayFormat(DataFormatString = "{0:MMM dd yyyy}", ApplyFormatInEditMode = true)]
        public System.DateTime Date { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        public decimal? Hours { get; set; }
		public int Matter_ID { get; set; }
        public string Matter_Reference { get; set; }
        public System.DateTime Created { get; set; }
        public string Created_By { get; set; }
        public string strDate { get; set; }
        public bool CanUpdateMatter { get; set; }
        public MatterViewModel MatterVM { get; set; }
        public List<ReportClassificationOptionVM> ReportClassificationOptionList { get; set; }
        //public virtual PeoplePicker PeoplePicker { get; set; }
    }
}
