﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
	public class SystemTypeViewModel
	{
		public int ID { get; set; }
		public string SystemTypeName { get; set; }
	}
}
