﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.Common
{
  public  class ListViewModel
    {
      public long LongId { get; set; }
      public int Id { get; set; }
      public string Name { get; set; }
      public string Cid { get; set; }
      public string ShortName { get; set; }
      public string EntityType { get; set; }
      public string Geo { get; set; }
    }
}
