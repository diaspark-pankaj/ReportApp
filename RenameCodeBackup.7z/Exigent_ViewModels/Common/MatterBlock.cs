﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.ViewModels.Common
{
    public class MatterBlock
    {
        public int Id { get; set; }
        public string MatterReferenceNumber { get; set; }
        public string MatterName { get; set; }       
        public string Matter_Status { get; set; }

        /// <summary>
        /// Name of Business Unit
        /// Ref: [Inform].[Business Units]
        /// </summary>
        public string BusinessUnitName { get; set; }
        public int BusinessUnitNameId { get; set; }
        /// <summary>
        /// Matter Type for System=BusinessUnit
        /// Report Classification Category for System=GroupLegal
        /// Ref: [Inform].[Report Classification]
        /// </summary>
        public string MatterType { get; set; }
        public string LegalDiscipline { get; set; }
        public int LegalDisciplineId { get; set; }
        public string LegalPraticeArea { get; set; }        
        #region Added for email purpose only

        /// <summary>
        /// Being used as part for only email for now.
        /// </summary>
        public string Lead_Lawyer { get; set; }

        /// <summary>
        /// Being used as part for only email for now.
        /// </summary>
        public string Lead_Client { get; set; }
        public string System { get; set; }
        /// <summary>
        /// Being used as part for only email for now.
        /// </summary>
        public string Discipline_Lead { get; set; }

        public string Country { get; set; }

        public string Operations { get; set; }

        #endregion
    }
}
