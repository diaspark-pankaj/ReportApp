﻿using Exigent.Common.Constants;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Exigent_ViewModels.Common
{
    public class EmailTemplateViewModel
    {
        #region Primitive Properties

        public int ID { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string Name { get; set; }
        public string SystemName { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string EmailFrom { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string FromName { get; set; }
        public string HtmlContent { get; set; }
        public DateTime createdDateTime { get; set; }
        public long createdBy { get; set; }
        public DateTime updatedDateTime { get; set; }
        public long updatedBy { get; set; }
        public List<EmailTemplateViewModel> emailTemplateViewModelList { get; set; }
        public string Subject { get; set; }
        public string Keywords { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        [AllowHtml]
        public string EmailContent { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string EmailSubject { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public string TextContent { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        public int CategoryId { get; set; }
        public string Category { get; set; }
        public bool CanEdit { get; set; }

        #endregion
    }

    public class EmailTemplatesListViewModel
    {
        public EmailTemplatesListViewModel()
        {
            RustyData = new Dictionary<string, object>();
            EntityList = new List<EmailTemplateViewModel>();
        }

        public Dictionary<string, object> RustyData;
        public List<EmailTemplateViewModel> EntityList { get; set; }
        public String SearchField { get; set; }
        public int RecordCount { get; set; }
    }

    public partial class EmailCategoryViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
