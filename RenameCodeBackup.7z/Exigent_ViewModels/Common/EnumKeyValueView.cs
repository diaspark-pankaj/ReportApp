﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.Common
{
    public class EnumKeyValueViewModel
    {
        public int Key { get; set; }

        public string Name { get; set; }

        public string Category { get; set; }
        public int DashBoardId{ get; set; }
    }
}