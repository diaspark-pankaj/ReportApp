﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.CustomControl
{
    public class BrandLookupViewViewModel
    {
        public int Id  { get; set; }

        public string Name { get; set; }

        public string ShortName { get; set; }

        public string CompanyIdentifier { get; set; }

        public string Cid { get; set; }

        public string CompanyCid { get; set; }

        public string ParentCompany { get; set; }
    }
}
