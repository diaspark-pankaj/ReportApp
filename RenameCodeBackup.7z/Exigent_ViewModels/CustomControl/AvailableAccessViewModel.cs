﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Exigent_ViewModels.CustomControl
{
    public class AvailableAccessViewModel
    {
        private List<MarketAccessViewModel> _marketAccessList;
        private string _marketAccessListJson;

        public int EntityId { get; set; }

        public string MarketAccessListJson
        {
            get
            {
                string marketAccessListJson = JsonConvert.SerializeObject(_marketAccessList);
                _marketAccessListJson = marketAccessListJson;
                return marketAccessListJson;
            }
            set
            {
                _marketAccessListJson = value;
            }
        }

        public List<MarketAccessViewModel> MarketAccessList
        {
            get
            {
                List<MarketAccessViewModel> marketAccessViewModelList = JsonConvert.DeserializeObject<List<MarketAccessViewModel>>(_marketAccessListJson ?? string.Empty);
                _marketAccessList = marketAccessViewModelList;
                return marketAccessViewModelList;
            }
            set
            {
                _marketAccessList = value;
            }
        }


        public List<MarketAccessViewModel> MarketAccessList2 { get; set; }

        //Extra
        public List<MarketAccessViewModel> ConceptList { get; set; }

        //public List<MarketAccessViewModel> MarketAccessList { get; set; }

        public AvailableAccessViewModel()
        {
           // MarketAccessList = new List<MarketAccessViewModel>();
           // ConceptList = new List<MarketAccessViewModel>();
        }
    }

    public class MarketAccessViewModel
    {
        public ConceptViewModel Concept { get; set; }

        public List<LocationViewModel> LocationList { get; set; }

        public MarketAccessViewModel()
        {
            LocationList = new List<LocationViewModel>();
        }
    }

    public class LocationViewModel
    {
        public string LocationId { get; set; }

        public string LocationName { get; set; }

        //public bool IsVisible { get; set; }
    }

    public class ConceptViewModel
    {
        public string ConceptId { get; set; }

        public string ConceptName { get; set; }

        //public bool IsVisible { get; set; }
    }
}