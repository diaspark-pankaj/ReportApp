﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exigent_ViewModels.CustomControl
{
    public class Files
    {
        public List<FileDetails> FileDetailsList { get; set; }

        public Files()
        {
            FileDetailsList = new List<FileDetails>();
        }
    }

    public class FileDetails
    {
        public string Name { get; set; }
        public long Size { get; set; }
        public string ContentType { get; set; }
        public string Location { get; set; }
        public string ThumbLocation { get; set; }
        public string Tags { get; set; }
        public byte[] Content { get; set; }
        public string SASUri { get; set; }
        public DateTime ModifiedTime { get; set; }
    }
}
