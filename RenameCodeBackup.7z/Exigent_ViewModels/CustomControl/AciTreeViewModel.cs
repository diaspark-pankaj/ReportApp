﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.CustomControl
{
    public class AciTreeViewModel
    {
        public string id { get; set; }
        public string label { get; set; }
        public bool inode { get; set; }
        public bool open { get; set; }
        public bool checkbox { get; set; }
        public bool radio { get; set; }
        public List<AciTreeViewModel> branch { get; set; }
    }
}
