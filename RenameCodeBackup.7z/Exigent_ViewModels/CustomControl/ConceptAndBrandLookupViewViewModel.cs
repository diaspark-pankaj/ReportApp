﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.CustomControl
{
    public class ConceptAndBrandLookupViewViewModel
    {
        public string Name { get; set; }

        public string Cid { get; set; }

        public string CompanyCid { get; set; }
    }
}
