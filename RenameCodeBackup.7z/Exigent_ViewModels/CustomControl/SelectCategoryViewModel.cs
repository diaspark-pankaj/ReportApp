﻿using Exigent_ViewModels.ObjectDataMgmtSystem;
using System.Collections.Generic;

namespace Exigent_ViewModels.CustomControl
{
    public class SelectCategoryViewModel
    {
        public int CategoryId { get; set; }

        //[Required(ErrorMessage = "Category is Required")]
        public string Category { get; set; }

        public List<ODMSEquipmentCategoryViewModel> CategoryList { get; set; }

        public bool  ProcessIdentifier { get; set; }

        public SelectCategoryViewModel()
        {
            ProcessIdentifier = true;
        }
    }
}