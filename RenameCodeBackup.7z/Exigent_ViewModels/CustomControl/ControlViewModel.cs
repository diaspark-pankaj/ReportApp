﻿using Exigent.Common.Enums;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web;
using System.Web.Mvc;

namespace Exigent_ViewModels.CustomControl
{
    public abstract class ControlViewModel
    {
        public abstract string Type { get; }
        public string Label { get; set; }
        public bool Visible { get; set; }
        public long EquipmentFieldValueId { get; set; }
        public bool IsTempField { get; set; }
        public bool Removed { get; set; }
        public int FieldOrder { get; set; }
    }

    public class TextBoxViewModel : ControlViewModel
    {
        public override string Type
        {
            get { return ControlType.TextBox.ToString(); }
        }

        /*----------Don't change order of these properties-----------*/
        public long FieldId { get; set; } //Don't move this property in parent class and don't rename this field

        [StringLength(100, ErrorMessage = "Maximum 100 characters allowed.")]
        public string TxtValue { get; set; }
        /*---------------------*/
    }

    public class EmailInputTextBoxViewModel : ControlViewModel
    {
        public override string Type
        {
            get { return ControlType.EmailInput.ToString(); }
        }

        public long FieldId { get; set; }//Don't move this property in parent class and don't rename this field
        public string TxtValue { get; set; }
        public string TxtIds { get; set; }
    }

    public class TextAreaViewModel : ControlViewModel
    {
        public override string Type
        {
            get { return ControlType.TextArea.ToString(); }
        }

        /*----------Don't change order of these properties-----------*/
        public long FieldId { get; set; } //Don't move this property in parent class and don't rename this field

        [StringLength(100, ErrorMessage = "Maximum 100 characters allowed.")]
        public string TxtAreaValue { get; set; }
        /*---------------------*/
    }

    public class DatePickerViewModel : ControlViewModel
    {
        public override string Type
        {
            get { return ControlType.DatePicker.ToString(); }
        }

        /*----------Don't change order of these properties-----------*/
        public long FieldId { get; set; } //Don't move this property in parent class and don't rename this field

        public string DpValue { get; set; }
        /*---------------------*/
    }

    public class RadioButtonsViewModel : ControlViewModel
    {
        public override string Type
        {
            get { return ControlType.RadioButtonList.ToString(); }
        }

        public Dictionary<string, string> RbTextValues { get; set; }

        /*----------Don't change order of these properties-----------*/
        public long FieldId { get; set; } //Don't move this property in parent class and don't rename this field

        public string RbValue { get; set; }
        /*---------------------*/
    }

    public class CheckBoxViewModel : ControlViewModel
    {
        public override string Type
        {
            get { return ControlType.CheckBox.ToString(); }
        }

        /*----------Don't change order of these properties-----------*/
        public long FieldId { get; set; } //Don't move this property in parent class and don't rename this field

        public bool CbValue { get; set; }
        /*---------------------*/
    }

    public class DropDownListViewModel : ControlViewModel
    {
        public override string Type
        {
            get { return ControlType.DropDown.ToString(); }
        }
        public List<SelectListItem> Values { get; set; }

        /*----------Don't change order of these properties-----------*/
        public long FieldId { get; set; } //Don't move this property in parent class and don't rename this field

        public string DdlSelectedValue { get; set; }
        /*---------------------*/
    }

    //public class ListBoxViewModel : ControlViewModel
    //{
    //    public override string Type
    //    {
    //        get { return ControlType.ListBox.ToString(); }
    //    }
    //    public SelectList Values { get; set; }

    //    public List<string> LbSelectedValues { get; set; }
    //}

    public class CheckBoxListViewModel : ControlViewModel
    {
        public override string Type
        {
            get { return ControlType.CheckBoxList.ToString(); }
        }

        /*----------Don't change order of these properties-----------*/
        public long FieldId { get; set; } //Don't move this property in parent class and don't rename this field

        public List<CheckBoxViewModel> CheckBoxList { get; set; }
    }

    public class FileUploadViewModel : ControlViewModel
    {
        public override string Type
        {
            get
            {
                return IsMultiple ? ControlType.MultipleFileUpload.ToString() : ControlType.SingleFileUpload.ToString();
            }
        }

        public bool IsMultiple { get; set; }

        /*----------Don't change order of these properties-----------*/
        public long FieldId { get; set; } //Don't move this property in parent class and don't rename this field

        public HttpPostedFileBase FuValue { get; set; }

        public UploadDocumentViewModel UploadFile { get; set; }

        public int EquipmentId { get; set; }
    }

    public class HtmlSeparatorViewModel : ControlViewModel
    {
        public override string Type
        {
            get { return ControlType.HtmlLine.ToString(); }
        }

        /*----------Don't change order of these properties-----------*/
        public long FieldId { get; set; } //Don't move this property in parent class and don't rename this field

        public string HtmlSepTestField { get; set; } //don't remove this field
    }
}
