﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.CustomControl
{
    public class CircleProgressViewModel
    {
        public decimal ProgressValue { get; set; }
    }
}