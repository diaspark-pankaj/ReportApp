﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent_ViewModels.CustomControl
{
    public class TagInputViewModel
    {
        [StringLength(500, ErrorMessage = "The Hash Tags must be less than or equal to 500 characters")]
        public string Tags { get; set; }
    }
}