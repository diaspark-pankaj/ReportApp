﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Web;


namespace Exigent_ViewModels.CustomControl
{
    public class UploadDocumentViewModel
    {
        public string ControlId { get; set; }

        public string SaveTagServiceUrl { get; set; }

        public string DeleteTagServiceUrl { get; set; }

        public int EquipmentDocTypeId { get; set; }

        public int EquipmentId { get; set; }

        public string DocStorageDirPath { get; set; }

        public string SaveDocServiceUrl { get; set; }

        public string CookieValue { get; set; }

        public string GetDocListServicePath { get; set; }

        public bool IsTagVisible { get; set; }

       
        public List<FileDetails> FileDetailsList { get; set; }

        public UploadDocumentViewModel()
        {
            FileDetailsList = new List<FileDetails>();
            
        }
    }
}