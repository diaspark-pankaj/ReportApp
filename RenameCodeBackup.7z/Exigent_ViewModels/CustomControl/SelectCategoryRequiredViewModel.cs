﻿using System.ComponentModel.DataAnnotations;
using Exigent_ViewModels.ObjectDataMgmtSystem;
using System.Collections.Generic;

namespace Exigent_ViewModels.CustomControl
{

    public class SelectMultipleCategoryRequiredViewModel
    {
        public string CategoryId { get; set; }

        [Required(ErrorMessage = "Category is Required")]
        public string Category { get; set; }

        public List<ODMSEquipmentCategoryViewModel> CategoryList { get; set; }

    }


    public class SelectCategoryRequiredViewModel
    {
        public int CategoryId { get; set; }

        [Required(ErrorMessage = "Category is Required")]
        public string Category { get; set; }

        public List<ODMSEquipmentCategoryViewModel> CategoryList { get; set; }

        public bool  ProcessIdentifier { get; set; }

        public SelectCategoryRequiredViewModel()
        {
            ProcessIdentifier = true;
        }
    }

    public class ContainerSelectCategoryRequiredViewModel
    {
        public string RuleType { get; set; }//TODO:Place in enum
         public string Target { get; set; }//TODO:Place in enum
         [UIHint("_SelectCategoryRequiredViewModel")]
         public SelectCategoryRequiredViewModel EntityFrom { get; set; }
         [UIHint("_SelectCategoryRequiredViewModel")]
         public SelectCategoryRequiredViewModel EntityTo { get; set; }
    }
}