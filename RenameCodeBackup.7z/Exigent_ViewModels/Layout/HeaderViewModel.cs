﻿using Exigent_ViewModels.Admin;
using System;
using System.Collections.Generic;

namespace Exigent_ViewModels.Layout
{
   public class HeaderViewModel
    {
        public int  UserId { get; set; }
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string CurrentMarket { get; set; }
        public string CurrentGeo { get; set; }
        public string ThumbImage { get; set; }
        public List<RoleViewModel> Roles { get; set; }
        public DateTime? DateModified { get; set; }
        public string HeaderType { get; set; }
    }
}
