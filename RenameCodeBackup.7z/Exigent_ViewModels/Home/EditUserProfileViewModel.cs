﻿using Exigent.Common.Constants;
using Exigent.MVCHelpers.CustomAttribute;
using Exigent_ViewModels.Admin;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web;
using System.Web.Mvc;

namespace Exigent_ViewModels.Home
{
    public class EditUserProfileViewModel
    {
        
        public int? Id { get; set; }

        [Required(ErrorMessage = CommonConstants.Required)]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid email address")]
        [DataType(DataType.EmailAddress)]
        [StringLength(100, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "Email")]
        public string Email { get; set; }


        //[Required(ErrorMessage = "User Name is Required")]
        //[StringLength(100, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "User Name")]
        public string UserName { get; set; }


        [Required(ErrorMessage = CommonConstants.Required)]
        [StringLength(50, ErrorMessage = "Maximum allowed characters upto 50")]
        [Display(Name = "Full Name")]
        public string FullName { get; set; }

        [StringLength(50, ErrorMessage = "Maximum allowed characters upto 50")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Invalid email address")]
        [Display(Name = "Alternate Email")]
        public string AltEmail { get; set; }

        [Display(Name = "Upload User Image")]
        [ValidateFile]
        public HttpPostedFileBase File { get; set; }

        public string OriginalImage { get; set; }
          
        public string ThumbImage { get; set; }

        public bool IsVendor { get; set; }

        public List<KeyValuePair<string, string>> UserTypes { get; set; }
        [Required(ErrorMessage = CommonConstants.Required)]
        [Display(Name = "User Type")]
        public int UserTypeId { get; set; }
    }

    public class xyz
    {
        public string Id { get; set; }

        public string Name { get; set; }
    }
}