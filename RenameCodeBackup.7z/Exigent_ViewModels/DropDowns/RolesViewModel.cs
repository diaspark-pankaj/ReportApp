﻿
namespace Exigent_ViewModels.DropDowns
{
    public class RolesViewModel
    {
        public int Id { get; set; }
        public string RoleName { get; set; }
    }
}
