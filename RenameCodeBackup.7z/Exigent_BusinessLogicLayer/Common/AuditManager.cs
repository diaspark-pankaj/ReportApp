﻿using Exigent.EF.Data.Repository;
using Exigent_ViewModels.Audit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Linq.Expressions;
using System.Web;
using System.Linq.Dynamic;


namespace Exigent_BusinessLogicLayer.Audit
{
    public class AuditManager
    {
        /// <summary>
        /// Search from audit table for given search criteria
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public List<AuditViewModel> searchAudit(Expression<Func<AuditViewModel, bool>> predicate, string sortColumn, string sortDir)
        {
            using (AuditRepository auditRepository = new AuditRepository())
            {
                string sort_Query = sortColumn + "  " + sortDir; var auditlist = auditRepository.GetQuery();

                AuditListViewModel objauditListViewModel = new AuditListViewModel();
                objauditListViewModel.AuditList = auditlist.Select(r => new AuditViewModel
               {
                   AuditID = r.AuditID,
                   IPAddress = r.IPAddress,
                   UserName = (r.UserName == null) ? "" : r.UserName,
                   URLAccessed = r.URLAccessed,
                   CustomMessage = r.CustomMessage,
                   TimeAccessed = r.TimeAccessed
               }).Where(predicate).ToList();

                return objauditListViewModel.AuditList.AsQueryable().OrderBy(sort_Query).ToList();
            }
        }

        public List<AuditViewModel> GetAuditList()
        {
            using (AuditRepository auditRepository = new AuditRepository())
            {
                var auditList = auditRepository.GetAll();

                AuditListViewModel objAuditListViewModel = new AuditListViewModel();

                return objAuditListViewModel.AuditList = auditList.Select(r =>
                {
                    return new AuditViewModel
                    {
                        AuditID = r.AuditID,
                        IPAddress = r.IPAddress,
                        UserName = (r.UserName == null) ? "" : r.UserName,
                        URLAccessed = r.URLAccessed,
                        CustomMessage = r.CustomMessage,
                        TimeAccessed = r.TimeAccessed
                    };
                }).ToList();
            }
        }

        public void SaveAudit(AuditViewModel auditData)
        {
            //using (AuditRepository auditRepository = new AuditRepository())
            //{
            //    Exigent.Models.Audit ObjAudit = new Exigent.Models.Audit();

            //    ObjAudit.AuditID = Guid.NewGuid();
            //    ObjAudit.IPAddress = auditData.IPAddress;
            //    ObjAudit.UserName = auditData.UserName;
            //    ObjAudit.URLAccessed = auditData.URLAccessed;
            //    ObjAudit.TimeAccessed = System.DateTime.Now;
            //    ObjAudit.CustomMessage = auditData.CustomMessage;

            //    auditRepository.Add(ObjAudit);
            //    auditRepository.SaveChanges();
            //}
        }
        public static void SaveAudit(string CustomMessage, string PageURL, int UserId)
        {
            //using (AuditRepository tempAuditRepository = new AuditRepository())
            //{
            //    UserRepository objUserRepository = new UserRepository();
            //    string strUserName = "";
            //    string IPAddress = string.Empty;
            //    string SearchName = string.Empty;

            //    if (UserId != '0')
            //    {
            //        var strUserDetails = objUserRepository.GetById(UserId);
            //        strUserName = strUserDetails.FirstName + " " + strUserDetails.LastName;
            //    }
            //    String strHostName = HttpContext.Current.Request.UserHostAddress.ToString();
            //    IPAddress = System.Net.Dns.GetHostAddresses(strHostName).GetValue(0).ToString();

            //    Exigent.Models.Audit ObjAudit = new Exigent.Models.Audit();

            //    ObjAudit.AuditID = Guid.NewGuid();
            //    ObjAudit.IPAddress = IPAddress;
            //    ObjAudit.UserId = UserId;
            //    ObjAudit.UserName = strUserName;
            //    ObjAudit.URLAccessed = PageURL;
            //    ObjAudit.TimeAccessed = System.DateTime.Now;
            //    ObjAudit.CustomMessage = CustomMessage;

            //    tempAuditRepository.Add(ObjAudit);
            //    tempAuditRepository.SaveChanges();
            //}
        }
        public static void SaveAudit(string CustomMessage, string PageURL, string UserName)
        {
            //using (AuditRepository tempAuditRepository = new AuditRepository())
            //{
            //    string IPAddress = string.Empty;
            //    String strHostName = HttpContext.Current.Request.UserHostAddress.ToString();
            //    IPAddress = System.Net.Dns.GetHostAddresses(strHostName).GetValue(0).ToString();

            //    Exigent.Models.Audit ObjAudit = new Exigent.Models.Audit();

            //    ObjAudit.AuditID = Guid.NewGuid();
            //    ObjAudit.IPAddress = IPAddress;
            //    ObjAudit.UserName = UserName;
            //    ObjAudit.URLAccessed = PageURL;
            //    ObjAudit.TimeAccessed = System.DateTime.Now;
            //    ObjAudit.CustomMessage = CustomMessage;

            //    tempAuditRepository.Add(ObjAudit);
            //    tempAuditRepository.SaveChanges();
            //}
        }
    }
}
