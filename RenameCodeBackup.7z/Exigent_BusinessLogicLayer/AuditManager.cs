﻿using Exigent.EF.Data.Repository;
using Exigent_ViewModels.Audit;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Linq.Expressions;
using System.Web;
using System.Linq.Dynamic;


namespace Exigent_BusinessLogicLayer.Audit
{
    public class AuditManager
    {
        /// <summary>
        /// Search from audit table for given search criteria
        /// </summary>
        /// <param name="predicate"></param>
        /// <returns></returns>
        public List<AuditViewModel> SearchAudit(Expression<Func<AuditViewModel, bool>> predicate, string sortColumn, string sortDir)
        {
            using (AuditRepository auditRepository = new AuditRepository())
            {
                string sort_Query = sortColumn + "  " + sortDir; var auditlist = auditRepository.GetQuery();

                AuditListViewModel objauditListViewModel = new AuditListViewModel();
                objauditListViewModel.AuditList = auditlist.Select(r => new AuditViewModel
               {
                   AuditID = r.AuditID,
                   IPAddress = r.IPAddress,
                   UserName = (r.UserName == null) ? "" : r.UserName,
                   URLAccessed = r.URLAccessed,
                   CustomMessage = r.CustomMessage,
                   TimeAccessed = r.TimeAccessed
               }).Where(predicate).ToList();

                return objauditListViewModel.AuditList.AsQueryable().OrderBy(sort_Query).ToList();
            }
        }

        /// <summary>
        /// Get list of all the audits from audit table
        /// </summary>
        public List<AuditViewModel> GetAuditList()
        {
            using (AuditRepository auditRepository = new AuditRepository())
            {
                var auditList = auditRepository.GetAll();

                AuditListViewModel objAuditListViewModel = new AuditListViewModel();

                return objAuditListViewModel.AuditList = auditList.Select(r =>
                {
                    return new AuditViewModel
                    {
                        AuditID = r.AuditID,
                        IPAddress = r.IPAddress,
                        UserName = (r.UserName == null) ? "" : r.UserName,
                        URLAccessed = r.URLAccessed,
                        CustomMessage = r.CustomMessage,
                        TimeAccessed = r.TimeAccessed
                    };
                }).ToList();
            }
        }

        // Modified by Shreya Garhwal- 03/16/2017
        // Save Audit data in Audit table, provided AuditViewModel object
        public void SaveAudit(AuditViewModel auditData)
        {
            using (AuditRepository auditRepository = new AuditRepository())
            {
                Exigent.Models.Audit ObjAudit = new Exigent.Models.Audit();

                ObjAudit.AuditID = Guid.NewGuid();
                ObjAudit.IPAddress = auditData.IPAddress;
                ObjAudit.UserName = auditData.UserName;
                ObjAudit.URLAccessed = auditData.URLAccessed;
                ObjAudit.TimeAccessed = System.DateTime.Now;
                ObjAudit.CustomMessage = auditData.CustomMessage;
                // Added                
                ObjAudit.Userid = auditData.UserId;

                auditRepository.Add(ObjAudit);
                auditRepository.SaveChanges();
            }
        }

        // Save Audit data in Audit table, provided customMessage, pageURL and userId
        public static void SaveAudit(string customMessage, string pageURL, int userId)
        {
            using (AuditRepository tempAuditRepository = new AuditRepository())
            {
                UserRepository objUserRepository = new UserRepository();
                string strUserName = "";
                string IPAddress = string.Empty;

                if (userId != '0')
                {
                    var strUserDetails = objUserRepository.GetById(userId);
                    strUserName = strUserDetails.FullName;
                }
                String strHostName = HttpContext.Current.Request.UserHostAddress.ToString();
                IPAddress = System.Net.Dns.GetHostAddresses(strHostName).GetValue(0).ToString();

                Exigent.Models.Audit ObjAudit = new Exigent.Models.Audit();

                ObjAudit.AuditID = Guid.NewGuid();
                ObjAudit.IPAddress = IPAddress;
                ObjAudit.Userid = userId;
                ObjAudit.UserName = strUserName;
                ObjAudit.URLAccessed = pageURL;
                ObjAudit.TimeAccessed = System.DateTime.Now;
                ObjAudit.CustomMessage = customMessage;

                tempAuditRepository.Add(ObjAudit);
                tempAuditRepository.SaveChanges();
            }
        }

        // Modified by Shreya Garhwal- 03/16/2017
        // Save Audit data in Audit table, provided customMessage, pageURL and userName
        public static void SaveAudit(string customMessage, string pageURL, string userName, int? userId=null)
        {
            using (AuditRepository tempAuditRepository = new AuditRepository())
            {
                string IPAddress = string.Empty;
                String strHostName = HttpContext.Current.Request.UserHostAddress.ToString();
                IPAddress = System.Net.Dns.GetHostAddresses(strHostName).GetValue(0).ToString();

                Exigent.Models.Audit ObjAudit = new Exigent.Models.Audit();

                ObjAudit.AuditID = Guid.NewGuid();
                ObjAudit.IPAddress = IPAddress;
                ObjAudit.UserName = userName;
                ObjAudit.URLAccessed = pageURL;
                ObjAudit.TimeAccessed = System.DateTime.Now;
                ObjAudit.CustomMessage = customMessage;
                ObjAudit.Userid =Convert.ToInt32(userId);

                tempAuditRepository.Add(ObjAudit);
                tempAuditRepository.SaveChanges();
            }
        }
    }
}
