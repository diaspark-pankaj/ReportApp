using Exigent.DataLayer.Repository;
using Exigent.EF.Data.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using System.Linq.Dynamic;
using Exigent_ViewModels.Admin;
using Exigent.Common.Enums;
using Exigent.Common.Helpers;
using System.Data.Entity;
using Exigent.Common.Constants;
using System.Data.SqlClient;
using System.Data;
using System.Globalization;
using Exigent_ViewModels.Common;

namespace Exigent_BusinessLogicLayer
{
    public class LookupManager
    {
        #region "Instructions-AdminSection"

        /// <summary>
        /// Get the list of all pending instructions.
        /// </summary>
        /// <param name="limit">Number of rows to return</param>
        /// <param name="fromRowNumber">Row number to start display</param>
        /// <param name="sortcolumn">Name of column to sort</param>
        /// <param name="sortdirection">Sort Direction asc / desc</param>
        /// <param name="recordCount">integer out paramter to get the total number of records available in database.</param>
        /// <returns><![CDATA[List<InstructionViewModel>]]></returns>
        public static List<InstructionViewModel> GetPendingInstructionsListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, out int recordCount)
        {
            using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
            {
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Instruction_Reference") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");
                var query = rep.GetQueryWithInclude("External_Instructions_Approval");

                //Get the total counts of all the records in all the pages.
                recordCount = query.Count();

                var list = query.Where(m => (m.Status != VarConstants.Instruction_Active && m.Status != VarConstants.Instruction_Closed)
                                        && m.SystemType_ID == (int)SystemTypes.GroupLegal)
                                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit)
                                         .AsQueryable()
                                        .Select(m => new InstructionViewModel
                                        {
                                            ID = m.ID,
                                            Instruction_Reference = m.Instruction_Reference,
                                            Matter_Reference = m.Matter.Matter_Reference,
                                            MatterDetail = new MatterBlock
                                            {
                                                Id = m.Matter.ID,
                                                MatterReferenceNumber = m.Matter.Matter_Reference,
                                                BusinessUnitName = m.Matter.Business_Units.Business_Unit1
                                            },
                                            Status = m.Status,
                                            Vendor = m.Vendor.Company_Name,
                                            Billing_Entity = m.Client_Companies.Company_Name,
                                            Payment_Clearance_Number = m.Purchase_Order_Number,
                                            // Comments = m.External_Instructions_Confirm_PO.FirstOrDefault() != null ? m.External_Instructions_Confirm_PO.FirstOrDefault().Comments : string.Empty
                                        })

                        .ToList();

                return list;
            }
        }

        /// <summary>
        /// Get the list of all matching instructions by Instruction Ref. or Matter Ref.
        /// </summary>
        /// <param name="limit">Number of rows to return</param>
        /// <param name="fromRowNumber">Row number to start display</param>
        /// <param name="sortcolumn">Name of column to sort</param>
        /// <param name="sortdirection">Sort Direction asc / desc</param>
        /// <param name="recordCount">integer out paramter to get the total number of records available in database.</param>
        /// <param name="searchfield">Instruction Ref. or Matter Ref</param>
        /// <param name="filterBy">M for Matter or I for Instruction</param>
        /// <returns><![CDATA[List<InstructionViewModel>]]></returns>
        public static List<InstructionViewModel> SearchInstructionsListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, out int recordCount, string searchfield = "", string filterBy = "")
        {
            using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
            {
                // applied null check , code review : JIRA -EXICHM-462, vyom dixit, 28/06/2017
                searchfield = !string.IsNullOrEmpty(searchfield) ? searchfield.Trim() : "";
                filterBy = !string.IsNullOrEmpty(filterBy) ? filterBy.Trim() : "";

                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Instruction_Reference") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");
                var query = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchfield))
                {
                    searchfield = searchfield.Trim();
                    if (filterBy == "I")
                    {
                        query = query.Where(m => (m.Instruction_Reference.Equals(searchfield)));
                    }
                    else
                    {
                        query = query.Where(m => m.Instruction_Reference.Contains(searchfield)
                                         || m.Matter.Matter_Reference.Contains(searchfield)
                                         || m.Status.Contains(searchfield)
                                         || m.Vendor.Company_Name.Contains(searchfield)
                                         || m.Matter.Business_Units.Business_Unit1.Contains(searchfield)
                                         || m.Client_Companies.Company_Name.Contains(searchfield)
                                         || m.Purchase_Order_Number.Contains(searchfield));
                    }
                }

                //Get the total counts of all the records in all the pages.
                recordCount = query.Count();

                var list = query
                    .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(m => new InstructionViewModel
                        {
                            ID = m.ID,
                            Instruction_Reference = m.Instruction_Reference,
                            Matter_Reference = m.Matter.Matter_Reference,
                            MatterDetail = new MatterBlock
                            {
                                Id = m.Matter.ID,
                                MatterReferenceNumber = m.Matter.Matter_Reference,
                                BusinessUnitName = m.Matter.Business_Units.Business_Unit1
                            },
                            Status = m.Status,
                            Vendor = m.Vendor.Company_Name,
                            Billing_Entity = m.Client_Companies.Company_Name,
                            Payment_Clearance_Number = m.Purchase_Order_Number
                        }).ToList();

                return list;
            }
        }

        public static List<InvoiceViewModel> GetnvoicesForInstructionByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, out int recordCount, string instructionRef)
        {
            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "External_Instructions.Instruction_Reference") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");

            using (InvoiceRepository rep = new InvoiceRepository())
            {
                var query = rep.GetQuery()
                    .Where(m => m.External_Instructions.Instruction_Reference == instructionRef);

                //Get the total counts of all the records in all the pages.
                recordCount = query.Count();

                if (recordCount > 0)
                {
                    return query.OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                 .Select(m => new InvoiceViewModel
                 {
                     ID = m.ID,
                     Matter_Reference = m.Matter.Matter_Reference,
                     Instruction_Reference = m.External_Instructions.Instruction_Reference,
                     Invoice_Number = m.Invoice_Number,
                     Invoice_Status = m.Invoice_Status,
                     Vendor = m.Vendor.Company_Name,
                     PreVat_Total = m.PreVat_Total
                 }).ToList();
                }
                else
                {
                    return new List<InvoiceViewModel>();
                }
            }
        }


        #endregion

        #region MainDashboard
        /// <summary>
        /// Chaanged : Balnce Formula as suggested in email subjected as "FW: Query: Formula for balance(instruction grid)".
        /// Reverted : Balance Formula as previous ( just used "PreVat_Total" in place of "Invoice_Total") as per JIRA : EXICHM-376)
        /// </summary>
        /// <param name="limit">To set the limit of the records</param>
        /// <param name="fromRowNumber">Starting row number</param>
        /// <param name="sortColumn">sort by column name</param>
        /// <param name="sortDirection">sort direction asc/desc</param>
        /// <param name="searchField">searched instruction number.</param>
        /// <param name="isAdminUser">Is Accessed by Admin Role user</param>
        /// <param name="matterRefNo">Matter Reference number</param>
        /// <returns></returns>

        public static List<InstructionViewModel> GetInstructionsListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField, bool isAdminUser = false, string matterRefNo = "", string loggedInUserFullName = "")
        {
            using (ExternalInstructionRepository _externalInstructionRepository = new ExternalInstructionRepository())
            {
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Instruction_Reference") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");
                var instructlist = _externalInstructionRepository.GetQueryWithInclude("Invoices");
                //string creditedStatus = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Credited.ToString());
                //string rejectedStatus = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Rejected.ToString());
                //string noELFInstStatus = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.NoELFInstruction.ToString());
                var canEditMatter = false;
                string Assisting_Team_Members = string.Empty;

                var matterDetailByRef = instructlist.Any(x => (x.Matter.Matter_Reference.Equals(matterRefNo))) ? instructlist.Where(x => (x.Matter.Matter_Reference.Equals(matterRefNo))).FirstOrDefault().Matter : null;
                if (matterDetailByRef != null)
                {
                    Assisting_Team_Members = matterDetailByRef.Matters_AssistingTeamMembers.Any() ? string.Join(";", matterDetailByRef.Matters_AssistingTeamMembers.Select(x => x.PeoplePicker.Full_Name).ToArray()) : string.Empty;
                    canEditMatter = ((matterDetailByRef.User != null ? matterDetailByRef.User.FullName.ToLower().Trim() == loggedInUserFullName.ToLower().Trim() : false)
                                        || (matterDetailByRef.Matters_AssistingTeamMembers != null ?
                                        Assisting_Team_Members.Split(';').Select(s => s.ToLowerInvariant().Trim()).Contains(loggedInUserFullName.ToLowerInvariant().Trim()) : false));
                }
                string paid = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Paid.ToString());
                InstructionListViewModel objInstructionListViewModel = new InstructionListViewModel();
                if (!string.IsNullOrEmpty(searchField))
                {
                    if (isAdminUser && limit != -1)
                    {
                        objInstructionListViewModel.InstructionList = instructlist
                        .Where(x => (x.Matter.Matter_Reference.Equals(matterRefNo))
                            && (x.Instruction_Reference != null
                            && x.Instruction_Reference.Contains(searchField))
                            )
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(inst => new InstructionViewModel
                        {
                            ID = inst.ID,
                            SystemType_ID = inst.SystemType_ID,
                            System = inst.SystemType.SystemTypeName,
                            Status = inst.Status,
                            Instruction_Reference = inst.Instruction_Reference,
                            Matter_Reference = inst.Matter.Matter_Reference,
                            Vendor = inst.Vendor.Company_Name,
                            Payment_Clearance_Number = inst.Purchase_Order_Number,
                            EstimatedLegalCost = (inst.Estimated_Legal_Cost_Non_Vatable.HasValue ? inst.Estimated_Legal_Cost_Non_Vatable.Value : 0) + (inst.Estimated_Legal_Cost_Vatable.HasValue ? inst.Estimated_Legal_Cost_Vatable.Value : 0),
                            //EXICHM-376
                            Balance = (inst.Legal_Cost_Non_Vatable_Balance.HasValue ? inst.Legal_Cost_Non_Vatable_Balance.Value : 0) + (inst.Legal_Cost_Vatable_Balance.HasValue ? inst.Legal_Cost_Vatable_Balance.Value : 0)
                        }).ToList();
                    }
                    else if (limit > 0)
                    {
                        objInstructionListViewModel.InstructionList = instructlist
                       .Where(x => (x.Matter.Matter_Reference.Equals(matterRefNo))
                           && (x.Instruction_Reference != null
                           && x.Instruction_Reference.Contains(searchField))
                           )
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                       .Select(inst => new InstructionViewModel
                       {
                           ID = inst.ID,
                           SystemType_ID = inst.SystemType_ID,
                           System = inst.SystemType.SystemTypeName,
                           Status = inst.Status,
                           Instruction_Reference = inst.Instruction_Reference,
                           Matter_Reference = inst.Matter.Matter_Reference,
                           Vendor = inst.Vendor.Company_Name,
                           Payment_Clearance_Number = inst.Purchase_Order_Number,
                           EstimatedLegalCost = (inst.Estimated_Legal_Cost_Non_Vatable.HasValue ? inst.Estimated_Legal_Cost_Non_Vatable.Value : 0) + (inst.Estimated_Legal_Cost_Vatable.HasValue ? inst.Estimated_Legal_Cost_Vatable.Value : 0),
                           Balance = (inst.Legal_Cost_Non_Vatable_Balance.HasValue ? inst.Legal_Cost_Non_Vatable_Balance.Value : 0) + (inst.Legal_Cost_Vatable_Balance.HasValue ? inst.Legal_Cost_Vatable_Balance.Value : 0)
                           //EXICHM-376
                           //Balance = ((inst.Estimated_Legal_Cost_Non_Vatable.HasValue ? inst.Estimated_Legal_Cost_Non_Vatable.Value : 0) + (inst.Estimated_Legal_Cost_Vatable.HasValue ? inst.Estimated_Legal_Cost_Vatable.Value : 0))
                           //           - (inst.Invoices.Any(x => (x.Invoice_Status == paid)) ? inst.Invoices.Where(y => (y.External_Instructions.Instruction_Reference.Equals(inst.Instruction_Reference)) && (y.Invoice_Status == paid)).Sum(x => (x.PreVat_Total.HasValue ? x.PreVat_Total.Value : 0)) : 0.0M)
                          
                       }).ToList();
                    }
                    else
                    {


                        objInstructionListViewModel.InstructionList = instructlist
                           .Where(x => (x.Matter.Matter_Reference.Equals(matterRefNo))
                               && (x.Instruction_Reference != null
                               && x.Instruction_Reference.Contains(searchField))
                               )
                            .OrderBy(sort_Query).AsQueryable()
                           .Select(inst => new InstructionViewModel
                           {
                               ID = inst.ID,
                               SystemType_ID = inst.SystemType_ID,
                               System = inst.SystemType.SystemTypeName,
                               Status = inst.Status,
                               Instruction_Reference = inst.Instruction_Reference,
                               Matter_Reference = inst.Matter.Matter_Reference,
                               Vendor = inst.Vendor.Company_Name,
                               Payment_Clearance_Number = inst.Purchase_Order_Number,
                               EstimatedLegalCost = (inst.Estimated_Legal_Cost_Non_Vatable.HasValue ? inst.Estimated_Legal_Cost_Non_Vatable.Value : 0) + (inst.Estimated_Legal_Cost_Vatable.HasValue ? inst.Estimated_Legal_Cost_Vatable.Value : 0),
                               Balance = (inst.Legal_Cost_Non_Vatable_Balance.HasValue ? inst.Legal_Cost_Non_Vatable_Balance.Value : 0) + (inst.Legal_Cost_Vatable_Balance.HasValue ? inst.Legal_Cost_Vatable_Balance.Value : 0)
                               //EXICHM-376
                               //Balance = ((inst.Estimated_Legal_Cost_Non_Vatable.HasValue ? inst.Estimated_Legal_Cost_Non_Vatable.Value : 0) + (inst.Estimated_Legal_Cost_Vatable.HasValue ? inst.Estimated_Legal_Cost_Vatable.Value : 0))
                               //           - (inst.Invoices.Any(x => (x.Invoice_Status == paid)) ? inst.Invoices.Where(y => (y.External_Instructions.Instruction_Reference.Equals(inst.Instruction_Reference)) && (y.Invoice_Status == paid)).Sum(x => (x.PreVat_Total.HasValue ? x.PreVat_Total.Value : 0)) : 0.0M)
                           }).ToList();

                    }

                }
                else
                {

                    if (isAdminUser && limit != -1)
                    {
                        objInstructionListViewModel.InstructionList = instructlist
                        .Where(x => (x.Matter.Matter_Reference.Equals(matterRefNo))
                            )
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(inst => new InstructionViewModel
                        {
                            ID = inst.ID,
                            SystemType_ID = inst.SystemType_ID,
                            System = inst.SystemType.SystemTypeName,
                            Status = inst.Status,
                            Instruction_Reference = inst.Instruction_Reference,
                            Matter_Reference = inst.Matter.Matter_Reference,
                            Vendor = inst.Vendor.Company_Name,
                            Payment_Clearance_Number = inst.Purchase_Order_Number,
                            EstimatedLegalCost = (inst.Estimated_Legal_Cost_Non_Vatable.HasValue ? inst.Estimated_Legal_Cost_Non_Vatable.Value : 0) + (inst.Estimated_Legal_Cost_Vatable.HasValue ? inst.Estimated_Legal_Cost_Vatable.Value : 0),
                            Balance = (inst.Legal_Cost_Non_Vatable_Balance.HasValue ? inst.Legal_Cost_Non_Vatable_Balance.Value : 0) + (inst.Legal_Cost_Vatable_Balance.HasValue ? inst.Legal_Cost_Vatable_Balance.Value : 0)
                            //EXICHM-376
                            //Balance = ((inst.Estimated_Legal_Cost_Non_Vatable.HasValue ? inst.Estimated_Legal_Cost_Non_Vatable.Value : 0) + (inst.Estimated_Legal_Cost_Vatable.HasValue ? inst.Estimated_Legal_Cost_Vatable.Value : 0))
                            //           - (inst.Invoices.Any(x => (x.Invoice_Status == paid)) ? inst.Invoices.Where(y => (y.External_Instructions.Instruction_Reference.Equals(inst.Instruction_Reference)) && (y.Invoice_Status == paid)).Sum(x => (x.PreVat_Total.HasValue ? x.PreVat_Total.Value : 0)) : 0.0M)                            
                        }).ToList();

                    }
                    else if (limit > 0)
                    {
                        objInstructionListViewModel.InstructionList = instructlist
                         .Where(x => (x.Matter.Matter_Reference.Equals(matterRefNo))
                             )
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(inst => new InstructionViewModel
                        {
                            ID = inst.ID,
                            SystemType_ID = inst.SystemType_ID,
                            Status = inst.Status,
                            Instruction_Reference = inst.Instruction_Reference,
                            Matter_Reference = inst.Matter.Matter_Reference,
                            Vendor = inst.Vendor.Company_Name,
                            Payment_Clearance_Number = inst.Purchase_Order_Number,
                            EstimatedLegalCost = (inst.Estimated_Legal_Cost_Non_Vatable.HasValue ? inst.Estimated_Legal_Cost_Non_Vatable.Value : 0) + (inst.Estimated_Legal_Cost_Vatable.HasValue ? inst.Estimated_Legal_Cost_Vatable.Value : 0),
                            //EXICHM-376
                            Balance = (inst.Legal_Cost_Non_Vatable_Balance.HasValue ? inst.Legal_Cost_Non_Vatable_Balance.Value : 0) + (inst.Legal_Cost_Vatable_Balance.HasValue ? inst.Legal_Cost_Vatable_Balance.Value : 0)
                        }).ToList();
                    }
                    else
                    {
                        objInstructionListViewModel.InstructionList = instructlist
                             .Where(x => (x.Matter.Matter_Reference.Equals(matterRefNo))
                                 )
                            .OrderBy(sort_Query).AsQueryable()
                            .Select(inst => new InstructionViewModel
                            {
                                ID = inst.ID,
                                SystemType_ID = inst.SystemType_ID,
                                System = inst.SystemType.SystemTypeName,
                                Status = inst.Status,
                                Instruction_Reference = inst.Instruction_Reference,
                                Matter_Reference = inst.Matter.Matter_Reference,
                                Vendor = inst.Vendor.Company_Name,
                                EditMatter = canEditMatter,
                                Payment_Clearance_Number = inst.Purchase_Order_Number,
                                EstimatedLegalCost = (inst.Estimated_Legal_Cost_Non_Vatable.HasValue ? inst.Estimated_Legal_Cost_Non_Vatable.Value : 0) + (inst.Estimated_Legal_Cost_Vatable.HasValue ? inst.Estimated_Legal_Cost_Vatable.Value : 0),
                                //EXICHM-376
                                Balance = (inst.Legal_Cost_Non_Vatable_Balance.HasValue ? inst.Legal_Cost_Non_Vatable_Balance.Value : 0) + (inst.Legal_Cost_Vatable_Balance.HasValue ? inst.Legal_Cost_Vatable_Balance.Value : 0)
                            }).ToList();
                    }
                }
                return objInstructionListViewModel.InstructionList;
            }
        }
        public static List<InstructionsContactViewModel> GetPendingContactRequestTaskListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField, out int recordCount)
        {
            using (ExternalInstructionsContactsRepository rep = new ExternalInstructionsContactsRepository())
            {
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "ID") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");

                var groupedQuery = rep.GetQuery()
                    .Where(m => m.Status == VarConstants.Instruction_Pending_Contacts)
                    .GroupBy(m => m.External_Instructions.Instruction_Reference)
                    .Select(lst => new { Instruction_Reference = lst.Key, Data = lst.OrderByDescending(m => m.ID).FirstOrDefault() });

                try
                {
                    if (!string.IsNullOrEmpty(searchField))
                    {
                        searchField = searchField.Trim();
                        groupedQuery = groupedQuery.Where(m => m.Instruction_Reference.Contains(searchField) || m.Data.External_Instructions.Matter.Matter_Reference.Contains(searchField));
                    }


                    //Get the total counts of all the records in all the pages.
                    recordCount = groupedQuery.Count();

                    var query = groupedQuery
                        .Select(m => new InstructionsContactViewModel
                        {
                            ID = m.Data.ID,
                            Assigned_To = m.Data.PeoplePicker.Full_Name,
                            Instruction_Reference = m.Instruction_Reference,
                            Status = m.Data.Status,
                            Days = DbFunctions.DiffDays(m.Data.Created, DateTime.Now).Value,

                            Matter = new MatterBlock
                            {
                                MatterReferenceNumber = m.Data.External_Instructions.Matter.Matter_Reference
                            }
                        })
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable();

                    var data = query.ToList();

                    return data;
                }
                catch (Exception ex)
                {
                    recordCount = 0;
                    return null;
                }
            }
        }


        /// <summary>
        /// Get the list of all reportable matters.
        /// </summary>
        /// <param name="limit">Number of rows to return</param>
        /// <param name="fromRowNumber">Row number to start display</param>
        /// <param name="sortColumn">Name of column to sort</param>
        /// <param name="sortDirection">Sort Direction asc / desc</param>
        /// <param name="recordCount">integer out paramter to get the total number of records available in database.</param>
        /// <param name="businessUnit">Business Unit name (Optional)</param>
        /// <param name="matterStatus">Matter Status (Optional)</param>
        /// <param name="repClassCategory">Report Classification Category (Optional)</param>
        /// <param name="repClass">Report Classification (Optional)</param>
        /// <returns><![CDATA[List<MatterViewModel>]]></returns>
        public static List<MatterViewModel> GetReportableMattersListByRustyLoading(int limit, int fromRowNumber, string sortColumn,
                                                                string sortDirection, out int recordCount,
                                                                string[] businessUnit = null, string matterStatus = null,
                                                                string[] country = null, string[] office = null, string[] operation = null,
                                                                string[] legalDiscipline = null, string[] subDiscipline = null, string[] reportTemplate = null,
                                                                string[] matterreportclassification = null, string[] leadLawyer = null, bool showReportable = false)
        {


            //Metter status values that should be allowed in list (only Active & Open for Billing).
            var statusValues = new string[] {
                EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.Active.ToString()),
                EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.OpenForBilling.ToString())
            };

            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Matter_Reference") + "  "
                + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");

            using (MatterRepository rep = new MatterRepository())
            {
                //Core condition for reportable matters.
                var query = rep.GetQuery()
                    .Where(m => statusValues.Contains(m.Matter_Status.Matter_Status1) && m.SystemType.SystemTypeName != SystemTypes.BusinessUnit.ToString());
                var isFilterSelected = false;

                //Applying custom filters.
                if (showReportable)
                {
                    query = query.Where(m => m.Reportable == Exigent.Common.Constants.CommonConstants.Yes);
                    isFilterSelected = true;
                }
                else
                {

                    if (businessUnit != null && businessUnit.Length > 0)
                    {
                        query = query.Where(m => businessUnit.Contains(m.Business_Unit_ID.ToString()));
                        isFilterSelected = true;
                    }
                    if (!string.IsNullOrEmpty(matterStatus))
                    {
                        query = query.Where(m => m.Matter_Status.ID.ToString() == matterStatus);
                        isFilterSelected = true;
                    }
                    if (country != null && country.Length > 0)
                    {
                        query = query.Where(m => country.Contains(m.CountryId.ToString()));
                        isFilterSelected = true;
                    }
                    if (office != null && office.Length > 0)
                    {
                        query = query.Where(m => office.Contains(m.User.Office.Id.ToString()));
                        isFilterSelected = true;
                    }
                    if (operation != null && operation.Length > 0)
                    {
                        query = query.Where(m => operation.Contains(m.Operation_ID.ToString()));
                        isFilterSelected = true;
                    }
                    if (legalDiscipline != null && legalDiscipline.Length > 0)
                    {
                        query = query.Where(m => legalDiscipline.Contains(m.LegalDisciplineId.ToString()));
                        isFilterSelected = true;
                    }
                    if (subDiscipline != null && subDiscipline.Length > 0)
                    {
                        query = query.Where(m => subDiscipline.Contains(m.SubDisciplineId.ToString()));
                        isFilterSelected = true;
                    }
                    if (reportTemplate != null && reportTemplate.Length > 0)
                    {
                        query = query.Where(m => reportTemplate.Contains(m.ApplicationReportTemplateId.ToString()));
                        isFilterSelected = true;
                    }
                    if (matterreportclassification != null && matterreportclassification.Length > 0)
                    {
                        query = query.Where(m => matterreportclassification.Contains(m.MatterReportClassificationOptionId.ToString()));
                        isFilterSelected = true;
                    }
                    if (leadLawyer != null && leadLawyer.Length > 0 && leadLawyer[0] != "")
                    {

                        query = query.Where(m => leadLawyer.Contains(m.Lead_Lawyer_ID.ToString()));
                        isFilterSelected = true;

                    }
                }

                //Get the total counts of all the records in all the pages.
                if (isFilterSelected)
                    recordCount = query.Count();
                else
                    recordCount = 0;

                if (!isFilterSelected || fromRowNumber > 0)
                {
                    return null;
                }

                if (sortColumn == "Matter_Reference")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.Matter_Reference);
                    else
                        query = query.OrderByDescending(x => x.Matter_Reference);
                }
                if (sortColumn == "Matter_Name")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.Matter_Name);
                    else
                        query = query.OrderByDescending(x => x.Matter_Name);
                }
                if (sortColumn == "Lead_Lawyer")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.User.FullName);
                    else
                        query = query.OrderByDescending(x => x.User.FullName);
                }
                if (sortColumn == "Operation")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.Operation.Operation1);
                    else
                        query = query.OrderByDescending(x => x.Operation.Operation1);
                }
                if (sortColumn == "Legal_Discipline")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.LegalDiscipline.Name);
                    else
                        query = query.OrderByDescending(x => x.LegalDiscipline.Name);
                }
                if (sortColumn == "Sub_Discipline")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.SubDiscipline.Name);
                    else
                        query = query.OrderByDescending(x => x.SubDiscipline.Name);
                }
                if (sortColumn == "Modified")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.Modified);
                    else
                        query = query.OrderByDescending(x => x.Modified);
                }
                if (sortColumn == "DateSentForUpdate")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.DateSentForUpdate);
                    else
                        query = query.OrderByDescending(x => x.DateSentForUpdate);
                }
                if (sortColumn == "DateReturned")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.DateReturned);
                    else
                        query = query.OrderByDescending(x => x.DateReturned);
                }
                if (sortColumn == "ReportableStatus")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.ReportableStatus);
                    else
                        query = query.OrderByDescending(x => x.ReportableStatus);
                }
                if (sortColumn == "Reportable")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.Reportable);
                    else
                        query = query.OrderByDescending(x => x.Reportable);
                }
                if (sortColumn == "Submission_Date")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(x => x.DateSendForReporting);
                    else
                        query = query.OrderByDescending(x => x.DateSendForReporting);
                }

                if (limit > 0)
                    query = query.Skip(fromRowNumber).Take(limit);


                //Apply sorting & obtain records for a page.
                var list = query.AsQueryable()
                        .Select(m => new MatterViewModel
                        {
                            ID = m.ID,
                            Matter_Reference = m.Matter_Reference,
                            Matter_Name = m.Matter_Name,
                            Lead_Lawyer = m.User.FullName,
                            Operation = m.Operation.Operation1,
                            Report_Classification = m.LegalDiscipline.Name,
                            Modified = m.Modified,
                            ReportableCount = m.ReportableCount,
                            Reportable = m.Reportable,
                            ReportableStatus = m.ReportableStatus,
                            DateSentForUpdate = m.DateSentForUpdate,
                            DateReturned = m.DateReturned,
                            HODComments = m.HODComments,
                            LegalDiscipline = m.LegalDiscipline.Name,
                            SubDiscipline = m.SubDiscipline.Name,
                            DateSendForReporting = m.DateSendForReporting
                        }).ToList();





                return list;

            }
        }

        ///// <summary>
        ///// vyom dixit, 3/21/2017, List active matters
        ///// </summary>
        ///// <param name="limit"></param>
        ///// <param name="fromRowNumber"></param>
        ///// <param name="sortColumn"></param>
        ///// <param name="sortDirection"></param>
        ///// <param name="searchField"></param>
        ///// <param name="filterBusinessUnit"></param>
        ///// <returns></returns>
        public static List<MatterViewModel> GetMattersListByRustyloading(int limit, int fromRowNumber, List<RoleViewModel> Roles, string sortColumn, string sortDirection, string searchField, int? filterBusinessUnit, int? filterOffice, int? filterCountry, int? filterLegalDiscipline, string loggedInUserFullName, string systemType, bool isAdminUser = false, bool isAdminMainDashboard = false, bool isHighlyConfidentialUser = false)
        {
            string matterClosedStatus = EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.Closed.ToString());
            //string creditedStatus = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Credited.ToString());
            string paid = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Paid.ToString());
            string openForBillingStatus = EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.OpenForBilling.ToString());
            // removed noELFIntStatus, activeStatus , code review item : JIRA - EXICHM-462
            using (MatterRepository _matterRepository = new MatterRepository())
            {
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Matter_Reference") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var matterlist = _matterRepository.GetQueryWithInclude("Invoices");
                MatterListViewModel objMatterListViewModel = new MatterListViewModel();

                //Check For Highly Confidential User
                if (!isHighlyConfidentialUser)
                    matterlist = matterlist.Where(x => x.IsHighlyConfidential != true);

                if (filterBusinessUnit > 0)
                {
                    matterlist = matterlist.Where(m => m.Business_Units.ID == filterBusinessUnit);
                }

                if (filterOffice > 0)
                {
                    matterlist = matterlist.Where(m => m.User.Office.Id == filterOffice);
                }
                if (filterCountry > 0)
                {
                    matterlist = matterlist.Where(m => m.CountryId == filterCountry);
                }
                if (filterLegalDiscipline > 0)
                {
                    matterlist = matterlist.Where(m => m.LegalDisciplineId == filterLegalDiscipline);
                }

                if (!string.IsNullOrEmpty(searchField))
                {
                    searchField = searchField.Trim();
                    matterlist = matterlist.Where(m => m.Matter_Reference.Contains(searchField) || m.Matter_Name.Contains(searchField));
                }
                if (!string.IsNullOrEmpty(systemType))
                    matterlist = matterlist.Where(x => x.SystemType.SystemTypeName.Equals(systemType));

                var matterCount = matterlist.Count();
                if (matterCount == 0)
                    return new List<MatterViewModel>();


                if (!string.IsNullOrEmpty(searchField) || filterBusinessUnit > 0 || filterOffice > 0 || filterCountry > 0 || filterLegalDiscipline > 0)
                {
                    if (isAdminUser)
                    {
                        objMatterListViewModel.MattersList = matterlist
                        .Where(x => x.Matter_Status.Matter_Status1 != matterClosedStatus)
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .AsEnumerable()
                        .Select(matter => new MatterViewModel
                        {
                            SystemType_ID = matter.SystemType_ID,
                            ID = matter.ID,
                            IsHighlyConfidential = (bool)matter.IsHighlyConfidential,
                            Matter_Name = matter.Matter_Name,
                            Matter_Reference = matter.Matter_Reference,
                            Business_Unit = matter.Business_Units.Business_Unit1,
                            System = matter.SystemType.SystemTypeName,
                            //EXICHM-376
                            MatterCost = matter.Matter_Cost, //matter.Invoices.Count > 0 ? ((matter.Invoices.Any(i => (i.Matter.Matter_Reference.Equals(matter.Matter_Reference))) ? matter.Invoices.Where(y => (y.Matter.Matter_Reference.Equals(matter.Matter_Reference)) && (y.Invoice_Status == paid)).Sum(x => (x.PreVat_Total.HasValue ? x.PreVat_Total.Value : 0)) : 0.0M)) : 0.0M,
                            Matter_Status = matter.Matter_Status.Matter_Status1,
                            Lead_Lawyer = matter.User != null ? matter.User.FullName : string.Empty,
                            Lead_Client = matter.PeoplePicker != null ? matter.PeoplePicker.Full_Name : string.Empty,
                            Key_Work_Stream = string.Join(";", matter.Matters_KeyWorkStream.Select(x => x.KeyWorkStream.Key_Work_Stream).ToArray()),
                            Legal_Practise_Area = matter.LegalDiscipline != null ? matter.LegalDiscipline.Name : string.Empty,
                            OfficeName = matter.User != null ? (matter.User.Office != null ? matter.User.Office.OfficeName : string.Empty) : string.Empty,
                            Country = matter.Country != null ? matter.Country.Country1 : string.Empty
                        }).ToList();
                    }
                    else
                    {
                        objMatterListViewModel.MattersList = matterlist
                       .Where(x => x.Matter_Status.Matter_Status1 != matterClosedStatus)
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                       .AsEnumerable()
                        .Select(matter => new MatterViewModel
                        {
                            SystemType_ID = matter.SystemType_ID,
                            ID = matter.ID,
                            IsHighlyConfidential = (bool)matter.IsHighlyConfidential,
                            Matter_Name = matter.Matter_Name,
                            Matter_Reference = matter.Matter_Reference,
                            Business_Unit = matter.Business_Units != null ? matter.Business_Units.Business_Unit1 : string.Empty,
                            System = matter.SystemType != null ? matter.SystemType.SystemTypeName : string.Empty,
                            //EXICHM-376
                            Assisting_Team_Members = string.Join(";", matter.Matters_AssistingTeamMembers.Select(x => x.PeoplePicker.Full_Name).ToArray()),
                            MatterCost = matter.Matter_Cost,//matter.Invoices.Count > 0 ? ((matter.Invoices.Any(i => (i.Matter.Matter_Reference.Equals(matter.Matter_Reference))) ? matter.Invoices.Where(y => (y.Matter.Matter_Reference.Equals(matter.Matter_Reference)) && (y.Invoice_Status == paid)).Sum(x => (x.PreVat_Total.HasValue ? x.PreVat_Total.Value : 0)) : 0.0M)) : 0.0M,
                            Matter_Status = matter.Matter_Status != null ? matter.Matter_Status.Matter_Status1 : string.Empty,
                            Lead_Lawyer = matter.User != null ? matter.User.FullName : string.Empty,
                            Lead_Client = matter.PeoplePicker != null ? matter.PeoplePicker.Full_Name : string.Empty,
                            Key_Work_Stream = string.Join(";", matter.Matters_KeyWorkStream.Select(x => x.KeyWorkStream.Key_Work_Stream).ToArray()),
                            Legal_Practise_Area = matter.LegalDiscipline != null ? matter.LegalDiscipline.Name : string.Empty,
                            OfficeName = matter.User != null ? (matter.User.Office != null ? matter.User.Office.OfficeName : string.Empty) : string.Empty,
                            Country = matter.Country != null ? matter.Country.Country1 : string.Empty
                        }).ToList();
                    }

                }
                else
                {

                    if (isAdminUser)
                    {
                        //var lists = matterlist.Where(x => x.Matter_Status.Matter_Status1 != matterClosedStatus && x.Matter_Status.Matter_Status1 != openForBillingStatus);
                        var list = matterlist.Where(x => x.Matter_Status.Matter_Status1 != matterClosedStatus && x.Matter_Status.Matter_Status1 != openForBillingStatus || (x.PeoplePicker != null ? ((x.PeoplePicker.Full_Name.ToLower() == loggedInUserFullName.ToLower() || x.Matters_AssistingTeamMembers.Any(y => y.PeoplePicker.Full_Name.ToLower() == loggedInUserFullName.ToLower())) && x.Matter_Status.Matter_Status1 == openForBillingStatus) : false));
                        objMatterListViewModel.MattersList = list
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .AsEnumerable()
                        .Select(matter => new MatterViewModel
                        {
                            ID = matter.ID,
                            IsHighlyConfidential = (bool)matter.IsHighlyConfidential,
                            Matter_Name = matter.Matter_Name,
                            Matter_Reference = matter.Matter_Reference,
                            Business_Unit = matter.Business_Units != null ? matter.Business_Units.Business_Unit1 : string.Empty,
                            System = matter.SystemType != null ? matter.SystemType.SystemTypeName : string.Empty,
                            SystemType_ID = matter.SystemType_ID,
                            //EXICHM-376
                            MatterCost = matter.Matter_Cost, //matter.Invoices.Count > 0 ? ((matter.Invoices.Any(i => (i.Matter.Matter_Reference.Equals(matter.Matter_Reference))) ? matter.Invoices.Where(y => (y.Matter.Matter_Reference.Equals(matter.Matter_Reference)) && (y.Invoice_Status == paid)).Sum(x => (x.PreVat_Total.HasValue ? x.PreVat_Total.Value : 0)) : 0.0M)) : 0.0M,
                            Matter_Status = matter.Matter_Status != null ? matter.Matter_Status.Matter_Status1 : string.Empty,
                            Lead_Lawyer = matter.User != null ? matter.User.FullName : string.Empty,
                            Lead_Client = matter.PeoplePicker != null ? matter.PeoplePicker.Full_Name : string.Empty,
                            Key_Work_Stream = string.Join(";", matter.Matters_KeyWorkStream.Select(x => x.KeyWorkStream.Key_Work_Stream).ToArray()),
                            Legal_Practise_Area = matter.LegalDiscipline != null ? matter.LegalDiscipline.Name : string.Empty,
                            OfficeName = matter.User != null ? (matter.User.Office != null ? matter.User.Office.OfficeName : string.Empty) : string.Empty,
                            Country = matter.Country != null ? matter.Country.Country1 : string.Empty
                        }).ToList();

                    }
                    else
                    {
                        var matterlst = Enumerable.Empty<Matter>();
                        if (systemType.Equals("BusinessUnit"))
                        {
                            matterlst = matterlist
                                  .Where(y => y.Matter_Status.Matter_Status1 != matterClosedStatus && (y.PeoplePicker != null ? (y.PeoplePicker.Full_Name.ToLower() == loggedInUserFullName.ToLower() || y.Matters_AssistingTeamMembers.Any(x => x.PeoplePicker.Full_Name.ToLower() == loggedInUserFullName.ToLower())) : false)).OrderBy(sort_Query).ToList();
                        }
                        else if (Roles.Any(x => x.Id == (int)(SystemTypeEnum.SeniorLegalLeadershipStaff) || x.Id == (int)(SystemTypeEnum.SuperGroupLegal)))
                        {
                            matterlst = matterlist
                                   .Where(y => y.Matter_Status.Matter_Status1 != matterClosedStatus && (y.User != null ? (y.User.FullName.ToLower() == loggedInUserFullName.ToLower() || y.Matters_AssistingTeamMembers.Any(x => x.PeoplePicker.Full_Name.ToLower() == loggedInUserFullName.ToLower())) : false)).OrderBy(sort_Query).ToList();
                        }
                        else
                        {
                            matterlst = matterlist
                                   .Where(y => y.Matter_Status.Matter_Status1 != matterClosedStatus && y.Matter_Status.Matter_Status1 != openForBillingStatus && (y.User != null ? (y.User.FullName.ToLower() == loggedInUserFullName.ToLower() || y.Matters_AssistingTeamMembers.Any(x => x.PeoplePicker.Full_Name.ToLower() == loggedInUserFullName.ToLower())) : false)).OrderBy(sort_Query).ToList();
                        }

                        objMatterListViewModel.MattersList = matterlst
                         .AsEnumerable()
                         .Select(matter => new MatterViewModel
                         {
                             ID = matter.ID,
                             SystemType_ID = matter.SystemType_ID,
                             IsHighlyConfidential = (bool)matter.IsHighlyConfidential,
                             Matter_Name = matter.Matter_Name,
                             Matter_Reference = matter.Matter_Reference,
                             Business_Unit = matter.Business_Units != null ? matter.Business_Units.Business_Unit1 : string.Empty,
                             //EXICHM-376
                             MatterCost = matter.Matter_Cost,//matter.Invoices.Count > 0 ? ((matter.Invoices.Any(i => (i.Matter.Matter_Reference.Equals(matter.Matter_Reference))) ? matter.Invoices.Where(y => (y.Matter.Matter_Reference.Equals(matter.Matter_Reference)) && (y.Invoice_Status == paid)).Sum(x => (x.PreVat_Total.HasValue ? x.PreVat_Total.Value : 0)) : 0.0M)) : 0.0M,
                             Matter_Status = matter.Matter_Status != null ? matter.Matter_Status.Matter_Status1 : string.Empty,
                             Lead_Lawyer = matter.User != null ? matter.User.FullName : string.Empty,
                             Lead_Client = matter.PeoplePicker != null ? matter.PeoplePicker.Full_Name : string.Empty,
                             Key_Work_Stream = string.Join(";", matter.Matters_KeyWorkStream.Select(x => x.KeyWorkStream.Key_Work_Stream).ToArray()),
                             Assisting_Team_Members = string.Join(";", matter.Matters_AssistingTeamMembers.Select(x => x.PeoplePicker.Full_Name).ToArray()),
                             Legal_Practise_Area = matter.LegalDiscipline != null ? matter.LegalDiscipline.Name : string.Empty,
                             OfficeName = matter.User != null ? (matter.User.Office != null ? matter.User.Office.OfficeName : string.Empty) : string.Empty,
                             Country = matter.Country != null ? matter.Country.Country1 : string.Empty
                         }).ToList().Skip(fromRowNumber).Take(limit).ToList();
                    }
                }
                return objMatterListViewModel.MattersList;
            }
        }


        ///// <summary>
        ///// </summary>
        ///// <param name="limit"></param>
        ///// <param name="fromRowNumber"></param>
        ///// <param name="sortColumn"></param>
        ///// <param name="sortDirection"></param>
        ///// <param name="searchField"></param>
        ///// <param name="filterBusinessUnit"></param>
        ///// <returns></returns>
        public static DraftMattersListViewModel GetDraftMattersListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField, int? filterBusinessUnit, int? filterOffice, int? filterCountry, int? filterLegalDiscipline, string loggedInUserFullName, string systemType, bool isAdminUser = false, bool isAdminMainDashboard = false, bool isHighlyConfidentialUser = false)
        {

            using (var rep = new DraftMattersRepository())
            {
                var model = new DraftMattersListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "ID") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery().Where(m => m.isFinalized == false);


                if (sortColumn == "ID")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.ID).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.ID).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Matter_Name")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Matter_Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Matter_Name).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Country")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Country.Country1).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Country.Country1).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Lead_Lawyer")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.User.FullName).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.User.FullName).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Business_Unit")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Business_Units.Business_Unit1).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Business_Units.Business_Unit1).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Matter_Status")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Matter_Status.Matter_Status1).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Matter_Status.Matter_Status1).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Office_Name")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.User.Office.OfficeName).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.User.Office.OfficeName).Skip(fromRowNumber).Take(limit);
                }
                else
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(m => m.ID).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(m => m.ID).Skip(fromRowNumber).Take(limit);
                }

                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.DraftMattersList = list.AsEnumerable()
                        .Select(m => new DraftMattersViewModel
                        {
                            ID = m.ID,
                            Matter_Name = m.Matter_Name != null ? m.Matter_Name : string.Empty,
                            Country = m.Country != null ? (m.Country.Country1 != null ? m.Country.Country1 : string.Empty) : string.Empty,
                            Lead_Lawyer = m.User != null ? (m.User.FullName != null ? m.User.FullName : string.Empty) : string.Empty,
                            Business_Unit = m.Business_Units != null ? (m.Business_Units.Business_Unit1 != null ? m.Business_Units.Business_Unit1 : string.Empty) : string.Empty,
                            Matter_Status = m.Matter_Status != null ? (m.Matter_Status.Matter_Status1 != null ? m.Matter_Status.Matter_Status1 : string.Empty) : string.Empty,
                            OfficeName = m.User != null ? (m.User.Office != null ? (m.User.Office.OfficeName != null ? m.User.Office.OfficeName : string.Empty) : string.Empty) : string.Empty,
                            LegalDiscipline = m.LegalDiscipline != null ? (m.LegalDiscipline.Name != null ? m.LegalDiscipline.Name : string.Empty) : string.Empty,
                            isFinalized = m.isFinalized ?? false,
                            Lead_Client_ID = m.Lead_Client_ID ?? 0,
                            Lead_Client = m.PeoplePicker != null ? m.PeoplePicker.Full_Name : string.Empty,
                            Assisting_Team_Members = m.DraftMatters_AssistingTeamMembers.Count > 0 ? string.Join(";", m.DraftMatters_AssistingTeamMembers.Select(x => x.PeoplePicker.Full_Name).ToArray()) : string.Empty,
                            Created_By = m.Created_By != null ? m.Created_By : string.Empty,
                        }).ToList();


                return model;
            }




        }


        /// <summary>
        /// vyom dixit, 3/21/2017, List active matters
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <param name="filterBusinessUnit"></param>
        /// <returns></returns>


        public static List<MatterViewModel> GetMattersApprovalListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            string creditedStatus = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Credited.ToString());
            string rejectedStatus = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Rejected.ToString());

            var model = new MatterListViewModel();
            using (MatterRepository rep = new MatterRepository())
            {
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Matter_Reference") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var matterlist = rep.GetQueryWithInclude("Invoices");

                model.MattersList = matterlist.Where(x => x.ReportableStatus == VarConstants.Reportable_PendingApproval)
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(m => new MatterViewModel
                        {
                            ID = m.ID,
                            Matter_Name = m.Matter_Name,
                            Matter_Reference = m.Matter_Reference,
                            Business_Unit = m.Business_Units.Business_Unit1,
                            System = m.SystemType.SystemTypeName,
                            MatterCost = m.Matter_Cost,//m.Invoices.Count > 0 ? ((m.Invoices.Any(i => (i.Matter.Matter_Reference.Equals(m.Matter_Reference))) ? m.Invoices.Where(y => (y.Matter.Matter_Reference.Equals(m.Matter_Reference)) && (y.Invoice_Status != creditedStatus && y.Invoice_Status != rejectedStatus)).Sum(x => (x.PreVat_Total.HasValue ? x.PreVat_Total.Value : 0)) : 0.0M)) : 0.0M,
                            Matter_Status = m.Matter_Status.Matter_Status1
                        }).ToList();
            }

            return model.MattersList;
        }

        public static List<MatterViewModel> GetInactiveMattersListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField, string loggedInUserFullName, out int recordCount)
        {
            string matterClosedStatus = EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.Closed.ToString());
            string creditedStatus = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Credited.ToString());
            string rejectedStatus = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Rejected.ToString());

            searchField = searchField.Trim();

            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Matter_Reference") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");

            using (MatterRepository rep = new MatterRepository())
            {
                //EXICHM-428 & search from Assisting Team Members
                var queryMatter = rep.GetQuery().Where(m => m.Matter_Status.Matter_Status1 == matterClosedStatus &&
                    m.SystemType.SystemTypeName == SystemTypes.GroupLegal.ToString())
                    // .OrderBy(sort_Query)
                    .ToList();

                var query = queryMatter.Where(m => (m.User.FullName.ToLower() == loggedInUserFullName.ToLower() ||
                (m.Matters_AssistingTeamMembers != null && m.Matters_AssistingTeamMembers.Any() ?
                 m.Matters_AssistingTeamMembers.Any(x => x.PeoplePicker.Full_Name == loggedInUserFullName.ToLowerInvariant()) : false)));

                if (!string.IsNullOrEmpty(searchField))
                    query = query.Where(m => m.Matter_Reference == searchField || m.Matter_Name.Contains(searchField));

                if (sortColumn == "Matter_Reference")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(m => m.Matter_Reference).Skip(fromRowNumber).Take(limit);
                    else
                        query = query.OrderByDescending(m => m.Matter_Reference).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Matter_Name")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(m => m.Matter_Name).Skip(fromRowNumber).Take(limit);
                    else
                        query = query.OrderByDescending(m => m.Matter_Name).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Business_Unit")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(m => m.Business_Units.Business_Unit1).Skip(fromRowNumber).Take(limit);
                    else
                        query = query.OrderByDescending(m => m.Business_Units.Business_Unit1).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Matter_Status")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(m => m.Matter_Status.Matter_Status1).Skip(fromRowNumber).Take(limit);
                    else
                        query = query.OrderByDescending(m => m.Matter_Status.Matter_Status1).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Legal_Practise_Area")
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(m => m.LegalDiscipline.Name).Skip(fromRowNumber).Take(limit);
                    else
                        query = query.OrderByDescending(m => m.LegalDiscipline.Name).Skip(fromRowNumber).Take(limit);
                }
                else
                {
                    if (sort_Query.Contains("asc"))
                        query = query.OrderBy(m => m.Matter_Reference).Skip(fromRowNumber).Take(limit);
                    else
                        query = query.OrderByDescending(m => m.Matter_Reference).Skip(fromRowNumber).Take(limit);
                }

                //Get the total counts of all the records in all the pages.
                recordCount = query.Count();

                return query
                    .Skip(fromRowNumber).Take(limit).AsQueryable().AsEnumerable()
                        .Select(m => new MatterViewModel
                        {
                            ID = m.ID,
                            Matter_Reference = m.Matter_Reference,
                            Business_Unit = m.Business_Units.Business_Unit1,
                            Matter_Status = m.Matter_Status.Matter_Status1,
                            Matter_Name = m.Matter_Name,
                            //EXICHM-376
                            MatterCost = m.Matter_Cost,//m.Invoices.Count > 0 ? ((m.Invoices.Any(i => (i.Matter.Matter_Reference.Equals(m.Matter_Reference))) ? m.Invoices.Where(y => (y.Matter.Matter_Reference.Equals(m.Matter_Reference)) && (y.Invoice_Status != creditedStatus && y.Invoice_Status != rejectedStatus)).Sum(x => (x.PreVat_Total.HasValue ? x.PreVat_Total.Value : 0)) : 0.0M)) : 0.0M,
                            Key_Work_Stream = string.Join(";", m.Matters_KeyWorkStream.Select(x => x.KeyWorkStream.Key_Work_Stream.ToString())),
                            Legal_Practise_Area = m.LegalDiscipline.Name
                        }).ToList();
            }
        }

        /// <summary>
        /// To check matter existence.
        /// </summary>
        /// <param name="matterRef"></param>
        /// <returns></returns>
        public static bool IsMatterExist(string matterRef)
        {
            bool result = false;
            string matter_reference = !string.IsNullOrEmpty(matterRef) ? matterRef.Trim().ToLower() : "NA";
            using (MatterRepository repository = new MatterRepository())
            {
                result = repository.GetQuery().Any(x => x.Matter_Reference.Trim().ToLower() == matter_reference);
            }
            return result;
        }

        public static List<SubMattersViewModel> GetSubMatterByReferenceNumber(string matterRef)
        {
            string matter_reference = !string.IsNullOrEmpty(matterRef) ? matterRef.Trim().ToLower() : "NA";
            SubMatterListViewModel subMatterListViewModel = new SubMatterListViewModel();
            MatterRepository matterRepository = new MatterRepository();
            SubMattersRepository _subMattersRepository = new SubMattersRepository();
            List<SubMattersViewModel> subMatterListViewModels = new List<SubMattersViewModel>();
            var matterDetial = matterRepository.Find(x => x.Matter_Reference.Trim().ToLower() == matter_reference).FirstOrDefault();

            var subMattersList = _subMattersRepository.GetQueryWithInclude("Matter");
            subMatterListViewModels = subMattersList.Where(x => (x.Matter.Matter_Reference.Equals(matterRef)))
                           .Select(subMttr => new SubMattersViewModel
                           {
                               Id = subMttr.Id,
                               Name = subMttr.Name,
                               date = subMttr.date,
                               FileName = subMttr.FileName,
                           }).ToList();
            return subMatterListViewModels;
        }

        public static List<MatterViewModel> GetMatterByReferenceNumber(string matterRef)
        {
            // JIRA : EXICHM-428 ( trimming & case matching for matter reference )
            string matter_reference = !string.IsNullOrEmpty(matterRef) ? matterRef.Trim().ToLower() : "NA";
            MatterListViewModel objMatterListViewModel = new MatterListViewModel();
            using (MatterRepository repository = new MatterRepository())
            {
                return objMatterListViewModel.MattersList = repository.GetQueryWithInclude("Invoices").Where(x => x.Matter_Reference.Trim().ToLower() == matter_reference)
                .Select(matter => new MatterViewModel
                {
                    ID = matter.ID,
                    Matter_Name = matter.Matter_Name,
                    Matter_Reference = matter.Matter_Reference,
                    Business_Unit = matter.Business_Units.Business_Unit1,
                    System = matter.SystemType.SystemTypeName,
                    MatterCost = matter.Matter_Cost,//matter.Invoices.Any() ? matter.Invoices.Sum(x => x.PreVat_Total.Value) : 0.0M,
                    Matter_Status = matter.Matter_Status.Matter_Status1,
                    IsHighlyConfidential = (bool)matter.IsHighlyConfidential,
                    Lead_Lawyer = matter.User.FullName,
                    SystemType_ID = matter.SystemType_ID,
                }).AsQueryable().ToList();
            }
        }


        /// <summary>
        /// Purpose : To list select matter invoices.
        /// vyom dixit, 03/29/2017
        /// </summary>
        /// <param name="limit">Total records to fetch</param>
        /// <param name="fromRowNumber">Start page no.</param>
        /// <param name="sortcolumn">Sort column name</param>
        /// <param name="sortDirection">Asc or Desc</param>
        /// <param name="searchField">Search text</param>
        /// <param name="isAdminUser">Has logged in user an admin</param>
        /// <param name="matterRef">Matter ref. no.</param>
        /// <returns></returns>
        public static List<InvoiceViewModel> GetMatterInoviceListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField, bool isAdminUser = false, string matterRef = "")
        {
            using (InvoiceRepository _invoiceRepository = new InvoiceRepository())
            {
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "External_Instructions.Instruction_Reference") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");
                var invoicelist = _invoiceRepository.GetQueryWithInclude("External_Instructions.Instruction_Reference");
                //string awaitingApproval = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.AwaitingApproval.ToString());
                InvoiceListViewModel objInvoiceListViewModel = new InvoiceListViewModel();
                if (!string.IsNullOrEmpty(searchField))
                {
                    if (isAdminUser && limit != -1)
                    {
                        objInvoiceListViewModel.Invoices = invoicelist
                        .Where(x => (x.Matter.Matter_Reference.Equals(searchField))
                        )
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(inv => new InvoiceViewModel
                        {
                            ID = inv.ID,
                            Invoice_Status = inv.Invoice_Status,
                            Vendor = inv.Vendor.Company_Name,
                            Invoice_Number = inv.Invoice_Number,
                            PreVat_Total = inv.PreVat_Total,
                            Instruction_Reference = inv.External_Instructions.Instruction_Reference,
                            PreVat_Total_InvCur = inv.PreVat_Total_InvCur,
                            CurrencySymbol = inv.CurrencyTable.Symbol,
                        }).ToList();
                    }
                    else if (limit > 0)
                    {
                        objInvoiceListViewModel.Invoices = invoicelist
                       .Where(x => (x.Matter.Matter_Reference.Equals(searchField)))
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                       .Select(inv => new InvoiceViewModel
                       {
                           ID = inv.ID,
                           Invoice_Status = inv.Invoice_Status,
                           Vendor = inv.Vendor.Company_Name,
                           Invoice_Number = inv.Invoice_Number,
                           PreVat_Total = inv.PreVat_Total,
                           Instruction_Reference = inv.External_Instructions.Instruction_Reference,
                           PreVat_Total_InvCur = inv.PreVat_Total_InvCur,
                           CurrencySymbol = inv.CurrencyTable.Symbol,
                       }).ToList();
                    }
                    else
                    {

                        objInvoiceListViewModel.Invoices = invoicelist
                           .Where(x => (x.Matter.Matter_Reference.Equals(searchField)))
                            .OrderBy(sort_Query).AsQueryable()
                           .Select(inv => new InvoiceViewModel
                           {
                               ID = inv.ID,
                               Invoice_Status = inv.Invoice_Status,
                               Vendor = inv.Vendor.Company_Name,
                               Invoice_Number = inv.Invoice_Number,
                               PreVat_Total = inv.PreVat_Total,
                               Instruction_Reference = inv.External_Instructions.Instruction_Reference,
                               PreVat_Total_InvCur = inv.PreVat_Total_InvCur,
                               CurrencySymbol = inv.CurrencyTable.Symbol,
                           }).ToList();

                    }

                }
                else
                {

                    if (isAdminUser && limit != -1)
                    {
                        objInvoiceListViewModel.Invoices = invoicelist
                        .Where(x => (x.Matter.Matter_Reference.Equals(matterRef))
                            )
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(inv => new InvoiceViewModel
                        {
                            ID = inv.ID,
                            Invoice_Status = inv.Invoice_Status,
                            Vendor = inv.Vendor.Company_Name,
                            Invoice_Number = inv.Invoice_Number,
                            PreVat_Total = inv.PreVat_Total,
                            Instruction_Reference = inv.External_Instructions.Instruction_Reference,
                            PreVat_Total_InvCur = inv.PreVat_Total_InvCur,
                            CurrencySymbol = inv.CurrencyTable.Symbol,
                        }).ToList();

                    }
                    else if (limit > 0)
                    {
                        objInvoiceListViewModel.Invoices = invoicelist
                         .Where(x => (x.Matter.Matter_Reference.Equals(matterRef)))
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(inv => new InvoiceViewModel
                        {
                            ID = inv.ID,
                            Invoice_Status = inv.Invoice_Status,
                            Vendor = inv.Vendor.Company_Name,
                            Invoice_Number = inv.Invoice_Number,
                            PreVat_Total = inv.PreVat_Total,
                            Instruction_Reference = inv.External_Instructions.Instruction_Reference,
                            PreVat_Total_InvCur = inv.PreVat_Total_InvCur,
                            CurrencySymbol = inv.CurrencyTable.Symbol,
                        }).ToList();


                    }
                    else
                    {
                        objInvoiceListViewModel.Invoices = invoicelist
                         .Where(x => (x.Matter.Matter_Reference.Equals(matterRef)))
                        .OrderBy(sort_Query).AsQueryable()
                        .Select(inv => new InvoiceViewModel
                        {
                            ID = inv.ID,
                            Invoice_Status = inv.Invoice_Status,
                            Vendor = inv.Vendor.Company_Name,
                            Invoice_Number = inv.Invoice_Number,
                            PreVat_Total = inv.PreVat_Total,
                            Instruction_Reference = inv.External_Instructions.Instruction_Reference,
                            PreVat_Total_InvCur = inv.PreVat_Total_InvCur,
                            CurrencySymbol = inv.CurrencyTable.Symbol,
                        }).ToList();
                    }
                }
                return objInvoiceListViewModel.Invoices;
            }
        }
        /// <summary>
        /// Purpose : To list select matter submatters.
        /// 
        /// </summary>
        /// <param name="limit">Total records to fetch</param>
        /// <param name="fromRowNumber">Start page no.</param>
        /// <param name="sortcolumn">Sort column name</param>
        /// <param name="sortDirection">Asc or Desc</param>
        /// <param name="searchField">Search text</param>
        /// <param name="isAdminUser">Has logged in user an admin</param>
        /// <param name="matterRef">Matter ref. no.</param>
        /// <returns></returns>
        public static List<SubMattersViewModel> GetSubMatterListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField, bool isAdminUser = false, string matterRef = "")
        {
            using (SubMattersRepository _subMattersRepository = new SubMattersRepository())
            {
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "MatterId") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");
                var subMattersList = _subMattersRepository.GetQueryWithInclude("Matter");
                SubMatterListViewModel objSubMatterListViewModel = new SubMatterListViewModel();
                if (!string.IsNullOrEmpty(searchField))
                {
                    if (isAdminUser && limit != -1)
                    {
                        objSubMatterListViewModel.SubMattersList = subMattersList
                        .Where(x => (x.Matter.Matter_Reference.Equals(searchField))

                        )
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(subMttr => new SubMattersViewModel
                        {
                            Id = subMttr.Id,
                            Name = subMttr.Name,
                            date = subMttr.date,
                            FileName = subMttr.FileName,
                        }).ToList();
                    }
                    else if (limit > 0)
                    {
                        objSubMatterListViewModel.SubMattersList = subMattersList
                       .Where(x => (x.Matter.Matter_Reference.Equals(searchField)))
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                       .Select(subMttr => new SubMattersViewModel
                       {
                           Id = subMttr.Id,
                           Name = subMttr.Name,
                           date = subMttr.date,
                           FileName = subMttr.FileName,
                       }).ToList();
                    }
                    else
                    {

                        objSubMatterListViewModel.SubMattersList = subMattersList
                           .Where(x => (x.Matter.Matter_Reference.Equals(searchField)))
                            .OrderBy(sort_Query).AsQueryable()
                            .Select(subMttr => new SubMattersViewModel
                            {
                                Id = subMttr.Id,
                                Name = subMttr.Name,
                                date = subMttr.date,
                                FileName = subMttr.FileName,
                            }).ToList();

                    }

                }
                else
                {

                    if (isAdminUser && limit != -1)
                    {
                        objSubMatterListViewModel.SubMattersList = subMattersList
                        .Where(x => (x.Matter.Matter_Reference.Equals(matterRef))

                            )
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(subMttr => new SubMattersViewModel
                        {
                            Id = subMttr.Id,
                            Name = subMttr.Name,
                            date = subMttr.date,
                            FileName = subMttr.FileName,
                        }).ToList();

                    }
                    else if (limit > 0)
                    {
                        objSubMatterListViewModel.SubMattersList = subMattersList
                         .Where(x => (x.Matter.Matter_Reference.Equals(matterRef)))
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(subMttr => new SubMattersViewModel
                        {
                            Id = subMttr.Id,
                            Name = subMttr.Name,
                            date = subMttr.date,
                            FileName = subMttr.FileName,
                        }).ToList();
                    }
                    else
                    {
                        objSubMatterListViewModel.SubMattersList = subMattersList
                         .Where(x => (x.Matter.Matter_Reference.Equals(matterRef)))
                        .OrderBy(sort_Query).AsQueryable()
                        .Select(subMttr => new SubMattersViewModel
                        {
                            Id = subMttr.Id,
                            Name = subMttr.Name,
                            date = subMttr.date,
                            FileName = subMttr.FileName,
                        }).ToList();
                    }
                }
                return objSubMatterListViewModel.SubMattersList;
            }
        }
        #endregion

        # region User
        // Shreya Garhwal- 03/08/2017, List users' details

        public List<UserListDetailViewModel> GetUsersListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField, out int rcount)
        {
            using (UserRepository _userRepository = new UserRepository())
            {

                UserListViewModel userListViewModel = new UserListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "FullName") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var userlist = _userRepository.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    userlist = userlist.Where(x => x.FullName != null && (x.FullName.Contains(searchField) || x.UserName.Contains(searchField)));
                    rcount = userlist.Count() > 0 ? userlist.Count() : 0;
                    userListViewModel.UsersList = userlist
                            .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                            .Select(user => new UserListDetailViewModel
                            {
                                UserName = user.UserName,
                                id = user.Id,
                                Email = user.Email,
                                FullName = user.FullName,
                                EntityId = user.EntityId,
                                IsActive = user.IsActive,
                                UserType = user.UserType.Description,
                                OfficeId = user.OfficeId,
                                OfficeName = user.Office.OfficeName
                            }).ToList();
                }
                else
                {
                    rcount = userlist.Count() > 0 ? userlist.Count() : 0;
                    userListViewModel.UsersList = userlist.OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                    .Select(user => new UserListDetailViewModel
                    {
                        UserName = user.UserName,
                        id = user.Id,
                        Email = user.Email,
                        FullName = user.FullName,
                        EntityId = user.EntityId,
                        IsActive = user.IsActive,
                        UserType = user.UserType.Description,
                        OfficeId = user.OfficeId,
                        OfficeName = user.Office.OfficeName
                    }).ToList();
                }
                return userListViewModel.UsersList;

            }
        }
        #endregion

        #region VendorDashboard

        /// <summary>
        /// get vendor active instructions
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchfield"></param>
        /// <param name="vendor"></param>
        /// <returns></returns>
        public static List<InstructionViewModel> GetActiveInstructionListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string vendor, out int rcnt)
        {
            DataSet ds = new DataSet();
            InstructionListViewModel objInsListViewModel = new InstructionListViewModel();
            sortColumn = !string.IsNullOrEmpty(sortColumn) ? sortColumn : "Days";
            sortDirection = !string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc";
            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Days") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
            SqlParameter prmVendor = new SqlParameter { ParameterName = "@vendor", DbType = System.Data.DbType.String, Value = vendor };
            SqlParameter prmStartPageIndex = new SqlParameter { ParameterName = "@prmStartPageIndex", DbType = System.Data.DbType.Int32, Value = fromRowNumber + 1 };
            SqlParameter prmEndPageIndex = new SqlParameter { ParameterName = "@prmEndPageIndex", DbType = System.Data.DbType.Int32, Value = ((fromRowNumber + 1) + (limit - 1)) };
            SqlParameter prmSortColumn = new SqlParameter { ParameterName = "@sortColumn", DbType = DbType.String, Value = sortColumn };
            SqlParameter prmsortDirection = new SqlParameter { ParameterName = "@sortDirection", DbType = DbType.String, Value = sortDirection };
            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetActiveInstructions, new SqlParameter[] { prmVendor, prmStartPageIndex, prmEndPageIndex, prmSortColumn, prmsortDirection });
            rcnt = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                var list = ds.Tables[0].ToList<InstructionViewModel>().AsQueryable();
                objInsListViewModel.InstructionList = list.Skip(fromRowNumber).Take(limit).ToList();
                rcnt = list.Count() > 0 ? list.Count() : 0;
            }
            return objInsListViewModel.InstructionList;
        }

        /// <summary>
        /// get vendor outstanding invoices
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="vendor"></param>
        /// <returns></returns>
        public static List<OutstandingInvoicesViewModel> GetOutstandingInvoicesListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string invoiceStatus, string vendor, bool isAdmin, out int rcnt)
        {
            DataSet ds = new DataSet();
            OutstandingInvoicesListViewModel objInListViewModel = new OutstandingInvoicesListViewModel();
            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Days") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
            SqlParameter prmVendor = new SqlParameter { ParameterName = "@vendor", DbType = System.Data.DbType.String, Value = vendor };
            SqlParameter prmisAdmin = new SqlParameter { ParameterName = "@isadmin", DbType = System.Data.DbType.Boolean, Value = isAdmin };
            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetOutstandingInvoices, new SqlParameter[] { prmVendor, prmisAdmin });
            rcnt = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                var list = ds.Tables[0].ToList<OutstandingInvoicesViewModel>().AsQueryable();
                if (!string.IsNullOrEmpty(invoiceStatus))
                {
                    list = list.Where(x => x.Invoice_Status.Equals(invoiceStatus));
                }
                list = list.OrderBy(sort_Query);
                objInListViewModel.OutstandingInvoiceList = list.Skip(fromRowNumber).Take(limit).ToList();
                rcnt = list.Count() > 0 ? list.Count() : 0;
            }

            return objInListViewModel.OutstandingInvoiceList;
        }


        /// <summary>
        /// get vendor rejected invoices
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="vendor"></param>
        /// <returns></returns>
        public static List<RejectedInvoicesViewModel> GetRejectedInvoicesListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string vendor, out int rcnt)
        {
            DataSet ds = new DataSet();
            RejectedInvoicesListViewModel objInListViewModel = new RejectedInvoicesListViewModel();
            sortColumn = !string.IsNullOrEmpty(sortColumn) ? sortColumn : "Matter_Reference";
            sortDirection = !string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc";
            if (sortColumn == "Rejection_Date")
                sortColumn = "RDate";
            SqlParameter prmVendor = new SqlParameter { ParameterName = "@vendor", DbType = System.Data.DbType.String, Value = vendor };
            SqlParameter prmStartPageIndex = new SqlParameter { ParameterName = "@prmStartPageIndex", DbType = System.Data.DbType.Int32, Value = fromRowNumber + 1 };
            SqlParameter prmEndPageIndex = new SqlParameter { ParameterName = "@prmEndPageIndex", DbType = System.Data.DbType.Int32, Value = ((fromRowNumber + 1) + (limit - 1)) };
            SqlParameter prmSortColumn = new SqlParameter { ParameterName = "@sortColumn", DbType = DbType.String, Value = sortColumn };
            SqlParameter prmsortDirection = new SqlParameter { ParameterName = "@sortDirection", DbType = DbType.String, Value = sortDirection };
            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetRejectedInvoices, new SqlParameter[] { prmVendor, prmStartPageIndex, prmEndPageIndex, prmSortColumn, prmsortDirection });
            rcnt = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                var list = ds.Tables[0].ToList<RejectedInvoicesViewModel>();
                objInListViewModel.RejectedInvoicesList = list.ToList();
                rcnt = list.Count() > 0 ? list.Count() : 0;
            }
            return objInListViewModel.RejectedInvoicesList;
        }

        /// <summary>
        /// get invoice by invoice number
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <param name="vendor"></param>
        /// <returns></returns>
        public static List<SearchInvoiceViewModel> GetInvoicesListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField, string vendor, bool isAdmin, out int rcnt)
        {
            DataSet ds = new DataSet();
            SearchInvoiceListViewModel objInListViewModel = new SearchInvoiceListViewModel();
            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Matter_Reference") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
            SqlParameter prmVendor = new SqlParameter { ParameterName = "@vendor", DbType = System.Data.DbType.String, Value = vendor };
            SqlParameter prmInvoiceNo = new SqlParameter { ParameterName = "@invoiceNo", DbType = System.Data.DbType.String, Value = searchField };
            SqlParameter prmisAdmin = new SqlParameter { ParameterName = "@isadmin", DbType = System.Data.DbType.Boolean, Value = isAdmin };
            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetInvoicesByInvoiceNumber, new SqlParameter[] { prmVendor, prmInvoiceNo, prmisAdmin });
            rcnt = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                var list = ds.Tables[0].ToList<SearchInvoiceViewModel>().AsQueryable().OrderBy(sort_Query);
                objInListViewModel.SearchInvoiceList = list.Skip(fromRowNumber).Take(limit).ToList();
                rcnt = list.Count() > 0 ? list.Count() : 0;
            }
            return objInListViewModel.SearchInvoiceList;
        }

        #endregion

        #region Invoices Dashboard

        public static List<InvoicesReadyForPaymentViewModel> GetnvoicesReadyForPaymentByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchText, out int recordCount)
        {
            /*SELECT 
             *      A.[Matter_Reference], A.[Instruction_Reference], C.Business_Unit, B.Billing_Entity, 
             *      A.[Vendor], A.[Invoice_Number], A.[Invoice_Status], A.[PreVat_Total], A.ID 
             *  FROM [Inform].[Invoices] A 
             *      LEFT JOIN [Inform].[External Instructions] B ON A.Instruction_Reference = B.Instruction_Reference 
             *      LEFT JOIN [Inform].[Client Companies] C ON B.Billing_Entity = C.Company_Name 
             *  WHERE Invoice_Status = 'Ready for Payment'*/

            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "External_Instructions.Instruction_Reference") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");

            using (InvoiceRepository rep = new InvoiceRepository())
            {
                var query = rep.GetQuery()
                    .Where(m => m.Invoice_Status == VarConstants.ReadyForPayment);

                if (!string.IsNullOrEmpty(searchText))
                {
                    searchText = searchText.Trim();
                    query = query.Where(x => x.Invoice_Number == searchText || x.External_Instructions.Instruction_Reference == searchText || x.Matter.Matter_Reference == searchText);
                }

                //Get the total counts of all the records in all the pages.
                recordCount = query.Count();


                var data = query.OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                                .Select(m => new InvoicesReadyForPaymentViewModel
                                {
                                    ID = m.ID,
                                    Matter_Reference = m.Matter != null ? m.Matter.Matter_Reference : string.Empty,
                                    Instruction_Reference = m.External_Instructions != null ? m.External_Instructions.Instruction_Reference : string.Empty,
                                    Billing_Entity = m.External_Instructions != null ? (m.External_Instructions.Client_Companies != null ? m.External_Instructions.Client_Companies.Company_Name : string.Empty) : string.Empty,
                                    Business_Unit = m.Matter.Business_Units != null ? m.Matter.Business_Units.Business_Unit1 : string.Empty,
                                    Invoice_Number = m.Invoice_Number,
                                    Invoice_Status = m.Invoice_Status,
                                    Vendor = m.Vendor != null ? m.Vendor.Company_Name : string.Empty,
                                    PreVat_Total = m.PreVat_Total,
                                    Payment_Processing_Email = m.User != null ? m.User.FullName : string.Empty,
                                    PreVat_Total_InvCur = m.PreVat_Total_InvCur,
                                    CurrencySymbol = m.Currency_ID != null && m.Currency_ID > 0 ? m.CurrencyTable.Symbol : string.Empty
                                }).ToList();

                var billingEntities = data.Where(a => !string.IsNullOrEmpty(a.Billing_Entity) && string.IsNullOrEmpty(a.Payment_Processing_Email)).Select(m => m.Billing_Entity).Distinct();

                if (billingEntities != null && billingEntities.Count() > 0)
                {
                    using (ClientComponyRepository repCC = new ClientComponyRepository())
                    {
                        var clientCompanies = repCC.GetQuery().Where(m => billingEntities.Contains(m.Company_Name))
                            .Select(m => new
                            {
                                Company_Name = m.Company_Name,
                                Payment_Processing = m.User.FullName
                            }).ToList();

                        data.ForEach(m =>
                        {
                            if (string.IsNullOrEmpty(m.Payment_Processing_Email))
                            {
                                var cc = clientCompanies.Where(a => a.Company_Name.Equals(m.Billing_Entity, StringComparison.CurrentCultureIgnoreCase)).FirstOrDefault();
                                m.Payment_Processing_Email = cc.Payment_Processing;
                            }
                        });
                    }
                }

                return data;

            }

        }

        public static List<InvoicesSentForPaymentViewModel> GetnvoicesSentForPaymentByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string invoiceNumber, string vendor, out int recordCount, bool hasAccess = false, int? currentUserID = 0)
        {
            /*SELECT 
             *      A.[Matter_Reference], A.[Instruction_Reference], C.Business_Unit, B.Billing_Entity, 
             *      A.[Vendor], A.[Invoice_Number], A.[Invoice_Status], A.[PreVat_Total], A.ID 
             *  FROM [Inform].[Invoices] A 
             *      LEFT JOIN [Inform].[External Instructions] B ON A.Instruction_Reference = B.Instruction_Reference 
             *      LEFT JOIN [Inform].[Client Companies] C ON B.Billing_Entity = C.Company_Name 
             *  WHERE Invoice_Status = 'Ready for Payment'*/

            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "External_Instructions.Instruction_Reference") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");

            using (InvoiceRepository rep = new InvoiceRepository())
            {
                var query = rep.GetQuery()
                    .Where(m => m.Invoice_Status == VarConstants.SentForPayment);

                if (!string.IsNullOrEmpty(invoiceNumber))
                {
                    invoiceNumber = invoiceNumber.Trim();
                    query = query.Where(x => x.Invoice_Number == invoiceNumber);
                }
                if (!string.IsNullOrEmpty(vendor))
                {
                    query = query.Where(x => x.Vendor.Company_Name == vendor);
                }

                //if (isGssUser)
                //{
                //    query = query.Where(x => x.User.UserName == currentUserName);
                //}

                //Get the total counts of all the records in all the pages.
                recordCount = query.Count();

                return query
                    .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                    .Select(m => new InvoicesSentForPaymentViewModel
                    {
                        ID = m.ID,
                        DateOfPayment = DateTime.Now,
                        SentForPayment = m.Sent_for_Payment,
                        Matter_Reference = m.Matter.Matter_Reference,
                        Instruction_Reference = m.External_Instructions.Instruction_Reference,
                        Billing_Entity = m.External_Instructions.Client_Companies.Company_Name,
                        Business_Unit = m.Matter.Business_Units.Business_Unit1,
                        Invoice_Number = m.Invoice_Number,
                        Invoice_Status = m.Invoice_Status,
                        Vendor = m.Vendor.Company_Name,
                        PreVat_Total = m.PreVat_Total,
                        Comments = m.Payment_Processing_Comments,
                        PreVat_Total_InvCur = m.PreVat_Total_InvCur,
                        CurrencySymbol = m.Currency_ID != null && m.Currency_ID > 0 ? m.CurrencyTable.Symbol : string.Empty,
                        AssignedTo = m.Payment_Processing_ID > 0 ? m.User.FullName : string.Empty,
                        AssignedTo_ID = m.Payment_Processing_ID,
                        OwnRecord = m.Payment_Processing_ID > 0 && m.Payment_Processing_ID == currentUserID ? true : false,
                        HasAccess = hasAccess
                    }).ToList();
            }

        }

        #endregion

        #region Invoice Audit

        /// <summary>
        ///  method to get Invoice Audit task list
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public static List<SearchInvoiceViewModel> GetInvoiceAuditListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string invoiceNo, out int rcnt)
        {
            DataSet ds = new DataSet();
            var objInListViewModel = new SearchInvoiceListViewModel();
            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Days") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");
            SqlParameter prmInvoiceNo = new SqlParameter { ParameterName = "@invoiceNo", DbType = System.Data.DbType.String, Value = invoiceNo };
            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetInvoiceAuditTask, new SqlParameter[] { prmInvoiceNo });
            rcnt = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                var list = ds.Tables[0].ToList<SearchInvoiceViewModel>().AsQueryable().OrderBy(sort_Query);
                objInListViewModel.SearchInvoiceList = list.Skip(fromRowNumber).Take(limit).ToList();
                rcnt = list.Count() > 0 ? list.Count() : 0;
            }
            return objInListViewModel.SearchInvoiceList;
        }

        #endregion

        #region Invoice Approval

        /// <summary>
        ///  method to get Invoice Approval task list
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public static List<SearchInvoiceViewModel> GetInvoiceApprovalListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string invoiceNo, string fullName, string matterRefNo, out int rcnt, string searchText = null)
        {
            DataSet ds = new DataSet();
            var objInListViewModel = new SearchInvoiceListViewModel();
            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Days") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");
            searchText = (!string.IsNullOrEmpty(searchText)) ? searchText.Trim() : string.Empty;

            SqlParameter prmInvoiceNo = new SqlParameter { ParameterName = "@invoiceNo", DbType = System.Data.DbType.String, Value = invoiceNo };
            SqlParameter prmName = new SqlParameter { ParameterName = "@GroupLawyer", DbType = System.Data.DbType.String, Value = fullName };
            SqlParameter prmMatter = new SqlParameter { ParameterName = "@MatterRefNo", DbType = System.Data.DbType.String, Value = matterRefNo };
            SqlParameter prmSearchText = new SqlParameter { ParameterName = "@SearchText", DbType = System.Data.DbType.String, Value = searchText };


            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetInvoiceApprovalTask, new SqlParameter[] { prmInvoiceNo, prmName, prmMatter, prmSearchText });
            rcnt = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                var list = ds.Tables[0].ToList<SearchInvoiceViewModel>().AsQueryable().OrderBy(sort_Query);
                objInListViewModel.SearchInvoiceList = list.Skip(fromRowNumber).Take(limit).ToList();
                rcnt = list.Count() > 0 ? list.Count() : 0;
            }
            return objInListViewModel.SearchInvoiceList;
        }

        #endregion

        #region Grv Tasks

        /// <summary>
        /// get grv tasks for account & exigent
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortcolumn"></param>
        /// <param name="sortdirection"></param>
        /// <param name="isAccount"></param>
        /// <returns></returns>
        public static List<GrvTasksViewModel> GetGrvTasksList(int limit, int fromRowNumber, string sortColumn, string sortDirection, bool isAccount, string searchNo, out int rcnt, string userFullName = null)
        {
            DataSet ds = new DataSet();
            var objInListViewModel = new GrvTasksListViewModel();
            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Days") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");
            SqlParameter prmIsAccount = new SqlParameter { ParameterName = "@isAccount", DbType = System.Data.DbType.Boolean, Value = isAccount };
            SqlParameter prmSearchNo = new SqlParameter { ParameterName = "@searchNo", DbType = System.Data.DbType.String, Value = searchNo };
            SqlParameter prmInvoiceNo = new SqlParameter { ParameterName = "@invoiceNo", DbType = System.Data.DbType.String, Value = string.Empty };
            SqlParameter prmUserFullName = new SqlParameter { ParameterName = "@UserFullName", DbType = System.Data.DbType.String, Value = userFullName };
            SqlParameter prmExp = new SqlParameter { ParameterName = "@IsExport", DbType = System.Data.DbType.Boolean, Value = false };

            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetGrvTasks, new SqlParameter[] { prmIsAccount, prmSearchNo, prmInvoiceNo, prmUserFullName, prmExp });
            rcnt = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                var list = ds.Tables[0].ToList<GrvTasksViewModel>().AsQueryable().OrderBy(sort_Query);
                objInListViewModel.GrvTasksList = list.Skip(fromRowNumber).Take(limit).ToList();
                rcnt = list.Count() > 0 ? list.Count() : 0;
            }
            return objInListViewModel.GrvTasksList;
        }

        /// <summary>
        /// get grv tasks by invoice number
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortcolumn"></param>
        /// <param name="sortdirection"></param>
        /// <param name="isAccount"></param>
        /// <returns></returns>
        public static List<SearchInvoiceViewModel> GetGrvTasks(bool isAccount, string searchNo, string invoiceNo)
        {
            DataSet ds = new DataSet();
            var objInListViewModel = new SearchInvoiceListViewModel();
            SqlParameter prmIsAccount = new SqlParameter { ParameterName = "@isAccount", DbType = System.Data.DbType.Boolean, Value = isAccount };
            SqlParameter prmSearchNo = new SqlParameter { ParameterName = "@searchNo", DbType = System.Data.DbType.String, Value = searchNo };
            SqlParameter prmInvoiceNo = new SqlParameter { ParameterName = "@invoiceNo", DbType = System.Data.DbType.String, Value = invoiceNo };
            SqlParameter prmExp = new SqlParameter { ParameterName = "@IsExport", DbType = System.Data.DbType.Boolean, Value = false };
            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetGrvTasks, new SqlParameter[] { prmIsAccount, prmSearchNo, prmInvoiceNo, prmExp });
            if (ds != null && ds.Tables.Count > 0)
            {
                objInListViewModel.SearchInvoiceList = ds.Tables[0].ToList<SearchInvoiceViewModel>().AsQueryable().ToList();
            }
            return objInListViewModel.SearchInvoiceList;
        }

        #endregion

        #region Timesheet Dashboard

        public List<InvoiceTimesheetCaptureTasksListViewModel> GetPendingTimesheets(int limit, int fromRowNumber, string sortColumn, string sortDirection, out int rcount)
        {
            using (InvoiceTimesheetRepository _invoiceTimesheetRepository = new InvoiceTimesheetRepository())
            {
                InvoiceTimesheetCaptureTasksViewModel invoiceTimesheetViewModel = new InvoiceTimesheetCaptureTasksViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "ID") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var timesheetsList = _invoiceTimesheetRepository.GetQueryWithInclude("Invoice");

                timesheetsList = timesheetsList.Where(x => x.Status == "Pending");
                rcount = timesheetsList.Count() > 0 ? timesheetsList.Count() : 0;
                invoiceTimesheetViewModel.TimesheetsList = timesheetsList.OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                    .Select(timesheet => new InvoiceTimesheetCaptureTasksListViewModel
                    {
                        ID = timesheet.ID,
                        InvoiceVM = new InvoiceViewModel
                        {
                            Vendor = !string.IsNullOrEmpty(timesheet.Invoice.Vendor.Company_Name) ? timesheet.Invoice.Vendor.Company_Name : " ",
                            Invoice_Number = !string.IsNullOrEmpty(timesheet.Invoice.Invoice_Number) ? timesheet.Invoice.Invoice_Number : " ",
                            Invoice_Status = !string.IsNullOrEmpty(timesheet.Invoice.Invoice_Status) ? timesheet.Invoice.Invoice_Status : " ",
                            PreVat_Total = timesheet.Invoice.PreVat_Total
                        }
                    }).ToList();
                return invoiceTimesheetViewModel.TimesheetsList;

            }
        }

        public List<InvoiceTimesheetsViewModel> GetTimesheets(int limit, int fromRowNumber, string sortColumn, string sortDirection, string invoiceNumber, out int rcount)
        {
            using (TimesheetRepository _timesheetRepository = new TimesheetRepository())
            {
                List<InvoiceTimesheetsViewModel> timesheetListViewModel = new List<InvoiceTimesheetsViewModel>();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "ID") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var timesheetsList = _timesheetRepository.GetQuery();

                timesheetsList = timesheetsList.Where(x => x.Invoice_Number == invoiceNumber);
                rcount = timesheetsList.Count() > 0 ? timesheetsList.Count() : 0;
                timesheetListViewModel = timesheetsList.OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                    .Select(timesheet => new InvoiceTimesheetsViewModel
                    {
                        ID = timesheet.ID,
                        InvoiceID = timesheet.InvoiceID,
                        Lawyer = timesheet.Lawyer,
                        Date = timesheet.Date,
                        //Task=timesheet.Task,
                        Detail = timesheet.Detail,
                        Hours = timesheet.Hours,
                        Amount = timesheet.Amount,
                        Discrepancy = timesheet.Discrepancy,
                        Invoice_Number = timesheet.Invoice_Number,
                    }).ToList();
                return timesheetListViewModel;

            }
        }

        #endregion

        #region PO Tasks

        /// <summary>
        /// method to get po tasks list
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="invoiceNo"></param>
        /// <param name="rcnt"></param>
        /// <returns></returns>
        public static List<SearchInvoiceViewModel> GetPOTaskListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, int purchaseId, out int rcnt, string userFullName = null)
        {
            DataSet ds = new DataSet();
            var objInListViewModel = new SearchInvoiceListViewModel();
            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Days") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");
            SqlParameter prmPurchaseId = new SqlParameter { ParameterName = "@purchaseId", DbType = System.Data.DbType.Int32, Value = purchaseId };
            SqlParameter prmUserFullName = new SqlParameter { ParameterName = "@UserFullName", DbType = System.Data.DbType.String, Value = userFullName };
            SqlParameter prmExp = new SqlParameter { ParameterName = "@IsExport", DbType = System.Data.DbType.Boolean, Value = false };
            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetPOTasks, new SqlParameter[] { prmPurchaseId, prmUserFullName, prmExp });
            rcnt = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                var list = ds.Tables[0].ToList<SearchInvoiceViewModel>().AsQueryable().OrderBy(sort_Query);
                objInListViewModel.SearchInvoiceList = list.Skip(fromRowNumber).Take(limit).ToList();
                rcnt = list.Count() > 0 ? list.Count() : 0;
            }
            return objInListViewModel.SearchInvoiceList;
        }


        public static List<MatterPOTaskViewModel> GetMatterPOTaskListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string matterReference, out int rcnt)
        {
            DataSet ds = new DataSet();
            var objInListViewModel = new List<MatterPOTaskViewModel>();
            sortColumn = !string.IsNullOrEmpty(sortColumn) ? sortColumn : "ID";
            sortDirection = !string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc";
            SqlParameter prmMatterRefNo = new SqlParameter { ParameterName = "@prmMatterRefNo", DbType = System.Data.DbType.String, Value = matterReference };
            SqlParameter prmStartPageIndex = new SqlParameter { ParameterName = "@prmStartPageIndex", DbType = System.Data.DbType.Int32, Value = fromRowNumber + 1 };
            SqlParameter prmEndPageIndex = new SqlParameter { ParameterName = "@prmEndPageIndex", DbType = System.Data.DbType.Int32, Value = ((fromRowNumber + 1) + (limit - 1)) };
            SqlParameter prmSortColumn = new SqlParameter { ParameterName = "@sortColumn", DbType = DbType.String, Value = sortColumn };
            SqlParameter prmsortDirection = new SqlParameter { ParameterName = "@sortDirection", DbType = DbType.String, Value = sortDirection };
            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetPOTasksByMatterRef, new SqlParameter[] { prmMatterRefNo, prmStartPageIndex, prmEndPageIndex, prmSortColumn, prmsortDirection });
            rcnt = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                var list = ds.Tables[0].ToList<MatterPOTaskViewModel>();//.AsQueryable().OrderBy(sort_Query);
                objInListViewModel = list.ToList(); //.Skip(fromRowNumber).Take(limit).ToList();
                rcnt = list.Count() > 0 ? list.Count() : 0;
            }
            return objInListViewModel;
        }

        public static List<MatterGRVTaskViewModel> GetMatterGRVTaskListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string matterReference, out int rcnt)
        {
            DataSet ds = new DataSet();
            var objInListViewModel = new List<MatterGRVTaskViewModel>();
            sortColumn = !string.IsNullOrEmpty(sortColumn) ? sortColumn : "Vendor";
            sortDirection = !string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc";
            SqlParameter prmMatterRefNo = new SqlParameter { ParameterName = "@prmMatterRefNo", DbType = System.Data.DbType.String, Value = matterReference };
            SqlParameter prmStartPageIndex = new SqlParameter { ParameterName = "@prmStartPageIndex", DbType = System.Data.DbType.Int32, Value = fromRowNumber + 1 };
            SqlParameter prmEndPageIndex = new SqlParameter { ParameterName = "@prmEndPageIndex", DbType = System.Data.DbType.Int32, Value = ((fromRowNumber + 1) + (limit - 1)) };
            SqlParameter prmSortColumn = new SqlParameter { ParameterName = "@sortColumn", DbType = DbType.String, Value = sortColumn };
            SqlParameter prmsortDirection = new SqlParameter { ParameterName = "@sortDirection", DbType = DbType.String, Value = sortDirection };
            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetGRVTasksByMatterRef, new SqlParameter[] { prmMatterRefNo, prmStartPageIndex, prmEndPageIndex, prmSortColumn, prmsortDirection });
            rcnt = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                var list = ds.Tables[0].ToList<MatterGRVTaskViewModel>();//.AsQueryable().OrderBy(sort_Query);
                objInListViewModel = list.ToList();
                rcnt = list.Count() > 0 ? list.Count() : 0;
            }
            return objInListViewModel;
        }

        /// <summary>
        /// Displays all instructions relevant to the signed in user that has invoices that are unabled to be processed due to not enough money left over
        /// </summary>
        /// <param name="limit">No. of records to fetch at a single request.</param>
        /// <param name="fromRowNumber">starting row number</param>
        /// <param name="sortColumn">sort column name</param>
        /// <param name="sortDirection"> sort direction asc/desc</param>
        /// <param name="fullName">logged in user full name</param>
        /// <param name="rcnt"></param>
        /// <returns></returns>
        public static List<POIncreaseRequiredViewModel> GetPOIncreaseRequiredListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string fullName, out int rcnt)
        {
            DataSet ds = new DataSet();
            var objInListViewModel = new List<POIncreaseRequiredViewModel>();
            sortColumn = !string.IsNullOrEmpty(sortColumn) ? sortColumn : "ID";
            sortDirection = !string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc";
            SqlParameter prmFullName = new SqlParameter { ParameterName = "@prmFullName", DbType = System.Data.DbType.String, Value = fullName };
            SqlParameter prmStartPageIndex = new SqlParameter { ParameterName = "@prmStartPageIndex", DbType = System.Data.DbType.Int32, Value = fromRowNumber + 1 };
            SqlParameter prmEndPageIndex = new SqlParameter { ParameterName = "@prmEndPageIndex", DbType = System.Data.DbType.Int32, Value = ((fromRowNumber + 1) + (limit - 1)) };
            SqlParameter prmSortColumn = new SqlParameter { ParameterName = "@sortColumn", DbType = DbType.String, Value = sortColumn };
            SqlParameter prmsortDirection = new SqlParameter { ParameterName = "@sortDirection", DbType = DbType.String, Value = sortDirection };
            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetPOIncreaseRequiredList, new SqlParameter[] { prmFullName, prmStartPageIndex, prmEndPageIndex, prmSortColumn, prmsortDirection });
            rcnt = 0;
            if (ds != null && ds.Tables.Count > 0)
            {
                var list = ds.Tables[0].ToList<POIncreaseRequiredViewModel>();
                objInListViewModel = list.ToList();
                rcnt = list.Count() > 0 ? list.Count() : 0;
            }
            return objInListViewModel;
        }

        #endregion

        #region BU Dashboard

        /// <summary>
        /// method to get rfq by matter
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortcolumn"></param>
        /// <param name="sortdirection"></param>
        /// <param name="matterRef"></param>
        /// <returns></returns>
        public static List<RFQViewModel> GetMatterRFQListByRustyloading(int limit, int fromRowNumber, string sortcolumn, string sortdirection, string matterRef, string loginUser, out int rcnt)
        {
            using (RFQRepository rfqRepository = new RFQRepository())
            {
                var lstRfq = new List<RFQViewModel>();
                var tblRfq = rfqRepository.Find(x => x.Matter.Matter_Reference == matterRef && x.Status != VarConstants.Complete);
                rcnt = 0;
                foreach (var rfq in tblRfq)
                {
                    lstRfq.Add(new RFQViewModel
                    {
                        Background_To_Request = rfq.Background_To_Request,
                        Services_Required = rfq.Services_Required,
                        Date = DateTime.Parse(rfq.To_Respond_By.ToString()).ToString(AppConstants.DATEFORMAT_SERVER, CultureInfo.InvariantCulture),
                        Status = rfq.Status,
                        ID = rfq.ID,
                        IsUserRFQ = rfq.Matter.PeoplePicker.Full_Name == loginUser
                    });
                }
                return lstRfq;
            }
        }


        #endregion

        #region Export Tasks

        public static DataTable GetPOTaskListByRustyloading(string sortColumn, string sortDirection, int purchaseId, string userFullName = null)
        {
            DataSet ds = new DataSet();
            var objInListViewModel = new SearchInvoiceListViewModel();
            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Days") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");
            SqlParameter prmPurchaseId = new SqlParameter { ParameterName = "@purchaseId", DbType = System.Data.DbType.Int32, Value = purchaseId };
            SqlParameter prmUserFullName = new SqlParameter { ParameterName = "@UserFullName", DbType = System.Data.DbType.String, Value = userFullName };
            SqlParameter prmExp = new SqlParameter { ParameterName = "@IsExport", DbType = System.Data.DbType.Boolean, Value = true };
            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetPOTasks, new SqlParameter[] { prmPurchaseId, prmUserFullName, prmExp });

            if (ds != null && ds.Tables.Count > 0)
                return ds.Tables[0];

            return null;
        }

        public static DataTable GetGrvTasksList(string sortColumn, string sortDirection, bool isAccount, string searchNo, string userFullName = null)
        {
            DataSet ds = new DataSet();
            var objInListViewModel = new GrvTasksListViewModel();
            string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Days") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "desc");
            SqlParameter prmIsAccount = new SqlParameter { ParameterName = "@isAccount", DbType = System.Data.DbType.Boolean, Value = isAccount };
            SqlParameter prmSearchNo = new SqlParameter { ParameterName = "@searchNo", DbType = System.Data.DbType.String, Value = searchNo };
            SqlParameter prmInvoiceNo = new SqlParameter { ParameterName = "@invoiceNo", DbType = System.Data.DbType.String, Value = string.Empty };
            SqlParameter prmUserFullName = new SqlParameter { ParameterName = "@UserFullName", DbType = System.Data.DbType.String, Value = userFullName };
            SqlParameter prmExp = new SqlParameter { ParameterName = "@IsExport", DbType = System.Data.DbType.Boolean, Value = true };

            ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetGrvTasks, new SqlParameter[] { prmIsAccount, prmSearchNo, prmInvoiceNo, prmUserFullName, prmExp });
            if (ds != null && ds.Tables.Count > 0)
                return ds.Tables[0];

            return null;
        }

        #endregion

        #region Admin Control Panel

        /// <summary>
        /// Get the list of all Business Units.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>
        public BusinesUnitListViewModel GetBUListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new BusinessUnitRepository())
            {

                var model = new BusinesUnitListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Business_Unit1") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.Business_Unit1 != null && (x.Business_Unit1.Contains(searchField) || x.ShortName.Contains(searchField) || x.Acronym.Contains(searchField)));
                }

                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(m => new BusinesUnitViewModel
                        {
                            Id = m.ID,
                            Business_Unit = m.Business_Unit1,
                            Color = m.Color,
                            Acronym = m.Acronym,
                            ShortName = m.ShortName
                        }).ToList();

                return model;
            }
        }

        /// <summary>
        /// Get the list of all vendors.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>
        public VendorListViewModel GetVendorListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new VendorRepository())
            {

                var model = new VendorListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Company_Name") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.Company_Name != null && x.Company_Name.Contains(searchField));
                }

                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(m => new VendorViewModel
                        {
                            Id = m.ID,
                            Company_Name = m.Company_Name,
                            Category = m.Category,
                            Color = m.Color,
                            Email = m.Email,
                            IsActive = (m.Active == "Yes")
                        }).ToList();

                return model;
            }
        }

        /// <summary>
        /// Get the list of all legal desciplines for vendor and BU access.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>
        public LegalDesciplineListViewModel GetLegalDesciplineListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new BUVendorAccessRepository())
            {

                var model = new LegalDesciplineListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Vendor") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.Vendor != null && (x.Vendor.Company_Name.Contains(searchField)
                                                             || x.LegalDiscipline.Name.Contains(searchField)
                                                             || x.Business_Units.Business_Unit1.Contains(searchField)
                                                             || x.Email.Contains(searchField)));
                }

                if (sortColumn == "Legal_Discipline")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.LegalDiscipline.Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.LegalDiscipline.Name).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Vendor")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Vendor.Company_Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Vendor.Company_Name).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Business_Unit")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Business_Units.Business_Unit1).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Business_Units.Business_Unit1).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Email")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Email).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Email).Skip(fromRowNumber).Take(limit);
                }
                else
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.LegalDiscipline.Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.LegalDiscipline.Name).Skip(fromRowNumber).Take(limit);
                }



                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list
                        .Select(m => new LegalDesciplineViewModel
                        {
                            Id = m.ID,
                            Vendor = m.Vendor.Company_Name,
                            Business_Unit = m.Business_Units.Business_Unit1,
                            Legal_Discipline = m.LegalDiscipline.Name,
                            Email = m.Email

                        }).ToList();

                return model;
            }
        }


        /// <summary>
        /// Get the list of all currencies.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>
        public CurrencyListViewModel GetCurrencyListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new CurrencyRepository())
            {
                var model = new CurrencyListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "CurrencyCode") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.CurrencyCode.Contains(searchField) || x.Currency.Contains(searchField) || x.Symbol.Contains(searchField));
                }
                if (sortColumn == "CurrencyCode")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.CurrencyCode).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.CurrencyCode).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Currency")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Currency).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Currency).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Symbol")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Symbol).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Symbol).Skip(fromRowNumber).Take(limit);
                }
                else
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.CurrencyCode).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.CurrencyCode).Skip(fromRowNumber).Take(limit);
                }
                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list
                        .Select(m => new CurrencyViewModel
                        {
                            Id = m.Id,
                            CurrencyCode = m.CurrencyCode,
                            Currency = m.Currency,
                            Symbol = m.Symbol
                        }).ToList();

                return model;
            }
        }

        /// <summary>
        /// Get the list of all countries.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>
        public CountryListViewModel GetCountryListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new CountryRepository())
            {
                var model = new CountryListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "CntryCode") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.Country1.Contains(searchField) || x.ISO_CntryCode.Contains(searchField));
                }

                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(m => new CountryViewModel
                        {
                            Id = m.Id,
                            CntryCode = m.CntryCode,
                            Country = m.Country1,
                            ISO_CntryCode = m.ISO_CntryCode,
                            IsActive = m.IsActive,
                        }).ToList();

                return model;
            }
        }



        /// <summary>
        /// Get the list of all key work streams.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>
        public KeyWorkStreamListViewModel GetKeyWorkStreamListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new KeyWorkStreamRepository())
            {
                var model = new KeyWorkStreamListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Key_Work_Stream") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.Key_Work_Stream.Contains(searchField));
                }

                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(m => new KeyWorkStreamViewModel
                        {
                            Id = m.ID,
                            Key_Work_Stream = m.Key_Work_Stream
                        }).ToList();

                return model;
            }
        }

        /// <summary>
        /// Get the list of all operations.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>
        public OperationListViewModel GetOperationListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new OperationsRepository())
            {
                var model = new OperationListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Operation1") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.Operation1.Contains(searchField) || x.Business_Units.Business_Unit1.Contains(searchField));
                }
                if (sortColumn == "Operation1")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Operation1).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Operation1).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Business_Unit")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Business_Units.Business_Unit1).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Business_Units.Business_Unit1).Skip(fromRowNumber).Take(limit);
                }
                else
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Operation1).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Operation1).Skip(fromRowNumber).Take(limit);
                }

                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list

                        .Select(m => new OperationViewModel
                        {
                            Id = m.ID,
                            Business_Unit = m.Business_Units.Business_Unit1,
                            Operation = m.Operation1,
                        }).ToList();

                return model;
            }
        }

        /// <summary>
        /// Get the list of all client companies.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>
        public ClientCompanyListViewModel GetClientCompanyListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new ClientComponyRepository())
            {
                var model = new ClientCompanyListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Company_Name") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.Company_Name.Contains(searchField) || x.Business_Units.Business_Unit1.Contains(searchField));
                }
                if (sortColumn == "Company_Name")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Company_Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Company_Name).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Business_Unit")
                {

                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Business_Units.Business_Unit1).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Business_Units.Business_Unit1).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Registration_Number")
                {

                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Registration_Number).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Registration_Number).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Vat_Number")
                {

                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Vat_Number).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Vat_Number).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "GRV")
                {

                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.GRV).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.GRV).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "PO")
                {

                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.PO).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.PO).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Payment_Processing")
                {

                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.User.FullName).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.User.FullName).Skip(fromRowNumber).Take(limit);
                }
                else
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Company_Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Company_Name).Skip(fromRowNumber).Take(limit);
                }



                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list

                        .Select(m => new ClientCompanyViewModel
                        {
                            Id = m.ID,
                            BusinessUnit_ID = m.Business_Units.ID,
                            Business_Unit = m.Business_Units.Business_Unit1,
                            Company_Name = m.Company_Name,
                            GRV = m.GRV,
                            PO = m.PO,
                            Payment_Processing = m.User.FullName,
                            Registration_Number = m.Registration_Number,
                            Vat_Number = m.Vat_Number,
                        }).ToList();

                return model;
            }
        }

        /// <summary>
        /// Get the list of all vendor lawyers.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>
        public VendorLawyerListViewModel GetVendorLawyerListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new VendorLawyerRepository())
            {
                var model = new VendorLawyerListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Vendor") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.Vendor.Company_Name.Contains(searchField) || x.Lawyer.Contains(searchField));
                }
                if (sortColumn == "Vendor")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Vendor.Company_Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Vendor.Company_Name).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Lawyer")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Lawyer).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Lawyer).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Rate")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Rate).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Rate).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "HDSA")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.HDSA).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.HDSA).Skip(fromRowNumber).Take(limit);
                }
                else
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Vendor.Company_Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Vendor.Company_Name).Skip(fromRowNumber).Take(limit);
                }

                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list

                        .Select(m => new VendorLawyerViewModel
                        {
                            Id = m.ID,
                            Vendor_ID = m.Vendor.ID,
                            Lawyer = m.Lawyer,
                            Vendor1 = m.Vendor.Company_Name,
                            HDSA = m.HDSA,
                            Rate = (m.Rate.HasValue) ? m.Rate.Value : 0,
                        }).ToList();

                return model;
            }
        }

        /// <summary>
        /// Get the list of all People Picker.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>
        public PeoplePickerListViewModel GetPeoplePickerListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new PeoplePickerRepository())
            {
                var model = new PeoplePickerListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Full_Name") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.Full_Name.Contains(searchField) || x.Email.Contains(searchField));
                }

                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list
                        .OrderBy(sort_Query).Skip(fromRowNumber).Take(limit).AsQueryable()
                        .Select(m => new PeoplePickerViewModel
                        {
                            ID = m.ID,
                            Full_Name = m.Full_Name,
                            Email = m.Email,
                        }).ToList();

                return model;
            }
        }

        public EmailTemplatesListViewModel GetEmailTemplatesListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new EmailRepository())
            {
                var model = new EmailTemplatesListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Name") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.Name.Contains(searchField));
                }
                if (sortColumn == "Name")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Name).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "EmailSubject")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.EmailSubject).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.EmailSubject).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "FromEmail")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.FromEmail).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.FromEmail).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "FromName")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.FromName).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.FromName).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Category")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.EmailCategory.Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.EmailCategory.Name).Skip(fromRowNumber).Take(limit);
                }
                else
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Name).Skip(fromRowNumber).Take(limit);
                }


                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list
                        .Select(m => new EmailTemplateViewModel
                        {
                            ID = m.Id,
                            Name = m.Name,
                            TextContent = m.TextContent,
                            EmailContent = m.EmailContent,
                            EmailSubject = m.EmailSubject,
                            EmailFrom = m.FromEmail,
                            FromName = m.FromName,
                            Category = m.EmailCategory.Name
                        }).ToList();

                return model;
            }
        }


        /// <summary>
        /// Get the list of offices.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>

        public OfficesListViewModel GetOfficeListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new OfficeRepository())
            {
                var model = new OfficesListViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Office") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.OfficeName.Contains(searchField));
                }
                if (sortColumn == "Office")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.OfficeName).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.OfficeName).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Country")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Country.Country1).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Country.Country1).Skip(fromRowNumber).Take(limit);
                }
                else if (sortColumn == "Active")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.IsActive).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.IsActive).Skip(fromRowNumber).Take(limit);
                }
                else
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.OfficeName).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.OfficeName).Skip(fromRowNumber).Take(limit);
                }


                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list
                        .Select(m => new OfficesViewModel
                        {
                            Id = m.Id,
                            OfficeName = m.OfficeName,
                            Country = m.Country.Country1,
                            IsActive = m.IsActive
                        }).ToList();

                return model;
            }
        }

        public BUTimeRecordingViewModel GetBUTimeRecordingListByRustyloading(string sortColumn, string sortDirection, int? userId)
        {
            var RecordCount = 0;
            using (var rep = new BUTimeRecordingRepository())
            {
                var model = new BUTimeRecordingViewModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Business_Units.Business_Unit1") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();
                RecordCount = list.Count() > 0 ? list.Count() : 0;
                model.EntityList = list.OrderBy(sort_Query).AsQueryable()
                    .Where(m => m.UserId == userId && (m.Month == DateTime.Now.Month.ToString() || m.Month == (DateTime.Now.Month - 1).ToString()))
                    .Select(m => new BUTimeRecordingViewModel
                    {
                        BusinessUnitId = m.Business_Unit_ID,
                        Business_Unit = m.Business_Units != null ? m.Business_Units.Business_Unit1 : string.Empty,
                        LegalDisciplineId = m.LegalDisciplineId,
                        Legal_Discipline = m.LegalDiscipline != null ? m.LegalDiscipline.Name : string.Empty,
                        BUTimeValue = m.BUTimeValue,
                        Month = m.Month,
                        BusinessUnitColor = m.Business_Units != null ? m.Business_Units.Color : string.Empty,
                        Id = m.ID
                    }).ToList();
                model.ListForCurrentMonth = model.EntityList.Where(m => m.Month == DateTime.Now.Month.ToString()).ToList();
                model.ListForPreviousMonth = model.EntityList.Where(m => m.Month == (DateTime.Now.Month - 1).ToString()).ToList();
                return model;
            }

        }


        /// <summary>
        /// Get the list of Report Classification.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="searchField"></param>
        /// <returns></returns>

        public ReportClassificationOptionsListViemModel GetReportClassificationOptionListByRustyloading(int limit, int fromRowNumber, string sortColumn, string sortDirection, string searchField)
        {
            using (var rep = new ReportClassificationOptionRepository())
            {
                var model = new ReportClassificationOptionsListViemModel();
                string sort_Query = (!string.IsNullOrEmpty(sortColumn) ? sortColumn : "Name") + "  " + (!string.IsNullOrEmpty(sortDirection) ? sortDirection : "asc");
                var list = rep.GetQuery();

                if (!string.IsNullOrEmpty(searchField))
                {
                    list = list.Where(x => x.Name.Contains(searchField));
                }
                if (sortColumn == "Name")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Name).Skip(fromRowNumber).Take(limit);
                }

                else if (sortColumn == "Active")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.IsActive).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.IsActive).Skip(fromRowNumber).Take(limit);
                }

                else if (sortColumn == "IsReportable")
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.IsReportable).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.IsReportable).Skip(fromRowNumber).Take(limit);
                }
                else
                {
                    if (sort_Query.Contains("asc"))
                        list = list.OrderBy(x => x.Name).Skip(fromRowNumber).Take(limit);
                    else
                        list = list.OrderByDescending(x => x.Name).Skip(fromRowNumber).Take(limit);
                }


                model.RecordCount = list.Count() > 0 ? list.Count() : 0;

                model.EntityList = list
                        .Select(m => new ReportClassificationsOptionsViewModel
                        {
                            Id = m.Id,
                            Name = m.Name,
                            IsActive = m.IsActive,
                            IsReportable = m.IsReportable
                        }).ToList();

                return model;
            }
        }
        #endregion

    }
}


