﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.BLL
{
    public class CurrencyManager
    {
        public static CurrencyViewModel GetCurrencyById(int id)
        {
            using (var rep = new CurrencyRepository())
            {
                var model = rep.GetQuery().Where(m => m.Id == id)
                    .Select(m => new CurrencyViewModel
                    {
                        Id = m.Id,
                        CurrencyCode = m.CurrencyCode,
                        Currency = m.Currency,
                        Symbol = m.Symbol
                    }).FirstOrDefault();

                return model;
            }
        }

        public static bool IsExists(CurrencyViewModel model)
        {
            using (var rep = new CurrencyRepository())
            {
                return rep.Any(p => p.Id != model.Id && (p.Currency == model.Currency.Trim() || p.CurrencyCode == model.CurrencyCode.Trim()));
            }
        }

        public static bool UpdateCurrency(CurrencyViewModel model)
        {
            using (var rep = new CurrencyRepository())
            {
                var dt = rep.GetQuery().Where(m => m.Id == model.Id).FirstOrDefault();

                if (dt == null)
                    return false;
                dt.CurrencyCode = model.CurrencyCode;
                dt.Symbol = model.Symbol;

                rep.SaveChanges();
            }

            return true;
        }

        public static string CreateCurrency(CurrencyViewModel model)
        {
            using (var rep = new CurrencyRepository())
            {
                var dt = new CurrencyTable
                {
                    CurrencyCode = model.CurrencyCode,
                    Currency = model.Currency,
                    Symbol = model.Symbol,
                };

                rep.Add(dt);
                rep.SaveChanges();

                return dt.CurrencyCode;
            }
        }

    }
}
