﻿using Exigent.DataLayer.Repository;
using Exigent.EF.Data.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System.Collections.Generic;
using System.Linq;

namespace Exigent.BLL
{
    public class PeoplePickerManager
    {
        /// <summary>
        /// Get users email list (separated by semi column).
        /// </summary>
        /// <param name="fullName">string User's full names (separated by a separator)</param>
        /// <param name="separator">Separator symbol used</param>
        /// <returns>User's email list (separated by semi column)</returns>
        public static string GetUsersEmailAddress(string fullName, string separator)
        {
            var usersEmails = string.Empty;
            using (PeoplePickerRepository peoplePickerRepository = new PeoplePickerRepository())
            {
                var usersEmailList = peoplePickerRepository.Find(x => fullName.Contains(x.Full_Name)).Select(y => y.Email);

                if (usersEmailList != null)
                    usersEmails = string.Join(";", usersEmailList.ToArray());
            }            

            return usersEmails;
        }


		public static int GetPeoplePickerIDByName(string fullName)
		{
			int ID = 0;
			using (PeoplePickerRepository peoplePickerRepository = new PeoplePickerRepository())
			{
				ID = peoplePickerRepository.Find(x => x.Full_Name == fullName).Select(y => y.ID).FirstOrDefault();
			}
			return ID;
		}

		/// <summary>
		/// get user email address
		/// </summary>
		/// <param name="fullName"></param>
		/// <returns></returns>
		public static string GetUserEmailAddress(string fullName)
        {
            var usersEmail = string.Empty;
            using (PeoplePickerRepository peoplePickerRepository = new PeoplePickerRepository())
            {
                usersEmail = peoplePickerRepository.Find(x => x.Full_Name == fullName).Select(y => y.Email).FirstOrDefault();
            }
            return usersEmail;
        }

        /// <summary>
        /// get user email address
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public static string GetUserEmail(string name)
        {
            var usersEmail = string.Empty;
            using (UserRepository repo = new UserRepository())
            {
                usersEmail = repo.Find(x => x.UserName == name).Select(y => y.Email).FirstOrDefault();
            }
            return usersEmail;
        }

        // Save user in people-picker table
        public void AddUserInPeoplePicker(PeoplePickerViewModel peoplePickerViewModel)
        {
            
            using (PeoplePickerRepository _peoplePickerRepository = new PeoplePickerRepository())
            {
                PeoplePicker peoplePicker = new PeoplePicker();
                peoplePicker.Full_Name = peoplePickerViewModel.Full_Name;
                peoplePicker.Email = peoplePickerViewModel.Email.Trim();
                _peoplePickerRepository.Add(peoplePicker);
                _peoplePickerRepository.SaveChanges();
            }
           
            //}
        }

		public bool IsPeoplePickerExists(int ID)
		{
			using (PeoplePickerRepository _peoplePickerRepository = new PeoplePickerRepository())
			{
				return _peoplePickerRepository.Any(p => p.ID == ID);
			}
		}

		//Check if full name exists
		public bool IsFullNameExists(string fullName)
        {
            using (PeoplePickerRepository _peoplePickerRepository = new PeoplePickerRepository())
            {
                return _peoplePickerRepository.Any(p => p.Full_Name == fullName);
            }
        }

		#region Master Manager Functionality.

        public static PeoplePickerViewModel GetPeoplePickerById(int id)
        {
            using (var rep = new PeoplePickerRepository())
            {
                var model = rep.GetQuery().Where(m => m.ID == id)
                    .Select(m => new PeoplePickerViewModel
                    {
                        ID = m.ID,
                        Full_Name = m.Full_Name,
                        Email = m.Email,
                    }).FirstOrDefault();

                return model;
            }
        }

        public static bool IsExists(int id, string fullName)
        {
            using (PeoplePickerRepository _peoplePickerRepository = new PeoplePickerRepository())
            {
                return _peoplePickerRepository.Any(p => p.Full_Name == fullName && p.ID != id);
            }
        }

        public static bool UpdatePeoplePicker(PeoplePickerViewModel model)
        {
            using (var rep = new PeoplePickerRepository())
            {
                var dt = rep.GetQuery().Where(m => m.ID == model.ID).FirstOrDefault();

                if (dt == null)
                    return false;

               
                dt.Email = model.Email;

                rep.SaveChanges();
            }

            return true;
        }

        public static int CreatePeoplePicker(PeoplePickerViewModel model)
        {
            using (var rep = new PeoplePickerRepository())
            {
                var dt = new PeoplePicker
                {
                    Full_Name = model.Full_Name,
                    Email = model.Email,
                };

                rep.Add(dt);
                rep.SaveChanges();

                return dt.ID;
            }
        }
        #endregion
    }
}
