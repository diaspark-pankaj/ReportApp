﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using Exigent_ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Exigent.BLL
{
    public class ReportClassificationOptionManager
    {
        public static List<ReportClassificationOptionVM> GetReportClassificationOption(int matterId = 0)
        {
            var lstReportClassificationOption = new List<ReportClassificationOptionVM>();
            using (ReportClassificationOptionRepository reportClassificationOptionRepository = new ReportClassificationOptionRepository())
            {
                reportClassificationOptionRepository.Find(x => x.IsActive == true).Select(x => new { Id = x.Id, Name = x.Name,IsReportable=x.IsReportable }).Distinct().ToList().ForEach(y => lstReportClassificationOption.Add(
                            new ReportClassificationOptionVM
                            {
                                Id = y.Id,
                                Name = y.Name.ToString(),
                                IsChecked = false,
                                IsReportable=y.IsReportable
                            }));

            }
            List<MatterReportClassificationOptionsMappingViewModel> lstMatterReportClassificationOptions = GetMatterReportClassificationOptionsMapping(matterId);

            foreach (var item in lstMatterReportClassificationOptions)
            {
                lstReportClassificationOption.Where(x => x.Id == item.OptionId).FirstOrDefault(p => p.IsChecked = true);
            }
            return lstReportClassificationOption.OrderBy(x => x.Name).ToList();
        }

        public static List<MatterReportClassificationOptionsMappingViewModel> GetMatterReportClassificationOptionsMapping(int matterId)
        {
            MatterReportClassificationOptionsMappingViewModel matterReportClassificationOptionsMappingViewModel = new MatterReportClassificationOptionsMappingViewModel();
            List<MatterReportClassificationOptionsMappingViewModel> lstMatterReportClassificationOptions = new List<MatterReportClassificationOptionsMappingViewModel>();
            MatterReportClassificationOptionsMappingRepository matterReportClassificationOptionsMappingRepository = new MatterReportClassificationOptionsMappingRepository();

            var matterReportMappingList = matterReportClassificationOptionsMappingRepository.Find(x => x.MatterId == matterId).ToList();
            if (matterReportMappingList.Any())
            {
                foreach (var item in matterReportMappingList)
                {
                    matterReportClassificationOptionsMappingViewModel = new MatterReportClassificationOptionsMappingViewModel();
                    matterReportClassificationOptionsMappingViewModel.Id = item.Id;
                    matterReportClassificationOptionsMappingViewModel.MatterId = item.MatterId;
                    matterReportClassificationOptionsMappingViewModel.OptionId = item.OptionId;
                    lstMatterReportClassificationOptions.Add(matterReportClassificationOptionsMappingViewModel);
                }
            }
            return lstMatterReportClassificationOptions;
        }

        public static bool IsExists(ReportClassificationsOptionsViewModel model)
        {
            using (var rep = new ReportClassificationOptionRepository())
            {
                return rep.Any(p => p.Id != model.Id && (p.Name == model.Name.Trim()));
            }
        }

        public static string CreateReportClassificationsOption(ReportClassificationsOptionsViewModel model)
        {
            using (var rep = new ReportClassificationOptionRepository())
            {
                var dt = new ReportClassificationOption
                {
                    Name = model.Name,
                    IsActive = model.IsActive,
                    IsReportable = Convert.ToBoolean(model.IsReportable)
                };

                rep.Add(dt);
                rep.SaveChanges();

                return dt.Name;
            }
        }

        public static ReportClassificationsOptionsViewModel GetReportClassificationsOptionsById(int id)
        {
            using (var rep = new ReportClassificationOptionRepository())
            {
                var model = rep.GetQuery().Where(m => m.Id == id)
                    .Select(m => new ReportClassificationsOptionsViewModel
                    {
                        Id = m.Id,
                        Name = m.Name,
                        IsActive = m.IsActive,
                        IsReportable = m.IsReportable
                    }).FirstOrDefault();

                return model;
            }
        }

        public static bool UpdateReportClassificationOption(ReportClassificationsOptionsViewModel model)
        {
            using (var rep = new ReportClassificationOptionRepository())
            {
                var dt = rep.GetQuery().Where(m => m.Name == model.Name).FirstOrDefault();

                if (dt == null)
                    return false;
                dt.Name = model.Name;
                dt.IsActive = model.IsActive;
                dt.IsReportable =  Convert.ToBoolean(model.IsReportable);

                rep.SaveChanges();
            }

            return true;
        }

        public static List<ReportClassificationOptionVM> GetReportClassificationOptionForDraft(int matterId = 0)
        {
            var lstReportClassificationOption = new List<ReportClassificationOptionVM>();
            using (ReportClassificationOptionRepository reportClassificationOptionRepository = new ReportClassificationOptionRepository())
            {
                reportClassificationOptionRepository.Find(x => x.IsActive == true).Select(x => new { Id = x.Id, Name = x.Name, IsReportable = x.IsReportable }).Distinct().ToList().ForEach(y => lstReportClassificationOption.Add(
                               new ReportClassificationOptionVM
                               {
                                   Id = y.Id,
                                   Name = y.Name.ToString(),
                                   IsChecked = false,
                                   IsReportable = y.IsReportable
                               }));

            }
            List<MatterReportClassificationOptionsMappingViewModel> lstMatterReportClassificationOptions = GetDraftMatterReportClassificationOptionsMapping(matterId);

            foreach (var item in lstMatterReportClassificationOptions)
            {
                lstReportClassificationOption.Where(x => x.Id == item.OptionId).FirstOrDefault(p => p.IsChecked = true);
            }
            return lstReportClassificationOption.OrderBy(x => x.Name).ToList();
        }


        public static List<MatterReportClassificationOptionsMappingViewModel> GetDraftMatterReportClassificationOptionsMapping(int matterId)
        {
            MatterReportClassificationOptionsMappingViewModel matterReportClassificationOptionsMappingViewModel = new MatterReportClassificationOptionsMappingViewModel();
            List<MatterReportClassificationOptionsMappingViewModel> lstMatterReportClassificationOptions = new List<MatterReportClassificationOptionsMappingViewModel>();
            DraftMatterReportClassificationOptionsMappingRepository matterReportClassificationOptionsMappingRepository = new DraftMatterReportClassificationOptionsMappingRepository();

            var matterReportMappingList = matterReportClassificationOptionsMappingRepository.Find(x => x.DraftMatterId == matterId).ToList();
            if (matterReportMappingList.Any())
            {
                foreach (var item in matterReportMappingList)
                {
                    matterReportClassificationOptionsMappingViewModel = new MatterReportClassificationOptionsMappingViewModel();
                    matterReportClassificationOptionsMappingViewModel.Id = item.Id;
                    matterReportClassificationOptionsMappingViewModel.MatterId = item.DraftMatterId;
                    matterReportClassificationOptionsMappingViewModel.OptionId = item.OptionId;
                    lstMatterReportClassificationOptions.Add(matterReportClassificationOptionsMappingViewModel);
                }
            }
            return lstMatterReportClassificationOptions;
        } 
    }
}
