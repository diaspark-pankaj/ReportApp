﻿using Exigent.Common.Constants;
using Exigent.DataLayer.Repository;
//using Exigent.EF.Data.AbstractRepository;
using Exigent.EF.Data.Repository;
using Exigent.ViewModels.Admin;
using Exigent.ViewModels.Common;
using Exigent_ViewModels.DropDowns;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;

namespace Exigent_BusinessLogicLayer.DropDowns
{
    public class DropDownManager
    {

        //Gets list of roles
        public List<RolesViewModel> GetRolesListForDropDown()
        {
            using (RolesRepository _rolesRepository = new RolesRepository())
            {
                return _rolesRepository.Find(q => q.IsActive).Select(r => new RolesViewModel
                                                                                    {
                                                                                        Id = r.Id,
                                                                                        RoleName = r.Name
                                                                                    }).ToList();
            }
        }

        // Gets UserType details from UserType table
        public List<UserTypeViewModel> GetUserTypes()
        {
            using (UserTypeRepository _userTypeRepository = new UserTypeRepository())
            {
                return _userTypeRepository.Find(x => x.IsActive == true).Select(x => new UserTypeViewModel
                {
                    Id = x.ID,
                    Description = x.Description,
                    SortOrder = x.SortOrder,
                    IsActive = x.IsActive
                }).ToList();
            }
        }

        //Get Office details for office table

       public List<OfficeViewModel> GetOfficesList()
        {
            using (OfficeRepository _officeRepository = new OfficeRepository())
            {
                return _officeRepository.Find(x => x.IsActive == true).Select(x => new OfficeViewModel
                {
                    Id = x.Id,
                    CountryId = x.CountryId,
                    OfficeName = x.OfficeName,
                    IsActive = x.IsActive
                }).ToList();
            }
        }

        // Get Lawyers list for timesheet against an invoice
        public static List<SelectListItem> GetLawyersList(string invoiceNumber)
        {
            InvoiceRepository _invoicerepo = new InvoiceRepository();
            var objVendor = _invoicerepo.Find(x => x.Invoice_Number.Equals(invoiceNumber)).ToList();

            if (objVendor.Count() > 0)
            {
                if (objVendor.FirstOrDefault().Vendor.VendorLawyers.Any())
                {
                    return objVendor.FirstOrDefault().Vendor.VendorLawyers
                        .Select(x => new SelectListItem()
                        {
                            Value = x.ID.ToString(),
                            Text = x.Lawyer
                        }).ToList();
                }
                return null;
            }
            else
            {
                return null;
            }

        }

		/// <summary>
		/// Get Vendor-Lawyers list against an instruction
		/// </summary>
		/// <param name="instructionID">Required instruction ID.</param>
		/// <returns>List of SelectListItem</returns>
		public static List<SelectListItem> GetLawyersListByInstructionID(int instructionID)
		{
			using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
			{
				var objVendor = rep.Find(x => x.ID == instructionID).Select(x => x.Vendor).ToList();

				if (objVendor.Count() > 0)
				{
					if (objVendor.FirstOrDefault().VendorLawyers.Any())
					{
						return objVendor.FirstOrDefault().VendorLawyers
							.Select(x => new SelectListItem()
							{
								Value = x.ID.ToString(),
								Text = x.Lawyer
							}).ToList();
					}
					return null;
				}
				else
				{
					return null;
				}
			}
		}

		/// <summary>
		/// Get Vendor-Lawyers list against an instruction
		/// </summary>
		/// <param name="instructionReference">Required instruction reference number.</param>
		/// <returns>List of SelectListItem</returns>
		public static List<SelectListItem> GetLawyersListByInstruction(string instructionReference)
        {
            using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
            {
                var objVendor = rep.Find(x => x.Instruction_Reference.Equals(instructionReference)).Select(x => x.Vendor).ToList();

                if (objVendor.Count() > 0)
                {
                    if (objVendor.FirstOrDefault().VendorLawyers.Any())
                    {
                        return objVendor.FirstOrDefault().VendorLawyers
                            .Select(x => new SelectListItem()
                            {
                                Value = x.ID.ToString(),
                                Text = x.Lawyer
                            }).ToList();
                    }
                    return null;
                }
                else
                {
                    return null;
                }
            }
        }

        // Get Tasks list for timesheet
        public static List<SelectListItem> GetTasksList()
        {
            TimesheetTaskRepository timesheetRepository = new TimesheetTaskRepository();
            return timesheetRepository.GetAll().Select(x => new SelectListItem()
            {
                Value = x.Task,
                Text = x.Task
            }).ToList();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static string[] GetInvoiceStatus()
        {
            var InvoiceStatusArray = new string[] { VarConstants.SentForPayment, VarConstants.Approved, VarConstants.AwaitingGRV, VarConstants.ReadyForPayment, VarConstants.AwaitingApproval, VarConstants.AwaitingAudit };
            return InvoiceStatusArray;
        }
    }
}
