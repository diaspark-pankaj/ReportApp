﻿using Exigent.DataLayer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Exigent.BLL
{
    public class LegalDisciplineManager
    {
        public static List<SelectListItem> GetLegalDiscipline()
        {
            var lstLegalDiscipline = new List<SelectListItem>();
            using (LegalDisciplineRepository legalDisciplineRepository = new LegalDisciplineRepository())
            {
                legalDisciplineRepository.Find(x => x.IsActive == true).Select(x => new { Id = x.ID, Name = x.Name }).Distinct().ToList().ForEach(y => lstLegalDiscipline.Add(
                            new SelectListItem
                            {
                                Text = y.Name,
                                Value = y.Id.ToString()
                            }));

            }
            return lstLegalDiscipline.OrderBy(x => x.Text).ToList();
        }
     }
}
