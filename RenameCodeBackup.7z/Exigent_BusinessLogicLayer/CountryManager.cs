﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.BLL
{
    public class CountryManager
    {
        public static CountryViewModel GetCountryById(int id)
        {
            using (var rep = new CountryRepository())
            {
                var model = rep.GetQuery().Where(m => m.Id == id)
                    .Select(m => new CountryViewModel
                    {
                        Id = m.Id,
                        CntryCode = m.CntryCode,
                        Country = m.Country1,
                        ISO_CntryCode = m.ISO_CntryCode,
                        IsActive = m.IsActive
                    }).FirstOrDefault();

                return model;
            }
        }

        public static bool IsExists(CountryViewModel model)
        {
            using (var rep = new CountryRepository())
            {
                return rep.Any(p => p.Id != model.Id && (p.Country1 == model.Country.Trim() || p.CntryCode == model.CntryCode.Trim() || p.ISO_CntryCode == model.ISO_CntryCode.Trim()));
            }
        }

        public static bool UpdateCountry(CountryViewModel model)
        {
            using (var rep = new CountryRepository())
            {
                var dt = rep.GetQuery().Where(m => m.CntryCode == model.CntryCode).FirstOrDefault();

                if (dt == null)
                    return false;

                dt.CntryCode = model.CntryCode;
                dt.ISO_CntryCode = model.ISO_CntryCode;
                dt.IsActive = model.IsActive;

                rep.SaveChanges();
            }

            return true;
        }

        public static string CreateCountry(CountryViewModel model)
        {
            using (var rep = new CountryRepository())
            {
                var dt = new Country
                {
                    CntryCode = model.CntryCode,
                    Country1 = model.Country,
                    ISO_CntryCode = model.ISO_CntryCode,
                    IsActive = model.IsActive
                };

                rep.Add(dt);
                rep.SaveChanges();

                return dt.CntryCode;
            }
        }
    }
}
