﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace Exigent.BLL
{
    public class SubMattersManager
    {

        public SubMattersManager()
        {
            SubMattersRepository subMattersRepository = new SubMattersRepository();
        }
        public static List<SubMattersViewModel> GetSubMattersByMatterId(int matterId = 0)
        {
            SubMattersRepository subMattersRepository = new SubMattersRepository();
            List<SubMattersViewModel> lstSubMaterViewModel = new List<SubMattersViewModel>();

            var lstSubMatter = subMattersRepository.Find(x => x.MatterId == matterId).ToList();
            string subMatterDirectory = SystemDetailsViewModel.SubMatterPath + @"\";
            if (lstSubMatter.Any())
            {
                foreach (var item in lstSubMatter)
                {
                    SubMattersViewModel subMattersViewModel = new SubMattersViewModel();
                    subMattersViewModel.Id = item.Id;
                    subMattersViewModel.MatterId = item.MatterId;
                    subMattersViewModel.Name = item.Name;
                    subMattersViewModel.date = item.date;
                    subMattersViewModel.FileName = item.FileName;
                    subMattersViewModel.FilePath = subMatterDirectory + subMatterDirectory;
                    subMattersViewModel.FileUploadDate = item.FileUploadDate;
                    subMattersViewModel.UploadBy = item.UploadBy;
                    subMattersViewModel.IsActive = item.IsActive;
                    lstSubMaterViewModel.Add(subMattersViewModel);
                }
                return lstSubMaterViewModel;
            }
            return new List<SubMattersViewModel>();
        }

        public static SubMattersViewModel GetSubMattersById(int Id = 0)
        {
            SubMattersRepository subMattersRepository = new SubMattersRepository();
            SubMattersViewModel subMattersViewModel = new SubMattersViewModel();
            var lstSubMatter = subMattersRepository.GetById(Id);
            string subMatterDirectory = SystemDetailsViewModel.SubMatterPath + @"\";
            if (lstSubMatter != null)
            {

                subMattersViewModel.Id = lstSubMatter.Id;
                subMattersViewModel.MatterId = lstSubMatter.MatterId;
                subMattersViewModel.Name = lstSubMatter.Name;
                subMattersViewModel.date = lstSubMatter.date;
                subMattersViewModel.hdnDate = lstSubMatter.date.Value.ToString("MM/dd/yyyy");
                subMattersViewModel.FileName = lstSubMatter.FileName;
                subMattersViewModel.FilePath = subMatterDirectory + @"\" + lstSubMatter.FileName;
                subMattersViewModel.FileUploadDate = lstSubMatter.FileUploadDate;
                subMattersViewModel.UploadBy = lstSubMatter.UploadBy;
                subMattersViewModel.IsActive = lstSubMatter.IsActive;
                return subMattersViewModel;
            }
            return new SubMattersViewModel();
        }

        public static int AddEditSubMatters(SubMattersViewModel subMattersViewModel, out string fileName, out string oldFileName, out string matterRef)
        {
            oldFileName = string.Empty;
            fileName = string.Empty;
            matterRef = string.Empty;
            SubMattersRepository subMattersRepository = new SubMattersRepository();
            if (subMattersViewModel.Id > 0)
            {
                SubMatter subMatter = subMattersRepository.GetById(subMattersViewModel.Id);
                if (subMatter != null)
                {
                    matterRef = subMatter.Matter.Matter_Reference;
                    subMatter.Name = subMattersViewModel.Name;
                    subMatter.date = subMattersViewModel.date;


                    //Check If uploaded new file
                    if (subMattersViewModel.File != null && (subMatter.Matter.Matter_Reference + "_" + subMattersViewModel.File.FileName != subMatter.FileName))
                    {
                        oldFileName = subMatter.FileName;
                        matterRef = subMatter.Matter.Matter_Reference;
                        subMatter.FileName = subMatter.Matter.Matter_Reference + "_" + subMattersViewModel.File.FileName;
                        subMatter.FileUploadDate = DateTime.Now;
                        fileName = subMatter.FileName;
                    }

                    subMattersRepository.SaveChanges();
                    return subMatter.Id;
                }
            }
            else
            {
                SubMatter subMatter = new SubMatter();
                subMatter.MatterId = subMattersViewModel.MatterId;
                subMatter.Name = subMattersViewModel.Name;
                subMatter.date = subMattersViewModel.date;
                subMatter.FileName = subMattersViewModel.ReferenceNumber + "_" + subMattersViewModel.FileName;
                subMatter.FileUploadDate = subMattersViewModel.FileUploadDate;
                subMatter.UploadBy = subMattersViewModel.UploadBy;
                subMatter.IsActive = true;
                subMattersRepository.Add(subMatter);
                subMattersRepository.SaveChanges();
                fileName = subMatter.FileName;
                return subMatter.Id;
            }
            return 0;
        }

        public static int DeleteSubMattersById(int Id = 0)
        {
            SubMattersRepository subMattersRepository = new SubMattersRepository();            
            var subMatterDetail = subMattersRepository.GetById(Id);
            if (subMatterDetail != null)
            {
                subMattersRepository.Entry(subMatterDetail, EntityState.Deleted);
                subMattersRepository.SaveChanges();
                return 1;
            }

            return 0;
        }
        public static int CheckDuplicateSubMatterName(int Id, string Name, int MatterId)
        {
            SubMattersRepository subMattersRepository = new SubMattersRepository();            
            var subMatterDetail = subMattersRepository.Find(x => x.Name.ToLower().ToString() == Name.ToLower().Trim() && x.MatterId == MatterId && x.Id != Id).FirstOrDefault();
            if (subMatterDetail != null)
            {
                return 1;
            }

            return 0;
        }
        public static int CheckDuplicateSubMatterFileName(int Id, string FileName, int MatterId)
        {
            SubMattersRepository subMattersRepository = new SubMattersRepository();            
            var subMatterDetail = subMattersRepository.Find(x => (x.FileName.ToLower().ToString() == FileName.ToLower().Trim() + ".xls" || x.FileName.ToLower() == FileName.ToLower().Trim() + ".xlsx") && x.MatterId == MatterId && x.Id != Id).FirstOrDefault();
            if (subMatterDetail != null)
            {
                return 1;
            }

            return 0;
        }

    }
}
