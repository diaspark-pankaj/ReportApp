﻿using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using Exigent_BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Exigent.BLL
{
    public class TaskManager
    {
        /// <summary>
        /// method to check grv task status
        /// </summary>
        /// <param name="invoiceNo"></param>
        /// <returns></returns>
        public static bool CheckGrvStatus(string invoiceNo)
        {
            bool grv = true;
            using (GRVTaskRepository grvTaskRepository = new GRVTaskRepository())
            {
                var grvTask = grvTaskRepository.Find(x => x.Invoice_Number == invoiceNo).ToList();
                if (grvTask != null && grvTask.Count() > 0)
                {
                    var status = grvTask.FirstOrDefault().Status;
                    if (status == VarConstants.Complete || status == VarConstants.Rejected || status == VarConstants.Approved)
                        grv = false;
                }
            }
            return grv;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="purchaseId"></param>
        /// <returns></returns>
        public static bool CheckPoStatus(int purchaseId)
        {
            bool po = true;
            using (POTaskRepository poTaskRepository = new POTaskRepository())
            {
                var poTask = poTaskRepository.Find(x => x.ID == purchaseId).ToList();
                if (poTask != null && poTask.Count() > 0)
                {
                    var status = poTask.FirstOrDefault().Status;
                    if (status == VarConstants.Complete || status == VarConstants.Rejected || status == VarConstants.Approved)
                        po = false;
                }
            }
            return po;
        }

        /// <summary>
        /// check RFQ status on approval
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static bool CheckRFQStatus(int id)
        {
            bool rfq = true;
            using (RFQRepository rfqRepository = new RFQRepository())
            {
                var rfqTask = rfqRepository.Find(x => x.ID == id).ToList();
                if (rfqTask != null && rfqTask.Count() > 0)
                {
                    var status = rfqTask.FirstOrDefault().Status;
                    if (status == VarConstants.Complete || status == VarConstants.Rejected || status == VarConstants.Approved)
                        rfq = false;
                }
            }
            return rfq;
        }

        /// <summary>
        /// get invoice approval tasks for Reminder
        /// </summary>
        /// <returns></returns>
        public static List<SearchInvoiceViewModel> GetInvoiceApprovalTask()
        {
            int cnt = 0;
            var invoices = LookupManager.GetInvoiceApprovalListByRustyloading(100, 0, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, out cnt);
            invoices = invoices.Where(m => m.Days == 5 || m.Days == 10).ToList();
            return invoices;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="invoice"></param>
        public static void SendReminderApprovalMail(SearchInvoiceViewModel invoice)
        {
            var emailManager = new EmailManager();
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            var invoiceVm = new InvoiceViewModel();
            var matter = new Matter(); var instruction = new External_Instruction();

            string TermURL = SystemDetailsViewModel.URL + "/" + VarConstants.TermsAndConditions + "/" + VarConstants.TermsFileName;
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        {"id", invoice.Invoice_Number}                                          
                                    };

            string DocsURL = SystemDetailsViewModel.URL + "/" + VarConstants.InvoiceDocument + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary);

            using (MatterRepository matterRepository = new MatterRepository())
            {
                matter = matterRepository.First(x => x.Matter_Reference == invoice.Matter_Reference);
            }
            using (ExternalInstructionRepository instructionRepository = new ExternalInstructionRepository())
            {
                instruction = instructionRepository.First(x => x.Instruction_Reference == invoice.Instruction_Reference);
            }
            invoiceVm.MatterTitle = matter.Matter_Name;
            invoiceVm.MatterReference = matter.Matter_Reference;
            invoiceVm.MatterStatus = matter.Matter_Status.Matter_Status1;
            invoiceVm.LeadLawyer = matter.SystemType.SystemTypeName == SystemTypes.BusinessUnit.ToString() ? matter.PeoplePicker.Full_Name : matter.User.FullName;
            invoiceVm.ApprovalDate = DateTime.Now.Date.ToShortDateString();
            invoiceVm.PreVat_Total = invoice.PreVat_Total;
            invoiceVm.Invoice_Total = invoice.InvoiceTotal;
            invoiceVm.Vendor = invoice.Vendor;
            invoiceVm.Comments = invoice.Comments;
            invoiceVm.InvoiceDate = DateTime.Parse(invoice.InvoiceDate.ToString()).Date.ToShortDateString();
            invoiceVm.Invoice_Number = invoice.Invoice_Number;
            invoiceVm.PONumber = instruction.Purchase_Order_Number;
            invoiceVm.User = SystemDetailsViewModel.InvoiceApprovalOwner;
            invoiceVm.Url = TermURL;
            invoiceVm.UrlDocs = DocsURL;
            invoiceVm.ReminderMessage = invoice.ReminderMessage;
            using (ClientComponyRepository clientComponyRepository = new ClientComponyRepository())
            {
                var company = clientComponyRepository.Find(x => x.Company_Name == instruction.Client_Companies.Company_Name).ToList();
                invoiceVm.VatNo = company.Count() > 0 ? company.FirstOrDefault().Vat_Number : string.Empty;
            }

            if (invoice.Days == 10)
            {
                //Changes to invlude discipline lead for escalation email in CC.
                //int disLead = 0;
                //var dlEmail = MatterManager.GetDisciplineLead(matter.Discipline_Lead.MatterType, matter.SystemType.SystemTypeName, ref disLead);
                //if (!string.IsNullOrEmpty(dlEmail))
                //    emailDetails.EmailCC = PeoplePickerManager.GetUserEmailAddress(dlEmail);
            }

            emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(invoiceVm.LeadLawyer);

            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.ReminderInvoiceApproval, (int)EmailCategoryEnum.ReminderInvoiceApproval, emailDetails, invoiceVm, true, false, false);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public static List<SearchInvoiceViewModel> GetInvoiceAuditTask()
        {
            int cnt = 0;
            var invoices = LookupManager.GetInvoiceAuditListByRustyloading(100, 0, string.Empty, string.Empty, string.Empty, out cnt);
            invoices = invoices.Where(m => m.Days == 5 || m.Days == 10).ToList();
            return invoices;
        }

        /// <summary>
        /// send mail on invoice audit tasks
        /// </summary>
        /// <param name="invoice"></param>
        public static void SendReminderAuditMail(SearchInvoiceViewModel invoice)
        {
            var emailManager = new EmailManager();
            var qsdId = new Dictionary<string, string> { { "id", invoice.Invoice_Number } };
            invoice.Url = SystemDetailsViewModel.URL + "/" + VarConstants.AuditTasks + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsdId);
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(SystemDetailsViewModel.InvoiceApprovalOwner);
            //emailDetails.EmailCC = SystemDetailsViewModel.Team;
            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.ReminderInvoiceAudit, (int)EmailCategoryEnum.ReminderInvoiceAudit, emailDetails, invoice, true, false, false);
        }
    }
}
