﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Exigent.BLL
{
    public class VendorManager
    {
        public static VendorViewModel GetVendorById(int id)
        {
            using (var rep = new VendorRepository())
            {
                var model = rep.GetQuery().Where(m => m.ID == id)
                    .Select(m => new VendorViewModel
                    {
                        Id = m.ID,
                        Company_Name = m.Company_Name,
                        Color = m.Color,
                        Category = m.Category,
                        Email = m.Email,
                        IsActive = (m.Active == "Yes")
                    }).FirstOrDefault();

                return model;
            }
        }

        public static bool IsExists(int id, string vendor)
        {
            using (var rep = new VendorRepository())
            {
                return rep.Any(p => p.Company_Name == vendor.Trim() && p.ID != id);
            }
        }

        public static bool UpdateVendor(VendorViewModel model)
        {
            using (var rep = new VendorRepository())
            {
                var dt = rep.GetQuery().Where(m => m.ID == model.Id).FirstOrDefault();

                if (dt == null)
                    return false;

              
                dt.Color = model.Color;
                dt.Category = model.Category;
                dt.Email = model.Email;
                
                rep.SaveChanges();
            }

            return true;
        }

        public static int CreateVendor(VendorViewModel model)
        {
            using (var rep = new VendorRepository())
            {
                var dt = new Vendor
                {
                    Company_Name = model.Company_Name.Trim(),
                    Color = model.Color,
                    Category = model.Category,
                    Email = model.Email,
                    Active = "Yes" //(model.IsActive) ? "Yes" : "No"
                };

                rep.Add(dt);
                rep.SaveChanges();

                return dt.ID;
            }
        } 
        
         ///<summary>
		/// get vendor email address
		/// </summary>
		/// <param name="fullName"></param>
		/// <returns></returns>
		public static string GetVendorEmailAddress(int VendorId)
        {
            var usersEmail = string.Empty;
            using (VendorRepository vendorRepository = new VendorRepository())
            {
                usersEmail = vendorRepository.Find(x => x.ID == VendorId).Select(y => y.Email).FirstOrDefault();
            }
            return usersEmail;
        }
    }
}
