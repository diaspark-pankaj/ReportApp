﻿using Exigent.DataLayer.Repository;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Linq;
using Exigent.ViewModels.Common;
using Exigent.Models;
using Exigent.EF.Data.Repository;
using Exigent_ViewModels.Admin.Exigent;
using System;
using System.Web;
using Exigent.Common.Enums;
using Exigent_ViewModels.Common;
using Exigent.Common.Constants;

namespace Exigent.BLL
{
    public class CommonManager
    {
        /// <summary>
        /// method to get list of business units for showing dropdown.
        /// </summary>
        /// <returns></returns>
        public List<SelectListItem> GetBusinessUnitsList(bool isBusinessUnit = false, string userName = "")
        {
            var lstBusinessUnit = new List<SelectListItem>();
            if (isBusinessUnit && !string.IsNullOrEmpty(userName))
            {
                using (UserRepository userRepository = new UserRepository())
                {
                    var user = userRepository.Find(x => x.UserName == userName).FirstOrDefault();
                    var list = user != null ? user.Users_BusinessUnit : null;
                    foreach (var user_BU in list)
                    {
                        lstBusinessUnit.Add(new SelectListItem
                        {
                            Text = user_BU.Business_Units.Business_Unit1,
                            Value = user_BU.Business_Units.ID.ToString()
                        });
                    }
                    lstBusinessUnit.OrderBy(q => q.Text).ToList();
                }
            }
            else
            {
                using (BusinessUnitRepository businessUnitRepository = new BusinessUnitRepository())
                {
                    lstBusinessUnit = businessUnitRepository.GetQuery().Select(x =>
                         new SelectListItem
                          {
                              Text = x.Business_Unit1,
                              Value = x.ID.ToString()
                          }).OrderBy(q => q.Text).ToList();
                }
            }
            return lstBusinessUnit;
        }

        public static List<SelectListItem> GetEmailCategoryList()
        {
            var res = new List<SelectListItem>();

            using (var rep = new EmailCategoryRepository())
            {
                res = rep.GetQuery().Select(x =>
                        new SelectListItem
                        {
                            Value = x.Id.ToString(),
                            Text = x.Name
                        }).OrderBy(q => q.Text).ToList();
            }

            return res;
        }

        /// <summary>
        /// method to get list of business units
        /// </summary>
        /// <returns></returns>
        public static List<BusinesUnitViewModel> GetAllBusinessUnits()
        {
            var res = new List<BusinesUnitViewModel>();

            using (BusinessUnitRepository rep = new BusinessUnitRepository())
            {
                res = rep.GetQuery().Select(x =>
                        new BusinesUnitViewModel
                        {
                            Id = x.ID,
                            Business_Unit = x.Business_Unit1
                        }).OrderBy(q => q.Business_Unit).ToList();
            }

            return res;
        }

        /// <summary>
        /// method to get list of operations from business unit
        /// </summary>
        /// <returns></returns>
        public List<SelectListItem> GetOperationByBUList(int businessUnitID)
        {
            var lstOperations = new List<SelectListItem>();
            using (OperationsRepository operationsRepository = new OperationsRepository())
            {
                lstOperations = operationsRepository.GetQuery().Where(x => x.BusinessUnit_ID == businessUnitID).Select(x =>
                      new SelectListItem
                      {
                          Text = x.Operation1,
                          Value = x.ID.ToString()
                      }).OrderBy(q => q.Text).ToList();
            }
            return lstOperations;
        }

        ///// <summary>
        ///// method to get list of changed since last for matter
        ///// </summary>
        ///// <returns></returns>
        //public List<SelectListItem> GetChangedSinceLastList()
        //{
        //    var lstChangeSince = new List<SelectListItem>();
        //    using (ChangedSinceLastRepository changedRepository = new ChangedSinceLastRepository())
        //    {
        //        lstChangeSince = changedRepository.GetQuery().Select(x =>
        //            new SelectListItem
        //            {
        //                Text = x.Changed_Since_Last1,
        //                Value = x.Changed_Since_Last1
        //            }).OrderBy(q => q.Text).ToList();
        //    }
        //    return lstChangeSince;
        //}

        /// <summary>
        /// method to get list of matter status
        /// </summary>
        /// <returns></returns>
        public List<SelectListItem> GetMatterStatusList()
        {
            var lstMatterStatus = new List<SelectListItem>();
            using (MatterStatusRepository matterStatusRepository = new MatterStatusRepository())
            {
                lstMatterStatus = matterStatusRepository.GetQuery().Select(x =>
                    new SelectListItem
                    {
                        Text = x.Matter_Status1,
                        Value = x.ID.ToString()
                    }).OrderBy(q => q.Text).ToList();
            }
            return lstMatterStatus;
        }



		///// <summary>
		///// method to get list of report classification & category based on parameter
		///// </summary>
		///// <returns></returns>
		//public List<SelectListItem> GetReportClassificationList(string reportCategory = "", string system = "", bool IsMatterType = false, string userName = "")
		//{
		//	var lstReportClassification = new List<SelectListItem>();
		//	using (LegalDisciplineRepository reportRepository = new LegalDisciplineRepository())
		//	{
		//		if (string.IsNullOrEmpty(reportCategory))
		//		{
		//			if (IsMatterType)
		//			{
		//				using (UserRepository userRepository = new UserRepository())
		//				{
		//					var user = userRepository.Find(x => x.UserName == userName).FirstOrDefault();
		//					var list = user != null ? user.Users_LPA : null;
		//					if (list != null)
		//					{
		//						foreach (var item in list)
		//						{
		//							lstReportClassification.Add(
		//							new SelectListItem { Text = item.LegalDiscipline.Name, Value = item.LegalDiscipline.ID.ToString() });
		//						}
		//					}
		//				}
		//			}
		//			else
		//			{
		//				reportRepository.Find(x => x.SystemType.SystemTypeName == system && x.IsActive == true).Select(x => new { Id = x.Report_Classification_Category, Name = x.Report_Classification_Category }).Distinct().ToList().ForEach(y => lstReportClassification.Add(
		//					 new SelectListItem
		//					 {
		//						 Text = y.Name,
		//						 Value = y.Id.ToString()
		//					 }));
		//			}
		//		}
		//		else
		//		{
		//			lstReportClassification = reportRepository.Find(x => x.Report_Classification_Category == reportCategory).Select
		//				   (x => new SelectListItem
		//				   {
		//					   Text = x.Report_Classification1,
		//					   Value = x.ID.ToString()
		//				   }).ToList();
		//		}
		//	}
		//	return lstReportClassification.OrderBy(q => q.Text).ToList();
		//}

		/// <summary>
		/// method to get legal pratice area
		/// </summary>
		/// <returns></returns>
		public static List<SelectListItem> GetLegalDiscipline(SystemTypes systemType)
        {
            var lstLegal = new List<SelectListItem>();
            using (LegalDisciplineRepository repo = new LegalDisciplineRepository())
            {
                repo.Find(x => x.SystemType_ID == (int)systemType).Select(x => new { Id = x.ID, Name = x.Name }).Distinct().ToList().ForEach(y => lstLegal.Add(
                           new SelectListItem
                           {
                               Text = y.Name,
                               Value = y.Id.ToString()
                           }));

            }
            return lstLegal.OrderBy(x => x.Text).ToList();
        }

        /// <summary>
        /// Get all legal pratice areas
        /// </summary>
        /// <returns></returns>
        public List<string> GetLegalDiscipline()
        {
            var lstLegal = new List<SelectListItem>();
            using (var rep = new LegalDisciplineRepository())
            {
                return rep.GetAll().Select(x => x.Name).Distinct().ToList();
            }
        }

        ///// <summary>
        ///// method to get list of report classification & category based on parameter
        ///// </summary>
        ///// <returns></returns>
        //public List<SelectListItem> GetReportClassificationDetailList(string system)
        //{
        //    using (ReportClassificationRepository rep = new ReportClassificationRepository())
        //    {
        //        return rep.GetQuery().Where(x => x.SystemType.SystemTypeName == system && x.IsActive == true).Select(x =>
        //                new SelectListItem
        //                {
        //                    Text = x.Report_Classification1,
        //                    Value = x.Report_Classification_Category
        //                }).ToList();
        //    }
        //}

        ///// <summary>
        ///// method to get list of all distinct report classification category.
        ///// </summary>
        ///// <returns></returns>
        //public List<string> GetReportClassificationCategoryList()
        //{
        //    using (var rep = new ReportClassificationRepository())
        //    {
        //        return rep.GetQuery().Select(x => x.Report_Classification_Category).Distinct().ToList();
        //    }
        //}

        ///// <summary>
        ///// method to get list of all distinct report classification category.
        ///// </summary>
        ///// <returns></returns>
        //public List<SelectListItem> GetReportClassificationList(SystemTypeEnum systemType)
        //{
        //    using (var rep = new ReportClassificationRepository())
        //    {
        //        return rep.GetQuery().Where(x => x.SystemType.SystemTypeName == systemType.ToString()).Select(x =>
        //        new SelectListItem
        //        {
        //            Text = x.Report_Classification1,
        //            Value = x.ID.ToString()
        //        }).Distinct().ToList();
        //    }
        //}

        /// <summary>
        /// method to get list of users from people picker
        /// </summary>
        /// <returns></returns>
        public List<EnumKeyValueViewModel> GetUsersFromPeoplePicker()
        {
            var lstUsers = new List<EnumKeyValueViewModel>();
            using (PeoplePickerRepository peoplePickerRepository = new PeoplePickerRepository())
            {
                lstUsers.AddRange(peoplePickerRepository.GetQuery().Select(x => new EnumKeyValueViewModel() { Key = x.ID, Name = x.Full_Name }));
            }
            return lstUsers;
        }

		public List<EnumKeyValueViewModel> GetSpecialUsers()
		{
			var lstUsers = new List<EnumKeyValueViewModel>();
			using (UserRepository rep = new UserRepository())
			{
				lstUsers.AddRange(rep.GetQuery().Where(m => m.IsActive && m.Roles.Any(x => (x.Id==(int)
                SystemTypeEnum.SpecialGroupLegal || x.Id == (int)SystemTypeEnum.SuperGroupLegal || x.Id == (int)SystemTypeEnum.LegalAdminStaff || x.Id == (int)SystemTypeEnum.ServiceProviderAdmin))).Select(x => new EnumKeyValueViewModel() { Key = x.Id, Name = x.FullName }));
			}
			return lstUsers;
		}

		/// <summary>
		/// method to get list of all users from user table
		/// </summary>
		/// <returns></returns>
		public List<EnumKeyValueViewModel> GetAllUsers()
        {
            var lstUsers = new List<EnumKeyValueViewModel>();
            using (UserRepository rep = new UserRepository())
            {
                lstUsers.AddRange(rep.GetQuery().Where(m => m.IsActive).Select(x => new EnumKeyValueViewModel() { Key = x.Id, Name = x.FullName }));
            }
            return lstUsers;
        }

        /// <summary>
        /// method to get list of GSS users from user table
        /// </summary>
        /// <returns></returns>
        public List<EnumKeyValueViewModel> GetGSSUsers()
        {
            //var lstUsers = new List<string>();
            //using (UserRepository rep = new UserRepository())
            //{
            //    lstUsers.AddRange(rep.GetQuery().Where(m => m.EntityId == (int)Exigent.Common.Enums.UserTypes.GSS || m.EntityId == (int)Exigent.Common.Enums.UserTypes.AccountUser).Select(x => x.FullName));
            //}
            //return lstUsers;

            var lstUsers = new List<EnumKeyValueViewModel>();
            using (UserRepository rep = new UserRepository())
            {
                lstUsers.AddRange(rep.GetQuery().Where(m => m.EntityId == (int)UserTypes.LegalAdminStaff).Select(x => new EnumKeyValueViewModel() { Key = x.Id, Name = x.FullName }));
            }
            return lstUsers;
        }

        /// <summary>
        /// method to get list of LawFims from firms picker
        /// </summary>
        /// <returns></returns>
        /// 
        // Remove lawfirm dropdown as per requirement from user page ...........  By Mahwish Khan

        //public List<EnumKeyValueViewModel> GetLawFirmsFromFirmsPicker()
        //{
        //    var lstUsers = new List<EnumKeyValueViewModel>();
        //    using (VendorRepository vendorRepository = new VendorRepository())
        //    {
        //        lstUsers = vendorRepository.GetQuery().Select(x =>
        //                  new EnumKeyValueViewModel
        //                  {
        //                      Name = x.Company_Name,
        //                      Key = x.ID
        //                  }).ToList();
        //    }
        //    return lstUsers;
        //}

        /// <summary>
        /// method to get Acronym by business unit
        /// </summary>
        /// <param name="businessUnit"></param>
        /// <returns></returns>
        public static string GetBusinessUnitAcronym(int businessUnit)
        {
            var Acronym = string.Empty;
            using (BusinessUnitRepository businessUnitRepository = new BusinessUnitRepository())
            {
                Acronym = businessUnitRepository.Find(x => x.ID == businessUnit).FirstOrDefault().Acronym;
            }
            return Acronym;
        }

        /// <summary>
        /// method to get system details
        /// </summary>
        /// <returns></returns>
        public static void GetSystemDetails()
        {
            var system = new SystemDetail();
            var systemVm = new SystemDetailsViewModel();
            using (SystemDetailsRepository systemDetailsRepository = new SystemDetailsRepository())
            {
                system = systemDetailsRepository.GetQuery().FirstOrDefault();
                SystemDetailsViewModel.Team = system.Team;
                SystemDetailsViewModel.GRVOwner = system.PeoplePicker.Full_Name;
                SystemDetailsViewModel.GRVOwnerID = system.GRVOwner_ID;
                SystemDetailsViewModel.InvoiceApprovalOwner = system.PeoplePicker1.Full_Name;
                SystemDetailsViewModel.InvoiceApprovalOwnerID = system.InvoiceApprovalOwner_ID;
                SystemDetailsViewModel.Path = system.Path;
                SystemDetailsViewModel.TeamLead = system.TeamLead;
                SystemDetailsViewModel.TimesheetCaptureOwner = system.PeoplePicker2.Full_Name;
                SystemDetailsViewModel.TimesheetCaptureOwnerID = system.TimesheetCaptureOwner_ID;
                SystemDetailsViewModel.URL = system.URL;
                SystemDetailsViewModel.AttorneyRateChangeEmail = system.AttorneyRateChangeEmail;
                SystemDetailsViewModel.SubMatterPath = system.SubMatterPath;
            }
        }

        /// <summary>
        /// method to get app config details
        /// </summary>
        public static void GetAppConfigDetails()
        {
            var system = new AppConfig();
            using (AppConfigRepository appConfigRepository = new AppConfigRepository())
            {
                List<AppConfigViewModel> appConfig = new List<AppConfigViewModel>();
            }
        }

        /// <summary>
        /// get client companies from business unit
        /// </summary>
        /// <param name="businessUnit"></param>
        /// <returns></returns>
        public static List<SelectListItem> GetClientCompanies(int businessUnit)
        {
            List<SelectListItem> list = null;

            using (ClientComponyRepository rep = new ClientComponyRepository())
            {
                list = rep.GetQuery()
                    .Select(m => new SelectListItem
                    {
                        Text = m.Company_Name,
                        Value = m.ID.ToString()
                    }).Distinct().OrderBy(x => x.Text).ToList();
            }

            return list;
        }

        /// <summary>
        /// To Get GRV value from Client Companies table 
        /// </summary>
        /// <returns>Returns Yes/No</returns>
        public static string GetGRVForClientCompanyByID(int ID)
        {
            string IsGRV = "";

            using (ClientComponyRepository rep = new ClientComponyRepository())
            {
                IsGRV = rep.GetQuery()
                    .Where(m => m.ID == ID)
                    .Select(m => m.GRV)
                    .FirstOrDefault();
            }

            return IsGRV;
        }

        /// <summary>
        /// To Get GRV value from Client Companies table 
        /// </summary>
        /// <param name="clientCompanyName">Billing Entity Name or Client Company Name</param>
        /// <returns>Returns Yes/No</returns>
        public static string GetGRVForClientCompany(string clientCompanyName, int billingId = 0)
        {
            string IsGRV = "";

            using (ClientComponyRepository rep = new ClientComponyRepository())
            {
                if (billingId > 0)
                    IsGRV = rep.GetQuery().Where(m => m.ID == billingId).Select(m => m.GRV).FirstOrDefault();
                else
                    IsGRV = rep.GetQuery().Where(m => m.Company_Name == clientCompanyName).Select(m => m.GRV).FirstOrDefault();
            }
            return IsGRV;
        }

        /// <summary>
        /// To Get PO value from Client Companies table 
        /// </summary>
        /// <param name="clientCompanyName">Billing Entity Name or Client Company Name</param>
        /// <returns>Returns Yes/No</returns>
        public static string GetPOForClientCompany(string clientCompanyName)
        {
            string IsPO = "";

            using (ClientComponyRepository rep = new ClientComponyRepository())
            {
                IsPO = rep.GetQuery()
                    .Where(m => m.Company_Name == clientCompanyName)
                    .Select(m => m.PO)
                    .FirstOrDefault();
            }

            return IsPO;
        }

        /// <summary>
        /// get vendor email address
        /// </summary>
        /// <param name="vendor"></param>
        /// <returns></returns>
        public static string GetBusinessUnitEmail(int vendor, int businessUnit, int legalDis)
        {
            string email = string.Empty;
            using (BUVendorAccessRepository vendorRepository = new BUVendorAccessRepository())
            {
                if (vendor == 0)
                {
                    var list = vendorRepository.Find(y => y.Legal_Discipline_ID == legalDis && y.BusinessUnit_ID == businessUnit).Select(x => x.Email);
                    list = list.Distinct().ToList();
                    foreach (var item in list)
                    {
                        if (!string.IsNullOrEmpty(item))
                            email = email == string.Empty ? item : email + " ;" + item;
                    }
                }
                else
                    email = vendorRepository.Find(y => y.Legal_Discipline_ID == legalDis && y.Vendor_ID == vendor && y.BusinessUnit_ID == businessUnit).Select(x => x.Email).FirstOrDefault();
            }
            return email;
        }

        /// <summary>
        /// Get the list of all the vendors/vendor companies.
        /// </summary>
        /// <returns><![CDATA[List<SelectListItem>]]></returns>
        public static List<SelectListItem> GetVendors(int businessUnit = 0, int legalDis = 0)
        {
            List<SelectListItem> list = null;
            if (businessUnit > 0)
            {
                using (BUVendorAccessRepository rep = new BUVendorAccessRepository())
                {
                    list = new List<SelectListItem>();
                    rep.Find(x => x.BusinessUnit_ID == businessUnit && x.Legal_Discipline_ID == legalDis)
                       .Select(x => x.Vendor).Distinct().ToList().ForEach(y => list.Add(
                         new SelectListItem
                         {
                             Text = y.Company_Name,
                             Value = y.ID.ToString()
                         }));
                    list = list.OrderBy(x => x.Text).ToList();
                }
            }
            else
            {
                using (VendorRepository rep = new VendorRepository())
                {
                    list = rep.GetQuery()
                        .Select(m => new SelectListItem
                        {
                            Text = m.Company_Name,
                            Value = m.ID.ToString()
                        }).ToList();
                }
            }
            return list;
        }

        /// <summary>
        /// Get the legal practice area for specified report classification.
        /// </summary>
        /// <param name="reportClassification"></param>
        /// <returns></returns>
        public static string GetLegalPracticeArea(string matterReference)
        {
            string legalPracticeArea = "";

            using (MatterRepository rep = new MatterRepository())
            {
                legalPracticeArea = rep.GetQuery()
                    .Where(m => m.Matter_Reference == matterReference)
                    .Select(m => m.LegalDiscipline.Name).FirstOrDefault();
            }

            return legalPracticeArea;
        }

        /// <summary>
        /// Get the Payment Clearance Number frp, Framework Order
        /// </summary>
        /// <param name="legalDiscipline"></param>
        /// <param name="billingEntity"></param>
        /// <param name="vendor"></param>
        /// <returns></returns>
        public static string GetPaymentClearanceNumber(string legalDiscipline, string billingEntity, string vendor)
        {
            string paymentClearanceNumber = "";

            using (FrameworkOrderRepository rep = new FrameworkOrderRepository())
            {
                paymentClearanceNumber = rep.GetQuery()
                    .Where(m => m.Client_Companies.Company_Name == billingEntity
                            && m.Vendor.Company_Name == vendor
                            && m.LegalDiscipline.Name == legalDiscipline)
                    .Select(m => m.Payment_Clearance_Number).FirstOrDefault();
            }

            return paymentClearanceNumber;
        }

        /// <summary>
        /// To get the list of all access dashboards.
        /// </summary>
        /// <returns></returns>
        public static List<AccessDashboardViewModel> GetAccessDashboards()
        {
            List<AccessDashboardViewModel> lstAccessDashboards = null;
            using (AccessDashboardsRepository _accessDashboardsRepo = new AccessDashboardsRepository())
            {
                lstAccessDashboards = _accessDashboardsRepo.Find(obj => obj.IsActive == true)
                                        .OrderBy(y => y.SortOrder)
                                        .Select(x => new AccessDashboardViewModel()
                                        {
                                            ID = x.ID,
                                            Name = x.Name,
                                            Description = x.Description,
                                            SortOrder = x.SortOrder,
                                            IsActive = x.IsActive
                                        }).ToList();
            }
            return lstAccessDashboards;
        }

        /// <summary>
        /// To get the list of all access dashboards.
        /// </summary>
        /// <returns></returns>
        public static List<RoleAppActivityViewModel> GetRoleAppActivity()
        {
            List<RoleAppActivityViewModel> lstRoleAppActivityViewModel = null;
            using (RoleAppActivityRepository roleAppActivityRepository = new RoleAppActivityRepository())
            {
                lstRoleAppActivityViewModel = roleAppActivityRepository.GetAll()
                                        .Select(x => new RoleAppActivityViewModel()
                                        {
                                            Id = x.Id,
                                            RoleId=x.RoleId,
                                            AppActivityId=x.AppActivityId
                                        }).ToList();
            }
            return lstRoleAppActivityViewModel;
        }
        /// <summary>
        /// get vendor email address
        /// </summary>
        /// <param name="vendor"></param>
        /// <returns></returns>
        public static string GetVendorEmail(string vendor)
        {
            string email = string.Empty;
            using (VendorRepository vendorRepository = new VendorRepository())
            {
                email = vendorRepository.Find(y => y.Company_Name == vendor).Select(x => x.Email).FirstOrDefault();
            }
            return email;
        }

        /// <summary>
        /// method to get Key Work Stream
        /// </summary>
        /// <returns></returns>
        public List<SelectListItem> GetKeyWorkStream()
        {
            var lstKey = new List<SelectListItem>();
            using (KeyWorkStreamRepository keyWorkStreamRepository = new KeyWorkStreamRepository())
            {
                keyWorkStreamRepository.GetQuery().Select(x => new { Id = x.ID, Name = x.Key_Work_Stream }).Distinct().ToList().ForEach(y => lstKey.Add(
                         new SelectListItem
                         {
                             Text = y.Name,
                             Value = y.Id.ToString()
                         }));
            }
            return lstKey;
        }

        public List<SelectListItem> GetCountries()
        {
            var countriesList = new List<SelectListItem>();
            using (CountryRepository countryRepository = new CountryRepository())
            {
                countryRepository.Find(x => x.IsActive == true).Select(x => new { ID = x.Id, Name = x.Country1 }).Distinct().OrderBy(x=>x.Name).ToList().ForEach(y => countriesList.Add(
                    new SelectListItem
                    {
                        Text = y.Name,
                        Value = y.ID.ToString()
                    }
                ));
            }
            return countriesList;
        }

        public List<SelectListItem> GetLeadLawyers()
        {
            var leadlawyersList = new List<SelectListItem>();
            using (UserRepository countryRepository = new UserRepository())
            {
                countryRepository.Find(x => x.IsActive == true).Select(x => new { ID = x.Id, Name = x.FullName }).Distinct().OrderBy(x => x.Name).ToList().ForEach(y => leadlawyersList.Add(
                      new SelectListItem
                      {
                          Text = y.Name,
                          Value = y.ID.ToString()
                      }
                  ));
            }
            return leadlawyersList;
        }

        public List<SelectListItem> GetOffices()
        {
            var officesList = new List<SelectListItem>();
            using (OfficeRepository officeRepository = new OfficeRepository())
            {
                officeRepository.Find(x => x.IsActive == true).Select(x => new { ID = x.Id, Name = x.OfficeName }).Distinct().OrderBy(x=>x.Name).ToList().ForEach(y => officesList.Add(
                    new SelectListItem
                    {
                        Text = y.Name,
                        Value = y.ID.ToString()
                    }
                ));
            }
            return officesList;
        }

        public List<SelectListItem> GetOperations()
        {
            using (OperationsRepository operationRepository = new OperationsRepository())
            {
                return operationRepository.GetAll()
                     .Select(x => new SelectListItem
                     {
                         Text = x.Operation1,
                         Value = x.ID.ToString()
                     }).Distinct().OrderBy(x=>x.Text).ToList();
            }
        }

        public List<SelectListItem> GetLegalDisciplineForReportable()
        {
            using (LegalDisciplineRepository legaldisciplineRepository = new LegalDisciplineRepository())
            {
                return legaldisciplineRepository.GetAll()
                     .Select(x => new SelectListItem
                     {
                         Text = x.Name,
                         Value = x.ID.ToString()
                     }).OrderBy(x=>x.Text).ToList();
            }
        }

        public List<SelectListItem> GetSubDiscipline()
        {
            using (SubDisciplineRepository subdisciplineRepository = new SubDisciplineRepository())
            {
                return subdisciplineRepository.GetAll()
                     .Select(x => new SelectListItem
                     {
                         Text = x.Name,
                         Value = x.ID.ToString()
                     }).OrderBy(x=>x.Text).ToList();
            }
        }

        public List<SelectListItem> GetApplicationReportTemplate()
        {
            var reportTemplatesList = new List<SelectListItem>();
            using (ApplicationReportTemplateRepository reportTemplateRepository = new ApplicationReportTemplateRepository())
            {
                reportTemplateRepository.Find(x => x.IsActive == true).Select(x => new { ID = x.Id, Name = x.Name }).Distinct().OrderBy(x=>x.Name).ToList().ForEach(y => reportTemplatesList.Add(
                    new SelectListItem
                    {
                        Text = y.Name,
                        Value = y.ID.ToString()
                    }
                ));
            }
            return reportTemplatesList;
        }

        public List<SelectListItem> GetMatterReportClassificationOption()
        {
            var MatterReportClassificationsList = new List<SelectListItem>();
            using (MatterReportClassificationOptionRepository matterReportclassificationoptionRepository = new MatterReportClassificationOptionRepository())
            {
                matterReportclassificationoptionRepository.Find(x => x.IsActive == true).Select(x => new { ID = x.Id, Name = x.Name }).Distinct().OrderBy(x=>x.Name).ToList().ForEach(y => MatterReportClassificationsList.Add(
                    new SelectListItem
                    {
                        Text = y.Name,
                        Value = y.ID.ToString()
                    }
                ));
            }
            return MatterReportClassificationsList;
        }

        public List<SelectListItem> GetCurrencies()
        {
            using (CurrencyRepository currencyRepository = new CurrencyRepository())
            {
                return currencyRepository.GetAll()
                     .Select(x => new SelectListItem
                 {
                     Text = "(" + x.CurrencyCode + ") " + x.Currency,
                     Value = x.Id.ToString()
                 }).ToList();
            }
        }

        public static string GetErrorLogString(Exception ex, string additionalMessage = null)
        {
            if (ex.InnerException == null)
                return @"<html>
                                            <body>"
                            + (string.IsNullOrEmpty(additionalMessage) ? "" : "Error on step - " + additionalMessage + "</br>")
                                         + "Exception Message: " + ex.Message + "</br>"
                                         + "Stack Trace: " + ex.StackTrace + "</br>"
                                         + @"</body>
                                        </html>";
            else
                return @"<html>
                                            <body>"
                                         + "Exception Message: " + ex.Message + "</br>"
                                         + "Stack Trace: " + ex.StackTrace + "</br>"
                                         + "<hr>"
                                         + "Inner Exception Message: " + ex.InnerException.Message + "</br>"
                                         + "Inner Exception Stack Trace: " + ex.InnerException.StackTrace
                                         + @"</body>
                                        </html>";
        }

        public static bool SendErrorEmail(string errorString, string emailSubject)
        {
            var emailManager = new EmailManager();
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            emailDetails.EmailTo = SystemDetailsViewModel.Team;

            emailDetails.EmailContent = errorString;
            emailDetails.EmailSubject = emailSubject;

            emailManager.SendDirectMail(emailDetails);

            return true;
        }

        #region HTML Static Content Get/Update

        /// <summary>
        /// Get HTML Static Content
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static string GetHtmlContent(int id)
        {
            using (HtmlContentRepository rep = new HtmlContentRepository())
            {
                if (rep.Any(x => x.Id == id))
                    return rep.GetById(id).Description;
                else
                    return string.Empty;

            }
        }

        /// <summary>
        /// Update HTML Static Content
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static bool UpdateHtmlContent(int id, string content)
        {
            using (HtmlContentRepository rep = new HtmlContentRepository())
            {
                var rec = rep.GetById(id);

                if (rep.Any(x => x.Id == id))
                {
                    rec.Description = content;
                    rep.SaveChanges();
                    return true;
                }

                else
                {
                    return false;

                }


            }
        }

        #endregion

        /// <summary>
        /// method to get list of all distinct report classification category.
        /// </summary>
        /// <returns></returns>
        public static List<string> GetAllVendorInstruction(string vendor, string matterReference)
        {
            using (var rep = new ExternalInstructionRepository())
            {
                return rep.GetQuery()
                          .Where(x => x.Vendor.Company_Name == vendor && x.Matter.Matter_Reference == matterReference)
                          .Select(x => x.Instruction_Reference + " - " + x.Status).Distinct().ToList();
            }
        }
        public static List<SelectListItem> GetSystemTypes()
        {
            using (var repo = new SystemTypeRepository())
            {
                return repo.GetAll()
                     .Select(x => new SelectListItem
                     {
                         Text = x.SystemTypeName,
                         Value = x.ID.ToString()
                     }).ToList();
            }
        }
        //public static List<SelectListItem> GetMatterReference()
        //{
        //    using (var repo = new MatterRepository())
        //    {
        //        return repo.GetAll()
        //             .Select(x => new SelectListItem
        //             {
        //                 Text = x.Matter_Reference,
        //                 Value = x.Matter_Reference
        //             }).ToList();
        //    }
        //}

        //public static List<SelectListItem> GetInstructionReference()
        //{
        //    using (var repo = new ExternalInstructionRepository())
        //    {
        //        return repo.GetAll()
        //             .Select(x => new SelectListItem
        //             {
        //                 Text = x.Instruction_Reference,
        //                 Value = x.Instruction_Reference
        //             }).ToList();
        //    }
        //}

        public static List<SelectListItem> GetCountryList()
        {
            var res = new List<SelectListItem>();

            using (var rep = new CountryRepository())
            {
                res = rep.GetQuery().Select(x =>
                        new SelectListItem
                        {
                            Value = x.Id.ToString(),
                            Text = x.Country1
                        }).OrderBy(q => q.Text).ToList();
            }

            return res;
        }
    }
}
