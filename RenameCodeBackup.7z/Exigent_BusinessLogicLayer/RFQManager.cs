﻿using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Globalization;
using System.Linq;
namespace Exigent.BLL
{
    public class RFQManager
    {
        /// <summary>
        /// method to save rfq of matter
        /// </summary>
        /// <param name="rfqVm"></param>
        public static void SaveRFQ(RFQViewModel rfqVm)
        {
            string businessUnit, leadClient = string.Empty; int businessUnitId, leagalDisId, matterId = 0;
            using (MatterRepository matterRepository = new MatterRepository())
            {
                var matter = matterRepository.Find(x => x.Matter_Reference == rfqVm.Matter_Reference).Select(y => new { y.ID, y.Business_Unit_ID, y.PeoplePicker.Full_Name, y.Business_Units.Business_Unit1, y.LegalDisciplineId }).FirstOrDefault();
                businessUnit = matter.Business_Unit1;
                leagalDisId = matter.LegalDisciplineId.Value;
                leadClient = matter.Full_Name;
                businessUnitId = matter.Business_Unit_ID.Value;
                matterId = matter.ID;
            }

            using (RFQRepository rfqRepository = new RFQRepository())
            {
                //var dLead = MatterManager.GetDisciplineLeadID(legal, systemType);
                var rfq = new RFQ();
                rfq.Background_To_Request = rfqVm.Background_To_Request;
                rfq.Services_Required = rfqVm.Services_Required;
                rfq.To_Respond_By = rfqVm.To_Respond_By;
                rfq.Status = VarConstants.Approved;
                rfq.Matter_ID = matterId;
                rfqRepository.Add(rfq);
                rfqRepository.SaveChanges();

                //send mail for RFQ approval to vendor
                var emailManager = new EmailManager();
                var emailDetails = new Exigent.Email.Configuration.EmailDetails();
                rfqVm.BusinessUnit = businessUnit;
                var leadEmail = PeoplePickerManager.GetUserEmailAddress(leadClient);
                rfqVm.Lead = leadEmail;
                emailDetails.EmailCC = SystemDetailsViewModel.Team + " ;" + leadEmail;
                emailDetails.EmailTo = CommonManager.GetBusinessUnitEmail(0, businessUnitId, leagalDisId);
                emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.RFQApproved, (int)EmailCategoryEnum.RFQApproved, emailDetails, rfqVm, true);

                //var rfqApp = new RFQ_Approval(); rfqApp.ID = rfq.ID;
                //rfqApp.Created = DateTime.Now; rfqApp.Status = VarConstants.AwaitingApproval;
                ////rfqApp.Assigned_To_ID = dLead;
                //rfq.RFQ_Approval.Add(rfqApp);               
                //send mail for RFQ approval
                //rfqVm.Assigned_To_ID = dLead;
                //rfqVm.MatterName = matterName;
                //rfqVm.ID = rfq.ID;
                //SendNewRFQEmail(rfqVm);
            }
        }       
    }
}
