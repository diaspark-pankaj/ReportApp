﻿using System;
using System.Linq;
using Exigent.DataLayer.Repository;
using Exigent.ViewModels.Common;
using Exigent.Models;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using System.Collections.Generic;
using System.Transactions;
using System.Data.SqlClient;
using Exigent.EF.Data.Repository;
using System.Data;
using Exigent.Common.Helpers;
using System.Data.Entity;

namespace Exigent.BLL
{
    public class InstructionManager
    {
        #region CRUD Operations on "External Instruction"

        /// <summary>
        /// Get the instruction details by specifying reference number.
        /// </summary>
        /// <param name="instructionRef">Instruction Reference Number is required.</param>
        /// <returns>Instruction View Model</returns>
        public static InstructionViewModel GetInstruction(int id)
        {
            InstructionViewModel instruction = null;

            //Get the instruction record.
            using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
            {
                var instructionEntity = rep.GetQuery().Where(m => m.ID == id).FirstOrDefault();

                instruction = new InstructionViewModel
                {
                    ID = instructionEntity.ID,
                    IsInvoiceExists = instructionEntity.Invoices.Any(x => x.Invoice_Status == VarConstants.AwaitingApproval || x.Invoice_Status == VarConstants.AwaitingAudit || x.Invoice_Status == VarConstants.ReadyForPayment || x.Invoice_Status == VarConstants.SentForPayment || x.Invoice_Status == VarConstants.AwaitingGRV) ? true : false,
                    Instruction_Reference = instructionEntity.Instruction_Reference,
                    Matter_ID = instructionEntity.Matter_ID,

                    Status = instructionEntity.Status,
                    FrameworkOrder = instructionEntity.FrameworkOrder,
                    Confirmed = instructionEntity.Confirmed,
                    Vendor = instructionEntity.Vendor.Company_Name,
                    Vendor_ID = instructionEntity.Vendor_ID,
                    Billing_Entity_ID = instructionEntity.BillingEntityId,
                    Billing_Entity = instructionEntity.Client_Companies != null ? instructionEntity.Client_Companies.Company_Name : string.Empty,
                    PO_Contact_ID = instructionEntity.PO_Contact_ID,
                    GRV_Contact_ID = instructionEntity.GRV_Contact_ID,
                    PO_Contact = instructionEntity.PeoplePicker != null ? instructionEntity.PeoplePicker.Full_Name : string.Empty,
                    GRV_Contact = instructionEntity.PeoplePicker1 != null ? instructionEntity.PeoplePicker1.Full_Name : string.Empty,
                    Matter_Reference = instructionEntity.Matter != null ? instructionEntity.Matter.Matter_Reference : string.Empty,
                    Sent_Status = instructionEntity.Sent_Status,
                    System = instructionEntity.SystemType != null ? instructionEntity.SystemType.SystemTypeName : string.Empty,
                    Instruction = instructionEntity.Instruction,
                    Payment_Clearance_Number = instructionEntity.Purchase_Order_Number,

                    Estimated_Legal_Cost_Vatable = instructionEntity.Estimated_Legal_Cost_Vatable,
                    Estimated_Legal_Cost_Non_Vatable = instructionEntity.Estimated_Legal_Cost_Non_Vatable,

                    Estimated_Legal_Cost_Vatable_Local = instructionEntity.Estimated_Legal_Cost_Vatable_Local,
                    Estimated_Legal_Cost_Non_Vatable_Local = instructionEntity.Estimated_Legal_Cost_Non_Vatable_Local,
                    Currency_ID = instructionEntity.CurrencyID,

                    Legal_Cost_Vatable_Balance = instructionEntity.Legal_Cost_Vatable_Balance,
                    Legal_Cost_Non_Vatable_Balance = instructionEntity.Legal_Cost_Non_Vatable_Balance,
                    Cost_Centre = instructionEntity.Cost_Centre,
                    Created_By = instructionEntity.Created_By,
                    Created = instructionEntity.Created != null ? instructionEntity.Created.Value : Convert.ToDateTime(instructionEntity.Created),
                    SystemType_ID = instructionEntity.SystemType_ID,
                    Email = instructionEntity.Email != null ? instructionEntity.Email.Trim() : instructionEntity.Email,
                    FileName = !string.IsNullOrEmpty(instructionEntity.FileName) ? instructionEntity.FileName : string.Empty,

                    GLAccount = (instructionEntity.Purchase_Orders != null && instructionEntity.Purchase_Orders.Any() && !string.IsNullOrEmpty(instructionEntity.Purchase_Orders.FirstOrDefault().GL_Account)) ? instructionEntity.Purchase_Orders.FirstOrDefault().GL_Account : string.Empty,
                    GroupWideSplit = (instructionEntity.Purchase_Orders != null && instructionEntity.Purchase_Orders.Any() && !string.IsNullOrEmpty(instructionEntity.Purchase_Orders.FirstOrDefault().GroupWideSplit)) ? instructionEntity.Purchase_Orders.FirstOrDefault().GroupWideSplit : string.Empty,
                    OldFileName = !string.IsNullOrEmpty(instructionEntity.FileName) ? instructionEntity.FileName : string.Empty,
                };
            }

            return instruction;
        }

        /// <summary>
        /// Get the instruction details by specifying reference number.
        /// </summary>
        /// <param name="instructionRef">Instruction Reference Number is required.</param>
        /// <returns>Instruction View Model</returns>
        public static InstructionViewModel GetInvoiceStatistics(InstructionViewModel instruction)
        {
            if (instruction == null)
                instruction = new InstructionViewModel();

            using (PurchaseOrdersRepository rep = new PurchaseOrdersRepository())
            {
                decimal poAmountVatable = 0;
                decimal poAmountNonVatable = 0;
                decimal osInvoicesAmountVatable = 0;
                decimal osInvoicesAmountNonVatable = 0;

                var purchaseOrderAmount = rep.GetQuery()
                    .Where(m => m.External_Instructions.Instruction_Reference == instruction.Instruction_Reference && (m.Status == VarConstants.PendingIncrease || m.Status == VarConstants.PendingAmendment))
                    .GroupBy(s => 1)
                    .Select(m => new
                    {
                        Vatable = (m.Sum(n => (n.Status == VarConstants.PendingIncrease) ? n.Vatable_Amount : n.Vatable_Amount - n.Non_Vatable_Amount)) ?? 0,
                        Non_Vatable = (m.Sum(n => (n.Status == VarConstants.PendingIncrease) ? n.Non_Vatable_Amount : n.Vatable_Amount - n.Non_Vatable_Amount)) ?? 0
                    }).FirstOrDefault();

                if (purchaseOrderAmount != null)
                {
                    poAmountVatable = purchaseOrderAmount.Vatable;
                    poAmountNonVatable = purchaseOrderAmount.Non_Vatable;
                }

                //Get the instruction record.
                using (InvoiceRepository repInv = new InvoiceRepository())
                {
                    var outstandingInvoicesAmount = repInv.GetQuery()
                        .Where(m => m.External_Instructions.Instruction_Reference == instruction.Instruction_Reference && (m.Invoice_Status == VarConstants.AwaitingApproval || m.Invoice_Status == VarConstants.AwaitingAudit))
                        .GroupBy(s => 1)
                        .Select(m => new
                        {
                            Vatable = ((m.Sum(n => n.Invoice_Total) - m.Sum(n => n.PreVat_Total))) ?? 0,
                            Non_Vatable = ((m.Sum(n => n.PreVat_Total)) - ((m.Sum(n => n.Invoice_Total) - m.Sum(n => n.PreVat_Total)))) ?? 0
                        }).FirstOrDefault();

                    if (outstandingInvoicesAmount != null)
                    {
                        osInvoicesAmountVatable = outstandingInvoicesAmount.Vatable;
                        osInvoicesAmountNonVatable = outstandingInvoicesAmount.Non_Vatable;
                    }

                    instruction.Outstanding_Invoices_Vatable_Amount = osInvoicesAmountVatable;
                    instruction.Outstanding_Invoices_Non_Vatable_Amount = osInvoicesAmountNonVatable;

                    instruction.Future_Vatable_Line_Balance = instruction.Legal_Cost_Vatable_Balance ?? 0
                                                                - osInvoicesAmountVatable
                                                                + poAmountVatable;

                    instruction.Future_Non_Vatable_Line_Balance = instruction.Legal_Cost_Non_Vatable_Balance ?? 0
                                                                - osInvoicesAmountNonVatable
                                                                + poAmountNonVatable;

                }
            }

            return instruction;
        }

        /// <summary>
        /// Create the instruction in database.
        /// </summary>
        /// <param name="model">Instruction View Model to be stored in database.</param>
        /// <param name="refId">System Type: 1-Legal Lawyer Portal / 2-Business Unit Portal</param>
        /// <returns>true for success, false otherwise</returns>
        public static bool CreateInstruction(InstructionViewModel model, SystemTypes refId, out string instructionRef)
        {
            bool sendInstruction = (model.Sent_Status == "Send Instruction") ? true : false;
            int instructionID = 0;
            //1. GENERATING Instruction Reference Number
            //2. Insert New Instruction
            //3. Update the generated number to External Instruction table with recently inserted record
            model.Instruction_Reference = InsertNewInstruction(model, refId, out instructionID);
            instructionRef = model.Instruction_Reference;
            if (instructionID != 0)
                model.ID = instructionID;
            //If INSTRUCTION Created at Group Legal Dashboard (status = GroupLegalInstruction)
            if (refId == SystemTypes.GroupLegal)
            {
                //Get GRV value from Client Companies table
                var isGRV = CommonManager.GetGRVForClientCompanyByID(Convert.ToInt32(model.Billing_Entity_ID ?? 0));
                if (isGRV == CommonConstants.Yes)
                {
                    var dict = new Dictionary<string, string>();
                    dict.Add("GRV", "YES");
                    dict.Add("Mode", "NEW INSTRUCTION");
                    //Set the instruction status as "Pending Contact"
                    SetInstructionStatus(model.Instruction_Reference, VarConstants.Instruction_Pending_Contacts, sendInstruction, dict);
                }
                else if (isGRV == CommonConstants.No)
                {
                    var dict = new Dictionary<string, string>();
                    dict.Add("GRV", "NO");
                    dict.Add("Mode", "NEW INSTRUCTION");
                    //Set the instruction status as "Pending Review"
                    SetInstructionStatus(model.Instruction_Reference, VarConstants.Instruction_Pending_Review, sendInstruction, dict);

                    //TODO: Check email functionality.
                    NewInstruction_GRV_NO_SendEmail(model);
                }
                else
                {
                    //Nothing for now.
                }
                //Create PO task
                if (!string.IsNullOrEmpty(model.GLAccount))
                {
                    var instruction = InstructionManager.GetInstruction(model.ID);
                    PurchaseOrderViewModel purchaseOrderViewModel = new PurchaseOrderViewModel();
                    purchaseOrderViewModel.External_Instructions = instruction;
                    purchaseOrderViewModel.External_Instructions.MatterDetail = MatterManager.GetMatterBlock(instruction.Matter_Reference);

                    purchaseOrderViewModel.Instruction_ID = instruction.ID;
                    purchaseOrderViewModel.Cost_Centre = instruction.Cost_Centre;
                    purchaseOrderViewModel.Instruction_Reference = instruction.Instruction_Reference;
                    purchaseOrderViewModel.Vatable_Amount = instruction.Estimated_Legal_Cost_Vatable;
                    purchaseOrderViewModel.Non_Vatable_Amount = instruction.Estimated_Legal_Cost_Non_Vatable;
                    purchaseOrderViewModel.Vendor = instruction.Vendor;
                    purchaseOrderViewModel.Vendor_ID = instruction.Vendor_ID;
                    purchaseOrderViewModel.External_Instructions.Matter_Reference = instruction.Matter_Reference;
                    purchaseOrderViewModel.External_Instructions.Matter_Name = purchaseOrderViewModel.External_Instructions.MatterDetail.MatterName;
                    purchaseOrderViewModel.External_Instructions.PO_Contact_ID = instruction.PO_Contact_ID;
                    purchaseOrderViewModel.Status = VarConstants.OnHold;
                    purchaseOrderViewModel.GL_Account = model.GLAccount;
                    purchaseOrderViewModel.GroupWideSplit = model.GroupWideSplit;

                    purchaseOrderViewModel.Created_By = model.Created_By;
                    var purchaseOrderId = POManager.CreatePurchaseOrder(purchaseOrderViewModel);

                    if (purchaseOrderId > 0)
                    {
                        var poTask = new POTaskViewModel
                        {
                            PurchaseOrderID = purchaseOrderId,
                            Status = VarConstants.OnHold,
                            Assigned_To_ID = instruction.PO_Contact_ID,
                            Assigned_To = purchaseOrderViewModel.External_Instructions.PO_Contact,
                            Complete = null,
                            Comments = null,
                            Created = DateTime.Now
                        };

                        var poTaskId = POManager.CreatePOTask(poTask);

                        if (poTaskId > 0)
                        {
                            poTask.ID = poTaskId;
                            poTask.Purchase_Orders = purchaseOrderViewModel;
                            poTask.Purchase_Orders.External_Instructions.Cost = (purchaseOrderViewModel.Vatable_Amount.Value) + purchaseOrderViewModel.Non_Vatable_Amount.Value;
                            //JIRA-696
                            poTask.BusinessUnit = purchaseOrderViewModel.External_Instructions.MatterDetail.BusinessUnitName;
                            //POManager.SendEmailNewPOAndNewPOTaskAndPOContact(poTask);
                        }
                    }
                }
            }
            //else if (refId == SystemTypes.BusinessUnit)
            //SendInstruction_Approval_DisciplineLead_SendEmail(model.Instruction_Reference, MatterManager.GetDisciplineLead(model.MatterDetail.LegalPraticeArea, model.MatterDetail.System, ref dLeadId), (int)SystemTypeEnum.BusinessUnit);

            return true;
        }

        public static void UpdatePO(InstructionViewModel model, string instructionRef)
        {
            using (var repo = new PurchaseOrdersRepository())
            {
                var po = repo.First(x => x.External_Instructions.Instruction_Reference == instructionRef && (x.Status == VarConstants.PendingNew || x.Status == VarConstants.OnHold));
                if (po != null)
                {
                    po.Vatable_Amount = model.Estimated_Legal_Cost_Vatable;
                    po.Non_Vatable_Amount = model.Estimated_Legal_Cost_Non_Vatable;
                    po.GL_Account = model.GLAccount;
                    po.GroupWideSplit = model.GroupWideSplit;
                    po.Cost_Centre = model.Cost_Centre;
                    repo.Entry(po, EntityState.Modified);
                    repo.SaveChanges();
                }
                else
                {
                    if (!string.IsNullOrEmpty(model.GLAccount))
                    {
                        var instruction = InstructionManager.GetInstruction(model.ID);
                        PurchaseOrderViewModel purchaseOrderViewModel = new PurchaseOrderViewModel();
                        purchaseOrderViewModel.External_Instructions = instruction;
                        purchaseOrderViewModel.External_Instructions.MatterDetail = MatterManager.GetMatterBlock(instruction.Matter_Reference);

                        purchaseOrderViewModel.Instruction_ID = instruction.ID;
                        purchaseOrderViewModel.Cost_Centre = instruction.Cost_Centre;
                        purchaseOrderViewModel.Instruction_Reference = instruction.Instruction_Reference;
                        purchaseOrderViewModel.Vatable_Amount = instruction.Estimated_Legal_Cost_Vatable;
                        purchaseOrderViewModel.Non_Vatable_Amount = instruction.Estimated_Legal_Cost_Non_Vatable;
                        purchaseOrderViewModel.Vendor = instruction.Vendor;
                        purchaseOrderViewModel.Vendor_ID = instruction.Vendor_ID;
                        purchaseOrderViewModel.External_Instructions.Matter_Reference = instruction.Matter_Reference;
                        purchaseOrderViewModel.External_Instructions.Matter_Name = purchaseOrderViewModel.External_Instructions.MatterDetail.MatterName;
                        purchaseOrderViewModel.External_Instructions.PO_Contact_ID = instruction.PO_Contact_ID;
                        purchaseOrderViewModel.Status = model.Status == VarConstants.Instruction_Pending_Review ? VarConstants.PendingNew : VarConstants.OnHold;
                        purchaseOrderViewModel.GL_Account = model.GLAccount;
                        purchaseOrderViewModel.GroupWideSplit = model.GroupWideSplit;

                        purchaseOrderViewModel.Created_By = model.Created_By;
                        var purchaseOrderId = POManager.CreatePurchaseOrder(purchaseOrderViewModel);

                        if (purchaseOrderId > 0)
                        {
                            var poTask = new POTaskViewModel
                            {
                                PurchaseOrderID = purchaseOrderId,
                                Status = model.Status == VarConstants.Instruction_Pending_Review ? VarConstants.PendingNew : VarConstants.OnHold,
                                Assigned_To_ID = model.Status == VarConstants.Instruction_Pending_Review ? model.PO_Contact_ID : null,
                                Complete = null,
                                Comments = null,
                                Created = DateTime.Now
                            };

                            var poTaskId = POManager.CreatePOTask(poTask);

                            if (poTaskId > 0)
                            {
                                poTask.ID = poTaskId;
                                poTask.Purchase_Orders = purchaseOrderViewModel;
                                poTask.Purchase_Orders.External_Instructions.Cost = (purchaseOrderViewModel.Vatable_Amount.Value) + purchaseOrderViewModel.Non_Vatable_Amount.Value;
                                poTask.BusinessUnit = purchaseOrderViewModel.External_Instructions.MatterDetail.BusinessUnitName;
                            }
                        }

                        if (model.Status == VarConstants.Instruction_Pending_Review)
                        {
                            using (ExternalInstructionRepository externalInsRepository = new ExternalInstructionRepository())
                            {
                                var instruc = externalInsRepository.First(x => x.Instruction_Reference == instructionRef);
                                instruc.Status = VarConstants.Instruction_Pending_PO;
                                externalInsRepository.Entry(instruc, EntityState.Modified);
                                externalInsRepository.SaveChanges();
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Create the instruction in database.
        /// </summary>
        /// <param name="model">Instruction View Model to be stored in database.</param>
        /// <param name="refId">System Type: 1-Legal Lawyer Portal / 2-Business Unit Portal</param>
        /// <returns>true for success, false otherwise</returns>
        public static bool UpdateInstruction(InstructionViewModel model, string instructionRef)
        {
            bool sendInstruction = (model.Sent_Status == VarConstants.Send_Instruction) ? true : false;

            //Update the External Instruction table with recently updated data in model.
            var updateSuccess = UpdateInstructionEntity(model, instructionRef, false);

            //If INSTRUCTION Created at Group Legal Dashboard (status = GroupLegalInstruction)
            if (updateSuccess)
            {
                var dict = new Dictionary<string, string>();
                dict.Add("GRV", model.GRV != null ? model.GRV.Trim() : model.GRV);

                SetInstructionStatus(instructionRef, model.Status, sendInstruction, dict);

                return true;
            }

            return false;
        }

        #region PRIVATE Operations

        /// <summary>
        /// Get the new instruction reference number according to the specified user portal.
        /// </summary>
        /// <param name="refId">System Type: 1-Legal Lawyer Portal / 2-Business Unit Portal</param>
        /// <returns>string reference number</returns>
        private static string GetInstructionReferenceNumber(string businessUnitName, SystemTypes refId)
        {
            string refNo;

            //string businessUnitAcronym = string.Empty;

            //using (BusinessUnitRepository rep = new BusinessUnitRepository())
            //{
            //    businessUnitAcronym = rep.GetQuery().Where(m => m.Business_Unit1 == businessUnitName).Select(m => m.Acronym).FirstOrDefault();
            //}

            //businessUnitAcronym = businessUnitAcronym ?? "";

            //GENERATING Instruction Reference Number
            using (InstructionReferenceRepository rep = new InstructionReferenceRepository())
            {
                int? instructionRef = 0;

                if (refId == SystemTypes.GroupLegal)
                {
                    instructionRef = rep.Find(x => x.Title == refId.ToString()).FirstOrDefault().NextNumber;
                    //refNo = businessUnitAcronym + "-" + instructionRef.Value.ToString().PadLeft(4, '0') + VarConstants.InstructionRefGL;
                    refNo = instructionRef.Value.ToString().PadLeft(4, '0') + VarConstants.InstructionRefGL;
                }
                else
                {
                    instructionRef = rep.Find(x => x.Title == refId.ToString() && x.Year == DateTime.Now.Year).FirstOrDefault().NextNumber;
                    refNo = instructionRef.Value.ToString().PadLeft(4, '0') + VarConstants.InstructionRefBU;
                }
            }

            return refNo;
        }

        /// <summary>
        /// Inserts the new record to External Instruction table. Also updates the next instruction reference number.
        /// </summary>
        /// <param name="model">Data view model</param>
        /// <param name="refId">System Type: 1-Legal Lawyer Portal / 2-Business Unit Portal</param>
        /// <returns>Returns Instruction Reference Number.</returns>
        private static string InsertNewInstruction(InstructionViewModel model, SystemTypes refId, out int instructionID)
        {
            string refNo = string.Empty;

            RE_EXECUTE_CODE:

            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions { IsolationLevel = System.Transactions.IsolationLevel.Snapshot }))
            {

                try
                {
                    //GENERATING Instruction Reference Number
                    refNo = GetInstructionReferenceNumber(model.MatterDetail.BusinessUnitName, refId);

                    //Insert New Instruction
                    using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
                    {
                        External_Instruction rec = new External_Instruction
                        {
                            Instruction_Reference = refNo,
                            Status = refId == SystemTypes.GroupLegal ? VarConstants.GroupLegalInstruction : VarConstants.BusinessUnitInstruction,
                            FrameworkOrder = model.FrameworkOrder,
                            Confirmed = model.Confirmed,
                            Vendor_ID = model.Vendor_ID,
                            BillingEntityId = model.Billing_Entity_ID,
                            Instruction = model.Instruction,
                            Purchase_Order_Number = model.Payment_Clearance_Number,

                            Estimated_Legal_Cost_Vatable = model.Estimated_Legal_Cost_Vatable,
                            // set instruction balance as same as instruction estimated legal vatable cost.
                            Instructions_Balance = model.Estimated_Legal_Cost_Non_Vatable + model.Estimated_Legal_Cost_Vatable,
                            
                            Instructions_Balance_Local = model.Estimated_Legal_Cost_Non_Vatable_Local + model.Estimated_Legal_Cost_Vatable_Local,//CI-Global_CRI(19-Sep-2018)
                            Legal_Cost_Vatable_Balance_Local = model.Estimated_Legal_Cost_Vatable_Local,//CI-Global_CRI(19-Sep-2018)
                            Legal_Cost_Non_Vatable_Balance_Local = model.Estimated_Legal_Cost_Non_Vatable_Local,//CI-Global_CRI(19-Sep-2018)

                            Estimated_Legal_Cost_Non_Vatable = model.Estimated_Legal_Cost_Non_Vatable,
                            Legal_Cost_Vatable_Balance = model.Estimated_Legal_Cost_Vatable,
                            Legal_Cost_Non_Vatable_Balance = model.Estimated_Legal_Cost_Non_Vatable,
                            
                            CurrencyID = model.Currency_ID,
                            Estimated_Legal_Cost_Vatable_Local = model.Estimated_Legal_Cost_Vatable_Local,
                            Estimated_Legal_Cost_Non_Vatable_Local = model.Estimated_Legal_Cost_Non_Vatable_Local,

                            Cost_Centre = model.Cost_Centre,

                            Matter_ID = model.MatterDetail.Id,

                            Created_By = model.Created_By,
                            Created = DateTime.Now,

                            Modified_By = model.Created_By,
                            Modified = DateTime.Now,

                            Email = model.Email,
                            FileName = model.File != null ? refNo + "_" + model.File.FileName : string.Empty,
                            //GroupWideSplite = model.GroupWideSplite,
                        };

                        if (refId == SystemTypes.GroupLegal)
                            rec.SystemType_ID = (int)SystemTypes.GroupLegal;
                        else
                        {
                            rec.SystemType_ID = (int)SystemTypes.BusinessUnit;
                            rec.PO_Contact_ID = model.PO_Contact_ID;
                            rec.GRV_Contact_ID = model.GRV_Contact_ID;
                            rec.Status = VarConstants.Instruction_Active;

                        }

                        rep.Add(rec);
                        rep.SaveChanges();
                        instructionID = rec.ID;
                    }

                    //Update the generated number to External Instruction table with recently inserted record
                    using (InstructionReferenceRepository rep = new InstructionReferenceRepository())
                    {
                        Instruction_Reference instructionReferenceRecord = null;

                        if (refId == SystemTypes.GroupLegal)
                        {
                            instructionReferenceRecord = rep.Find(x => x.Title == refId.ToString()).FirstOrDefault();
                            instructionReferenceRecord.NextNumber++;
                        }
                        else
                        {
                            instructionReferenceRecord = rep.Find(x => x.Title == refId.ToString() && x.Year == DateTime.Now.Year).FirstOrDefault();
                            instructionReferenceRecord.NextNumber++;
                            if (instructionReferenceRecord.Year != DateTime.Now.Year)
                            {
                                instructionReferenceRecord.Year = DateTime.Now.Year;
                                instructionReferenceRecord.NextNumber = 1;
                            }
                        }

                        rep.SaveChanges();
                    }

                    scope.Complete();
                }
                catch (SqlException ex) // JIRA - EXICHM-371
                {
                    if (ex.Number == 2627)
                    {
                        if (ex.Message.Contains("Unique"))
                        {
                            goto RE_EXECUTE_CODE;
                        }
                        else
                        {
                            throw ex;
                        }
                    }
                    else
                    {
                        throw ex;
                    }
                }
            }

            return refNo;
        }

        /// <summary>
        /// Update the model data to database instruction table.
        /// </summary>
        /// <param name="model">Model object required</param>
        /// <param name="instructionRef">Instruction Reference Number is required</param>
        /// <returns>True for success</returns>
        private static bool UpdateInstructionEntity(InstructionViewModel model, string instructionRef, bool updateStatus = true)
        {
            using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
            {
                var instruction = rep.GetQuery().Where(m => m.Instruction_Reference == instructionRef).FirstOrDefault();

                if (instruction == null)
                    return false;

                instruction.Instruction = model.Instruction;

                //instruction.Sent_Status = model.Sent_Status;
                if (updateStatus)
                    instruction.Status = model.Status;

                instruction.BillingEntityId = model.Billing_Entity_ID;
                instruction.Vendor_ID = model.Vendor_ID;

                instruction.Estimated_Legal_Cost_Vatable = model.Estimated_Legal_Cost_Vatable;
                instruction.Estimated_Legal_Cost_Non_Vatable = model.Estimated_Legal_Cost_Non_Vatable;
                //instruction.Legal_Cost_Vatable_Balance = model.Legal_Cost_Vatable_Balance;
                //instruction.Legal_Cost_Non_Vatable_Balance = model.Legal_Cost_Non_Vatable_Balance;

                instruction.Estimated_Legal_Cost_Vatable_Local = model.Estimated_Legal_Cost_Vatable_Local;
                instruction.Estimated_Legal_Cost_Non_Vatable_Local = model.Estimated_Legal_Cost_Non_Vatable_Local;
                instruction.CurrencyID = model.Currency_ID;

                instruction.Cost_Centre = model.Cost_Centre;
                instruction.Email = model.Email;

                instruction.FrameworkOrder = model.FrameworkOrder;
                instruction.Purchase_Order_Number = model.Payment_Clearance_Number;
                instruction.Confirmed = model.Confirmed;        //PCN Confirmed

                instruction.GRV_Contact_ID = model.GRV_Contact_ID;
                instruction.PO_Contact_ID = model.PO_Contact_ID;
                //instruction.GroupWideSplite = model.GroupWideSplite;
                instruction.Modified = DateTime.Now;
                instruction.Modified_By = model.Modified_By;

                if (model.File != null)
                    instruction.FileName = instruction.Instruction_Reference + "_" + model.File.FileName;

                rep.SaveChanges();
            }

            return true;
        }

        #region Email Sending

        private static void NewInstruction_GRV_NO_SendEmail(InstructionViewModel model)
        {
            string legalPracticeArea, systemType = string.Empty;

            using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
            {
                var externalInstruction = rep.GetByReferenceID(m => m.Instruction_Reference == model.Instruction_Reference).FirstOrDefault();
                var matter = externalInstruction.Matter;
                legalPracticeArea = matter.LegalDiscipline.Name;
                systemType = matter.SystemType.SystemTypeName;
                model.MatterDetail.Lead_Client = matter.PeoplePicker != null ? matter.PeoplePicker.Full_Name : string.Empty;
                model.MatterDetail.Lead_Lawyer = matter.User != null ? matter.User.FullName : string.Empty;
                model.Cost = externalInstruction.Estimated_Legal_Cost_Vatable.Value + externalInstruction.Estimated_Legal_Cost_Non_Vatable.Value;
            }

            var disciplineLead = string.Empty;
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            var emailManager = new EmailManager();

            emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(model.MatterDetail.Lead_Lawyer);
            emailDetails.EmailCC = SystemDetailsViewModel.Team;
            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.NewInstruction_GRV_NO, (int)EmailCategoryEnum.NewInstruction_GRV_NO, emailDetails, model, true);
        }

        private static void PendingContacts_GRV_Required_SendEmail(string instructionRef, int newContactRequestTaskID)
        {
            string legalPracticeArea, systemType = string.Empty;
            var model = new InstructionViewModel();
            model.MatterDetail = new MatterBlock();

            var qsdId = new Dictionary<string, string>
                                    {
                                        {"id", newContactRequestTaskID.ToString()}
                                    };

            using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
            {
                var externalInstruction = rep.GetByReferenceID(m => m.Instruction_Reference == instructionRef).FirstOrDefault();
                var matter = externalInstruction.Matter;
                legalPracticeArea = matter.LegalDiscipline != null ? matter.LegalDiscipline.Name : string.Empty;
                systemType = matter.SystemType != null ? matter.SystemType.SystemTypeName : string.Empty;
                model.Instruction_Reference = model.Instruction_Reference;

                model.Matter_Reference = externalInstruction.Matter != null ? externalInstruction.Matter.Matter_Reference : string.Empty;
                model.MatterDetail.MatterReferenceNumber = externalInstruction.Matter != null ? externalInstruction.Matter.Matter_Reference : string.Empty;

                model.Matter_Name = matter.Matter_Name;
                model.MatterDetail.MatterName = matter.Matter_Name;

                model.Status = externalInstruction.Status;

                model.MatterDetail.Lead_Client = matter.PeoplePicker != null ? matter.PeoplePicker.Full_Name : string.Empty;
                model.MatterDetail.Lead_Lawyer = matter.User != null ? matter.User.FullName : string.Empty;
                model.Payment_Clearance_Number = externalInstruction.Purchase_Order_Number;

                model.Vendor = externalInstruction.Vendor.Company_Name;
                model.Cost = externalInstruction.Estimated_Legal_Cost_Vatable.Value + externalInstruction.Estimated_Legal_Cost_Non_Vatable.Value;
                model.Assigned_To = matter.PeoplePicker != null ? matter.PeoplePicker.Full_Name : string.Empty;
            }

            model.URL = SystemDetailsViewModel.URL
                + "/Section/Instructions/ContactsRequestTask?q="
                + Exigent.Common.Helpers.Crypto.Encrypt(qsdId);

            var disciplineLead = string.Empty; int dLeadId = 0;


            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            var emailManager = new EmailManager();


            emailDetails.EmailTo = SystemDetailsViewModel.Team;


            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.NewContact_PendingContacts, (int)EmailCategoryEnum.NewContact_PendingContacts, emailDetails, model, true);
        }

        private static void PendingContacts_Reassigned_SendEmail(string instructionRef, int newContactRequestTaskID)
        {
            string systemType, legalPracticeArea = string.Empty;

            var model = new InstructionViewModel();
            model.MatterDetail = new MatterBlock();

            var qsdId = new Dictionary<string, string>
                                    {
                                        {"id", newContactRequestTaskID.ToString()}
                                    };
            using (ExternalInstructionsContactsRepository rep = new ExternalInstructionsContactsRepository())
            {
                model.Assigned_To = rep.GetQuery().Where(m => m.ID == newContactRequestTaskID)
                                .Select(m => m.PeoplePicker.Full_Name)
                                .FirstOrDefault();
            }

            using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
            {
                var externalInstruction = rep.GetByReferenceID(m => m.Instruction_Reference == instructionRef).FirstOrDefault();
                var matter = externalInstruction.Matter;
                legalPracticeArea = matter.LegalDiscipline.Name;
                systemType = matter.SystemType.SystemTypeName;
                model.Matter_Reference = externalInstruction.Matter.Matter_Reference;
                model.MatterDetail.MatterReferenceNumber = externalInstruction.Matter.Matter_Reference;

                model.Matter_Name = matter.Matter_Name;
                model.MatterDetail.MatterName = matter.Matter_Name;

                model.Vendor = externalInstruction.Vendor.Company_Name;
            }

            model.URL = SystemDetailsViewModel.URL
                + "/Section/Instructions/ContactsRequestTask?q="
                + Exigent.Common.Helpers.Crypto.Encrypt(qsdId);

            var disciplineLead = string.Empty;
            int dLeadId = 0;
            //disciplineLead = MatterManager.GetDisciplineLead(legalPracticeArea, systemType, ref dLeadId);

            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            var emailManager = new EmailManager();

            emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(model.Assigned_To);
            emailDetails.EmailCC = SystemDetailsViewModel.Team;
            emailDetails.EmailCC += ";" + PeoplePickerManager.GetUserEmailAddress(model.MatterDetail.Lead_Lawyer);
            emailDetails.EmailCC += ";" + PeoplePickerManager.GetUserEmailAddress(disciplineLead);

            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.Pending_Contacts_Reassign, (int)EmailCategoryEnum.Pending_Contacts_Reassign, emailDetails, model, true);
        }

        private static void ActiveInstruction_SendEmails(string instructionRef, string systemType = "")
        {
            var legalPracticeArea = string.Empty;
            var model = new InstructionViewModel();
            model.MatterDetail = new MatterBlock();
            var vendorEmail = string.Empty;

            using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
            {
                var externalInstruction = rep.GetByReferenceID(m => m.Instruction_Reference == instructionRef).FirstOrDefault();
                var matter = externalInstruction.Matter;
                legalPracticeArea = matter.LegalDiscipline.Name;
                vendorEmail = externalInstruction.Email;

                model.Vendor = externalInstruction.Vendor.Company_Name;

                model.Instruction_Reference = externalInstruction.Instruction_Reference;
                model.Instruction = externalInstruction.Instruction;
                model.Billing_Entity = externalInstruction.Client_Companies.Company_Name;

                model.Matter_Reference = externalInstruction.Matter.Matter_Reference;
                model.MatterDetail.MatterReferenceNumber = externalInstruction.Matter.Matter_Reference;

                model.Matter_Name = matter.Matter_Name;
                model.MatterDetail.MatterName = matter.Matter_Name;

                model.MatterDetail.Lead_Lawyer = matter.SystemType.SystemTypeName == SystemTypes.BusinessUnit.ToString() ? matter.PeoplePicker.Full_Name : matter.User.FullName;
                model.MatterDetail.Lead_Client = matter.PeoplePicker.Full_Name;
                model.Cost_Centre = externalInstruction.Cost_Centre;

                model.Cost = externalInstruction.Estimated_Legal_Cost_Vatable.Value + externalInstruction.Estimated_Legal_Cost_Non_Vatable.Value;

                model.Payment_Clearance_Number = externalInstruction.Purchase_Order_Number;
            }

            model.URL = SystemDetailsViewModel.URL;

            //var disciplineLead = string.Empty;
            //using (DisciplineLeadRepository rep = new DisciplineLeadRepository())
            //{
            //    disciplineLead = rep.GetQuery().Where(m => m.Legal_Practise_Area == legalPracticeArea).Select(m => m.Discipline_Lead1).FirstOrDefault();
            //}

            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            var emailManager = new EmailManager();
            var leadLawyerEmail = PeoplePickerManager.GetUserEmailAddress(model.MatterDetail.Lead_Lawyer);

            #region Send Email to Vendor + Lead Lawyer + Admin
            emailDetails.EmailTo = vendorEmail;
            emailDetails.EmailCC = SystemDetailsViewModel.Team + ";" + leadLawyerEmail;
            //emailDetails.EmailCC += ";" + PeoplePickerManager.GetUserEmailAddress(disciplineLead);

            //Sending active instruction email to vendor.
            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.InstructionToVendor, (int)EmailCategoryEnum.InstructionToVendor, emailDetails, model, true);
            #endregion

            #region Send Email to Client Lead + Lead Lawyer + Admin
            emailDetails = new Exigent.Email.Configuration.EmailDetails();
            emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(model.MatterDetail.Lead_Client);
            emailDetails.EmailCC = SystemDetailsViewModel.Team + ";" + leadLawyerEmail;

            //Sending active instruction email to lead client.
            // emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.InstructionApprovedToClientLead, (int)EmailCategoryEnum.InstructionApprovedToClientLead, emailDetails, model, true);
            #endregion
        }

        //private static void SendInstruction_Approval_DisciplineLead_SendEmail(string instructionRef, string assignedTo, int systemType)
        //{
        //    InstructionViewModel model = null;

        //    using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
        //    {
        //        model = rep.GetQuery().Where(m => m.Instruction_Reference == instructionRef)
        //                .Select(m => new InstructionViewModel
        //                {
        //                    Instruction_Reference = m.Instruction_Reference,
        //                    Matter_Reference = m.Matter.Matter_Reference,
        //                    Instruction = m.Instruction,

        //                    MatterDetail = new MatterBlock
        //                    {
        //                        MatterReferenceNumber = m.Matter.Matter_Reference,
        //                        MatterName = m.Matter.Matter_Name,
        //                        Lead_Lawyer = systemType == (int)SystemTypeEnum.BusinessUnit ? m.Matter.PeoplePicker.Full_Name : m.Matter.User.FullName
        //                    },
        //                    Created = m.Created.Value,
        //                    Vendor = m.Vendor.Company_Name,
        //                    Created_By = m.Created_By,
        //                    Matter_Name = m.Matter.Matter_Name,
        //                    Payment_Clearance_Number = m.Purchase_Order_Number,
        //                    Cost = m.Estimated_Legal_Cost_Vatable.Value + m.Estimated_Legal_Cost_Non_Vatable.Value,
        //                    Cost_Centre = m.Cost_Centre
        //                }).FirstOrDefault();

        //        var qsd = new Dictionary<string, string>
        //                            {
        //                                {"instructionRef", model.Instruction_Reference}
        //                            };

        //        model.URL = SystemDetailsViewModel.URL
        //            + "/Section/Instructions/InstructionApprovalTask?q="
        //            + Exigent.Common.Helpers.Crypto.Encrypt(qsd);

        //        //Full name of discipline lead.
        //        model.Assigned_To = assignedTo;
        //    }

        //    var emailDetails = new Exigent.Email.Configuration.EmailDetails();
        //    var emailManager = new EmailManager();

        //    emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(assignedTo);
        //    emailDetails.EmailCC = SystemDetailsViewModel.Team;

        //    emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.SendInstruction_Approval_DisciplineLead, (int)EmailCategoryEnum.SendInstruction_Approval_DisciplineLead, emailDetails, model, true);
        //}

        //private static void InstructionRejected_SendEmail(string instructionRef, string rejectionReason, string currentUserName)
        //{
        //    InstructionApprovalTaskViewModel model = null;

        //    //Get the lead client full-name for current matter of instruction.
        //    using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
        //    {
        //        model = rep.GetQuery()
        //            .Where(m => m.Instruction_Reference == instructionRef)
        //            .Select(m => new InstructionApprovalTaskViewModel
        //            {
        //                Matter_Reference = m.Matter.Matter_Reference,
        //                Matter_Name = m.Matter.Matter_Name,
        //                Vendor = m.Vendor.Company_Name,
        //                Lead_Lawyer = m.SystemType_ID == (int)SystemTypes.GroupLegal ? m.Matter.User.FullName : m.Matter.PeoplePicker.Full_Name,
        //                Instruction_Reference = instructionRef,
        //                Rejection_Reason = rejectionReason,
        //                UserName = currentUserName
        //            }).FirstOrDefault();


        //        //mailTo = rep.GetQuery().Where(m => m.Instruction_Reference == instructionRef)
        //        //            .Select(m => m.Matter.Lead_Client).FirstOrDefault();
        //    }

        //    var emailDetails = new Exigent.Email.Configuration.EmailDetails();
        //    var emailManager = new EmailManager();

        //    emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(model.Lead_Lawyer);

        //    emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.InstructionRejected, (int)EmailCategoryEnum.InstructionRejected, emailDetails, model, true);
        //}

        #endregion Email Sending

        #endregion PRIVATE Operations

        #endregion CRUD Operations on "External Instruction"

        #region Commonly Used Operations on "External Instruction"

        /// <summary>
        /// Set the status of instruction and act according to the specified status.
        /// </summary>
        /// <param name="instructionRef">Required Instruction Ref. Number</param>
        /// <param name="newStatusValue">Required new status value for the instruction</param>
        /// <param name="Sent_Status">Optional Is Sending Instruction </param>
        /// <param name="param">Optional Additional parameters (if required any)</param>
        public static void SetInstructionStatus(string instructionRef, string newStatusValue, bool Sent_Status = false, Dictionary<string, string> param = null)
        {
            External_Instruction externalInstruction = null;
            string systemType = string.Empty;
            bool isStatusChanged = false;

            //Updating new status to External Instruction.
            using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
            {
                externalInstruction = rep.Find(m => m.Instruction_Reference == instructionRef).FirstOrDefault();

                if (externalInstruction.Status != newStatusValue)
                {
                    isStatusChanged = true;

                    //LPA is required only for Instruction_Pending_Approval status.
                    if (newStatusValue == VarConstants.Instruction_Pending_Approval)
                    {
                        ////Get the LPA (Legal Practice Area) for instruction/matter -> for respective Report Classification.
                        //legalPracticeArea = externalInstruction.Matter.LegalDiscipline.Name;
                        //systemType = externalInstruction.Matter.SystemType.SystemTypeName;
                        newStatusValue = VarConstants.Active;
                    }
                    externalInstruction.Status = newStatusValue;
                    rep.SaveChanges();
                }

                if (isStatusChanged)
                {
                    //If status value is changed.
                    switch (newStatusValue)
                    {
                        case VarConstants.Instruction_Pending_Approval:
                            if (Sent_Status == true)
                            {
                                /* Skip approval task
                                //Get the full name of discipline lead for LPA (Legal Practice Area) applicable for respective matter.
                                var disciplineLead = string.Empty;
                                int dLeadId = 0;
                                //disciplineLead = MatterManager.GetDisciplineLead(legalPracticeArea, systemType, ref dLeadId);

                                //Open (Create) a new instruction approval task to discipline lead.
                                var success = InstructionManager.InsertInstructionsApprovalTask(new InstructionApprovalTaskViewModel
                                {
                                    Instruction_Reference = instructionRef,
                                    Comments = string.Empty,
                                    Created = DateTime.Now,
                                    Status = VarConstants.Instruction_Pending_Approval,
                                    Assigned_To = disciplineLead,
                                    Rejection_Reason = null,
                                    Assigned_To_ID = dLeadId,
                                    Instruction_ID = externalInstruction.ID
                                }, false); */
                            }

                            break;

                        case VarConstants.Instruction_Active:
                            if (Sent_Status == true)
                            {
                                //Email Sending Functionality for pending contacts (inserted new pending contact task).
                                ActiveInstruction_SendEmails(instructionRef);
                            }

                            break;

                        case VarConstants.Instruction_Rejected:
                            //Email Sending Functionality.
                            if (Sent_Status == true)
                            {
                                //Email Sending Functionality for pending contacts (inserted new pending contact task).
                                //InstructionRejected_SendEmail(instructionRef, param["RejectionReason"], param["CurrentUserName"]);
                            }
                            break;

                        case VarConstants.Instruction_Pending_Contacts:

                            if (param.ContainsKey("GRV") && param.ContainsKey("Mode") && param["GRV"].ToUpper() == "YES" && param["Mode"].ToUpper() == "NEW INSTRUCTION")
                            {
                                var leadClient = externalInstruction.Matter.PeoplePicker.ID;
                                var newContactRequestTaskID = 0;

                                //Insert External Instruction Pending Contact Information
                                using (ExternalInstructionsContactsRepository repo = new ExternalInstructionsContactsRepository())
                                {
                                    var contact = new External_Instructions_Contact
                                    {
                                        Instruction_ID = externalInstruction.ID,
                                        Status = VarConstants.POContactTask_Pending_Contacts,
                                        Assigned_To_ID = leadClient,
                                        Created = DateTime.Now,
                                        Complete = null
                                    };
                                    repo.Add(contact);
                                    repo.SaveChanges();

                                    newContactRequestTaskID = contact.ID;
                                }

                                //Email Sending Functionality for pending contacts (inserted new pending contact task).
                                PendingContacts_GRV_Required_SendEmail(instructionRef, newContactRequestTaskID);
                            }
                            break;

                        case VarConstants.Instruction_Pending_Review:

                            if (param.ContainsKey("GRV") && param["GRV"].ToUpper() == "NO")
                            {
                                if ((externalInstruction.PO_Contact_ID != null) || (externalInstruction.GRV_Contact_ID != null))
                                {
                                    int payment_processing_ID = 0;
                                    using (ClientComponyRepository reposi = new ClientComponyRepository())
                                    {
                                        payment_processing_ID = reposi.GetQuery().Where(m => m.Company_Name == externalInstruction.Client_Companies.Company_Name)
                                                        .Select(m => m.Payment_Processing_ID).FirstOrDefault().Value;
                                    }

                                    if (payment_processing_ID > 0)
                                    {
                                        if (new PeoplePickerManager().IsPeoplePickerExists(payment_processing_ID))
                                        {
                                            //Update POContact & GRVContact with PaymentProcessing value for selected billing entity.
                                            using (ExternalInstructionRepository rept = new ExternalInstructionRepository())
                                            {
                                                externalInstruction = rept.GetByReferenceID(m => m.Instruction_Reference == instructionRef).FirstOrDefault();

                                                if (externalInstruction.PO_Contact_ID == 0)
                                                    externalInstruction.PO_Contact_ID = payment_processing_ID;

                                                if (externalInstruction.GRV_Contact_ID == 0)
                                                    externalInstruction.GRV_Contact_ID = payment_processing_ID;

                                                rept.SaveChanges();
                                            }
                                        }
                                    }
                                }
                            }

                            break;
                        default:
                            break;
                    }
                }
            }
        }

        public static bool ResolveContacts(InstructionViewModel model, string instructionRef, string billingEntity, string grvRequired)
        {
            bool result = false;

            if (grvRequired.ToUpper() == "NO")
            {
                if (model.PO_Contact_ID == 0 || model.GRV_Contact_ID == 0)
                {
                    int paymentProcessing_ID = 0;

                    using (ClientComponyRepository rep = new ClientComponyRepository())
                    {
                        paymentProcessing_ID = rep.GetQuery().Where(m => m.Company_Name == billingEntity)
                                        .Select(m => m.Payment_Processing_ID).FirstOrDefault().Value;
                    }

                    if (paymentProcessing_ID > 0)
                    {
                        if (new PeoplePickerManager().IsPeoplePickerExists(paymentProcessing_ID))
                        {
                            if (model.PO_Contact_ID == 0)
                            {
                                model.PO_Contact_ID = paymentProcessing_ID;
                                result = true;
                            }

                            if (model.GRV_Contact_ID == 0)
                            {
                                model.GRV_Contact_ID = paymentProcessing_ID;
                                result = true;
                            }
                        }
                    }
                }
            }

            return result;
        }

        /// <summary>
        /// Get the instruction details by specifying reference number.
        /// </summary>
        /// <param name="instructionRef">Instruction Reference Number is required.</param>
        /// <returns>Instruction View Model</returns>
        public static InstructionBlockViewModel GetInstructionSummary(string instructionRef)
        {
            InstructionBlockViewModel instructionVM = null;

            using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
            {
                if (!rep.Any(m => m.Instruction_Reference == instructionRef))
                {
                    return null;
                }
                var instruction = rep.GetQueryWithInclude("Matter").Where(m => m.Instruction_Reference == instructionRef).FirstOrDefault();
                instructionVM = new InstructionBlockViewModel();
                instructionVM.ID = instruction.ID;
                instructionVM.Instruction_Reference = instruction.Instruction_Reference;
                instructionVM.Matter_Reference = instruction.Matter.Matter_Reference;
                instructionVM.Matter_ID = Convert.ToInt32(instruction.Matter_ID);
                instructionVM.Billing_Entity = instruction.Client_Companies.Company_Name;
                instructionVM.Billing_Entity_ID = Convert.ToInt32(instruction.BillingEntityId);
                instructionVM.Matter = new MatterBlock
                {
                    MatterReferenceNumber = instruction.Matter.Matter_Reference,
                    BusinessUnitName = instruction.Matter.Business_Units.Business_Unit1,
                    MatterName = instruction.Matter.Matter_Name,
                    MatterType = instruction.Matter.LegalDiscipline.Name
                };
                instructionVM.Vendor_ID = Convert.ToInt32(instruction.Vendor_ID);
                instructionVM.Vendor = instruction.Vendor.Company_Name;
                instructionVM.Instruction = instruction.Instruction;
                instructionVM.Payment_Clearance_Number = instruction.Purchase_Order_Number;
                instructionVM.Business_Unit_ID = Convert.ToInt32(instruction.Matter.Business_Unit_ID);
                instructionVM.Business_Unit = instruction.Matter.Business_Units.Business_Unit1;
                instructionVM.Estimated_Legal_Cost = ((instruction.Estimated_Legal_Cost_Vatable.HasValue) ? instruction.Estimated_Legal_Cost_Vatable.Value : 0)
                                        + ((instruction.Estimated_Legal_Cost_Non_Vatable.HasValue) ? instruction.Estimated_Legal_Cost_Non_Vatable.Value : 0);

                instructionVM.Cost_Centre = instruction.Cost_Centre;

            }

            return instructionVM;
        }

        /// <summary>
        /// Check & Insert POContact to External Instruction Confirm PO.
        /// Used during Save & Send Instruction processes.
        /// </summary>
        /// <param name="model">InstructionViewModel model object is required</param>
        /// <returns>True for success</returns>
        public static bool InsertInstructionsConfirmPO(InstructionViewModel model)
        {
            var checkCount = false;

            if (model.Confirmed == CommonConstants.No)
                if (model.GRV == CommonConstants.Yes)
                    if (!string.IsNullOrEmpty(model.Payment_Clearance_Number))
                        if (model.PO_Contact_ID > 0)
                            checkCount = true;

            if (checkCount)
            {
                using (ExternalInstructionConfirmPORepository rep = new ExternalInstructionConfirmPORepository())
                {
                    var count = rep.GetQuery().Count(m => m.External_Instructions.Instruction_Reference == model.Instruction_Reference);

                    if (count == 0)
                    {
                        rep.Add(new External_Instructions_Confirm_PO
                        {
                            Instruction_ID = model.ID,
                            Status = VarConstants.InstructionsConfirmPOTask_Pending,
                            Assigned_To_ID = model.PO_Contact_ID,
                            Created = DateTime.Now,
                            Complete = null
                        });

                        rep.SaveChanges();
                    }
                }
            }

            return true;
        }

        #endregion


        #region Instruction - Contact Request Task

        /// <summary>
        /// Check, if Contact Request Task Status is complete?
        /// </summary>
        /// <param name="id">Requires Contact Request Task Id (integer)</param>
        /// <returns>Returns true if task is complete</returns>
        public static bool IsContactRequestTaskComplete(int id)
        {
            using (ExternalInstructionsContactsRepository rep = new ExternalInstructionsContactsRepository())
            {
                var status = rep.GetQuery().Where(m => m.ID == id).Select(m => m.Status).FirstOrDefault();

                if (!string.IsNullOrEmpty(status) && status == VarConstants.POContactTask_Complete)
                    return true;
            }

            return false;
        }

        /// <summary>
        /// Get model detail for Contact Request Task to show on page.
        /// </summary>
        /// <param name="id">Requires Contact Request Task Id (integer)</param>
        /// <returns>Returns ContactRequestTaskViewModel object</returns>
        public static ContactRequestTaskViewModel GetContactRequestTaskDetail(int id)
        {
            using (ExternalInstructionsContactsRepository rep = new ExternalInstructionsContactsRepository())
            {
                var data = rep.GetById(id);

                if (data == null)
                    return null;

                return new ContactRequestTaskViewModel
                {
                    ID = data.ID,
                    Status = data.Status,
                    Instruction_Reference = data.External_Instructions.Instruction_Reference,
                    Instruction_ID = data.External_Instructions.ID,
                    Matter_Reference = data.External_Instructions.Matter.Matter_Reference,
                    Matter_Name = data.External_Instructions.Matter.Matter_Name,
                    Matter_Status = data.External_Instructions.Matter.Matter_Status.Matter_Status1,
                    Matter_LeadLawyer = data.External_Instructions.Matter.User != null ? data.External_Instructions.Matter.User.FullName : string.Empty,
                    Operation = data.External_Instructions.Matter.Operation != null ? data.External_Instructions.Matter.Operation.Operation1 : string.Empty,
                    Vendor = data.External_Instructions.Vendor.Company_Name,
                    Cost_Centre = data.External_Instructions.Cost_Centre,
                    Billing_Entity = data.External_Instructions.Client_Companies.Company_Name,
                    GRV_Contact = data.External_Instructions.PeoplePicker1 != null ? data.External_Instructions.PeoplePicker1.Full_Name : string.Empty,
                    PO_Contact = data.External_Instructions.PeoplePicker != null ? data.External_Instructions.PeoplePicker.Full_Name : string.Empty,
                    GRV_Contact_ID = data.External_Instructions != null ? data.External_Instructions.GRV_Contact_ID : null,
                    PO_Contact_ID = data.External_Instructions != null ? data.External_Instructions.PO_Contact_ID : null,
                    Assigned_To = data.PeoplePicker != null ? data.PeoplePicker.Full_Name : string.Empty,
                    Assigned_To_ID = Convert.ToInt32(data.Assigned_To_ID)
                };

            }

        }


        /// <summary>
        /// Complete the task.
        /// </summary>
        /// <param name="id">Required Contact Request Task Id</param>
        /// <param name="status">Optional status (if provided, then, change the status.</param>
        public static void CompleteContactRequestTask(ContactRequestTaskViewModel model)
        {
            string instructionReference;
            bool canUpdateExternalInstructionStatus = false;
            using (ExternalInstructionsContactsRepository rep = new ExternalInstructionsContactsRepository())
            {
                var data = rep.GetById(model.ID);
                instructionReference = data.External_Instructions.Instruction_Reference;
                data.Status = VarConstants.POContactTask_Complete;
                data.Complete = DateTime.Now;

                rep.SaveChanges();
            }

            if (!string.IsNullOrEmpty(instructionReference))
            {
                int instructionId = 0;
                int purchaseOrderId = 0;
                using (ExternalInstructionRepository externalInstructionRepository = new ExternalInstructionRepository())
                {
                    var externalInstructionDetail = externalInstructionRepository.GetQuery()
                        .Where(m => m.Instruction_Reference == instructionReference).FirstOrDefault();

                    if (externalInstructionDetail != null)
                    {
                        instructionId = externalInstructionDetail.ID;
                        externalInstructionDetail.PO_Contact_ID = model.PO_Contact_ID;
                        externalInstructionDetail.GRV_Contact_ID = model.GRV_Contact_ID;
                        externalInstructionDetail.Status = VarConstants.Instruction_Pending_Review;

                        externalInstructionRepository.SaveChanges();
                    }
                }
                //Check PO task Exist and Assign to is null
                using (PurchaseOrdersRepository purchaseOrdersRepository = new PurchaseOrdersRepository())
                {
                    if (instructionId > 0)
                    {
                        var purchaseOrderList = purchaseOrdersRepository.Find(x => x.Instruction_ID == instructionId && x.Status.ToLower() == "onhold").OrderByDescending(x => x.ID).ToList();
                        foreach (var purchaseOrderDetail in purchaseOrderList)
                        {
                            if (purchaseOrderDetail != null)
                            {
                                purchaseOrderId = purchaseOrderDetail.ID;
                                purchaseOrderDetail.Status = VarConstants.PendingNew;
                                purchaseOrdersRepository.SaveChanges();
                            }

                            #region Update PO Task
                            //Start Update PO Task
                            using (POTaskRepository poTaskRepository = new POTaskRepository())
                            {
                                if (purchaseOrderId > 0)
                                {
                                    var poTaskList = poTaskRepository.Find(x => x.PurchaseOrder_ID == purchaseOrderId && x.Assigned_To_ID == null && x.Status.ToLower() == "onhold").ToList();
                                    foreach (var poTaskDetail in poTaskList)
                                    {
                                        if (poTaskDetail != null)
                                        {
                                            poTaskDetail.Assigned_To_ID = model.PO_Contact_ID;
                                            poTaskDetail.Created = DateTime.Now;
                                            poTaskDetail.Status = VarConstants.PendingNew;
                                            poTaskRepository.SaveChanges();

                                            canUpdateExternalInstructionStatus = true;
                                            SendMailOnNewPOTask(instructionId, purchaseOrderId, poTaskDetail.ID);
                                        }
                                    }
                                }
                            }
                            //End PO task
                            #endregion
                        }
                    }
                }
                //Update External Instruction 
                if (canUpdateExternalInstructionStatus)
                {
                    using (ExternalInstructionRepository externalInstructionRepository = new ExternalInstructionRepository())
                    {
                        var externalInstructionDetail = externalInstructionRepository.GetQuery()
                            .Where(m => m.Instruction_Reference == instructionReference).FirstOrDefault();

                        if (externalInstructionDetail != null)
                        {
                            externalInstructionDetail.Status = VarConstants.Instruction_Pending_PO;
                            externalInstructionRepository.SaveChanges();
                        }
                    }
                }

            }
        }

        public static void SendMailOnNewPOTask(int instructionId, int purchaseOrderId, int poTaskId)
        {
            var instruction = InstructionManager.GetInstruction(instructionId);
            PurchaseOrderViewModel purchaseOrderViewModel = new PurchaseOrderViewModel();
            purchaseOrderViewModel.External_Instructions = instruction;
            purchaseOrderViewModel.External_Instructions.MatterDetail = MatterManager.GetMatterBlock(instruction.Matter_Reference);

            purchaseOrderViewModel.Instruction_ID = instruction.ID;
            purchaseOrderViewModel.Cost_Centre = instruction.Cost_Centre;
            purchaseOrderViewModel.Instruction_Reference = instruction.Instruction_Reference;
            purchaseOrderViewModel.Vatable_Amount = instruction.Estimated_Legal_Cost_Vatable;
            purchaseOrderViewModel.Non_Vatable_Amount = instruction.Estimated_Legal_Cost_Non_Vatable;
            purchaseOrderViewModel.Vendor = instruction.Vendor;
            purchaseOrderViewModel.Vendor_ID = instruction.Vendor_ID;
            purchaseOrderViewModel.External_Instructions.Matter_Reference = instruction.Matter_Reference;
            purchaseOrderViewModel.External_Instructions.Matter_Name = purchaseOrderViewModel.External_Instructions.MatterDetail.MatterName;
            purchaseOrderViewModel.External_Instructions.PO_Contact_ID = instruction.PO_Contact_ID;
            purchaseOrderViewModel.Status = VarConstants.OnHold;
            purchaseOrderViewModel.GL_Account = instruction.GLAccount;
            purchaseOrderViewModel.GroupWideSplit = instruction.GroupWideSplit;

            purchaseOrderViewModel.Created_By = instruction.Created_By;

            if (purchaseOrderId > 0)
            {
                var poTask = new POTaskViewModel
                {
                    PurchaseOrderID = purchaseOrderId,
                    Status = VarConstants.OnHold,
                    Assigned_To_ID = instruction.PO_Contact_ID,
                    Assigned_To = purchaseOrderViewModel.External_Instructions.PO_Contact,
                    Complete = null,
                    Comments = null,
                    Created = DateTime.Now
                };


                if (poTaskId > 0)
                {
                    poTask.ID = poTaskId;
                    poTask.Purchase_Orders = purchaseOrderViewModel;
                    poTask.Purchase_Orders.External_Instructions.Cost = (purchaseOrderViewModel.Vatable_Amount.Value) + purchaseOrderViewModel.Non_Vatable_Amount.Value;
                    //JIRA-696
                    poTask.BusinessUnit = purchaseOrderViewModel.External_Instructions.MatterDetail.BusinessUnitName;
                    poTask.Country = purchaseOrderViewModel.External_Instructions.MatterDetail.Country;
                    poTask.Operations = purchaseOrderViewModel.External_Instructions.MatterDetail.Operations;
                    poTask.Lead_Lawyer = purchaseOrderViewModel.External_Instructions.MatterDetail.Lead_Lawyer;
                    poTask.Taxable_Amount = purchaseOrderViewModel.External_Instructions.Estimated_Legal_Cost_Vatable;
                    poTask.Non_Taxable_Amount = purchaseOrderViewModel.External_Instructions.Estimated_Legal_Cost_Non_Vatable;
                    poTask.Currency = CommonConstants.Currency;
                    poTask.Vendor_Number = purchaseOrderViewModel.External_Instructions.Vendor_ID != null ? purchaseOrderViewModel.External_Instructions.Vendor_ID.ToString() : string.Empty;
                    POManager.SendEmailNewPOAndNewPOTaskAndPOContact(poTask);
                }
            }
        }

        /// <summary>
        /// Set Contact Request Task Re-Assign to another user.
        /// </summary>
        /// <param name="model">Model (ContactRequestTaskViewModel) requires Contact Request Task Id, Assign To & Comments</param>
        public static void ReassignContactRequestTask(ContactRequestTaskViewModel model)
        {
            var newContactRequestTaskID = 0;
            var instructionRef = string.Empty;

            using (ExternalInstructionsContactsRepository rep = new ExternalInstructionsContactsRepository())
            {
                //Complete (close) the instruction approval task without changing status
                var data = rep.GetById(model.ID);
                data.Complete = DateTime.Now;
                rep.SaveChanges();

                //Insert new task for reassignment.
                var contact = new External_Instructions_Contact
                {
                    Instruction_ID = data.Instruction_ID,
                    Assigned_To_ID = model.Assigned_To_ID,
                    Status = VarConstants.POContactTask_Pending_Contacts,
                    Comments = model.Comments,
                    Created = DateTime.Now,
                    Complete = null
                };

                rep.Add(contact);
                rep.SaveChanges();

                newContactRequestTaskID = contact.ID;
                instructionRef = data.External_Instructions.Instruction_Reference;
            }

            //Email Sending Functionality for pending contacts reassign (reassign pending contact task).
            PendingContacts_Reassigned_SendEmail(instructionRef, newContactRequestTaskID);
        }

        #endregion

        #region IncreasePO

        public static IncreasePOViewModel GetIncreasePODetail(string instructRefNo)
        {

            IncreasePOViewModel objIncreasePOViewModel = new IncreasePOViewModel();
            using (ExternalInstructionRepository objExternalInstructionRepo = new ExternalInstructionRepository())
            {
                var objExternalInstruct = objExternalInstructionRepo.Find(x => x.Instruction_Reference.Equals(instructRefNo)).FirstOrDefault();
                var currencyDetail = CurrencyManager.GetCurrencyById(Convert.ToInt16(objExternalInstruct.CurrencyID));
                string CurrencyCode = objExternalInstruct.CurrencyID > 0 ? currencyDetail.CurrencyCode : string.Empty;                
                objIncreasePOViewModel = new IncreasePOViewModel()
                {
                    Matter_Reference = objExternalInstruct.Matter.Matter_Reference,
                    Instruction_Reference = objExternalInstruct.Instruction_Reference,
                    Instruction_ID = objExternalInstruct.ID,
                    Matter_Status = objExternalInstruct.Matter.Matter_Status.Matter_Status1,
                    Vendor = objExternalInstruct.Vendor.Company_Name,
                    Vendor_ID = objExternalInstruct.Vendor_ID,
                    Lead_Lawyer = objExternalInstruct.Matter.User.FullName,
                    Matter_Title = objExternalInstruct.Matter.Matter_Name,
                    HasFinalInvoice = objExternalInstruct.Invoices.Any(x => x.Invoice_Type == "Final Invoice"),
                    PO_Number = objExternalInstruct.Purchase_Order_Number,
                    //cast(COALESCE(Sum(PreVat_Total)- ((Sum(Invoice_Total)-Sum(PreVat_Total))/0.14),0) as decimal(32,2))  AS 'NonVatable' 
                    //update for non Disbursement total new column on invoice table
                    Outstanding_Invoices_Non_Vatable_Amount = objExternalInstruct.Invoices.Any(x => x.Invoice_Status == "Awaiting Approval" || x.Invoice_Status == "Awaiting Audit") ? (objExternalInstruct.Invoices.Where(x => x.Invoice_Status == "Awaiting Approval" || x.Invoice_Status == "Awaiting Audit").Sum(x => x.Disbursement_Total)) : 0,
                    //objExternalInstruct.Invoices.Any(x => x.Invoice_Status == "Awaiting Approval" || x.Invoice_Status == "Awaiting Audit") ? (objExternalInstruct.Invoices.Where(x => x.Invoice_Status == "Awaiting Approval" || x.Invoice_Status == "Awaiting Audit").Sum(x => x.PreVat_Total) - ((objExternalInstruct.Invoices.Sum(x => x.Invoice_Total) - objExternalInstruct.Invoices.Sum(y => y.PreVat_Total)) / vatPercentage)) : 0,
                    //cast(COALESCE((Sum(Invoice_Total)-Sum(PreVat_Total))/0.14,0) as decimal(32,2)) as 'Vatable',
                    Outstanding_Invoices_Vatable_Amount = objExternalInstruct.Invoices.Any(x => x.Invoice_Status == "Awaiting Approval" || x.Invoice_Status == "Awaiting Audit") ? (objExternalInstruct.Invoices.Where(x => x.Invoice_Status == "Awaiting Approval" || x.Invoice_Status == "Awaiting Audit").Sum(x => x.Invoice_Total) - objExternalInstruct.Invoices.Sum(x => x.PreVat_Total)) : 0,
                    Estimated_Legal_Cost_Non_Vatable = objExternalInstruct.Estimated_Legal_Cost_Non_Vatable,
                    Estimated_Legal_Cost_Vatable = objExternalInstruct.Estimated_Legal_Cost_Vatable,
                    Non_Vatable_Balance = objExternalInstruct.Legal_Cost_Non_Vatable_Balance,
                    Vatable_Balance = objExternalInstruct.Legal_Cost_Vatable_Balance,
                    CurrencyCode=CurrencyCode,//CI-Global_CR1(19-Sep-2018): 
                    CurrencyId = objExternalInstruct.CurrencyID,//CI-Global_CR1(19-Sep-2018): 
                };
            }
            return objIncreasePOViewModel;
        }

        public static int UpdateIncreasePO(IncreasePOViewModel objIncreasePOModel, string loggedInUserName)
        {

            int purchaseOrderID = 0;
            if (string.IsNullOrEmpty(objIncreasePOModel.PO_Number))
            {
                return purchaseOrderID;
            }
            SqlParameter prmInstruction_Reference = new SqlParameter { ParameterName = "@Instruction_Reference", DbType = DbType.String, Value = objIncreasePOModel.Instruction_Reference };
            SqlParameter prmPO_Number = new SqlParameter { ParameterName = "@PO_Number", DbType = DbType.String, Value = objIncreasePOModel.PO_Number };
            SqlParameter prmPO_Vendor = new SqlParameter { ParameterName = "@PO_Vendor", DbType = DbType.String, Value = objIncreasePOModel.Vendor };
            SqlParameter prmPO_VatableAmount = new SqlParameter { ParameterName = "@PO_VatableAmount", DbType = DbType.String, Value = objIncreasePOModel.Vatable_Amount };
            SqlParameter prmPO_NonVatableAmount = new SqlParameter { ParameterName = "@PO_NonVatableAmount", DbType = DbType.String, Value = objIncreasePOModel.Non_Vatable_Amount };
            SqlParameter prmPO_User = new SqlParameter { ParameterName = "@PO_User", DbType = DbType.String, Value = loggedInUserName };
            SqlParameter prmPO_VatableAmount_Local = new SqlParameter { ParameterName = "@PO_VatableAmount_Local", DbType = DbType.String, Value = objIncreasePOModel.Vatable_Amount_Local };//CI-Global_CR1(19-Sep-2018): 
            SqlParameter prmPO_NonVatableAmount_Local = new SqlParameter { ParameterName = "@PO_NonVatableAmount_Local", DbType = DbType.String, Value = objIncreasePOModel.Non_Vatable_Amount_Local };//CI-Global_CR1(19-Sep-2018): 
            List<SqlParameter> lstParams = new List<SqlParameter>();
            lstParams.Add(prmInstruction_Reference);
            lstParams.Add(prmPO_Number);
            lstParams.Add(prmPO_Vendor);
            lstParams.Add(prmPO_VatableAmount);
            lstParams.Add(prmPO_NonVatableAmount);
            lstParams.Add(prmPO_User);
            lstParams.Add(prmPO_VatableAmount_Local);
            lstParams.Add(prmPO_NonVatableAmount_Local);
            DataSet ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentIncreasePOStart, lstParams);
            if (ds != null && ds.Tables.Count > 0)
            {
                purchaseOrderID = Convert.ToInt32(ds.Tables[0].Rows[0]["PurchaseOrderID"]);
                // write code to send an email to the 
                if (purchaseOrderID > 0)
                {
                    DataRow drMailAttributes = ds.Tables[1].Rows[0];
                    if (drMailAttributes != null && drMailAttributes.ItemArray.Count() > 0)
                    {

                        var potaskid = new Dictionary<string, string> {
                                    { "id", Convert.ToString(Convert.ToInt32(drMailAttributes["POTaskID"] != DBNull.Value ? drMailAttributes["POTaskID"] : 0))}
                                    , {"status", VarConstants.PendingIncrease.ToString()}
                                    };
                        // get following values to send an email.  
                        IncreasePOViewModel objModel = new IncreasePOViewModel()
                        {
                            POTaskID = Convert.ToInt32(drMailAttributes["POTaskID"] != DBNull.Value ? drMailAttributes["POTaskID"] : 0),
                            Matter_Title = Convert.ToString(drMailAttributes["MaterName"] != DBNull.Value ? drMailAttributes["MaterName"] : string.Empty),
                            Matter_Reference = Convert.ToString(drMailAttributes["MatterRef"] != DBNull.Value ? drMailAttributes["MatterRef"] : string.Empty),
                            Vendor = Convert.ToString(drMailAttributes["Vendor"] != DBNull.Value ? drMailAttributes["Vendor"] : string.Empty),
                            Comments = Convert.ToString(drMailAttributes["Comments"] != DBNull.Value ? drMailAttributes["Comments"] : string.Empty),
                            Vatable_Amount = Convert.ToDecimal(drMailAttributes["VatableAmount"] != DBNull.Value ? drMailAttributes["VatableAmount"] : 0),
                            Non_Vatable_Amount = Convert.ToDecimal(drMailAttributes["NonVatableAmount"] != DBNull.Value ? drMailAttributes["NonVatableAmount"] : 0),
                            Purchase_Total = Convert.ToDecimal(drMailAttributes["PurchaseTotal"] != DBNull.Value ? drMailAttributes["PurchaseTotal"] : 0),
                            URL = SystemDetailsViewModel.URL + "/Main/POTasks?q=" + Exigent.Common.Helpers.Crypto.Encrypt(potaskid),
                            Current_Date = DateTime.Now,
                            EmailTo = drMailAttributes["Email"] != DBNull.Value ? Convert.ToString(drMailAttributes["Email"]) : string.Empty,
                            EmailCC = drMailAttributes["EmailCC"] != DBNull.Value ? Convert.ToString(drMailAttributes["EmailCC"]) : string.Empty
                        };
                        // send email code..
                        // start...
                        var emailDetails = new Exigent.Email.Configuration.EmailDetails();
                        emailDetails.EmailTo = objModel.EmailTo;
                        emailDetails.EmailCC = objModel.EmailCC;
                        EmailManager emailManager = new EmailManager();
                        emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.IncreasePOStart, (int)EmailCategoryEnum.IncreasePOStart, emailDetails, objModel, true);
                        // end...

                    }
                }
            }
            return purchaseOrderID;
        }

        #endregion

        public static string GetInstructionByMatterRef(string matterRef)
        {
            string FileName = string.Empty;
            using (MatterRepository matterRepository = new MatterRepository())
            {
                var matterEntity = matterRepository.Find(m => m.Matter_Reference == matterRef).FirstOrDefault();

                if (matterEntity != null)
                {
                    FileName = matterEntity.External_Instructions != null && matterEntity.External_Instructions.Any() ? matterEntity.External_Instructions.FirstOrDefault().FileName : string.Empty;
                }
            };
            return FileName;
        }

        public static string GetInstructionByInstructionRef(string instructionRef)
        {
            string FileName = string.Empty;
            using (ExternalInstructionRepository externalInstructionRepository = new ExternalInstructionRepository())
            {
                var externalInstructionEntity = externalInstructionRepository.Find(m => m.Instruction_Reference == instructionRef).FirstOrDefault();

                if (externalInstructionEntity != null)
                {
                    FileName = externalInstructionEntity != null && !string.IsNullOrEmpty(externalInstructionEntity.FileName) ? externalInstructionEntity.FileName : string.Empty;
                }
            };
            return FileName;
        }

        public void CloseInstruction(string insRef)
        {
            using (var repo = new ExternalInstructionRepository())
            {
                var instructionEntity = repo.First(m => m.Instruction_Reference == insRef);
                instructionEntity.Status = VarConstants.Closed;

                if (instructionEntity.External_Instructions_Contacts.Any())
                {
                    foreach (var item in instructionEntity.External_Instructions_Contacts)
                    {
                        item.Status = VarConstants.Complete;
                        item.Complete = DateTime.Now;
                    }
                }

                if (instructionEntity.Purchase_Orders.Any())
                {
                    foreach (var item in instructionEntity.Purchase_Orders)
                    {
                        item.Status = VarConstants.Complete;

                        if (item.PO_Tasks.Any())
                        {
                            foreach (var po in item.PO_Tasks)
                            {
                                po.Status = VarConstants.Complete;
                                po.Complete = DateTime.Now;
                            }
                        }
                    }
                }

                repo.Entry(instructionEntity, EntityState.Modified);
                repo.SaveChanges();
            }
        }
    }
}
