﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.BLL
{
    public class OperationManager
    {
        public static OperationViewModel GetOperationById(int id)
        {
            using (var rep = new OperationsRepository())
            {
                var model = rep.GetQuery().Where(m => m.ID == id)
                    .Select(m => new OperationViewModel
                    {
                        Id = m.ID,
                        Business_Unit = m.Business_Units.Business_Unit1,
                        Operation = m.Operation1,
                    }).FirstOrDefault();

                return model;
            }
        }

        public static bool IsExists(int id, string operation)
        {
            using (var rep = new OperationsRepository())
            {
                return rep.Any(p => p.Operation1 == operation.Trim() && p.ID != id);
            }
        }

        public static bool UpdateOperation(OperationViewModel model)
        {
            using (var rep = new OperationsRepository())
            {
                var dt = rep.GetQuery().Where(m => m.ID == model.Id).FirstOrDefault();

                if (dt == null)
                    return false;

              
                dt.BusinessUnit_ID = model.Business_Unit_ID;

                rep.SaveChanges();
            }

            return true;
        }

        public static int CreateOperation(OperationViewModel model)
        {
            using (var rep = new OperationsRepository())
            {
                var dt = new Operation
                {
                    Operation1 = model.Operation,
                    BusinessUnit_ID = model.Business_Unit_ID,
                };

                rep.Add(dt);
                rep.SaveChanges();

                return dt.ID;
            }
        }

    }
}
