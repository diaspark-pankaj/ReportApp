﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent_ViewModels.Common;
using System.Data.Entity;

namespace Exigent.BLL
{
    public class OfficeManager
    {
        public static OfficesViewModel GetOfficeById(int id)
        {
            using (var repo = new OfficeRepository())
            {
                var model = new OfficesViewModel();
                var tbl = repo.First(x => x.Id == id);
                model.Id = tbl.Id;
                model.OfficeName = tbl.OfficeName;
                model.CountryId = tbl.CountryId;
                model.IsActive = tbl.IsActive;
                return model;
            }
        }

        public void SaveOffice(OfficesViewModel model)
        {
            using (var repo = new OfficeRepository())
            {
                var tbl = new Office();
                tbl.OfficeName = model.OfficeName;
                tbl.CountryId = model.CountryId;
                tbl.Id = model.Id;
                tbl.IsActive = model.IsActive;
                
                if (model.Id > 0)
                    repo.Entry(tbl, EntityState.Modified);
                else
                    repo.Add(tbl);

                repo.SaveChanges();

            }
        }
    }
}
