﻿using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.Common.Constants;

namespace Exigent.BLL
{
    public class BUManager
    {
        public static BusinesUnitViewModel GetBusinessUnitById(int id)
        {
            using (var rep = new BusinessUnitRepository())
            {
                var model = rep.GetQuery().Where(m => m.ID == id)
                    .Select(m => new BusinesUnitViewModel
                        {
                            Id = m.ID,
                            Business_Unit = m.Business_Unit1,
                            Color = m.Color,
                            Acronym = m.Acronym,
                            ShortName = m.ShortName
                        }).FirstOrDefault();

                return model;
            }
        }

        public static bool IsExists(int id, string businessUnit)
        {
            using (var rep = new BusinessUnitRepository())
            {
                return rep.Any(p => p.Business_Unit1 == businessUnit.Trim() && p.ID != id);
            }
        }

        public static bool UpdateBusinessUnit(BusinesUnitViewModel model)
        {
            using (var rep = new BusinessUnitRepository())
            {
                var dt = rep.GetQuery().Where(m => m.ID == model.Id).FirstOrDefault();

                if (dt == null)
                    return false;

                //dt.Business_Unit1 = model.Business_Unit;
                dt.Color = model.Color;
                dt.Acronym = model.Acronym;
                dt.ShortName = model.ShortName;

                rep.SaveChanges();
            }

            return true;
        }

        public static int CreateBusinessUnit(BusinesUnitViewModel model)
        {
            using (var rep = new BusinessUnitRepository())
            {
                var dt = new Business_Unit
                {
                    Business_Unit1 = model.Business_Unit,
                    Color = model.Color,
                    Acronym = model.Acronym,
                    ShortName = model.ShortName,
                };

                rep.Add(dt);
                rep.SaveChanges();

                return dt.ID;
            }
        }

        #region BU TimeRecording

        /// <summary>
        /// Add/Update BU time records per month in "BU Time Recording" Table.
        /// </summary>
        /// <param name="bUTimeRecordVm"></param>
        public bool SaveBUTimeRecord(BUTimeRecordingViewModel bUTimeRecordVm , int loggedinUser)
        {
            var month = bUTimeRecordVm.Date.Month;
            var year = bUTimeRecordVm.Date.Year;
            var name = bUTimeRecordVm.Name;

            using (BUTimeRecordingRepository rep = new BUTimeRecordingRepository())
            {
                //Get all BU Time records for specific month/year in single hit.
                var buTimeRecs = rep.GetQuery()
                    .Where(x => x.User.FullName.Equals(name) && x.Month.Equals(month.ToString()) && x.Year.Equals(year.ToString())).ToList();
                double buTimeSum = 0;
                foreach (var item in buTimeRecs)
                {
                    buTimeSum +=Convert.ToDouble(item.BUTimeValue);

                }
                if (buTimeSum >= 100)
                {
                    return false;
                }
                else
                {

                    var timeRec = buTimeRecs.Where(m => m.Business_Unit_ID == bUTimeRecordVm.BusinessUnitId && m.LegalDisciplineId==bUTimeRecordVm.LegalDisciplineId).FirstOrDefault();


                    //Check if it is a new record.
                    if (timeRec == null)
                    {
                        buTimeSum = buTimeSum +Convert.ToDouble(bUTimeRecordVm.BUTimeValue);
                        if (buTimeSum > 100)
                        {
                            return false;
                        }
                        else
                        {
                            timeRec = new BU_Time_Recording();
                            if (timeRec.User != null)
                                timeRec.User.FullName = name;

                            timeRec.Year = year.ToString();
                            timeRec.Month = month.ToString();
                            timeRec.Business_Unit_ID = bUTimeRecordVm.BusinessUnitId;
                            timeRec.BUTimeValue = bUTimeRecordVm.BUTimeValue;
                            timeRec.Created = DateTime.Now;
                            timeRec.UserId = bUTimeRecordVm.UserId;
                            timeRec.LegalDisciplineId = bUTimeRecordVm.LegalDisciplineId;
                            timeRec.Created_By = loggedinUser;
                            //Add the object to the entity set.
                            rep.Add(timeRec);
                        }
                    }
                    else
                    {
                        buTimeSum = buTimeSum - Convert.ToDouble(timeRec.BUTimeValue);
                        buTimeSum = buTimeSum + Convert.ToDouble(bUTimeRecordVm.BUTimeValue);
                        if (buTimeSum > 100)
                        {
                            return false;
                        }
                        else
                        {
                            //Update the already existing entity.
                            timeRec.User.FullName = name;
                            timeRec.Year = year.ToString();
                            timeRec.Month = month.ToString();
                            timeRec.Business_Unit_ID = bUTimeRecordVm.BusinessUnitId;
                            timeRec.BUTimeValue = bUTimeRecordVm.BUTimeValue;
                            timeRec.Modified = DateTime.Now;
                            //timeRec.Modified_By_LeadLawyer_ID = item.Modified_By;
                            timeRec.UserId = bUTimeRecordVm.UserId;
                            timeRec.LegalDisciplineId = bUTimeRecordVm.LegalDisciplineId;
                            //timeRec.Created_By = timeRec.Created_By;
                            timeRec.Modified_By = loggedinUser;
                            timeRec.Modified = DateTime.Now;
                        }
                    }
                    // }

                    //Permanently save changes to the database.
                    rep.SaveChanges();
                }
                return true;
            }
        }

        /// <summary>
        /// Retrieves BU time record from BU Time Recording table, provided fullname, month and year
        /// </summary>
        /// <param name="name"></param>
        /// <param name="month"></param>
        /// <param name="year"></param>
        /// <returns></returns>
        public List<BUTimeRecordingViewModel> GetExistingBUTimeRecord(string name, string month, string year)
        {
            var model = new List<BUTimeRecordingViewModel>();
			// User1 : User
			// User2 : Modified BY
			// User3 : Created By
			// Verify below user assignement : code Ref : x.User1.
			using (BUTimeRecordingRepository rep = new BUTimeRecordingRepository())
            {
                var buTimeRecs = rep.GetQuery()
                    .Where(x => x.User1.FullName.Equals(name) && x.Month.Equals(month) && x.Year.Equals(year)).ToList();

                using (BusinessUnitRepository buRep = new BusinessUnitRepository())
                {
                    var businessUnits = buRep.GetQuery().Select(m =>
                         new
                         {
                             Id = m.ID,
                             BusinessUnit = m.Business_Unit1,
                             Color = m.Color
                         }).OrderBy(q => q.BusinessUnit).ToList()
                         .Select(m =>
                         new
                         {
                             Id = m.Id,
                             TimeRec = buTimeRecs.Where(x => x.Business_Units.Business_Unit1 == m.BusinessUnit).FirstOrDefault(),
                             BusinessUnit = m.BusinessUnit,
                             Color = m.Color
                         }).ToList();

                    model = businessUnits
                        .Select(m => new BUTimeRecordingViewModel
                        {
                            BusinessUnitId = m.Id,
                            Business_Unit = m.BusinessUnit,
                            BUTimeValue = (m.TimeRec == null) ? null : m.TimeRec.BUTimeValue,
                            BusinessUnitColor = m.Color
                        }).ToList();
                }

                return model;
            }

        }

        /// <summary>
        /// Gets BU Time Allocation Chart details
        /// </summary>
        /// <param name="fullName"></param>
        /// <returns></returns>
        public List<BUTimeAllocationChartViewModel> GetBUTimeAllocationChartDetails(string fullName)
        {

            var modelList = GetExistingBUTimeRecord(fullName, DateTime.Now.Month.ToString(), DateTime.Now.Year.ToString())
                .Select(m => new BUTimeAllocationChartViewModel
                {
                    Business_Unit = m.Business_Unit,
                    color = m.BusinessUnitColor,
                    value = m.BUTimeValue
                }).ToList();

            return modelList;
        }

        public static BUTimeRecordingViewModel GetBUTimeRecordingById(int id, int businessUnit)
        {
            using (var rep = new BUTimeRecordingRepository())
            {
                var model = rep.GetQuery().Where(m => m.ID == id && m.Business_Unit_ID==businessUnit)
                    .Select(m => new BUTimeRecordingViewModel
                    {
                        Id = m.ID,
                        Business_Unit = m.Business_Units.Business_Unit1,
                        BusinessUnitId=m.Business_Unit_ID,
                        BUTimeValue = m.BUTimeValue,
                        Legal_Discipline = m.LegalDiscipline.Name,
                        LegalDisciplineId=m.LegalDisciplineId,
                        Year=m.Year,
                        Month=m.Month,
                        UserId=m.User.Id,
                        Name=m.User.FullName     
                    }).FirstOrDefault();

                return model;
            }
        }

        public static string UpdateBuTimeRecording(BUTimeRecordingViewModel model , int loggedinUserId)
        {
            var month = model.Month;
            var year = model.Year;
            var userId = model.UserId;
            bool isUpdated = false;
           
            using (BUTimeRecordingRepository rep = new BUTimeRecordingRepository())
            {
                //Get all BU Time records for specific month/year in single hit.
                var buTimeRecs = rep.GetQuery()
                    .Where(x => x.UserId==userId && x.Month.Equals(month.ToString()) && x.Year.Equals(year.ToString())).ToList();

                var timeRec = buTimeRecs.Where(m => m.Business_Unit_ID == model.BusinessUnitId && m.LegalDisciplineId == model.LegalDisciplineId).FirstOrDefault();            
                var buTime = buTimeRecs.Where(m => m.ID == model.Id).FirstOrDefault();
                isUpdated = timeRec == null ? true : timeRec.ID == buTime.ID ? true : false;
                if (isUpdated)
                { 
                    double buTimeRecsSum = 0;
                    foreach (var item in buTimeRecs)
                    {
                        buTimeRecsSum += Convert.ToDouble(item.BUTimeValue);
                    }

                    buTimeRecsSum = buTimeRecsSum - Convert.ToDouble(buTime.BUTimeValue);
                    buTimeRecsSum = buTimeRecsSum + Convert.ToDouble(model.BUTimeValue);
                    if (buTimeRecsSum < 100)
                    {
                        buTime.BUTimeValue = model.BUTimeValue;
                        buTime.Business_Unit_ID = model.BusinessUnitId;
                        buTime.LegalDisciplineId = model.LegalDisciplineId;
                        buTime.Modified_By = loggedinUserId;
                        buTime.Modified = DateTime.Now;
                        rep.SaveChanges();
                    }
                    else
                    {
                        return VarConstants.PercentageError;
                    }
                }
                else
                {
                    return VarConstants.RecordExists;
                }

            }

            return VarConstants.TimeAdded;
        }
        #endregion
    }
}
