﻿using Exigent.Common.Enums;
using Exigent.Common.Helpers;
using Exigent.DataLayer.Repository;
using Exigent.Email.Configuration;
using Exigent.Models;
using Exigent.ViewModels.Common;
using Exigent_ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Linq;
using System.Net.Mail;
using System.Threading;

namespace Exigent.BLL
{
    public class EmailManager
    {
        /// <summary>
        /// method to get email template from category type
        /// </summary>
        /// <param name="categoryId"></param>
        /// <returns></returns>
        public EmailTemplate GetEmailTemplateByCategory(int categoryId)
        {
            using (EmailRepository emailRepository = new EmailRepository())
            {
                var emailTemp = emailRepository.Find(x => x.CategoryId == categoryId);
                return emailTemp != null ? emailTemp.FirstOrDefault() : new EmailTemplate();
            }
        }

        public int GetEmailTemplateByCatId(int categoryId)
        {
            using (EmailRepository emailRepository = new EmailRepository())
            {
                var emailTemp = emailRepository.Find(x => x.CategoryId == categoryId);
                if (emailTemp.Count() > 0)
                    return emailTemp.FirstOrDefault().Id;
            }
            return 0;
        }

        /// <summary>
        /// method to get list of keywords from object type
        /// </summary>
        /// <param name="objectId"></param>
        /// <returns></returns>
        public List<KeywordViewModel> GetKeywordByObjectId(int objectId)
        {
            List<KeywordViewModel> lstkeywordVm = new List<KeywordViewModel>();
            using (KeywordRepository keywordRepository = new KeywordRepository())
            {
                var lstkeyword = keywordRepository.Find(x => x.ObjectId == objectId && x.IsActive == true);
                foreach (var keyword in lstkeyword)
                {
                    lstkeywordVm.Add(new KeywordViewModel
                    {
                        Id = keyword.Id,
                        IsActive = keyword.IsActive,
                        Name = keyword.Name,
                        Value = keyword.Value,
                        Type = keyword.Type,
                        ObjectId = keyword.ObjectId
                    });
                }

            }
            return lstkeywordVm;
        }

        /// <summary>
        /// method to get email template after keyword replaced & send mail
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objectType"></param>
        /// <param name="categoryId"></param>
        /// <param name="expectedObject"></param>
        /// <returns></returns>
        public bool GetEmailTemplateSendMail<T>(int objectType, int categoryId, EmailDetails emailDetails, T expectedObject, bool isSubject = false, bool isSendActualEmail = true, bool ccOverride = true)
        {
            List<KeywordViewModel> keywordvm = GetKeywordByObjectId(objectType);
            var template = GetEmailTemplateByCategory(categoryId);
            if (template != null)
            {
                template.EmailContent = KeywordReplacementHelper.ReplaceConditionalTagKeyword(template.EmailContent, keywordvm, expectedObject);
                template.TextContent = KeywordReplacementHelper.ReplaceConditionalTagKeyword(template.TextContent, keywordvm, expectedObject);
            }

            if (isSubject)
                template.EmailSubject = KeywordReplacementHelper.ReplaceConditionalTagKeyword(template.EmailSubject, keywordvm, expectedObject);

            //send email
            bool status = SendMail(template, emailDetails, isSendActualEmail, ccOverride);
            return status;
        }

        /// <summary>
        /// Send Text/HTML Content directly to mail without using Templates.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="objectType"></param>
        /// <param name="categoryId"></param>
        /// <param name="expectedObject"></param>
        /// <returns></returns>
        public bool SendDirectMail(EmailDetails emailDetails)
        {
            var template = new EmailTemplate();
            template.EmailContent = emailDetails.EmailContent;
            template.EmailSubject = emailDetails.EmailSubject;
            template.FromName = "Chameleon inform";
            template.FromEmail = "ChameleonInform@exigent-group.com";

            //send email
            bool status = SendMail(template, emailDetails);
            return status;
        }

        /// <summary>
        /// To initiate a reminder email (not in use for now).
        /// The job is being done using stand alone windows service.
        /// </summary>
        /// <param name="objectType"></param>
        /// <returns></returns>
        public static bool IsAReminderMailObject(int objectType)
        {
            switch (objectType)
            {
                case (int)EmailCategoryEnum.SendInstruction_Approval_DisciplineLead:
                    return true;
                case (int)EmailCategoryEnum.InvoiceApprove:
                    return true;
                case (int)EmailCategoryEnum.NewGrv:
                    return true;
                case (int)EmailCategoryEnum.NewPOTask:
                    return true;
                case (int)EmailCategoryEnum.InvoiceSubmission:
                    return true;
                default:
                    return false;
            }
        }

        // Create a new Mutex. The creating thread does not own the mutex.
        private static Mutex emailMutex = new Mutex();

        /// <summary>
        /// send mail using template
        /// </summary>
        /// <param name="template"></param>
        /// <param name="toEmail"></param>
        /// <returns></returns>
        private bool SendMail(EmailTemplate template, EmailDetails emailDetails, bool isSendActualEmail = true, bool ccOverride = true)
        {
            bool status = false;
            try
            {
                EmailDetails emailingDetails = new EmailDetails();
                if (Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["Environment"]) == (int)EnvironmentEnum.QA && Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["SendMail"]) == false)
                {
                    if (emailDetails.EmailTo != null && emailDetails.EmailTo.Contains("diaspark.com") && emailDetails.EmailCC != null && emailDetails.EmailCC.Contains("diaspark.com"))
                    {
                        emailingDetails.EmailTo = emailDetails.EmailTo;
                        var myList = new List<string>(emailDetails.EmailCC.Split(';'));
                        string cc = string.Empty;
                        foreach (var item in myList)
                        {
                            if (item.Contains("diaspark.com"))
                                cc = cc == string.Empty ? item : item + ";";
                        }
                        emailingDetails.EmailCC = cc;
                    }
                }
                else if (Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["Environment"]) == (int)EnvironmentEnum.UAT && Convert.ToBoolean(System.Configuration.ConfigurationManager.AppSettings["SendMail"]))
                {
                    emailingDetails.EmailTo = emailDetails.EmailTo;
                    emailingDetails.EmailCC = emailDetails.EmailCC;
                    if (string.IsNullOrEmpty(emailingDetails.EmailCC) && ccOverride)
                        emailingDetails.EmailCC = SystemDetailsViewModel.Team;
                }

                else if (Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["Environment"]) == (int)EnvironmentEnum.Local)
                {
                    emailingDetails.EmailTo = System.Configuration.ConfigurationManager.AppSettings["Email"].ToString();
                    emailingDetails.EmailCC = System.Configuration.ConfigurationManager.AppSettings["Email"].ToString();
                }

                #region For Testing

                if (string.IsNullOrEmpty(emailingDetails.EmailTo))
                    emailingDetails.EmailTo = System.Configuration.ConfigurationManager.AppSettings["Email"].ToString();

                if (string.IsNullOrEmpty(emailingDetails.EmailCC))
                    emailingDetails.EmailCC = System.Configuration.ConfigurationManager.AppSettings["Email"].ToString();

                #endregion

                emailingDetails.Attachment = emailDetails.Attachment;
                emailingDetails.EmailSubject = template.EmailSubject;
                emailingDetails.EmailContent = template.EmailContent;
                emailingDetails.EmailTextContent = template.TextContent;
                emailingDetails.EmailFrom = template.FromEmail;
                emailingDetails.FromName = template.FromName;
                emailingDetails.EmailSentSuccessfully = isSendActualEmail;

                if (emailMutex.WaitOne(Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["EmailMutexDelay"])))
                {
                    var sendMailAttempt = 0;
                RetrySendMail:
                    try
                    {
                        sendMailAttempt++;
						bool IsSecure = ConfigurationManager.AppSettings["IsSecure"] != null ? Convert.ToBoolean(ConfigurationManager.AppSettings["IsSecure"]) : false;
						bool isSendMail = true;
						if (ConfigurationManager.AppSettings["AllowEMail"] != null)
							isSendMail = Convert.ToBoolean(ConfigurationManager.AppSettings["AllowEMail"]);
						if (isSendMail)
							status = Exigent.Email.Helper.EmailHelper.SendEmail(emailingDetails, IsSecure);
					}
                    catch (SmtpFailedRecipientException ex) // JIRA - EXICHM-371
                    {
                        SmtpStatusCode statusCode = ex.StatusCode;

                        var emailRepeatCount = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["EmailRepeatCount"]);
                        var emailRepeatAttemptDelay = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["EmailRepeatAttemptDelay"]);

                        if (sendMailAttempt <= emailRepeatCount)
                        {
                            Thread.Sleep(emailRepeatAttemptDelay);
                            goto RetrySendMail;
                        }
                        else
                            throw ex;
                    }
					catch (Exception ex)
					{
						throw ex;
					}
					finally
                    {
                        emailMutex.ReleaseMutex();
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Due to some un-identified reasons with mail server, Email couldn't be sent.", ex);
            }
            return status;
        }

        //send email using service
        public static void SendQueueMail()
        {
            try
            {
                Exigent.Email.Helper.EmailHelper.SendQueueMail();
            }
            catch (Exception ex) { throw ex; }
        }

        public void SaveTemplates(EmailTemplateViewModel model)
        {
            using (var repo = new EmailRepository())
            {
                var tbl = new EmailTemplate();
                tbl.CategoryId = model.CategoryId;
                tbl.EmailContent = model.EmailContent;
                tbl.EmailSubject = model.EmailSubject;
                tbl.FromEmail = model.EmailFrom;
                tbl.FromName = model.FromName;
                tbl.Id = model.ID;
                tbl.Name = model.Name;
                tbl.TextContent = model.TextContent;

                if (model.ID > 0)
                    repo.Entry(tbl, EntityState.Modified);
                else
                    repo.Add(tbl);

                repo.SaveChanges();

            }
        }

        public static EmailTemplateViewModel GetEmailTemplateById(int id)
        {
            using (var repo = new EmailRepository())
            {
                var model = new EmailTemplateViewModel();
                var tbl = repo.First(x => x.Id == id);
                model.CategoryId = Convert.ToInt32(tbl.CategoryId);
                model.EmailContent = tbl.EmailContent;
                model.EmailSubject = tbl.EmailSubject;
                model.EmailFrom = tbl.FromEmail;
                model.FromName = tbl.FromName;
                model.ID = tbl.Id;
                model.Name = tbl.Name;
                model.TextContent = tbl.TextContent;
                return model;
            }
        }
    }
}
