﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System.Linq;

namespace Exigent.BLL
{
	public class ClientCompanyManager
	{
		public static ClientCompanyViewModel GetClientCompanyById(int id)
		{
			using (var rep = new ClientComponyRepository())
			{
				var model = rep.GetQuery().Where(m => m.ID == id)
					.Select(m => new ClientCompanyViewModel
					{
						Id = m.ID,
                        BusinessUnit_ID = m.Business_Unit_ID,
                        Business_Unit = m.Business_Units.Business_Unit1,
                        Company_Name = m.Company_Name,
						GRV = m.GRV,
						PO = m.PO,
						Payment_Processing_ID = m.Payment_Processing_ID,
                        Payment_Processing = m.User.FullName,
                        Registration_Number = m.Registration_Number,
						Vat_Number = m.Vat_Number,
					}).FirstOrDefault();

				return model;
			}
		}

		public static bool IsExists(int id, string companyName)
		{
			using (var rep = new ClientComponyRepository())
			{
				return rep.Any(p => p.Company_Name == companyName.Trim() && p.ID != id);
			}
		}

		public static bool UpdateClientCompany(ClientCompanyViewModel model)
		{
			using (var rep = new ClientComponyRepository())
			{
				var dt = rep.GetQuery().Where(m => m.ID == model.Id).FirstOrDefault();

				if (dt == null)
					return false;

				dt.Company_Name = model.Company_Name;
				dt.GRV = model.GRV;
				dt.PO = model.PO;
				dt.Payment_Processing_ID = model.Payment_Processing_ID;
				dt.Registration_Number = model.Registration_Number;
				dt.Vat_Number = model.Vat_Number;
                dt.Business_Unit_ID = model.BusinessUnit_ID;
                dt.Payment_Processing_ID = model.Payment_Processing_ID;

                rep.SaveChanges();
			}

			return true;
		}

		public static int CreateClientCompany(ClientCompanyViewModel model)
		{
			using (var rep = new ClientComponyRepository())
			{
				var dt = new Client_Company
				{
					ID = model.Id,
					Business_Unit_ID = model.BusinessUnit_ID,
					Company_Name = model.Company_Name,
					GRV = model.GRV,
					PO = model.PO,
					Payment_Processing_ID = model.Payment_Processing_ID,
					Registration_Number = model.Registration_Number,
					Vat_Number = model.Vat_Number,
				};

				rep.Add(dt);
				rep.SaveChanges();

				return dt.ID;
			}
		}

	}
}
