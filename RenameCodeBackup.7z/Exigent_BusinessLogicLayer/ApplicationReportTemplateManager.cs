﻿using Exigent.DataLayer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Exigent.BLL
{
    public class ApplicationReportTemplateManager
    {
        public static List<SelectListItem> GetApplicationReportTemplate()
        {
            var lstApplicationReportTemplate = new List<SelectListItem>();
            using (ApplicationReportTemplateRepository applicationReportTemplateRepository = new ApplicationReportTemplateRepository())
            {
                applicationReportTemplateRepository.Find(x => x.IsActive == true).Select(x => new { Id = x.Id, Name = x.Name }).Distinct().ToList().ForEach(y => lstApplicationReportTemplate.Add(
                            new SelectListItem
                            {
                                Text = y.Name,
                                Value = y.Id.ToString()
                            }));

            }
            return lstApplicationReportTemplate.OrderBy(x => x.Text).ToList();
        }
    }
}
