﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Admin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.BLL
{
    public class ManageLoginPageManager
    {
        // Saves and update the image and notification message in LoginPageAttributes table
        public void SaveLoginPageAttributes(ManageLoginPageViewModel manageLoginPageViewModel)
        {
            using (LoginPageAttributeRepository loginPageAttributeRepository = new LoginPageAttributeRepository())
            {
                var count = loginPageAttributeRepository.GetAll().Count();
                if (count == 1)
                {
                    var loginPageAttribute = loginPageAttributeRepository.Find(x => x.Id == x.Id).FirstOrDefault();
                    if (!string.IsNullOrEmpty(manageLoginPageViewModel.File))
                        loginPageAttribute.Image = manageLoginPageViewModel.File;
                    loginPageAttribute.NotificationBoardMessage = manageLoginPageViewModel.NotificationBoardMessage;

                    loginPageAttribute.Created = DateTime.Now;

                    loginPageAttributeRepository.SaveChanges();
                }
                else if (count == 0)
                {
                    LoginPageAttribute loginPageAttribute = new LoginPageAttribute();
                    if (!string.IsNullOrEmpty(manageLoginPageViewModel.File))
                        loginPageAttribute.Image = manageLoginPageViewModel.File;
                    if (manageLoginPageViewModel.NotificationBoardMessage != null)
                        loginPageAttribute.NotificationBoardMessage = manageLoginPageViewModel.NotificationBoardMessage;


                    loginPageAttribute.Created = DateTime.Now;

                    loginPageAttributeRepository.Add(loginPageAttribute);
                    loginPageAttributeRepository.SaveChanges();
                }


            }
        }

        // Get the image and notification message from LoginPageAttributes table
        public ManageLoginPageViewModel GetLoginPageAttributes()
        {
            using (LoginPageAttributeRepository loginPageAttributeRepository = new LoginPageAttributeRepository())
            {
                var loginPageAttribute = loginPageAttributeRepository.Find(x => x.Id == x.Id).FirstOrDefault(); ;
                if (loginPageAttribute != null)
                {
                    ManageLoginPageViewModel manageLoginPageViewModel = new ManageLoginPageViewModel();
                    manageLoginPageViewModel.File = loginPageAttribute.Image;
                    manageLoginPageViewModel.NotificationBoardMessage = loginPageAttribute.NotificationBoardMessage;
                    return manageLoginPageViewModel;
                }
                else
                    return null;
            }
        }
    }
}
