﻿using Exigent.DataLayer.Repository;
using Exigent.Common.Constants;
using System;
using System.Linq;
using Exigent.ViewModels.Common;
using Exigent.Models;
using Exigent.Common.Enums;
using System.Data.Entity;
using Exigent.EF.Data.Repository;
using Exigent.Common.Helpers;
using System.IO;
using System.Collections.Generic;
using Exigent.ViewModels.Admin;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;

namespace Exigent.BLL
{
    public static class POManager
    {
        public static int CreatePurchaseOrder(PurchaseOrderViewModel model)
        {
            if (model != null)
            {
                using (PurchaseOrdersRepository rep = new PurchaseOrdersRepository())
                {
                    var rec = new Purchase_Order
                    {
                        Cost_Centre = model.Cost_Centre,
                        Instruction_ID = model.Instruction_ID,
                        Vatable_Amount = model.Vatable_Amount,
                        Non_Vatable_Amount = model.Non_Vatable_Amount,
                        Vendor_ID = model.Vendor_ID,
                        Status = model.Status,
                        PO_Number = model.PO_Number,
                        GL_Account = model.GL_Account,
                        GroupWideSplit = model.GroupWideSplit,
                        Created_By = model.Created_By,
                        Created = DateTime.Now
                    };

                    rep.Add(rec);
                    rep.SaveChanges();

                    return rec.ID;
                }
            }
            else
            {
                return 0;
            }
        }

        public static int CreatePOTask(POTaskViewModel model)
        {
            if (model != null)
            {
                using (POTaskRepository rep = new POTaskRepository())
                {
                    var rec = new PO_Task
                    {
                        PurchaseOrder_ID = model.PurchaseOrderID,
                        Status = model.Status,
                        Assigned_To_ID = model.Assigned_To_ID,
                        Complete = model.Complete,
                        Comments = model.Comments,
                        Created = DateTime.Now
                    };

                    rep.Add(rec);
                    rep.SaveChanges();

                    return rec.ID;
                }
            }
            else
            {
                return 0;
            }

        }

        public static void AmendPurchaseOrder(IncreasePOViewModel model, string userName)
        {
            using (var externalInsRepository = new ExternalInstructionRepository())
            {
                var instruction = externalInsRepository.First(x => x.Instruction_Reference == model.Instruction_Reference);
                using (PurchaseOrdersRepository purchaseRepository = new PurchaseOrdersRepository())
                {
                    var purchase = new Purchase_Order();
                    purchase.Status = VarConstants.PendingAmendment;
                    purchase.Instruction_ID = model.Instruction_ID;
                    purchase.Vendor_ID = model.Vendor_ID;
                    purchase.Vatable_Amount = model.Vatable_Amount;
                    purchase.Non_Vatable_Amount = model.Non_Vatable_Amount;
                    purchase.Vatable_Amount_Local = model.Vatable_Amount_Local;//CI-Global_CR1(19-Sep-2018): 
                    purchase.Non_Vatable_Amount_Local = model.Non_Vatable_Amount_Local;//CI-Global_CR1(19-Sep-2018): 
                    purchase.Created = DateTime.Now;
                    purchase.Created_By = userName;
                    purchase.PO_Number = model.PO_Number;
                    var poTask = new PO_Task();
                    poTask.Status = VarConstants.PendingAmendment;
                    poTask.Assigned_To_ID = instruction.PO_Contact_ID;
                    poTask.Created = DateTime.Now;
                    poTask.Comments = VarConstants.PendingAmendment;
                    purchase.PO_Tasks.Add(poTask);
                    purchaseRepository.Add(purchase);
                    purchaseRepository.SaveChanges();
                    model.POTaskID = poTask.ID;
                    SendMailOnNewPO(instruction, model);
                }
                instruction.Status = VarConstants.Instruction_Pending_PO_Amendment;
                externalInsRepository.Entry(instruction, EntityState.Modified);
                externalInsRepository.SaveChanges();
            }
        }

        private static void SendMailOnNewPO(External_Instruction instruction, IncreasePOViewModel model)
        {
            var matter = new Matter();
            using (MatterRepository matterRepository = new MatterRepository())
            {
                matter = matterRepository.GetQueryWithInclude("PeoplePicker").First(x => x.Matter_Reference == instruction.Matter.Matter_Reference);

                var poTaskVm = new POTasksViewModel();
                poTaskVm.Matter_Reference = matter.Matter_Reference;
                poTaskVm.MatterName = matter.Matter_Name;
                poTaskVm.Date = DateTime.Parse(DateTime.Now.ToShortDateString()).ToString(AppConstants.DATEFORMAT_SERVER, CultureInfo.InvariantCulture);

                if (matter.SystemType != null && (matter.User != null || matter.PeoplePicker != null))
                    poTaskVm.LeadLawyer = matter.SystemType.SystemTypeName == SystemTypes.BusinessUnit.ToString() ? matter.PeoplePicker.Full_Name : matter.User.FullName;

                poTaskVm.NonVatable_Amount = Convert.ToString(model.Non_Vatable_Amount);
                poTaskVm.Vatable_Amount = Convert.ToString(model.Vatable_Amount);
                poTaskVm.PoNumber = model.PO_Number;
                poTaskVm.Vendor = instruction.Vendor.Company_Name;
                poTaskVm.Comments = VarConstants.PendingAmendment;

                var qsDictionary = new Dictionary<string, string> { { "id", model.POTaskID.ToString() }, { "status", VarConstants.PendingAmendment }, { "isAdmin", false.ToString() } };
                poTaskVm.Url = SystemDetailsViewModel.URL + "/" + VarConstants.POTasks + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary);

                var emailManager = new EmailManager();
                var emailDetails = new Exigent.Email.Configuration.EmailDetails();
                emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(instruction.PeoplePicker.Full_Name);
                emailDetails.EmailCC = SystemDetailsViewModel.Team + ";" + PeoplePickerManager.GetUserEmailAddress(matter.User.FullName);
                emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.AmendPOTask, (int)EmailCategoryEnum.AmendPOTask, emailDetails, poTaskVm, true);
            }
        }

        #region Email Sending

        public static void SendEmailNewPOAndNewPOTaskAndPOContact(POTaskViewModel model)
        {
            if (model != null)
            {
                var LPA = string.Empty;

                var qsdId = new Dictionary<string, string>
                                    {
                                        {"id", model.ID.ToString()},
                                        {"status", model.Status},
                                        {"isAdmin", true.ToString()}
                                    };

                model.URL = SystemDetailsViewModel.URL + "/" + VarConstants.POTasks + "?q="
                    + Exigent.Common.Helpers.Crypto.Encrypt(qsdId);

                var emailDetails = new Exigent.Email.Configuration.EmailDetails();
                var emailManager = new EmailManager();
                emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(model.Assigned_To);
                emailDetails.EmailCC = SystemDetailsViewModel.Team;
                emailDetails.EmailCC += ";" + PeoplePickerManager.GetUserEmailAddress(model.Purchase_Orders.External_Instructions.MatterDetail.Lead_Lawyer);

                emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.NewPO_NewPOTask_POContact, (int)EmailCategoryEnum.NewPO_NewPOTask_POContact, emailDetails, model, true);
            }
        }

        public static List<GrvTasksReminderViewModel> GetAllGrvTasksReminder()
        {
            var grvTasksList = new List<GrvTasksReminderViewModel>();
            var ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetGrvTasksReminder, new SqlParameter[] { });

            if (ds != null && ds.Tables.Count > 0)
            {
                grvTasksList = ds.Tables[0].ToList<GrvTasksReminderViewModel>().AsQueryable().ToList();
            }

            return grvTasksList;
        }

        public static void SendReminderEmailOnGrv(GrvTasksReminderViewModel model, string sendToEmail = null)
        {
            if (model != null)
            {
                var emailManager = new EmailManager();

                var qsDictionary = new Dictionary<string, string> { 
                                    { "id", model.Invoice_Number }, 
                                    { "isAdmin", false.ToString() }, 
                                    { "isMail", true.ToString() } 
                                };

                model.UrlDocs = SystemDetailsViewModel.URL + "/" + VarConstants.InvoiceDocument + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary);
                model.Url = SystemDetailsViewModel.URL + "/" + VarConstants.GRVTasks + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary);

                var emailDetails = new Exigent.Email.Configuration.EmailDetails();

                emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(model.Assigned_To);
                if (!string.IsNullOrEmpty(sendToEmail))
                    emailDetails.EmailCC = sendToEmail;

                emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.Reminder_NewGrv, (int)EmailCategoryEnum.Reminder_NewGrv, emailDetails, model, true, false, false);
            }
        }

        public static List<POTasksViewModel> GetAllPOTasksReminder()
        {
            var grvTasksList = new List<POTasksViewModel>();
            var ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetPOTasksReminder, new SqlParameter[] { });

            if (ds != null && ds.Tables.Count > 0)
            {
                grvTasksList = ds.Tables[0].ToList<POTasksViewModel>().AsQueryable().ToList();
            }

            return grvTasksList;
        }

        /// <summary>
        /// method to send mail on create po task
        /// </summary>
        /// <param name="instruction"></param>
        public static void SendReminderEMailOnPO(POTasksViewModel model, string sendToEmail = null)
        {
            if (model != null)
            {
                model.LegalDiscipline = model.Matter_Reference + ": " + model.MatterName;
                model.PurchaseRequestReference = model.Matter_Reference + "_" + model.Vendor;

                model.Total_Amount = Math.Round(Convert.ToDecimal(model.D_Vatable_Amount + model.D_NonVatable_Amount), 2);

                model.Vatable_Amount = CommonConstants.Currency + model.D_Vatable_Amount;
                model.NonVatable_Amount = CommonConstants.Currency + model.D_NonVatable_Amount;

                if (model.Status == VarConstants.PendingIncrease)
                    model.Subject = VarConstants.IncreasePurchaseOrder;
                else if (model.Status == VarConstants.PendingAmendment)
                    model.Subject = VarConstants.AmendmentSubject;
                else
                    model.Subject = VarConstants.NewPurchaseOrder;

                var qsDictionary = new Dictionary<string, string> { { "id", model.Id.ToString() }, { "status", model.Status }, { "isAdmin", false.ToString() } };
                model.Url = SystemDetailsViewModel.URL + "/" + VarConstants.POTasks + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary);

                var emailManager = new EmailManager();
                var emailDetails = new Exigent.Email.Configuration.EmailDetails();
                emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(model.POContact);

                if (!string.IsNullOrEmpty(sendToEmail))
                    emailDetails.EmailCC = sendToEmail;

                emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.Reminder_NewPOTask, (int)EmailCategoryEnum.Reminder_NewPOTask, emailDetails, model, true, false, false);
            }

        }

        #endregion
    }
}
