﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent_ViewModels.Admin;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.BLL
{
	public class Users_BU_LPA_Manager
	{
		/// <summary>
		/// 
		/// </summary>
		/// <param name="userAddVm"></param>
		/// <param name="userEditVM"></param>
		/// <param name="userID"></param>
		public static void AddOrUpdateUserBUs(AddUserViewModel userAddVm=null, EditUserViewModel userEditVM=null ,int userID =0, User user=null)
		{
			Users_BU_Repository _assistRepo = new Users_BU_Repository();
			List<Users_BusinessUnit> lstBUs;
			if (userEditVM != null && userID > 0)
				lstBUs = _assistRepo.Find(x => x.User_ID == userID).ToList();
			else
				lstBUs = new List<Users_BusinessUnit>();

			List<int> strIDs = new List<int>();

			// set Matters members in seprate list
			if(userAddVm !=null)
				strIDs = userAddVm.BusinessUnitIds;
			else if(userEditVM!=null)
				strIDs = userEditVM.BusinessUnitIds;

			// remove all members first from association that are un-associated now.
			if (userEditVM != null && userID > 0)
			{
				var arrRemoveItems = user.Users_BusinessUnit.Where(y => !strIDs.Any(z => z == y.BusinessUnit_ID)).Select(x => x.BusinessUnit_ID).ToArray();
				// remove if any item not present in the current list
				foreach (var buID in arrRemoveItems)
				{
					if (lstBUs.Count > 0)
					{
						var assitMember = lstBUs.FirstOrDefault(x => x.BusinessUnit_ID == buID && x.User_ID == userEditVM.Id);
						lstBUs.Remove(assitMember);
						_assistRepo.Entry(assitMember, EntityState.Deleted);
					}
				}
			}
				

			// add all new members as new item.

			Users_BusinessUnit objUserBUs = null;
			foreach (int assistID in strIDs)
			{
				if (userEditVM != null && userEditVM.BusinessUnitIds !=null && userEditVM.BusinessUnitIds.Count > 0)
				{
					if (assistID > 0 && !user.Users_BusinessUnit.Any(x => x.BusinessUnit_ID == assistID))
					{
						objUserBUs = new Users_BusinessUnit();
						objUserBUs.BusinessUnit_ID = assistID;
						objUserBUs.User_ID = userID;
						lstBUs.Add(objUserBUs);
						_assistRepo.Entry(objUserBUs, EntityState.Added);
					}
				}
				else
				{
					if (assistID > 0 && userAddVm!=null)
					{
						objUserBUs = new Users_BusinessUnit();
						objUserBUs.BusinessUnit_ID = assistID;
						objUserBUs.User_ID = userID;
						lstBUs.Add(objUserBUs);
						_assistRepo.Entry(objUserBUs, EntityState.Added);
					}
				}
			}
			objUserBUs = null;
			_assistRepo.SaveChanges();
		}

		/// <summary>
		/// 
		/// </summary>
		/// <param name="userAddVm"></param>
		/// <param name="userEditVM"></param>
		/// <param name="userID"></param>
		public static void AddOrUpdateUserLPAs(AddUserViewModel userAddVm = null, EditUserViewModel userEditVM = null, int userID = 0,User user=null)
		{
			Users_LPA_Repository _assistRepo = new Users_LPA_Repository();
			List<Users_LPA> lstLPAs;
			if (userEditVM != null && userID > 0)
				lstLPAs = _assistRepo.Find(x => x.User_ID == userID).ToList();
			else
				lstLPAs = new List<Users_LPA>();

			List<int> strIDs = new List<int>();

			// set Matters members in seprate list
			if (userAddVm != null)
				strIDs = userAddVm.MatterTypeIds;
			else if (userEditVM != null)
				strIDs = userEditVM.MatterTypeIds;

			// remove all members first from association that are un-associated now.
			if (userEditVM != null && userID > 0)
			{
                var arrRemoveItems = user.Users_LPA.Where(y => !strIDs.Any(z => z == y.LegalDisciplineId)).Select(x => x.LegalDisciplineId).ToArray();
				// remove if any item not present in the current list
				foreach (int lpaID in arrRemoveItems)
				{
					if (lstLPAs.Count > 0)
					{
                        var assitMember = lstLPAs.FirstOrDefault(x => x.LegalDisciplineId == lpaID && x.User_ID == userAddVm.Id);
						lstLPAs.Remove(assitMember);
						_assistRepo.Entry(assitMember, EntityState.Deleted);
					}
				}
			}

			// add all new members as new item.

			Users_LPA objUserLPA = null;
			foreach (int assistID in strIDs)
			{
				if (userEditVM != null && userEditVM.MatterTypeIds != null && userEditVM.MatterTypeIds.Count > 0)
				{
                    if (assistID > 0 && !user.Users_LPA.Any(x => x.LegalDisciplineId == assistID))
					{
						objUserLPA = new Users_LPA();
                        objUserLPA.LegalDisciplineId = assistID;
						objUserLPA.User_ID = userID;
						lstLPAs.Add(objUserLPA);
						_assistRepo.Entry(objUserLPA, EntityState.Added);
					}
				}
				else
				{
					if (assistID > 0 && userAddVm!=null)
					{
						objUserLPA = new Users_LPA();
                        objUserLPA.LegalDisciplineId = assistID;
						objUserLPA.User_ID = userID;
						lstLPAs.Add(objUserLPA);
						_assistRepo.Entry(objUserLPA, EntityState.Added);
					}
				}
			}
			objUserLPA = null;
			_assistRepo.SaveChanges();
		}
	}
}
