﻿using Exigent.Common.Enums;
using Exigent.EF.Data.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using Exigent_ViewModels.Admin;
using Exigent_ViewModels.Common;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;


namespace Exigent_BusinessLogicLayer.Admin
{
    public class RoleManager
    {
        public bool SaveRole(RoleViewModel roleViewModel, int createdBy, int[] aids, out int New_Genrated_Role_id)
        {
            using (RolesRepository roleRepository = new RolesRepository())
            {
                Role role;
                if (roleViewModel.Id == 0)
                {
                    role = new Role
                    {
                        //CompanyId = CompanyIdentifier.F.ToString(),
                        //IsSystem = false
                    };
                }
                else
                {
                    role = roleRepository.Find(r => r.Id == roleViewModel.Id).FirstOrDefault();
                }

                role.Name = roleViewModel.Name;
                role.IsActive = true;


                if (roleViewModel.Id == 0)
                    roleRepository.Add(role);

                roleRepository.SaveChanges();

                int newlyGeneratedRoleId = role.Id;
                New_Genrated_Role_id = newlyGeneratedRoleId;

                return true;
            }
        }
        public List<RoleViewModel> GetAllRoles(string rolename)
        {
            using (RolesRepository roleRepository = new RolesRepository())
            {
                var roleList = roleRepository.Find(r => r.Name.Contains(rolename) || rolename == "");
                List<RoleViewModel> objRoleListViewModel = new List<RoleViewModel>();
                return objRoleListViewModel = roleList.Where(x => x.IsActive).Select(p =>
                {
                    return new RoleViewModel
                    {
                        Id = p.Id,
                        Name = p.Name,
                        IsActive = p.IsActive,
                        Description = p.Description
                    };
                }).ToList();
            }
        }

        public bool IsRoleExists(string name, int id)
        {
            using (RolesRepository roleRepository = new RolesRepository())
            {
                return roleRepository.Find(q => (q.Name == name) && q.Id != id).Any();
            }
        }

        public RoleViewModel GetRole(int id)
        {
            using (RolesRepository roleRepository = new RolesRepository())
            {
                RoleViewModel objRoleViewModel = new RoleViewModel();
                if (id != 0)
                {
                    var role = roleRepository.Find(r => r.Id == id).FirstOrDefault();


                    objRoleViewModel = new RoleViewModel
                    {
                        Id = role.Id,
                        Name = role.Name,
                        IsActive = role.IsActive,


                    };
                }
                else
                {
                    // to do...
                }

                return objRoleViewModel;
            }
        }

        public Role GetRolesById(int roleId)
        {
            using (RolesRepository roleRepository = new RolesRepository())
            {
                return roleRepository.GetById(roleId);
            }
        }

        public List<RoleViewModel> searchRole(Expression<Func<RoleViewModel, bool>> predicate)
        {
            using (RolesRepository roleRepository = new RolesRepository())
            {
                var roleList = roleRepository.GetQuery();
                RoleListViewModel objRoleListViewModel = new RoleListViewModel();
                return objRoleListViewModel.RoleList = roleList.Select(p => new RoleViewModel
                {
                    Id = p.Id,
                    Name = p.Name,
                    IsActive = p.IsActive
                }).Where(predicate).ToList();
            }
        }

        public static List<EnumKeyValueViewModel> GetAccessByRole(int RoleId)
        {
			if (RoleId > 0)
			{
				using (RolesRepository roleRepo = new RolesRepository())
				{
					var roleInfo = roleRepo.Find(x => x.Id == RoleId).FirstOrDefault();
					return roleInfo.RoleAccesses.Select(x => new EnumKeyValueViewModel()
					{
						Key = Convert.ToInt32(x.DashBoardId),
						Name = x.AccessDashboard.Description,
						DashBoardId = x.Role.DashBoardId.Value
					}).ToList();
				}
			}
			else
			{
				 return new List<EnumKeyValueViewModel>()
				 {
					 new EnumKeyValueViewModel()
					 {
						Key = 0,
						Name = "Select",
						DashBoardId = 0
					 }
				 };
			}
        }
    }
}
