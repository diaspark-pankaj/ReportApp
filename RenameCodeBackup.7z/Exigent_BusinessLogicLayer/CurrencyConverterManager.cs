﻿using Exigent.Common.Enums;
using Exigent.Common.Helpers;
using Exigent.ViewModels.Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Exigent.BLL
{
    public class CurrencyConverterManager
    {
        public static decimal ConvertCurrencyToUSD(decimal? amount, string fromCurrency, string toCurrency, Dictionary<string, decimal> ConvertAmountCollection)
        {
            if (amount > 0)
            {
                CurrencyConverterViewModel currencyConverterViewModel = new CurrencyConverterViewModel();
                string response = CurrencyHelper.ConvertCurrency(amount, fromCurrency, toCurrency);
                var environment = int.Parse(System.Configuration.ConfigurationManager.AppSettings["Environment"]);
                if (!string.IsNullOrEmpty(response))
                {
                    currencyConverterViewModel = JsonConvert.DeserializeObject<CurrencyConverterViewModel>(response);
                }
                if (currencyConverterViewModel != null && currencyConverterViewModel.success)
                {
                    HttpRuntime.Cache.Insert("ConvertAmountCollection", AddConversionInCollection(toCurrency, Convert.ToDecimal(currencyConverterViewModel.result), ConvertAmountCollection), null, DateTime.Now.AddMinutes(60), System.Web.Caching.Cache.NoSlidingExpiration);
                    return !string.IsNullOrEmpty(currencyConverterViewModel.result) ? Convert.ToDecimal(currencyConverterViewModel.result) : 0;
                }
                else if (Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["Environment"]) == (int)EnvironmentEnum.Local || Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["Environment"]) == (int)EnvironmentEnum.QA)
                {
                    return 68;
                }
                else
                {
                    //Todo save error in log
                    //{"success":false,"error":{"code":105,"info":"Access Restricted - Your current Subscription Plan does not support this API Function."}}
                }
            }
            return 0;
        }
        public static Nullable<decimal> CalculateAmount(decimal? invoiceAmount, decimal amountToUsd)
        {
            if (invoiceAmount == null || invoiceAmount <= 0 || amountToUsd <= 0)
                return 0;
            else
                return Math.Round((Convert.ToDecimal(invoiceAmount) / amountToUsd), 2);
        }

        #region Caching functions
        public static decimal GetConversionAvailableInCache(string CurrencyCode, Dictionary<string, decimal> ConvertAmountCollection)
        {
            decimal returnAmount = 0;
            if (!string.IsNullOrEmpty(CurrencyCode) && ConvertAmountCollection != null && ConvertAmountCollection.ContainsKey(CurrencyCode.ToLower()))
            {
                returnAmount = Convert.ToDecimal(ConvertAmountCollection.Where(x => x.Key == CurrencyCode.ToLower()).FirstOrDefault().Value);
            }
            return returnAmount;
        }
        public static Dictionary<string, decimal> AddConversionInCollection(string CurrencyCode, decimal amount, Dictionary<string, decimal> ConvertAmountCollection)
        {
            ConvertAmountCollection = ConvertAmountCollection != null ? ConvertAmountCollection : new Dictionary<string, decimal>();
            //Dictionary<string, decimal> ConvertAmountCollection = HttpRuntime.Cache["ConvertAmountCollection"] as Dictionary<string, decimal>;
            if (!string.IsNullOrEmpty(CurrencyCode) && amount > 0)
                ConvertAmountCollection.Add(CurrencyCode.ToLower(), Convert.ToDecimal(amount));
            return ConvertAmountCollection;
        }
        #endregion
    }
}
