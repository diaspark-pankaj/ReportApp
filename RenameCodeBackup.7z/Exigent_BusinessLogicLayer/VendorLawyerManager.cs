﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.BLL
{
    public class VendorLawyerManager
    {
        public static VendorLawyerViewModel GetVendorLawyerById(int id)
        {
            using (var rep = new VendorLawyerRepository())
            {
                var model = rep.GetQuery().Where(m => m.ID == id)
                    .Select(m => new VendorLawyerViewModel
                    {
                        Id = m.ID,
                        Vendor = new VendorViewModel()
						{
							Id = m.Vendor.ID,
							Company_Name = m.Vendor.Company_Name,
							Category = m.Vendor.Category,
							Color = m.Vendor.Color,
							Email = m.Vendor.Email
						} ,
                        Lawyer = m.Lawyer,
                        HDSA = m.HDSA,
                        Rate = (m.Rate.HasValue) ? m.Rate.Value : 0,
                        Vendor_ID= m.Vendor_ID
                        //IsActive = (m.Active == "Yes")
                    }).FirstOrDefault();

                return model;
            }
        }

        public static bool IsExists(int id, string vendor, string lawyer)
        {
            using (var rep = new VendorLawyerRepository())
            {
                return rep.Any(p => p.ID != id && p.Vendor.Company_Name == vendor.Trim() && p.Lawyer == lawyer);
            }
        }

        public static bool UpdateVendorLawyer(VendorLawyerViewModel model)
        {
            using (var rep = new VendorLawyerRepository())
            {
                var dt = rep.GetQuery().Where(m => m.ID == model.Id).FirstOrDefault();

                if (dt == null)
                    return false;

                dt.ID = model.Id;
                dt.Vendor_ID = model.Vendor_ID;
                dt.Lawyer = model.Lawyer;
                dt.HDSA = model.HDSA;
                dt.Rate = model.Rate;

                rep.SaveChanges();
            }

            return true;
        }

        public static int CreateVendorLawyer(VendorLawyerViewModel model)
        {
            using (var rep = new VendorLawyerRepository())
            {
                var dt = new VendorLawyer
                {
                    ID = model.Id,
                    Vendor_ID = model.Vendor_ID,
                    Lawyer = model.Lawyer,
                    HDSA = model.HDSA,
                    Rate = model.Rate,
                };

                rep.Add(dt);
                rep.SaveChanges();

                return dt.ID;
            }
        }
    }
}
