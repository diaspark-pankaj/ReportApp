﻿using Exigent.DataLayer.Repository;
using Exigent.Common.Constants;
using System;
using System.Linq;
using Exigent.ViewModels.Common;
using Exigent.Models;
using Exigent.Common.Enums;
using System.Data.Entity;
using Exigent.EF.Data.Repository;
using Exigent.Common.Helpers;
using System.Collections.Generic;
using Exigent.ViewModels.Admin;
using Newtonsoft.Json;
using System.Globalization;
using System.Transactions;
using System.Web;
using System.IO;
using System.Data.SqlClient;

namespace Exigent.BLL
{
    public class InvoiceManager
    {
        #region Invoice

        /// <summary>
        /// Method to validate invoice status & exists
        /// </summary>
        /// <param name="vendor">Vendor to check invoice for.</param>
        /// <param name="invoiceNo">Invoice number is required.</param>
        /// <param name="isInvoice">Search only invoice table</param>
        /// <param name="searchExternal">Include vendor and search external invoices.</param>
        /// <returns></returns>
        public string ValidateInvoiceNo(string vendor, string invoiceNo, bool isInvoice, bool searchExternal = false)
        {
            var result = string.Empty;
            int vendorID = Convert.ToInt32(vendor);
            if (searchExternal)
            {
                using (InvoicesOutsideCIRepository rep = new InvoicesOutsideCIRepository())
                {
                    var lstInvoice = rep.Find(x => x.Vendor_ID == vendorID && x.Invoice_Number == invoiceNo).ToList();
                    if (lstInvoice != null && lstInvoice.Count() > 0)
                    {
                        result = VarConstants.AlreadyInvoiceNumber;
                        return result;
                    }
                    else
                        result = string.Empty;
                }
            }
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                if (isInvoice & !searchExternal)
                {
                    var lstInv = invoiceRepository.Find(x => x.Invoice_Number == invoiceNo).ToList();
                    if (lstInv != null && lstInv.Count() > 0)
                        return VarConstants.AlreadyInvoiceNumber;
                }
                var lstInvoice = invoiceRepository.Find(x => x.Vendor_ID == vendorID && x.Invoice_Number == invoiceNo).ToList();
                if (lstInvoice != null && lstInvoice.Count() > 0)
                {
                    if (isInvoice || searchExternal)
                        return VarConstants.AlreadyInvoiceNumber;

                    switch (lstInvoice.FirstOrDefault().Invoice_Status)
                    {
                        case VarConstants.SentForPayment:
                            result = VarConstants.SentForPaymentMsg;
                            break;
                        case VarConstants.Paid:
                            result = VarConstants.PaidMsg;
                            break;
                        case VarConstants.Credited:
                            result = VarConstants.CreditedMsg;
                            break;
                        default:
                            result = string.Empty;
                            break;
                    }
                }
                else
                {
                    if (isInvoice || searchExternal)
                        result = string.Empty;
                    else
                        result = VarConstants.NoInvoice;
                }
            }
            return result;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public int UpdatePaymentProcessing(InvoicesSentForPaymentViewModel model)
        {
            var updatedPaymentProcessingID = 0;
            using (InvoiceRepository invRepo = new InvoiceRepository())
            {
                Invoice invoice = invRepo.GetById(model.ID);
                invoice.Payment_Processing_ID = model.AssignedTo_ID;
                invoice.Payment_Processing_Comments = model.Comments;
                invRepo.Entry(invoice, EntityState.Modified);
                invRepo.SaveChanges();
                updatedPaymentProcessingID = (int)invoice.Payment_Processing_ID;
            }
            return updatedPaymentProcessingID;
        }

        /// <summary>
        /// method to submit invoice in related tables
        /// </summary>
        /// <param name="invoiceVm"></param>
        /// <returns></returns>
        public int SaveInvoice(InvoiceViewModel invoiceVm)
        {
            var result = 0;
            decimal amountToUSD = 0;
            if (invoiceVm != null)
            {
                //Add invoice
                if (invoiceVm.InvoiceId == 0)
                {
                    #region Extract references for instruction/matter/vendor
                    //=========================================================
                    //Extract references for instruction/matter/vendor.
                    //=========================================================
                    InstructionViewModel instructionVm = null;
                    using (ExternalInstructionRepository externalInsRepository = new ExternalInstructionRepository())
                    {
                        instructionVm = externalInsRepository.GetQuery()
                            .Where(x => x.Instruction_Reference == invoiceVm.Instruction_Reference.Trim())
                            .Select(m => new InstructionViewModel
                            {
                                ID = m.ID,
                                Matter_Reference = m.Matter.Matter_Reference,
                                Matter_ID = m.Matter_ID,
                                Vendor = m.Vendor.Company_Name,
                                Vendor_ID = m.Vendor_ID,
                                Status = m.Status,
                                Matter_Name = m.Matter.Matter_Name,
                                Email = m.Email
                            }).FirstOrDefault();

                        invoiceVm.Matter_Reference = instructionVm.Matter_Reference;
                        invoiceVm.MatterReference = instructionVm.Matter_Reference;
                        invoiceVm.MatterTitle = instructionVm.Matter_Name;
                        invoiceVm.Instruction_ID = instructionVm.ID;
                        invoiceVm.Email = instructionVm.Email;
                    }
                    #endregion
                    //=========================================================

                    //save data to invoice table
                    using (InvoiceRepository invoiceRepository = new InvoiceRepository())
                    {
                        //dynamic lstInvoice = JsonConvert.DeserializeObject(invoiceVm.lstInvoiceFee); 
                        // due to conversion issue, we havve used below strict type conversion.
                        List<InvoiceFeeDetail> lstInvoice = JsonConvert.DeserializeObject<List<InvoiceFeeDetail>>(invoiceVm.lstInvoiceFee);
                        var lstInvoiceFee = new List<InvoiceFeeDetail>();
                        foreach (var fee in lstInvoice)
                        {
                            lstInvoiceFee.Add(new InvoiceFeeDetail
                            {
                                VendorLawer_ID = fee.VendorLawer_ID,
                                Gender = fee.Gender,
                                Race = fee.Race,
                                Rate = fee.Rate,
                                Total = fee.Total,
                                Invoice_ID = invoiceVm.ID
                            });
                        }

                        #region Convert Amount to USD
                        invoiceVm.CurrencyCode = !string.IsNullOrEmpty(invoiceVm.CurrencyCode) ? invoiceVm.CurrencyCode : CurrencyManager.GetCurrencyById(invoiceVm.Currency_ID).CurrencyCode;

                        #region //Check if conversion amount available on cache
                        Dictionary<string, decimal> ConvertAmountCollection = HttpRuntime.Cache["ConvertAmountCollection"] as Dictionary<string, decimal>;
                        if (invoiceVm.CurrencyCode.ToLower().Equals("usd"))
                            amountToUSD = Convert.ToDecimal(1);
                        else if (ConvertAmountCollection != null && ConvertAmountCollection.ContainsKey(invoiceVm.CurrencyCode.ToLower()))
                        {
                            amountToUSD = CurrencyConverterManager.GetConversionAvailableInCache(invoiceVm.CurrencyCode, ConvertAmountCollection);
                            amountToUSD = amountToUSD > 0 ? amountToUSD : CurrencyConverterManager.ConvertCurrencyToUSD(1, "USD", invoiceVm.CurrencyCode, ConvertAmountCollection);
                        }
                        else
                            amountToUSD = CurrencyConverterManager.ConvertCurrencyToUSD(1, "USD", invoiceVm.CurrencyCode, ConvertAmountCollection);
                        #endregion

                        if (amountToUSD > 0)
                        {
                            var Invoice_Total_In_USD = CurrencyConverterManager.CalculateAmount(invoiceVm.Invoice_Total, amountToUSD);
                            var PreVat_Total_In_USD = CurrencyConverterManager.CalculateAmount(invoiceVm.PreVat_Total, amountToUSD);
                            var Attorney_Fee_In_USD = CurrencyConverterManager.CalculateAmount(invoiceVm.Attorney_Fee, amountToUSD);
                            var Advocate_Fee_In_USD = CurrencyConverterManager.CalculateAmount(invoiceVm.Advocate_Fee, amountToUSD);
                            var C3rd_Party_Fee_In_USD = CurrencyConverterManager.CalculateAmount(invoiceVm.C3rd_Party_Fee, amountToUSD);
                            var Disbursement_Fee_In_USD = CurrencyConverterManager.CalculateAmount(invoiceVm.Disbursement_Total, amountToUSD);
                            var Disbursement_Total_In_USD = CurrencyConverterManager.CalculateAmount(invoiceVm.Disbursement_Inv_Total, amountToUSD);
                        #endregion

                            var invoice = new Invoice
                            {
                                Instruction_ID = invoiceVm.Instruction_ID,
                                Invoice_Number = invoiceVm.Invoice_Number.Trim(),
                                Invoice_Date = invoiceVm.Invoice_Date,
                                Vendor_ID = invoiceVm.Vendor_ID,

                                Invoice_Total = Invoice_Total_In_USD,
                                PreVat_Total = PreVat_Total_In_USD,
                                Attorney_Fee = Attorney_Fee_In_USD,
                                Advocate_Fee = Advocate_Fee_In_USD,
                                C3rd_Party_Fee = C3rd_Party_Fee_In_USD,
                                Disbursement_Fee = Disbursement_Fee_In_USD,
                                Disbursement_Total = Disbursement_Total_In_USD,

                                Invoice_Total_InvCur = invoiceVm.Invoice_Total,
                                PreVat_Total_InvCur = invoiceVm.PreVat_Total,
                                Attorney_Fee_InvCur = invoiceVm.Attorney_Fee,
                                Advocate_Fee_InvCur = invoiceVm.Advocate_Fee,
                                C3rd_Party_Fee_InvCur = invoiceVm.C3rd_Party_Fee,
                                Disbursement_Fee_InvCur = invoiceVm.Disbursement_Total,
                                Disbursement_Total_InvCur = invoiceVm.Disbursement_Inv_Total,

                                Attorney_Fee_HDSA = invoiceVm.Attorney_HDSA,
                                Advocate_Fee_HDSA = invoiceVm.Advocate_HDSA,
                                C3rd_Party_Fee_HDSA = invoiceVm.C3rd_Party_HDSA,
                                Advocate_Recommendation = invoiceVm.Advocate_Recommendation,
                                Invoice_Type = invoiceVm.Invoice_Type,
                                Modified = DateTime.Now,
                                Created = DateTime.Now,
                                CreatedBy = invoiceVm.User,
                                Modified_By = VarConstants.SystemDetails,
                                InvoiceFeeDetails = lstInvoiceFee,
                                Currency_ID = invoiceVm.Currency_ID,

                            };

                            invoiceRepository.Add(invoice);
                            invoiceRepository.SaveChanges();

                            // on submit update invoice & reference tables
                            AddInvoiceOperations(invoice, instructionVm);

                            foreach (var fee in lstInvoiceFee)
                            {
                                using (VendorLawyerRepository rep = new VendorLawyerRepository())
                                {
                                    //TODO (CR #4): include lawyer name in condition.
                                    var vendorLawyer = rep.First(m => m.Vendor_ID == invoiceVm.Vendor_ID && m.ID == fee.VendorLawer_ID);
                                    if (vendorLawyer != null && vendorLawyer.Rate.HasValue && vendorLawyer.Rate.Value > 0)
                                    {
                                        var maxValue = vendorLawyer.Rate + (vendorLawyer.Rate * 10 / 100);

                                        if (fee.Rate >= maxValue)
                                        {
                                            //Send Email (Enqueue) to Admins and Eugenio Menezes
                                            SendEmailForChangeInRate(invoiceVm, fee, vendorLawyer);
                                        }
                                    }
                                }
                            }

                            UpdateInvoiceOperations(invoice);

                            //send email on invoice submited
                            SendInvoiceEMail(invoiceVm);
                            result = invoice.ID;
                        }
                        else
                        {
                            result = 0;
                            return result;
                        }

                    }
                    // }
                }
                else
                {
                    //update data to invoice table
                    using (InvoiceRepository invoiceRepository = new InvoiceRepository())
                    {
                        var invoice = invoiceRepository.First(x => x.Invoice_Number == invoiceVm.Invoice_Number);

                        invoice.Invoice_Date = invoiceVm.Invoice_Date;
                        invoice.Invoice_Total = invoiceVm.Invoice_Total;
                        invoice.PreVat_Total = invoiceVm.PreVat_Total;
                        invoice.Attorney_Fee = invoiceVm.Attorney_Fee;
                        invoice.Attorney_Fee_HDSA = invoiceVm.Attorney_HDSA;
                        invoice.Advocate_Fee = invoiceVm.Advocate_Fee;
                        invoice.Advocate_Fee_HDSA = invoiceVm.Advocate_HDSA;
                        invoice.C3rd_Party_Fee = invoiceVm.C3rd_Party_Fee;
                        invoice.C3rd_Party_Fee_HDSA = invoiceVm.C3rd_Party_HDSA;
                        invoice.Disbursement_Fee = invoiceVm.Disbursement_Total;
                        invoice.Advocate_Recommendation = invoiceVm.Advocate_Recommendation;
                        invoice.Invoice_Type = invoiceVm.Invoice_Type;
                        invoice.Modified = DateTime.Now;
                        invoice.Currency_ID = invoiceVm.Currency_ID;

                        //dynamic lstInvoice = JsonConvert.DeserializeObject(invoiceVm.lstInvoiceFee);
                        List<InvoiceFeeDetail> lstInvoice = JsonConvert.DeserializeObject<List<InvoiceFeeDetail>>(invoiceVm.lstInvoiceFee);
                        using (InvoiceFeeDetailRepository invoiceFeeRepository = new InvoiceFeeDetailRepository())
                        {
                            var invoiceFee = invoiceFeeRepository.Find(x => x.Invoice.Invoice_Number == invoiceVm.Invoice_Number);
                            foreach (var fee in invoiceFee.ToList())
                            {
                                invoiceFeeRepository.Delete(fee);
                                invoiceFeeRepository.SaveChanges();
                            }
                        }

                        foreach (var fee in lstInvoice)
                        {
                            invoice.InvoiceFeeDetails.Add(new InvoiceFeeDetail
                            {
                                VendorLawer_ID = fee.VendorLawer_ID,
                                Gender = fee.Gender,
                                Race = fee.Race,
                                Rate = fee.Rate,
                                Total = fee.Total,
                                Invoice_ID = invoiceVm.ID
                            });
                        }

                        if (invoice.Invoice_Status == VarConstants.AwaitingAudit)
                        {
                            invoiceRepository.Entry(invoice, EntityState.Modified);
                            invoiceRepository.SaveChanges();

                            foreach (var fee in invoice.InvoiceFeeDetails)
                            {
                                using (VendorLawyerRepository rep = new VendorLawyerRepository())
                                {
                                    //TODO (CR #4): include lawyer name in condition.
                                    var vendorLawyer = rep.First(m => m.Vendor_ID == invoiceVm.Vendor_ID && m.ID == fee.VendorLawer_ID);
                                    if (vendorLawyer != null && vendorLawyer.Rate.HasValue && vendorLawyer.Rate.Value > 0)
                                    {
                                        var maxValue = vendorLawyer.Rate + (vendorLawyer.Rate * 10 / 100);
                                        if (fee.Rate >= maxValue)
                                        {
                                            //Send Email (Enqueue) to Admins and Eugenio Menezes
                                            SendEmailForChangeInRate(invoiceVm, fee, vendorLawyer);
                                        }
                                    }
                                }
                            }
                        }
                        result = invoice.ID;
                    }
                }
            }
            return result;
        }


        /// <summary>
        /// Save function to capture outside invoices.
        /// </summary>
        /// <param name="invoiceVm">ExternalInvoiceViewModel model</param>
        /// <returns></returns>
        public int SaveExternalInvoice(ExternalInvoiceViewModel invoiceVm)
        {
            var result = 0;
            if (invoiceVm != null)
            {
                if (!string.IsNullOrEmpty(invoiceVm.Instruction_Reference))
                {
                    using (var rep = new ExternalInstructionRepository())
                    {
                        var instruction = rep.GetQuery().Where(m => m.Instruction_Reference == invoiceVm.Instruction_Reference)
                                .Select(m => new
                                {
                                    Matter_ID = m.Matter_ID,
                                    Vendor_ID = m.Vendor_ID,
                                    BusinessUnit_ID = m.Matter.Business_Unit_ID
                                }).FirstOrDefault();

                        invoiceVm.Matter_ID = instruction.Matter_ID;
                        invoiceVm.Vendor_ID = instruction.Vendor_ID;
                        invoiceVm.BusinessUnit_ID = instruction.BusinessUnit_ID;
                    }
                }

                using (InvoicesOutsideCIRepository rep = new InvoicesOutsideCIRepository())
                {
                    if (!string.IsNullOrEmpty(invoiceVm.Instruction_Reference))
                    {
                        invoiceVm.Instruction_Reference = invoiceVm.Instruction_Reference.Trim();
                    }

                    var invoiceSub = new InvoicesOutsideCI
                    {
                        Invoice_Number = invoiceVm.Invoice_Number.Trim(),
                        Instruction_ID = invoiceVm.Instruction_ID,
                        Matter_ID = invoiceVm.Matter_ID,
                        BusinessUnit_ID = invoiceVm.BusinessUnit_ID,
                        Vendor_ID = invoiceVm.Vendor_ID,
                        Invoice_Date = invoiceVm.Invoice_Date,
                        Payment_Date = invoiceVm.Payment_Date,
                        Invoice_Total = invoiceVm.Invoice_Total,
                        PreVat_Total = invoiceVm.PreVat_Total,
                        Description = invoiceVm.Description,
                        Created = DateTime.Now
                    };

                    rep.Add(invoiceSub);
                    rep.SaveChanges();
                    result = invoiceSub.ID;
                }
            }

            return result;
        }

        /// <summary>
        /// Send email notification for Attorney rate change. 
        /// </summary>
        /// <param name="invoiceSub">Invoice Submission details</param>
        /// <param name="rec">Invoice attorney fee details</param>
        private void SendEmailForChangeInRate(InvoiceViewModel invoiceVm, InvoiceFeeDetail fee, VendorLawyer vendorLawyer)
        {
            var differenceInRates = Math.Abs(fee.Rate.Value - vendorLawyer.Rate.Value);

            var emailModel = new
            {
                InvoiceNumber = invoiceVm.Invoice_Number,
                VendorName = invoiceVm.Vendor,
                AttorneyName = vendorLawyer.Lawyer,
                PercentageIncrease = (differenceInRates * 100 / vendorLawyer.Rate).Value.ToString("0.00"),
                CurrentHourlyRate = vendorLawyer.Rate.Value.ToString("0.00"),
                NewHourlyRate = fee.Rate.Value.ToString("0.00"),
                Matter_Reference = invoiceVm.Matter_Reference,
                Instruction_Reference = invoiceVm.Instruction_Reference
            };

            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            emailDetails.EmailTo = SystemDetailsViewModel.AttorneyRateChangeEmail + ";" + SystemDetailsViewModel.Team;
            emailDetails.EmailCC = PeoplePickerManager.GetUserEmailAddress(vendorLawyer.Lawyer);

            var emailManager = new EmailManager();
            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.AttorneyFeeIncreaseNotification, (int)EmailCategoryEnum.AttorneyFeeIncreaseNotification, emailDetails, emailModel, true, false);
        }

        /// <summary>
        /// send email on invoice submited
        /// </summary>
        /// <param name="invoiceVm"></param>
        private void SendInvoiceEMail(InvoiceViewModel invoiceVm)
        {
            var emailManager = new EmailManager();
            invoiceVm.ReferenceNumber = DateTime.Now.ToString("dd/MM/yy") + "-" + invoiceVm.Invoice_Number;
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            emailDetails.EmailTo = PeoplePickerManager.GetUserEmail(invoiceVm.User) + ";" + invoiceVm.Email; //VendorManager.GetVendorEmailAddress(invoiceVm.Vendor_ID);
            emailDetails.EmailCC = SystemDetailsViewModel.Team;
            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.InvoiceSubmission, (int)EmailCategoryEnum.InvoiceSubmission, emailDetails, invoiceVm, true);
        }

        /// <summary>
        /// on submit invoice update invoice & reference tables
        /// </summary>
        /// <param name="invoice"></param>
        private void AddInvoiceOperations(Invoice invoice, InstructionViewModel instructionVm)
        {
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                if (string.IsNullOrEmpty(instructionVm.Matter_Reference))
                {
                    invoiceRepository.Delete(invoice);
                    invoiceRepository.SaveChanges();
                }
                else
                {
                    invoice.Matter_ID = instructionVm.Matter_ID;
                    invoiceRepository.Entry(invoice, EntityState.Modified);
                    invoiceRepository.SaveChanges();
                }
                var lstInvoice = invoiceRepository.Find(x => x.Vendor == invoice.Vendor && x.Invoice_Number == invoice.Invoice_Number).ToList();
                if (lstInvoice != null && lstInvoice.Count() >= 2)
                {
                    invoiceRepository.Delete(invoice);
                    invoiceRepository.SaveChanges();
                }
                else
                {
                    if (instructionVm.Vendor_ID != invoice.Vendor_ID)
                    {
                        invoiceRepository.Delete(invoice);
                        invoiceRepository.SaveChanges();
                    }
                    else
                    {
                        if (instructionVm.Status == VarConstants.Instruction_Rejected)
                        {
                            invoiceRepository.Entry(invoice, EntityState.Deleted);
                            invoiceRepository.Delete(invoice);
                            invoiceRepository.SaveChanges();
                        }
                        else
                        {
                            invoice.Invoice_Status = VarConstants.AwaitingAudit;
                            invoice.Submit_Date = DateTime.Now;
                            Invoice_Audit invoiceAudit = new Invoice_Audit();
                            invoiceAudit.Assigned_To_ID = SystemDetailsViewModel.InvoiceApprovalOwnerID;
                            invoiceAudit.Created = DateTime.Now;
                            invoiceAudit.Status = VarConstants.AwaitingAudit;
                            invoiceAudit.Invoice_ID = invoice.ID;
                            invoice.Invoice_Audit.Add(invoiceAudit);
                            invoiceRepository.Entry(invoice, EntityState.Modified);
                            invoiceRepository.SaveChanges();
                            //send mail for invoice audit
                            SendMailOnInvoiceAudit(invoice, SystemDetailsViewModel.InvoiceApprovalOwner);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// send mail for invoice audit
        /// </summary>
        /// <param name="invoice"></param>
        private void SendMailOnInvoiceAudit(Invoice invoice, string assignedTo)
        {
            var emailManager = new EmailManager();
            var invoiceVm = new InvoiceViewModel();
            string invoiceNumber = invoice.Invoice_Number;
            using (InvoiceRepository _invoiceRepo = new InvoiceRepository())
            {
                invoice = _invoiceRepo.Find(x => x.Invoice_Number == invoiceNumber).FirstOrDefault();
                invoiceVm.Invoice_Number = invoice.Invoice_Number;
                invoiceVm.Vendor = invoice.Vendor != null ? invoice.Vendor.Company_Name : "";
                invoiceVm.Matter_Reference = invoice.Matter != null ? invoice.Matter.Matter_Reference : "";
            }

            var qsdId = new Dictionary<string, string> { { "id", invoiceVm.Invoice_Number } };
            invoiceVm.Url = SystemDetailsViewModel.URL + "/" + VarConstants.AuditTasks + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsdId);
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(assignedTo);
            emailDetails.EmailCC = SystemDetailsViewModel.Team;
            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.InvoiceAuditTask, (int)EmailCategoryEnum.InvoiceAuditTask, emailDetails, invoiceVm, true);
        }

        /// <summary>
        /// send mail on send po increase instruction status
        /// </summary>
        /// <param name="instruction"></param>
        private void SendMailOnPOIncrease(External_Instruction instruction)
        {
            var matterVm = new MatterViewModel(); string lawyer, matterName = string.Empty;
            var emailManager = new EmailManager();
            using (MatterRepository matterRepository = new MatterRepository())
            {
                var matter = matterRepository.Find(x => x.Matter_Reference == instruction.Matter.Matter_Reference).Select(y => new { y.User.FullName, y.Matter_Name }).FirstOrDefault();
                lawyer = matter.FullName;
                matterName = matter.Matter_Name;
            }
            var qsdId = new Dictionary<string, string> { { "id", instruction.ID.ToString() } };
            matterVm.Matter_Name = matterName;
            matterVm.Matter_Reference = instruction.Matter.Matter_Reference;
            matterVm.Url = SystemDetailsViewModel.URL + "/" + VarConstants.InsOverView + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsdId);
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(lawyer);
            emailDetails.EmailCC = SystemDetailsViewModel.Team;
            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.SendPOIncrease, (int)EmailCategoryEnum.SendPOIncrease, emailDetails, matterVm, true);
        }

        /// <summary>
        /// update invoice & reference tables
        /// </summary>
        /// <param name="invoice"></param>
        private void UpdateInvoiceOperations(Invoice invoice)
        {
            using (InvoiceRepository repo = new InvoiceRepository())
            {
                invoice = repo.Find(x => x.Invoice_Number == invoice.Invoice_Number).FirstOrDefault();

                using (ExternalInstructionRepository externalInsRepository = new ExternalInstructionRepository())
                {
                    string MatterSystem, GRVContact = string.Empty; int? GRVContact_ID;
                    string Comments = VarConstants.GRVInvoice;
                    string GRV = string.Empty;
                    string BusinessUnit = string.Empty;
                    int PendingAmendmentCnt, PendingIncreaseCnt = 0;
                    decimal FutureCostVatable, FutureCostNonVatable = 0;
                    var lstExtIns = externalInsRepository.GetQueryWithInclude("Client_Companies").Where(x => x.Instruction_Reference == invoice.External_Instructions.Instruction_Reference).ToList();
                    var instruction = lstExtIns.Count() > 0 ? lstExtIns.FirstOrDefault() : new External_Instruction();
                    if (instruction == null)
                    {
                        instruction = invoice.External_Instructions;
                    }
                    GRVContact_ID = instruction.GRV_Contact_ID;
                    //changes made for Non-Vatable Disbursement
                    var Invoice_Vatable = invoice.PreVat_Total - invoice.Disbursement_Total;
                    var Invoice_Non_Vatable = invoice.Disbursement_Total;
                    using (MatterRepository matterRepository = new MatterRepository())
                    {
                        MatterSystem = matterRepository.Find(x => x.Matter_Reference == instruction.Matter.Matter_Reference).Select(y => y.SystemType.SystemTypeName).FirstOrDefault();
                    }
                    using (PurchaseOrdersRepository purchaseRepository = new PurchaseOrdersRepository())
                    {
                        var lstPendingAmendment = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference && x.Status == VarConstants.PendingAmendment).ToList();
                        var lstPendingIncrease = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference && x.Status == VarConstants.PendingIncrease).ToList();
                        var PendingIncrease = lstPendingIncrease.Count() > 0 ? lstPendingIncrease.FirstOrDefault() : new Purchase_Order();
                        var PendingAmendment = lstPendingAmendment.Count() > 0 ? lstPendingAmendment.FirstOrDefault() : new Purchase_Order();
                        PendingAmendmentCnt = lstPendingAmendment.Count();
                        PendingIncreaseCnt = lstPendingIncrease.Count();

                        FutureCostVatable = (Convert.ToDecimal(instruction.Legal_Cost_Vatable_Balance) + (Convert.ToDecimal(PendingIncrease.Vatable_Amount) + Convert.ToDecimal(PendingAmendment.Vatable_Amount))) - Convert.ToDecimal(PendingAmendment.Non_Vatable_Amount);
                        FutureCostNonVatable = (Convert.ToDecimal(instruction.Legal_Cost_Non_Vatable_Balance) + (Convert.ToDecimal(PendingIncrease.Non_Vatable_Amount) + Convert.ToDecimal(PendingAmendment.Non_Vatable_Amount))) - Convert.ToDecimal(PendingAmendment.Vatable_Amount);
                    }
                    using (ClientComponyRepository clientComponyRepository = new ClientComponyRepository())
                    {
                        var clientComp = clientComponyRepository.Find(x => x.Company_Name == instruction.Client_Companies.Company_Name).ToList();
                        if (clientComp != null && clientComp.Count() > 0)
                        {
                            GRV = clientComp.FirstOrDefault().GRV;
                            BusinessUnit = clientComp.FirstOrDefault().Business_Units.Business_Unit1;
                        }
                    }

                    if (instruction.GRV_Contact_ID > 0)
                    {
                        Comments = VarConstants.NoGRV;
                        GRVContact_ID = SystemDetailsViewModel.GRVOwnerID;
                    }

                    if (invoice.Invoice_Status == EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.AwaitingGRV.ToString()) && PendingAmendmentCnt == 0 && PendingIncreaseCnt == 0)
                    {
                        SaveInvoiceGrv(invoice, GRVContact_ID.Value, Comments, instruction.PeoplePicker1.Full_Name);
                    }
                    if (invoice.Invoice_Status == InvoiceStatus.Approved.ToString())
                    {
                        if (invoice.Attorney_Fee != 0)
                        {
                            using (var invoiceTimesheetRepository = new InvoiceTimesheetRepository())
                            {
                                var timesheet = new Invoice_Timesheet_Capture_Task();
                                timesheet.InvoiceID = invoice.ID;
                                timesheet.Status = VarConstants.Pending;
                                timesheet.Assigned_To = SystemDetailsViewModel.TimesheetCaptureOwnerID;
                                timesheet.Created = DateTime.Now;
                                timesheet.Invoice_Number = invoice.Invoice_Number;
                                invoiceTimesheetRepository.Add(timesheet);
                                invoiceTimesheetRepository.SaveChanges();
                                SendNewTimeSheetMail(SystemDetailsViewModel.TimesheetCaptureOwner, invoice.Invoice_Number, timesheet.ID, instruction.Matter.Matter_Reference);
                            }
                        }

                        if (invoice.Invoice_Type == EnumHelper<InvoiceType>.GetEnumDescription(InvoiceType.FinalInvoice.ToString()))
                        {
                            instruction.Status = VarConstants.Closed;
                            externalInsRepository.Entry(instruction, EntityState.Modified);
                            externalInsRepository.SaveChanges();
                        }
                        if (GRV == CommonConstants.Yes)
                        {
                            if (MatterSystem == SystemTypes.GroupLegal.ToString())
                            {
                                /****************Pankaj: Code Commented for invoice calculation and moved this functionality to mark as paid.*******************/
                                /*
                                //changes
                                instruction.Legal_Cost_Vatable_Balance = instruction.Legal_Cost_Vatable_Balance - Invoice_Vatable;
                                instruction.Legal_Cost_Non_Vatable_Balance = instruction.Legal_Cost_Non_Vatable_Balance - Invoice_Non_Vatable;
                                externalInsRepository.Entry(instruction, EntityState.Modified);
                                externalInsRepository.SaveChanges();

                                if (FutureCostVatable < Invoice_Vatable)
                                {
                                    if (FutureCostNonVatable >= Invoice_Non_Vatable + (Invoice_Vatable - FutureCostVatable))
                                    {
                                        if (PendingAmendmentCnt == 0 && PendingIncreaseCnt == 0)
                                        {
                                            using (var purchaseRepository = new PurchaseOrdersRepository())
                                            {
                                                var purchase = new Purchase_Order();
                                                purchase.Status = VarConstants.PendingAmendment;
                                                purchase.Instruction_ID = instruction.ID;
                                                purchase.Vendor_ID = instruction.Vendor_ID;
                                                purchase.Vendor = invoice.Vendor;
                                                purchase.Vatable_Amount = Invoice_Vatable - instruction.Legal_Cost_Vatable_Balance;
                                                purchase.Non_Vatable_Amount = 0;
                                                purchase.Created = DateTime.Now;
                                                purchase.Created_By = VarConstants.SystemDetails;
                                                var poTask = new PO_Task();
                                                poTask.Status = VarConstants.PendingAmendment;
                                                poTask.Assigned_To_ID = instruction.PO_Contact_ID;
                                                poTask.Created = DateTime.Now;
                                                purchase.PO_Tasks.Add(poTask);
                                                purchaseRepository.Add(purchase);
                                                purchaseRepository.SaveChanges();
                                                SendMailOnNewPO(instruction, purchase.ID, false, "", "", (int)KeywordObjectTypeEnum.AmendPOTask, (int)EmailCategoryEnum.AmendPOTask);
                                            }
                                            instruction.Status = VarConstants.Instruction_Pending_PO_Amendment;
                                            externalInsRepository.Entry(instruction, EntityState.Modified);
                                            externalInsRepository.SaveChanges();
                                            Comments = VarConstants.Instruction_Pending_PO_Amendment;
                                            GRVContact = SystemDetailsViewModel.GRVOwner;
                                        }
                                        else
                                        {
                                            using (PurchaseOrdersRepository purchaseRepository = new PurchaseOrdersRepository())
                                            {
                                                var purchase = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference).FirstOrDefault();
                                                if (PendingIncreaseCnt == 0)
                                                {
                                                    purchase.Vatable_Amount = purchase.Vatable_Amount + (Invoice_Vatable - FutureCostVatable);
                                                    purchaseRepository.Entry(purchase, EntityState.Modified);
                                                    purchaseRepository.SaveChanges();
                                                    GRVContact = SystemDetailsViewModel.GRVOwner;
                                                    Comments = VarConstants.Instruction_Pending_PO_Amendment;
                                                }
                                                else
                                                {
                                                    purchase.Vatable_Amount = purchase.Vatable_Amount;
                                                    purchaseRepository.Entry(purchase, EntityState.Modified);
                                                    purchaseRepository.SaveChanges();
                                                    GRVContact = SystemDetailsViewModel.GRVOwner;
                                                    Comments = VarConstants.PendingIncrease;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (PendingIncreaseCnt == 0)
                                        {
                                            instruction.Status = VarConstants.Instruction_PO_Increase_Required;
                                            externalInsRepository.Entry(instruction, EntityState.Modified);
                                            externalInsRepository.SaveChanges();
                                            SendMailOnPOIncrease(instruction);
                                            GRVContact = SystemDetailsViewModel.GRVOwner;
                                            Comments = VarConstants.Instruction_PO_Increase_Required;

                                            if (PendingAmendmentCnt != 0)
                                            {
                                                using (PurchaseOrdersRepository purchaseRepository = new PurchaseOrdersRepository())
                                                {
                                                    var purchase = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference && x.Status == VarConstants.PendingAmendment).ToList();
                                                    if (purchase.Count() != 0)
                                                    {
                                                        foreach (var purc in purchase)
                                                        {
                                                            purc.Status = VarConstants.Cancelled;
                                                            purchaseRepository.Entry(purc, EntityState.Modified);
                                                            purchaseRepository.SaveChanges();

                                                            using (POTaskRepository poTaskRepository = new POTaskRepository())
                                                            {
                                                                var lstPoTask = poTaskRepository.Find(x => x.PurchaseOrder_ID == purc.ID).ToList();
                                                                if (lstPoTask.Count() > 0)
                                                                {
                                                                    var poTask = lstPoTask.FirstOrDefault();
                                                                    poTask.Status = VarConstants.Cancelled;
                                                                    poTaskRepository.SaveChanges();
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            GRVContact = SystemDetailsViewModel.GRVOwner;
                                            Comments = VarConstants.PendingIncrease;
                                        }
                                    }
                                }

                                if (FutureCostNonVatable < Invoice_Non_Vatable)
                                {
                                    if (FutureCostVatable >= Invoice_Vatable + (Invoice_Non_Vatable - FutureCostNonVatable))
                                    {
                                        if (PendingAmendmentCnt == 0 && PendingIncreaseCnt == 0)
                                        {
                                            using (var purchaseRepository = new PurchaseOrdersRepository())
                                            {
                                                var purchase = new Purchase_Order();
                                                purchase.Status = VarConstants.PendingAmendment;
                                                purchase.Instruction_ID = instruction.ID;
                                                purchase.Vendor_ID = instruction.Vendor_ID;
                                                purchase.Vatable_Amount = 0;
                                                purchase.Non_Vatable_Amount = Invoice_Non_Vatable - instruction.Legal_Cost_Non_Vatable_Balance;
                                                purchase.Created = DateTime.Now;
                                                purchase.Created_By = VarConstants.SystemDetails;
                                                var poTask = new PO_Task();
                                                poTask.Status = VarConstants.PendingAmendment;
                                                poTask.Assigned_To_ID = instruction.PO_Contact_ID;
                                                poTask.Created = DateTime.Now;
                                                purchase.PO_Tasks.Add(poTask);
                                                purchaseRepository.Add(purchase);
                                                purchaseRepository.SaveChanges();
                                                SendMailOnNewPO(instruction, purchase.ID, false, "", "", (int)KeywordObjectTypeEnum.AmendPOTask, (int)EmailCategoryEnum.AmendPOTask);
                                            }
                                            instruction.Status = VarConstants.Instruction_Pending_PO_Amendment;
                                            externalInsRepository.Entry(instruction, EntityState.Modified);
                                            externalInsRepository.SaveChanges();
                                            Comments = VarConstants.Instruction_Pending_PO_Amendment;
                                            GRVContact = SystemDetailsViewModel.GRVOwner;
                                        }
                                        else
                                        {
                                            using (PurchaseOrdersRepository purchaseRepository = new PurchaseOrdersRepository())
                                            {
                                                var purchase = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference).ToList();
                                                if (PendingIncreaseCnt == 0)
                                                {
                                                    if (purchase.Count() != 0)
                                                    {
                                                        foreach (var purc in purchase)
                                                        {
                                                            purc.Non_Vatable_Amount = purc.Non_Vatable_Amount + (Invoice_Non_Vatable - instruction.Legal_Cost_Non_Vatable_Balance);
                                                            purc.Instruction_ID = instruction.ID;
                                                            purchaseRepository.Entry(purc, EntityState.Modified);
                                                            purchaseRepository.SaveChanges();
                                                            Comments = VarConstants.Instruction_Pending_PO_Amendment;
                                                            GRVContact = SystemDetailsViewModel.GRVOwner;
                                                        }
                                                    }
                                                }

                                                else
                                                {
                                                    if (purchase.Count() != 0)
                                                    {
                                                        foreach (var purc in purchase)
                                                        {
                                                            purc.Vatable_Amount = purc.Vatable_Amount;
                                                            purc.Instruction_ID = instruction.ID;
                                                            purchaseRepository.Entry(purc, EntityState.Modified);
                                                            purchaseRepository.SaveChanges();
                                                            Comments = VarConstants.PendingIncrease;
                                                            GRVContact = SystemDetailsViewModel.GRVOwner;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (PendingIncreaseCnt == 0)
                                        {
                                            instruction.Status = VarConstants.Instruction_PO_Increase_Required;
                                            externalInsRepository.Entry(instruction, EntityState.Modified);
                                            externalInsRepository.SaveChanges();
                                            SendMailOnPOIncrease(instruction);
                                            Comments = VarConstants.POIncrease;
                                            GRVContact = SystemDetailsViewModel.GRVOwner;

                                            if (PendingAmendmentCnt != 0)
                                            {
                                                using (PurchaseOrdersRepository purchaseRepository = new PurchaseOrdersRepository())
                                                {
                                                    var purchase = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference && x.Status == VarConstants.PendingAmendment).ToList();
                                                    if (purchase.Count() != 0)
                                                    {
                                                        foreach (var purc in purchase)
                                                        {
                                                            purc.Status = VarConstants.Cancelled;

                                                            var poTask = new PO_Task();

                                                            using (POTaskRepository poTaskRepository = new POTaskRepository())
                                                            {
                                                                var lstPoTask = poTaskRepository.Find(x => x.PurchaseOrder_ID == purc.ID).ToList();
                                                                if (lstPoTask.Count() > 0)
                                                                {
                                                                    poTask = lstPoTask.FirstOrDefault();
                                                                    poTask.Status = VarConstants.Cancelled;
                                                                    poTaskRepository.SaveChanges();
                                                                }
                                                            }

                                                            purchaseRepository.Entry(purc, EntityState.Modified);
                                                            purchaseRepository.SaveChanges();
                                                        }
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                Comments = VarConstants.PendingIncrease;
                                                GRVContact = SystemDetailsViewModel.GRVOwner;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    Comments = VarConstants.PendingIncrease;
                                    GRVContact = SystemDetailsViewModel.GRVOwner;
                                }
                                */

                                GRVContact = SystemDetailsViewModel.GRVOwner;
                                Comments = string.Empty;//Todo: check later.
                                UpdateInvoiceGRV(invoice, GRVContact, true, Comments);
                            }
                            if (MatterSystem == SystemTypes.BusinessUnit.ToString())
                            {
                                UpdateInvoiceGRV(invoice, GRVContact, false, Comments, Convert.ToInt32(GRVContact_ID));
                            }
                        }

                        if (GRV == CommonConstants.No)
                            UpdateInvoiceStatus(invoice);
                    }

                    if (invoice.Invoice_Status == EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.GRVComplete.ToString()))
                        UpdateInvoiceStatus(invoice);

                    if (invoice.Invoice_Status == EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.SentforPayment.ToString()))
                    {
                        UpdateInvoicePayment(invoice);
                        //InvoicePaymentEmail(invoice, instruction.Payment_Clearance_Number, Email);
                    }
                }
            }
        }

        /// <summary>
        /// send email on new time sheet created
        /// </summary>
        /// <param name="assign"></param>
        private void SendNewTimeSheetMail(string assign, string invoiceNo, int tId, string matter)
        {
            var timeVm = new InvoiceTimesheetTaskViewModel();
            timeVm.AssignedTo = assign;
            var qsDictionary = new Dictionary<string, string> { { "id", tId.ToString() }, { "invoiceNumber", invoiceNo } };
            timeVm.Url = SystemDetailsViewModel.URL + "/" + VarConstants.TSTasks + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary);
            timeVm.Matter_Reference = matter;
            using (MatterRepository matterRepository = new MatterRepository())
            {
                timeVm.MatterName = matterRepository.Find(x => x.Matter_Reference == matter).Select(y => y.Matter_Name).FirstOrDefault();
            }
            var emailManager = new EmailManager();
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(assign);
            emailDetails.EmailCC = SystemDetailsViewModel.Team;
            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.NewTimeSheetTask, (int)EmailCategoryEnum.NewTimeSheetTask, emailDetails, timeVm, false);
        }

        /// <summary>
        /// method to send mail on create po task
        /// </summary>
        /// <param name="instruction"></param>
        private void SendMailOnNewPO(External_Instruction instruction, int purchaseId, bool isNew = false, string comment = "", string subject = "", int keyType = 0, int emailType = 0)
        {
            //var matter = new Matter();
            var purchase = new Purchase_Order();
            string comments = string.Empty; string status = string.Empty;
            int purId = 0;

            using (PurchaseOrdersRepository purchaseOrdersRepository = new PurchaseOrdersRepository())
            {
                purchase = purchaseOrdersRepository.First(x => x.ID == purchaseId);
                purId = purchase.PO_Tasks.Count() > 0 ? purchase.PO_Tasks.LastOrDefault().ID : 0;
                status = purchase.PO_Tasks.Count() > 0 ? purchase.PO_Tasks.LastOrDefault().Status : string.Empty;
                if (isNew)
                    comments = comment;
                else
                    comments = purchase.PO_Tasks.Count() > 0 ? purchase.PO_Tasks.LastOrDefault().Comments : string.Empty;
            }


            var poTaskVm = new POTasksViewModel();
            poTaskVm.Matter_Reference = instruction.Matter.Matter_Reference;
            poTaskVm.MatterName = instruction.Matter.Matter_Name;
            poTaskVm.Matter_Title = instruction.Matter.Matter_Name;
            poTaskVm.BusinessUnit = instruction.Client_Companies.Company_Name;
            poTaskVm.POContact = instruction.PeoplePicker != null ? instruction.PeoplePicker.Full_Name : string.Empty;
            poTaskVm.ClientLead = instruction.Matter.PeoplePicker.Full_Name;
            poTaskVm.CostCentre = instruction.Cost_Centre;
            poTaskVm.Date = DateTime.Parse(DateTime.Now.ToShortDateString()).ToString(AppConstants.DATEFORMAT_SERVER, CultureInfo.InvariantCulture);
            poTaskVm.GLAccount = purchase.GL_Account;
            poTaskVm.LeadLawyer = instruction.Matter.SystemType.SystemTypeName == SystemTypes.BusinessUnit.ToString() ? instruction.Matter.PeoplePicker.Full_Name : instruction.Matter.User.FullName;
            poTaskVm.LegalDiscipline = instruction.Matter.Matter_Reference + ": " + instruction.Matter.Matter_Name;
            poTaskVm.NonVatable_Amount = CommonConstants.Currency + purchase.Non_Vatable_Amount;
            poTaskVm.Non_Vatable_Amount = CommonConstants.Currency + purchase.Non_Vatable_Amount;
            poTaskVm.OrderNumber = purchase.PO_Number;
            poTaskVm.PO_Number = purchase.PO_Number;
            poTaskVm.PurchaseRequestReference = instruction.Matter.Matter_Reference + "_" + instruction.Vendor.Company_Name;
            poTaskVm.Purchase_Total = Math.Round(Convert.ToDecimal(purchase.Vatable_Amount + purchase.Non_Vatable_Amount), 2);
            poTaskVm.Total_Amount = Math.Round(Convert.ToDecimal(purchase.Vatable_Amount + purchase.Non_Vatable_Amount), 2);
            poTaskVm.Vatable_Amount = CommonConstants.Currency + purchase.Vatable_Amount;
            poTaskVm.Vendor = instruction.Vendor.Company_Name;
            poTaskVm.Comments = comments;
            poTaskVm.Subject = subject == "" ? VarConstants.AmendmentSubject : subject;
            var qsDictionary = new Dictionary<string, string> { { "id", purId.ToString() }, { "status", status }, { "isAdmin", false.ToString() } };
            poTaskVm.Url = SystemDetailsViewModel.URL + "/" + VarConstants.POTasks + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary);

            var emailManager = new EmailManager();
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            var emailTo = instruction.PeoplePicker != null ? instruction.PeoplePicker.Full_Name : string.Empty;
            emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(emailTo);
            emailDetails.EmailCC = SystemDetailsViewModel.Team + ";" + PeoplePickerManager.GetUserEmailAddress(instruction.Matter.User.FullName);
            emailManager.GetEmailTemplateSendMail(keyType, emailType, emailDetails, poTaskVm, true);
        }

        /// <summary>
        /// save grv task on invoice update
        /// </summary>
        /// <param name="invoice"></param>
        /// <param name="GRVContactId"></param>
        /// <param name="Comments"></param>
        private void SaveInvoiceGrv(Invoice invoice, int GRVContactId, string Comments, string GRVContact = "")
        {
            using (GRVTaskRepository grvTaskRepository = new GRVTaskRepository())
            {
                var grv = grvTaskRepository.Find(x => x.Invoice_ID == invoice.ID && x.Invoice_Number == invoice.Invoice_Number).FirstOrDefault();
                if (grv.PeoplePicker.ID != GRVContactId)
                {
                    grv.Complete = DateTime.Now;
                    grv.Invoice_Number = invoice.Invoice_Number;
                    grv.Invoice_ID = invoice.ID;
                    grvTaskRepository.Entry(grv, EntityState.Modified);
                    grvTaskRepository.SaveChanges();

                    var newGrv = new GRV_Task();
                    newGrv.Invoice_ID = invoice.ID;
                    newGrv.Invoice_Number = invoice.Invoice_Number;
                    newGrv.Status = VarConstants.Pending;
                    newGrv.Assigned_To_ID = GRVContactId;
                    newGrv.Created = DateTime.Now;
                    newGrv.Comments = Comments;
                    grvTaskRepository.Add(newGrv);
                    grvTaskRepository.SaveChanges();
                    SendEmailOnGrv(invoice, Comments, GRVContact);
                }
            }
        }

        /// <summary>
        /// send email on grv created
        /// </summary>
        /// <param name="invoice"></param>
        /// <param name="comments"></param>
        /// <param name="emailTo"></param>
        public void SendEmailOnGrv(Invoice invoice, string comments, string emailTo)
        {
            var matter = new Matter();
            var emailManager = new EmailManager();
            var invoiceVm = new InvoiceViewModel();
            using (MatterRepository matterRepository = new MatterRepository())
            {
                matter = matterRepository.GetQueryWithInclude("PeoplePicker").First(x => x.Matter_Reference == invoice.Matter.Matter_Reference);

                var qsDictionary = new Dictionary<string, string> { { "id", invoice.Invoice_Number }, { "isAdmin", false.ToString() }, { "isMail", true.ToString() } };
                invoiceVm.InvoiceDate = DateTime.Now.ToShortDateString();
                invoiceVm.Invoice_Number = invoice.Invoice_Number;
                invoiceVm.Comments = comments;
                invoiceVm.Vendor = invoice.Vendor.Company_Name;
                invoiceVm.LeadLawyer = matter.SystemType_ID == (int)SystemTypes.BusinessUnit ? matter.PeoplePicker.Full_Name : matter.User.FullName;
                invoiceVm.MatterReference = matter.Matter_Reference;
                invoiceVm.UrlDocs = SystemDetailsViewModel.URL + "/" + VarConstants.InvoiceDocument + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary);
                invoiceVm.Url = SystemDetailsViewModel.URL + "/" + VarConstants.GRVTasks + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary);
                invoiceVm.PONumber = GetPONumber(invoice);

                var emailDetails = new Exigent.Email.Configuration.EmailDetails();
                emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(emailTo);
                emailDetails.EmailCC = SystemDetailsViewModel.Team;

                var fileUrl = HttpContext.Current.Server.MapPath("/" + VarConstants.Invoices + "/" + invoiceVm.Vendor + @"/" + Convert.ToDateTime(invoice.Created).Year + @"/" + invoiceVm.Invoice_Number + @"/");
                var directory = new DirectoryInfo(fileUrl);
                if (Directory.Exists(fileUrl))
                {
                    foreach (FileInfo f in directory.GetFiles())
                    {
                        string file = Path.GetFileNameWithoutExtension(f.Name);
                        if (file.Contains(VarConstants.Invoice))
                            emailDetails.Attachment = string.IsNullOrEmpty(emailDetails.Attachment) ? fileUrl + f.Name : emailDetails.Attachment + " ;" + fileUrl + f.Name;
                    }
                }
                emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.NewGrv, (int)EmailCategoryEnum.NewGrv, emailDetails, invoiceVm, true);
            }
        }

        private string GetPONumber(Invoice invoice)
        {
            var poNumber = string.Empty;

            try
            {
                if (invoice.External_Instructions != null && invoice.External_Instructions.Purchase_Order_Number != null)
                    poNumber = invoice.External_Instructions.Purchase_Order_Number;
                else
                {
                    using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
                    {
                        poNumber = rep.GetQuery().Where(x => x.Instruction_Reference == invoice.External_Instructions.Instruction_Reference).FirstOrDefault().Purchase_Order_Number;
                    }
                }
            }
            catch (ObjectDisposedException)
            {
                using (ExternalInstructionRepository rep = new ExternalInstructionRepository())
                {
                    poNumber = rep.GetQuery().Where(x => x.Instruction_Reference == invoice.External_Instructions.Instruction_Reference).FirstOrDefault().Purchase_Order_Number;
                }
            }

            return poNumber;
        }

        /// <summary>
        /// update invoice send for payment
        /// </summary>
        /// <param name="tblInvoice"></param>
        private void UpdateInvoicePayment(Invoice tblInvoice)
        {
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                var invoice = invoiceRepository.First(x => x.Invoice_Number == tblInvoice.Invoice_Number);
                invoice.Sent_for_Payment = DateTime.Now;
                invoiceRepository.Entry(invoice, EntityState.Modified);
                invoiceRepository.SaveChanges();
            }
        }

        /// <summary>
        /// send email on invoice payment
        /// </summary>
        /// <param name="invoice"></param>
        private void InvoicePaymentEmail(Invoice invoice, string PoNumber, string emailTo)
        {
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            var emailManager = new EmailManager();
            emailDetails.EmailTo = emailTo;
            emailDetails.EmailCC = SystemDetailsViewModel.Team;
            var invoiceVm = new InvoiceViewModel();
            invoiceVm.Invoice_Number = invoice.Invoice_Number;
            invoiceVm.Vendor = invoice.Vendor != null ? invoice.Vendor.Company_Name : string.Empty;
            invoiceVm.GRVNumber = invoice.GRV_Number;
            invoiceVm.Costcentre = invoice.External_Instructions.Cost_Centre;
            invoiceVm.PONumber = PoNumber;
            invoiceVm.BillingEntity = invoice.External_Instructions != null ? invoice.External_Instructions.Client_Companies.Company_Name : string.Empty;
            if (invoice.Matter != null)
            {
                invoiceVm.Matter_Reference = invoice.Matter != null ? invoice.Matter.Matter_Reference : string.Empty;
                invoiceVm.MatterTitle = invoice.Matter.Matter_Name;
            }

            var fileUrl = HttpContext.Current.Server.MapPath("/" + VarConstants.Invoices + "/" + invoice.Vendor.Company_Name + @"/" + Convert.ToDateTime(invoice.Created).Year + @"/" + invoice.Invoice_Number + @"/");
            var directory = new DirectoryInfo(fileUrl);
            if (Directory.Exists(fileUrl))
            {
                foreach (FileInfo f in directory.GetFiles())
                {
                    string file = Path.GetFileNameWithoutExtension(f.Name);
                    if (file.Contains(VarConstants.Invoice))
                        emailDetails.Attachment = string.IsNullOrEmpty(emailDetails.Attachment) ? fileUrl + f.Name : emailDetails.Attachment + " ;" + fileUrl + f.Name;
                }
            }

            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.InvoicePayment, (int)EmailCategoryEnum.InvoicePayment, emailDetails, invoiceVm, true);
        }

        /// <summary>
        /// update invoice ready for payment
        /// </summary>
        /// <param name="tblInvoice"></param>
        private void UpdateInvoiceStatus(Invoice tblInvoice)
        {
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                var invoice = invoiceRepository.First(x => x.Invoice_Number == tblInvoice.Invoice_Number);
                invoice.Invoice_Status = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.ReadyforPayment.ToString());
                invoiceRepository.Entry(invoice, EntityState.Modified);
                invoiceRepository.SaveChanges();
            }
        }

        /// <summary>
        /// update invoice & add grv
        /// </summary>
        /// <param name="invoice"></param>
        /// <param name="GRVContact"></param>
        /// <param name="comments"></param>
        private void UpdateInvoiceGRV(Invoice tblInvoice, string GRVContact, bool comments, string Comments, int GRVContactId = 0)
        {
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                var invoice = invoiceRepository.First(x => x.Invoice_Number == tblInvoice.Invoice_Number);
                invoice.Invoice_Status = VarConstants.AwaitingGRV;
                invoice.GRV_Requested = DateTime.Now;
                var grv = new GRV_Task();
                grv.Invoice_ID = invoice.ID;
                grv.Status = VarConstants.Pending;

                if (!string.IsNullOrEmpty(GRVContact))
                    grv.Assigned_To_ID = PeoplePickerManager.GetPeoplePickerIDByName(GRVContact);
                else
                    grv.Assigned_To_ID = GRVContactId;

                grv.Created = DateTime.Now;
                grv.Invoice_Number = invoice.Invoice_Number;
                if (comments)
                    grv.Comments = Comments;

                invoice.GRV_Tasks.Add(grv);
                invoiceRepository.Entry(invoice, EntityState.Modified);
                invoiceRepository.SaveChanges();
                SendEmailOnGrv(invoice, grv.Comments, GRVContact);
            }
        }

        /// <summary>
        /// method to validate Instruction status & invoice status
        /// </summary>
        /// <param name="vendor"></param>
        /// <param name="invoiceNo"></param>
        /// <param name="isInvoice"></param>
        /// <returns></returns>
        public string ValidateInstructionRef(string vendor, string insNo)
        {
            var result = string.Empty;
            using (ExternalInstructionRepository externalInsRepository = new ExternalInstructionRepository())
            {
                var lstExtIns = externalInsRepository.Find(x => x.Vendor.Company_Name == vendor && x.Instruction_Reference == insNo).ToList();
                if (lstExtIns != null && lstExtIns.Count() > 0)
                {
                    result = string.Empty;
                    if (lstExtIns.FirstOrDefault().Status == VarConstants.Closed)
                        result = VarConstants.InstructionClosed;
                }
                else
                    result = VarConstants.NoSuchInstruction.Replace("{Vendor}", vendor);
            }
            //check reference in invoice table
            if (string.IsNullOrEmpty(result))
            {
                using (InvoiceRepository invoiceRepository = new InvoiceRepository())
                {
                    var invoice = invoiceRepository.Find(x => x.External_Instructions.Instruction_Reference == insNo && x.Invoice_Type == InvoiceType.FinalInvoice.ToString() && (x.Invoice_Status != InvoiceStatus.Rejected.ToString() || x.Invoice_Status != InvoiceStatus.Credited.ToString())).ToList();
                    if (invoice != null && invoice.Count() > 0)
                        result = VarConstants.FinalInvoice;
                }
            }
            return result;
        }

        #endregion

        /// <summary>
        /// Update invoice status & send email.
        /// </summary>
        /// <param name="invoice"></param>
        /// <param name="newStatus"></param>
        public bool UpdateInvoiceStatusById(int id, InvoiceStatus? newStatus = null, DateTime? paymentDate = null, string comments = null)
        {
            Invoice invoice = null;
            using (InvoiceRepository rep = new InvoiceRepository())
            {
                if (newStatus == null)
                {
                    //Updating Payment Processing Comments only.
                    if (comments == null)
                        return false;

                    invoice = rep.GetQuery().Where(m => m.ID == id).FirstOrDefault();

                    if (invoice != null)
                    {
                        invoice.Payment_Processing_Comments = comments;

                        rep.Entry(invoice, EntityState.Modified);
                        rep.SaveChanges();
                    }
                    else
                        return false;
                }
                else if (newStatus == InvoiceStatus.SentForPayment)
                {
                    var PCN = string.Empty;
                    var businessUnit = string.Empty;
                    var email = string.Empty;
                    var billingEntity = string.Empty;
                    var PaymentProcessing = string.Empty;

                    invoice = rep.GetQuery().Where(m => m.ID == id).FirstOrDefault();
                    PCN = invoice.External_Instructions.Purchase_Order_Number;
                    businessUnit = invoice.Matter.Business_Units.Business_Unit1;
                    billingEntity = invoice.External_Instructions.Client_Companies.Company_Name;
                    if (invoice.User != null && invoice.Payment_Processing_ID > 0)
                        PaymentProcessing = invoice.User.Email;
                    else
                        PaymentProcessing = "";

                    invoice.Invoice_Status = EnumHelper<InvoiceStatus>.GetEnumDescription(newStatus.ToString());
                    invoice.Sent_for_Payment = DateTime.Now;



                    if (invoice.Payment_Processing_ID <= 0 || invoice.Payment_Processing_ID == null)
                    {
                        using (ClientComponyRepository repo = new ClientComponyRepository())
                        {
                            var clientComp = repo.GetQueryWithInclude("User").Where(x => x.Company_Name == billingEntity).FirstOrDefault();
                            if (clientComp != null)
                            {
                                invoice.Payment_Processing_ID = clientComp.Payment_Processing_ID;
                                email = clientComp.User.Email;
                            }
                        }
                    }

                    //using (UserRepository rep = new UserRepository())
                    //{
                    //	email = rep.GetQuery().Where(e => e.FullName == PaymentProcessing).Select(m => m.Email).FirstOrDefault();
                    //}

                    rep.Entry(invoice, EntityState.Modified);
                    rep.SaveChanges();
                    // Get email from Payment_Processing_ID in Invoice table.
                    //if (invoice.User != null && invoice.Payment_Processing_ID > 0)
                    //    email = invoice.User.Email;
                    //else
                    //    email = "";

                    InvoicePaymentEmail(invoice, PCN, email);
                }
                else if (newStatus == InvoiceStatus.Paid)
                {
                    if (paymentDate == null)
                        return false;

                    using (InvoiceRepository repo = new InvoiceRepository())
                    {
                        paymentDate = paymentDate.Value.AddDays(1).AddMinutes(-1);

                        invoice = repo.GetQuery().Where(m => m.ID == id && m.Sent_for_Payment <= paymentDate).FirstOrDefault();

                        if (invoice != null)
                        {
                            invoice.Invoice_Status = EnumHelper<InvoiceStatus>.GetEnumDescription(newStatus.ToString());
                            invoice.Payment_Date = paymentDate;
                            /*****************Update invoice USD amount too*******************/
                            decimal amountToUSD = 0;
                            Dictionary<string, decimal> ConvertAmountCollection = HttpRuntime.Cache["ConvertAmountCollection"] as Dictionary<string, decimal>;
                            if (invoice.CurrencyTable.CurrencyCode.ToLower().Equals("usd"))
                                amountToUSD = Convert.ToDecimal(1);
                            else if (ConvertAmountCollection != null && ConvertAmountCollection.ContainsKey(invoice.CurrencyTable.CurrencyCode.ToLower()))
                            {
                                amountToUSD = CurrencyConverterManager.GetConversionAvailableInCache(invoice.CurrencyTable.CurrencyCode, ConvertAmountCollection);
                                amountToUSD = amountToUSD > 0 ? amountToUSD : CurrencyConverterManager.ConvertCurrencyToUSD(1, "USD", invoice.CurrencyTable.CurrencyCode, ConvertAmountCollection);
                            }
                            else
                                amountToUSD = CurrencyConverterManager.ConvertCurrencyToUSD(1, "USD", invoice.CurrencyTable.CurrencyCode, ConvertAmountCollection);

                            var Invoice_Total_In_USD = CurrencyConverterManager.CalculateAmount(invoice.Invoice_Total_InvCur, amountToUSD);
                            var PreVat_Total_In_USD = CurrencyConverterManager.CalculateAmount(invoice.PreVat_Total_InvCur, amountToUSD);
                            var Attorney_Fee_In_USD = CurrencyConverterManager.CalculateAmount(invoice.Attorney_Fee_InvCur, amountToUSD);
                            var Advocate_Fee_In_USD = CurrencyConverterManager.CalculateAmount(invoice.Advocate_Fee_InvCur, amountToUSD);
                            var C3rd_Party_Fee_In_USD = CurrencyConverterManager.CalculateAmount(invoice.C3rd_Party_Fee_InvCur, amountToUSD);
                            var Disbursement_Fee_In_USD = CurrencyConverterManager.CalculateAmount(invoice.Disbursement_Total_InvCur, amountToUSD);
                            var Disbursement_Total_In_USD = CurrencyConverterManager.CalculateAmount(invoice.Disbursement_Total_InvCur, amountToUSD);


                            invoice.Invoice_Total = Invoice_Total_In_USD;
                            invoice.PreVat_Total = PreVat_Total_In_USD;
                            invoice.Attorney_Fee = Attorney_Fee_In_USD;
                            invoice.Advocate_Fee = Advocate_Fee_In_USD;
                            invoice.C3rd_Party_Fee = C3rd_Party_Fee_In_USD;
                            invoice.Disbursement_Fee = Disbursement_Fee_In_USD;
                            invoice.Disbursement_Total = Disbursement_Total_In_USD;

                            /*****************Update invoice USD amount too*******************/

                            if (comments != null)
                                invoice.Payment_Processing_Comments = comments;

                            repo.Entry(invoice, EntityState.Modified);
                            repo.SaveChanges();

                            UpdateMatterCost(invoice.Matter_ID, PreVat_Total_In_USD);
                            UpdateMarkPaidCalculations(invoice);
                            UpdateInstructionBalance(invoice.Instruction_ID, PreVat_Total_In_USD);
                        }
                        else
                            return false;
                    }
                }
            }
            return true;
        }

        private void UpdateMatterCost(int? matterId, decimal? preVatTotal)
        {
            using (MatterRepository repo = new MatterRepository())
            {
                var matter = repo.First(x => x.ID == matterId);
                matter.Matter_Cost = (matter.Matter_Cost == null ? 0 : matter.Matter_Cost) + preVatTotal;
                repo.Entry(matter, EntityState.Modified);
                repo.SaveChanges();
            }
        }

        private void UpdateInstructionBalance(int? insId, decimal? preVatTotal)
        {
            using (var repo = new ExternalInstructionRepository())
            {
                var inst = repo.First(x => x.ID == insId);
                inst.Instructions_Balance = (inst.Legal_Cost_Non_Vatable_Balance.HasValue ? inst.Legal_Cost_Non_Vatable_Balance.Value : 0) + (inst.Legal_Cost_Vatable_Balance.HasValue ? inst.Legal_Cost_Vatable_Balance.Value : 0);
                inst.Instructions_Balance_Local = (inst.Legal_Cost_Non_Vatable_Balance_Local.HasValue ? inst.Legal_Cost_Non_Vatable_Balance_Local.Value : 0) + (inst.Legal_Cost_Vatable_Balance_Local.HasValue ? inst.Legal_Cost_Vatable_Balance_Local.Value : 0);
                repo.Entry(inst, EntityState.Modified);
                repo.SaveChanges();
            }
        }

        public void UpdateMarkPaidCalculations(Invoice invoice)
        {
            InvoiceRepository repo = new InvoiceRepository();
            ExternalInstructionRepository externalInsRepository = new ExternalInstructionRepository();
            invoice = repo.Find(x => x.Invoice_Number == invoice.Invoice_Number).FirstOrDefault();

            //string MatterSystem;
            string GRVContact = string.Empty; int? GRVContact_ID;
            //string Comments = VarConstants.GRVInvoice;
            //string PaymentProcessing = string.Empty;
            string GRV = string.Empty;
            string BusinessUnit = string.Empty;
            int PendingAmendmentCnt, PendingIncreaseCnt = 0;
            decimal FutureCostVatable, FutureCostNonVatable = 0;
            var lstExtIns = externalInsRepository.GetQueryWithInclude("Client_Companies").Where(x => x.Instruction_Reference == invoice.External_Instructions.Instruction_Reference).ToList();
            var instruction = lstExtIns.Count() > 0 ? lstExtIns.FirstOrDefault() : new External_Instruction();
            if (instruction == null)
            {
                instruction = invoice.External_Instructions;
            }
            GRVContact_ID = instruction.GRV_Contact_ID;
            //changes made for Non-Vatable Disbursement
            var Invoice_Vatable = invoice.PreVat_Total - invoice.Disbursement_Total;
            var Invoice_Non_Vatable = invoice.Disbursement_Total;

            var Invoice_Vatable_Local = invoice.PreVat_Total_InvCur - invoice.Disbursement_Total_InvCur;
            var Invoice_Non_Vatable_Local = invoice.Disbursement_Total_InvCur;

            using (PurchaseOrdersRepository purchaseRepository = new PurchaseOrdersRepository())
            {
                var lstPendingAmendment = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference && x.Status == VarConstants.PendingAmendment).ToList();
                var lstPendingIncrease = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference && x.Status == VarConstants.PendingIncrease).ToList();
                var PendingIncrease = lstPendingIncrease.Count() > 0 ? lstPendingIncrease.FirstOrDefault() : new Purchase_Order();
                var PendingAmendment = lstPendingAmendment.Count() > 0 ? lstPendingAmendment.FirstOrDefault() : new Purchase_Order();
                PendingAmendmentCnt = lstPendingAmendment.Count();
                PendingIncreaseCnt = lstPendingIncrease.Count();

                FutureCostVatable = (Convert.ToDecimal(instruction.Legal_Cost_Vatable_Balance) + (Convert.ToDecimal(PendingIncrease.Vatable_Amount) + Convert.ToDecimal(PendingAmendment.Vatable_Amount))) - Convert.ToDecimal(PendingAmendment.Non_Vatable_Amount);
                FutureCostNonVatable = (Convert.ToDecimal(instruction.Legal_Cost_Non_Vatable_Balance) + (Convert.ToDecimal(PendingIncrease.Non_Vatable_Amount) + Convert.ToDecimal(PendingAmendment.Non_Vatable_Amount))) - Convert.ToDecimal(PendingAmendment.Vatable_Amount);
            }

            instruction.Legal_Cost_Vatable_Balance = instruction.Legal_Cost_Vatable_Balance - Invoice_Vatable;
            instruction.Legal_Cost_Non_Vatable_Balance = instruction.Legal_Cost_Non_Vatable_Balance - Invoice_Non_Vatable;
            //CI-Global_CRI(19-Sep-2018)
            instruction.Legal_Cost_Vatable_Balance_Local = instruction.Legal_Cost_Vatable_Balance_Local - Invoice_Vatable_Local;
            instruction.Legal_Cost_Non_Vatable_Balance_Local = instruction.Legal_Cost_Non_Vatable_Balance_Local - Invoice_Non_Vatable_Local;
            externalInsRepository.Entry(instruction, EntityState.Modified);
            externalInsRepository.SaveChanges();

            if (FutureCostVatable < Invoice_Vatable)
            {
                if (FutureCostNonVatable >= Invoice_Non_Vatable + (Invoice_Vatable - FutureCostVatable))
                {
                    if (PendingAmendmentCnt == 0 && PendingIncreaseCnt == 0)
                    {
                        using (var purchaseRepository = new PurchaseOrdersRepository())
                        {
                            var purchase = new Purchase_Order();
                            purchase.Status = VarConstants.PendingAmendment;
                            purchase.Instruction_ID = instruction.ID;
                            purchase.Vendor_ID = instruction.Vendor_ID;
                            purchase.Vendor = invoice.Vendor;
                            purchase.Vatable_Amount = Invoice_Vatable - instruction.Legal_Cost_Vatable_Balance;
                            purchase.Non_Vatable_Amount = 0;
                            purchase.Vatable_Amount_Local = Invoice_Vatable_Local - instruction.Legal_Cost_Vatable_Balance_Local;
                            purchase.Non_Vatable_Amount_Local = 0;
                            purchase.Created = DateTime.Now;
                            purchase.Created_By = VarConstants.SystemDetails;
                            var poTask = new PO_Task();
                            poTask.Status = VarConstants.PendingAmendment;
                            poTask.Assigned_To_ID = instruction.PO_Contact_ID;
                            poTask.Created = DateTime.Now;
                            purchase.PO_Tasks.Add(poTask);
                            purchaseRepository.Add(purchase);
                            purchaseRepository.SaveChanges();
                            SendMailOnNewPO(instruction, purchase.ID, false, "", "", (int)KeywordObjectTypeEnum.AmendPOTask, (int)EmailCategoryEnum.AmendPOTask);
                        }
                        instruction.Status = VarConstants.Instruction_Pending_PO_Amendment;
                        externalInsRepository.Entry(instruction, EntityState.Modified);
                        externalInsRepository.SaveChanges();
                        //Comments = VarConstants.Instruction_Pending_PO_Amendment;
                        //GRVContact = SystemDetailsViewModel.GRVOwner;
                    }
                    else
                    {
                        using (PurchaseOrdersRepository purchaseRepository = new PurchaseOrdersRepository())
                        {
                            var purchase = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference).FirstOrDefault();
                            if (PendingIncreaseCnt == 0)
                            {
                                purchase.Vatable_Amount = purchase.Vatable_Amount + (Invoice_Vatable - FutureCostVatable);
                                purchaseRepository.Entry(purchase, EntityState.Modified);
                                purchaseRepository.SaveChanges();
                                //GRVContact = SystemDetailsViewModel.GRVOwner;
                                //Comments = VarConstants.Instruction_Pending_PO_Amendment;
                            }
                            else
                            {
                                purchase.Vatable_Amount = purchase.Vatable_Amount;
                                purchaseRepository.Entry(purchase, EntityState.Modified);
                                purchaseRepository.SaveChanges();
                                //GRVContact = SystemDetailsViewModel.GRVOwner;
                                //Comments = VarConstants.PendingIncrease;
                            }
                        }
                    }
                }
                else
                {
                    if (PendingIncreaseCnt == 0)
                    {
                        instruction.Status = VarConstants.Instruction_PO_Increase_Required;
                        externalInsRepository.Entry(instruction, EntityState.Modified);
                        externalInsRepository.SaveChanges();
                        //SendMailOnPOIncrease(instruction);
                        //GRVContact = SystemDetailsViewModel.GRVOwner;
                        //Comments = VarConstants.Instruction_PO_Increase_Required;

                        if (PendingAmendmentCnt != 0)
                        {
                            using (PurchaseOrdersRepository purchaseRepository = new PurchaseOrdersRepository())
                            {
                                var purchase = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference && x.Status == VarConstants.PendingAmendment).ToList();
                                if (purchase.Count() != 0)
                                {
                                    foreach (var purc in purchase)
                                    {
                                        purc.Status = VarConstants.Cancelled;
                                        purchaseRepository.Entry(purc, EntityState.Modified);
                                        purchaseRepository.SaveChanges();

                                        using (POTaskRepository poTaskRepository = new POTaskRepository())
                                        {
                                            var lstPoTask = poTaskRepository.Find(x => x.PurchaseOrder_ID == purc.ID).ToList();
                                            if (lstPoTask.Count() > 0)
                                            {
                                                var poTask = lstPoTask.FirstOrDefault();
                                                poTask.Status = VarConstants.Cancelled;
                                                poTaskRepository.SaveChanges();
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    //else
                    //{
                    //    GRVContact = SystemDetailsViewModel.GRVOwner;
                    //    Comments = VarConstants.PendingIncrease;
                    //}
                }
            }

            if (FutureCostNonVatable < Invoice_Non_Vatable)
            {
                if (FutureCostVatable >= Invoice_Vatable + (Invoice_Non_Vatable - FutureCostNonVatable))
                {
                    if (PendingAmendmentCnt == 0 && PendingIncreaseCnt == 0)
                    {
                        using (var purchaseRepository = new PurchaseOrdersRepository())
                        {
                            var purchase = new Purchase_Order();
                            purchase.Status = VarConstants.PendingAmendment;
                            purchase.Instruction_ID = instruction.ID;
                            purchase.Vendor_ID = instruction.Vendor_ID;
                            purchase.Vatable_Amount = 0;
                            purchase.Non_Vatable_Amount = Invoice_Non_Vatable - instruction.Legal_Cost_Non_Vatable_Balance;
                            purchase.Created = DateTime.Now;
                            purchase.Created_By = VarConstants.SystemDetails;
                            var poTask = new PO_Task();
                            poTask.Status = VarConstants.PendingAmendment;
                            poTask.Assigned_To_ID = instruction.PO_Contact_ID;
                            poTask.Created = DateTime.Now;
                            purchase.PO_Tasks.Add(poTask);
                            purchaseRepository.Add(purchase);
                            purchaseRepository.SaveChanges();
                            SendMailOnNewPO(instruction, purchase.ID, false, "", "", (int)KeywordObjectTypeEnum.AmendPOTask, (int)EmailCategoryEnum.AmendPOTask);
                        }
                        instruction.Status = VarConstants.Instruction_Pending_PO_Amendment;
                        externalInsRepository.Entry(instruction, EntityState.Modified);
                        externalInsRepository.SaveChanges();
                        //Comments = VarConstants.Instruction_Pending_PO_Amendment;
                        //GRVContact = SystemDetailsViewModel.GRVOwner;
                    }
                    else
                    {
                        using (PurchaseOrdersRepository purchaseRepository = new PurchaseOrdersRepository())
                        {
                            var purchase = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference).ToList();
                            if (PendingIncreaseCnt == 0)
                            {
                                if (purchase.Count() != 0)
                                {
                                    foreach (var purc in purchase)
                                    {
                                        purc.Non_Vatable_Amount = purc.Non_Vatable_Amount + (Invoice_Non_Vatable - instruction.Legal_Cost_Non_Vatable_Balance);
                                        purc.Instruction_ID = instruction.ID;
                                        purchaseRepository.Entry(purc, EntityState.Modified);
                                        purchaseRepository.SaveChanges();
                                        //Comments = VarConstants.Instruction_Pending_PO_Amendment;
                                        //GRVContact = SystemDetailsViewModel.GRVOwner;
                                    }
                                }
                            }

                            else
                            {
                                if (purchase.Count() != 0)
                                {
                                    foreach (var purc in purchase)
                                    {
                                        purc.Vatable_Amount = purc.Vatable_Amount;
                                        purc.Instruction_ID = instruction.ID;
                                        purchaseRepository.Entry(purc, EntityState.Modified);
                                        purchaseRepository.SaveChanges();
                                        //Comments = VarConstants.PendingIncrease;
                                        //GRVContact = SystemDetailsViewModel.GRVOwner;
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    if (PendingIncreaseCnt == 0)
                    {
                        instruction.Status = VarConstants.Instruction_PO_Increase_Required;
                        externalInsRepository.Entry(instruction, EntityState.Modified);
                        externalInsRepository.SaveChanges();
                        //SendMailOnPOIncrease(instruction);
                        //Comments = VarConstants.POIncrease;
                        //GRVContact = SystemDetailsViewModel.GRVOwner;

                        if (PendingAmendmentCnt != 0)
                        {
                            using (PurchaseOrdersRepository purchaseRepository = new PurchaseOrdersRepository())
                            {
                                var purchase = purchaseRepository.Find(x => x.External_Instructions.Instruction_Reference == instruction.Instruction_Reference && x.Status == VarConstants.PendingAmendment).ToList();
                                if (purchase.Count() != 0)
                                {
                                    foreach (var purc in purchase)
                                    {
                                        purc.Status = VarConstants.Cancelled;

                                        var poTask = new PO_Task();

                                        using (POTaskRepository poTaskRepository = new POTaskRepository())
                                        {
                                            var lstPoTask = poTaskRepository.Find(x => x.PurchaseOrder_ID == purc.ID).ToList();
                                            if (lstPoTask.Count() > 0)
                                            {
                                                poTask = lstPoTask.FirstOrDefault();
                                                poTask.Status = VarConstants.Cancelled;
                                                poTaskRepository.SaveChanges();
                                            }
                                        }

                                        purchaseRepository.Entry(purc, EntityState.Modified);
                                        purchaseRepository.SaveChanges();
                                    }
                                }
                            }
                        }
                        //else
                        //{
                        //    Comments = VarConstants.PendingIncrease;
                        //    GRVContact = SystemDetailsViewModel.GRVOwner;
                        //}
                    }
                }
            }
            //else
            //{
            //    Comments = VarConstants.PendingIncrease;
            //    GRVContact = SystemDetailsViewModel.GRVOwner;
            //}
        }

        public string GetFilePath(Invoice invoice)
        {
            return "";
        }

        /// <summary>
        /// method to get Invoice By Invoice No
        /// </summary>
        /// <param name="invoiceNo"></param>
        /// <returns></returns>
        public InvoiceViewModel GetInvoiceByInvoiceNo(string invoiceNo, bool isUpdate = false)
        {
            var invoiceVm = new InvoiceViewModel();
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                var invoice = invoiceRepository.First(x => x.Invoice_Number == invoiceNo);
                if (invoice != null)
                {
                    invoiceVm.Invoice_Number = invoice.Invoice_Number;
                    invoiceVm.Vendor = invoice.Vendor.Company_Name;
                    invoiceVm.Vendor_ID = Convert.ToInt32(invoice.Vendor_ID);
                    invoiceVm.Currency_ID = Convert.ToInt32(invoice.Currency_ID);
                    invoiceVm.Created = invoice.Created;
                    invoiceVm.Advocate_Fee = Math.Round(Convert.ToDecimal(invoice.Advocate_Fee), 2);
                    invoiceVm.Advocate_HDSA = invoice.Advocate_Fee_HDSA;
                    invoiceVm.Advocate_Recommendation = invoice.Advocate_Recommendation;
                    invoiceVm.Attorney_Fee = Math.Round(Convert.ToDecimal(invoice.Attorney_Fee), 2);
                    invoiceVm.Attorney_HDSA = invoice.Attorney_Fee_HDSA;
                    invoiceVm.C3rd_Party_Fee = Math.Round(Convert.ToDecimal(invoice.C3rd_Party_Fee), 2);
                    invoiceVm.C3rd_Party_HDSA = invoice.C3rd_Party_Fee_HDSA;
                    invoiceVm.Disbursement_Total = Math.Round(Convert.ToDecimal(invoice.Disbursement_Fee), 2);
                    invoiceVm.Instruction_Reference = invoice.External_Instructions.Instruction_Reference;
                    invoiceVm.ApprovalDate = DateTime.Parse(invoice.Invoice_Date.ToString()).ToString(AppConstants.DATEFORMAT_SERVER, CultureInfo.InvariantCulture);
                    invoiceVm.Invoice_Status = invoice.Invoice_Status;
                    invoiceVm.Invoice_Total = Math.Round(Convert.ToDecimal(invoice.Invoice_Total), 2);
                    invoiceVm.Invoice_Type = invoice.Invoice_Type;
                    invoiceVm.Matter_Reference = invoice.Matter.Matter_Reference;
                    invoiceVm.PreVat_Total = Math.Round(Convert.ToDecimal(invoice.PreVat_Total), 2);
                    invoiceVm.Invoice_Date = invoice.Invoice_Date;
                    invoiceVm.ID = invoice.ID;
                    invoiceVm.InvoiceId = invoice.ID;
                    invoiceVm.Disbursement_Inv_Total = Math.Round(Convert.ToDecimal(invoice.Disbursement_Total), 2);
                    invoiceVm.CurrencyCode = invoice.CurrencyTable.CurrencyCode;
                    invoiceVm.GRV_Number = invoice.GRV_Number;
                    invoiceVm.GRV_Received = invoice.GRV_Received != null ? DateTime.Parse(invoice.GRV_Received.ToString()).ToString(AppConstants.DATEFORMAT_SERVER, CultureInfo.InvariantCulture) : string.Empty;
                    invoiceVm.Payment_Date = invoice.Payment_Date != null ? DateTime.Parse(invoice.Payment_Date.ToString()).ToString(AppConstants.DATEFORMAT_SERVER, CultureInfo.InvariantCulture) : string.Empty;
                    invoiceVm.Comments = invoice.Payment_Processing_Comments;
                    invoiceVm.User = invoice.User != null ? invoice.User.FullName : string.Empty;
                    if (isUpdate && invoice.InvoiceFeeDetails.Count() > 0)
                    {
                        invoiceVm.lstInvoiceFeeDtl = new List<InvoiceFeeDetailViewModel>();
                        foreach (var fee in invoice.InvoiceFeeDetails)
                        {
                            invoiceVm.lstInvoiceFeeDtl.Add(
                               new InvoiceFeeDetailViewModel
                               {
                                   Gender = fee.Gender,
                                   VendorLawer_ID = fee.VendorLawer_ID,
                                   Id = fee.Id,
                                   Race = fee.Race,
                                   Name = fee.VendorLawyer != null ? fee.VendorLawyer.Lawyer : string.Empty,
                                   Rate = fee.Rate,
                                   Total = fee.Total
                               });
                        }
                    }
                }
            }
            return invoiceVm;
        }

        public InvoiceViewModel GetInvoiceDocumentPathDetail(int invoiceId)
        {
            var invoiceVm = new InvoiceViewModel();
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                var invoice = invoiceRepository.First(x => x.ID == invoiceId);
                if (invoice != null)
                {
                    invoiceVm.Invoice_Number = invoice.Invoice_Number;
                    invoiceVm.Vendor = invoice.Vendor.Company_Name;
                    invoiceVm.Created = invoice.Created;
                }
            }
            return invoiceVm;
        }

        #region Invoice Audit

        /// <summary>
        /// update invoice audit status
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="comments"></param>
        /// <param name="isSend"></param>
        public void UpdateInvoiceAuditStatus(InvoiceAuditViewModel invoiceAuditVM, string user, string userFullName)
        {
            using (InvoiceAuditRepository invoiceAuditRepository = new InvoiceAuditRepository())
            {
                var invoiceAudit = invoiceAuditRepository.First(x => x.Invoice_ID == invoiceAuditVM.InvoiceId);

                invoiceAudit.Comments = invoiceAudit.Comments;
                invoiceAudit.Complete = DateTime.Now;
                invoiceAudit.Status = invoiceAuditVM.IsSend ? InvoiceAudit.Approved.ToString() : InvoiceAudit.Rejected.ToString();
                //add invoice audit details
                var invoiceAud = new Invoice_Audit_Detail();
                invoiceAud.Advocate = invoiceAuditVM.Advocate != null ? invoiceAuditVM.Advocate.Trim() : string.Empty;
                invoiceAud.Associate = invoiceAuditVM.Associate != null ? invoiceAuditVM.Associate.Trim() : string.Empty;
                invoiceAud.CandidateAttorney = invoiceAuditVM.CandidateAttorney != null ? invoiceAuditVM.CandidateAttorney.Trim() : string.Empty;
                invoiceAud.InvoiceAudit_ID = invoiceAudit.ID;
                invoiceAud.InvoiceContains = invoiceAuditVM.InvoiceContains;
                invoiceAud.NotReflected = invoiceAuditVM.NotReflected;
                invoiceAud.Partner = invoiceAuditVM.Partner != null ? invoiceAuditVM.Partner.Trim() : string.Empty;
                invoiceAud.SalariedPartner = invoiceAuditVM.SalariedPartner != null ? invoiceAuditVM.SalariedPartner.Trim() : string.Empty;
                invoiceAud.SeniorAssociate = invoiceAuditVM.SeniorAssociate != null ? invoiceAuditVM.SeniorAssociate.Trim() : string.Empty;
                invoiceAudit.Invoice_Audit_Details.Add(invoiceAud);
                invoiceAuditRepository.Entry(invoiceAudit, EntityState.Modified);
                invoiceAuditRepository.SaveChanges();
            }
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                var invoice = invoiceRepository.First(x => x.ID == invoiceAuditVM.InvoiceId);
                var matter = invoice.Matter;
                var instruction = invoice.External_Instructions;
                string TermURL = SystemDetailsViewModel.URL + "/" + VarConstants.TermsAndConditions + "/" + VarConstants.TermsFileName;

                if (invoiceAuditVM.IsSend)
                {
                    invoice.Invoice_Status = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.AwaitingApproval.ToString());
                    invoice.Audited_Date = DateTime.Now;
                    invoice.Highlighted_Issues = invoiceAuditVM.Comments;
                    var invoiceApp = new Invoice_Approval();
                    invoiceApp.Invoice_ID = invoiceAuditVM.InvoiceId;
                    invoiceApp.Status = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.AwaitingApproval.ToString()); ;
                    if (matter.SystemType_ID == (int)SystemTypes.GroupLegal)
                        invoiceApp.Assigned_To_ID_LL = matter.Lead_Lawyer_ID;
                    else
                        invoiceApp.Assigned_To_ID = matter.Lead_Client_ID;
                    invoiceApp.Created = DateTime.Now;
                    invoice.Invoice_Approval.Add(invoiceApp);
                    invoiceRepository.Entry(invoice, EntityState.Modified);
                    invoiceRepository.SaveChanges();
                    //call method after invoice update 
                    UpdateInvoiceOperations(invoice);

                    //set invoice view model
                    var invoiceVm = new InvoiceViewModel();
                    invoiceVm.MatterTitle = matter.Matter_Name;
                    invoiceVm.MatterReference = matter.Matter_Reference;
                    invoiceVm.MatterStatus = matter.Matter_Status.Matter_Status1;
                    invoiceVm.LeadLawyer = matter.SystemType_ID == (int)SystemTypes.BusinessUnit ? matter.PeoplePicker.Full_Name : matter.User.FullName;
                    invoiceVm.ApprovalDate = DateTime.Now.Date.ToShortDateString();
                    invoiceVm.PreVat_Total = invoice.PreVat_Total;
                    invoiceVm.Invoice_Total = invoice.Invoice_Total;
                    invoiceVm.Vendor = invoice.Vendor.Company_Name;
                    invoiceVm.Comments = invoiceAuditVM.Comments;
                    invoiceVm.InvoiceDate = DateTime.Parse(invoice.Invoice_Date.ToString()).Date.ToShortDateString();
                    invoiceVm.Invoice_Number = invoice.Invoice_Number;
                    invoiceVm.User = user;
                    invoiceVm.Url = TermURL;
                    SendEmailInvoiceAudit(invoiceVm, true);
                }
                else
                {
                    invoice.Invoice_Status = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Rejected.ToString());
                    invoice.Rejection_Date = DateTime.Now;
                    invoice.Audited_Date = DateTime.Now;
                    invoice.Rejection_Reason = invoiceAuditVM.Comments;
                    invoiceRepository.Entry(invoice, EntityState.Modified);
                    invoiceRepository.SaveChanges();
                    //call method after invoice update 
                    UpdateInvoiceOperations(invoice);

                    //set invoice view model
                    var invoiceVm = new InvoiceViewModel();
                    invoiceVm.Instruction_Reference = instruction.Instruction_Reference;
                    invoiceVm.InvoiceDate = DateTime.Parse(invoice.Invoice_Date.ToString()).Date.ToShortDateString();
                    invoiceVm.Invoice_Number = invoice.Invoice_Number;
                    invoiceVm.RejectionReason = invoiceAuditVM.Comments;
                    invoiceVm.LeadLawyer = matter.SystemType_ID == (int)SystemTypes.BusinessUnit ? matter.PeoplePicker.Full_Name : matter.User.FullName;
                    invoiceVm.UpdatedByFullName = userFullName;
                    invoiceVm.Email = invoice.CreatedBy;
                    invoiceVm.Url = TermURL;
                    invoiceVm.EmailCC = matter.SystemType_ID == (int)SystemTypes.GroupLegal ? matter.User.FullName : matter.PeoplePicker.Full_Name;
                    invoiceVm.MatterReference = matter.Matter_Reference;
                    invoiceVm.Vendor = invoice.Vendor.Company_Name;
                    invoiceVm.Vendor_ID = invoice.Vendor_ID.Value;
                    invoiceVm.Vendor = invoice.External_Instructions != null ? invoice.External_Instructions.Email : string.Empty;
                    SendEmailInvoiceAudit(invoiceVm, false);
                }
            }
        }

        /// <summary>
        /// send email on invoice send or reject
        /// </summary>
        /// <param name="invoice"></param>
        /// <param name="isSend"></param>
        public void SendEmailInvoiceAudit(InvoiceViewModel invoiceVm, bool isSend)
        {
            if (invoiceVm != null)
            {
                var emailManager = new EmailManager();
                var emailDetails = new Exigent.Email.Configuration.EmailDetails();
                if (!isSend)
                {
                    emailDetails.EmailCC = SystemDetailsViewModel.Team;
                    //+";" + PeoplePickerManager.GetUserEmailAddress(invoiceVm.EmailCC) + ";" + VendorManager.GetVendorEmailAddress(invoiceVm.Vendor_ID);
                    emailDetails.EmailTo = PeoplePickerManager.GetUserEmail(invoiceVm.Email) + ";" + PeoplePickerManager.GetUserEmailAddress(invoiceVm.EmailCC) + ";" + invoiceVm.Vendor;
                    emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.InvoiceReject, (int)EmailCategoryEnum.InvoiceReject, emailDetails, invoiceVm, true);
                }
                else
                {
                    emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(invoiceVm.LeadLawyer);
                    emailDetails.EmailCC = SystemDetailsViewModel.Team;
                    emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.InvoiceApprove, (int)EmailCategoryEnum.InvoiceApprove, emailDetails, invoiceVm, true);
                }
            }
        }

        #endregion

        #region Invoice Approval

        /// <summary>
        /// update invoice approval
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="type"></param>
        /// <param name="comments"></param>
        /// <param name="reassignTo"></param>
        public void UpdateInvoiceApproval(int invoiceId, int type, string comments, string reassignTo, int appId, string userFullName, string reassignName)
        {
            using (InvoiceApprovalRepository invoiceApprovalRepository = new InvoiceApprovalRepository())
            {
                var invoiceApproval = invoiceApprovalRepository.First(x => x.Invoice_ID == invoiceId && x.ID == appId);
                invoiceApproval.Complete = DateTime.Now;
                if (type == (int)InvoiceButtonType.Reject)
                {
                    invoiceApproval.Rejection_Reason = comments;
                    invoiceApproval.Status = InvoiceApproval.Rejected.ToString();
                }

                if (type == (int)InvoiceButtonType.Approve)
                {
                    invoiceApproval.Comments = comments;
                    invoiceApproval.Status = InvoiceApproval.Approved.ToString();
                }

                invoiceApprovalRepository.Entry(invoiceApproval, EntityState.Modified);
                invoiceApprovalRepository.SaveChanges();

                if (type == (int)InvoiceButtonType.Reassign)
                    SaveInvoiceApproval(invoiceApproval, comments, reassignTo, userFullName, reassignName);

                if (type != (int)InvoiceButtonType.Reassign)
                {
                    using (InvoiceRepository invoiceRepository = new InvoiceRepository())
                    {
                        var invoice = invoiceRepository.First(x => x.ID == invoiceId);

                        if (type == (int)InvoiceButtonType.Reject)
                        {
                            invoice.Invoice_Status = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Rejected.ToString());
                            invoice.Rejection_Date = DateTime.Now;
                            invoice.Rejection_Reason = comments;
                        }
                        else
                        {
                            invoice.Invoice_Status = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.Approved.ToString());
                            invoice.Approval_Date = DateTime.Now;
                        }
                        invoiceRepository.Entry(invoice, EntityState.Modified);
                        invoiceRepository.SaveChanges();
                        //call method after invoice update 
                        UpdateInvoiceOperations(invoice);
                        if (type == (int)InvoiceButtonType.Reject)
                            SendInvoiceRejectionEmail(invoice, comments, userFullName);
                    }
                }

            }

        }

        /// <summary>
        /// send invoice rejection email to vendor
        /// </summary>
        /// <param name="invoice"></param>
        /// <param name="comments"></param>
        public void SendInvoiceRejectionEmail(Invoice invoice, string comments, string userFullName)
        {
            var matter = invoice.Matter;
            var emailTo = string.Empty;
            var emailManager = new EmailManager();
            var invoiceVm = new InvoiceViewModel();

            emailTo = PeoplePickerManager.GetUserEmail(invoice.CreatedBy);
            invoiceVm.Instruction_Reference = invoice.External_Instructions.Instruction_Reference;
            invoiceVm.InvoiceDate = DateTime.Parse(invoice.Invoice_Date.ToString()).Date.ToShortDateString();
            invoiceVm.Invoice_Number = invoice.Invoice_Number;
            invoiceVm.RejectionReason = comments;
            invoiceVm.LeadLawyer = matter.SystemType_ID == (int)SystemTypes.BusinessUnit ? matter.PeoplePicker.Full_Name : matter.User.FullName;
            invoiceVm.UpdatedByFullName = userFullName;
            invoiceVm.Email = emailTo;
            invoiceVm.EmailCC = matter.SystemType_ID == (int)SystemTypes.GroupLegal ? matter.User.FullName : matter.PeoplePicker.Full_Name;
            invoiceVm.MatterReference = matter.Matter_Reference;
            invoiceVm.Vendor = invoice.Vendor.Company_Name;

            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            emailDetails.EmailTo = emailTo + ";" + PeoplePickerManager.GetUserEmailAddress(matter.SystemType_ID == (int)SystemTypes.GroupLegal ? matter.User.FullName : matter.PeoplePicker.Full_Name) + ";" + (invoice.External_Instructions != null ? invoice.External_Instructions.Email : string.Empty);
            emailDetails.EmailCC = SystemDetailsViewModel.Team;
            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.InvoiceReject, (int)EmailCategoryEnum.InvoiceReject, emailDetails, invoiceVm, true);
        }

        /// <summary>
        /// save invoice approval on reassign
        /// </summary>
        /// <param name="invoice"></param>
        /// <param name="comments"></param>
        /// <param name="reassignTo"></param>
        public void SaveInvoiceApproval(Invoice_Approval invoiceAp, string comments, string reassignTo, string name, string reassignName)
        {
            using (InvoiceApprovalRepository invoiceRepository = new InvoiceApprovalRepository())
            {
                var invoiceApp = new Invoice_Approval();
                invoiceApp.Invoice_ID = invoiceAp.Invoice_ID;
                invoiceApp.Status = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.AwaitingApproval.ToString());
                if (invoiceAp.Invoice.Matter.SystemType_ID == (int)SystemTypes.GroupLegal)
                    invoiceApp.Assigned_To_ID_LL = Convert.ToInt32(reassignTo);
                else
                    invoiceApp.Assigned_To_ID = Convert.ToInt32(reassignTo);

                invoiceApp.Created = DateTime.Now;
                invoiceApp.Comments = comments;
                invoiceApp.Invoice_Number = invoiceAp.Invoice_Number;
                invoiceRepository.Add(invoiceApp);
                invoiceRepository.SaveChanges();
                var matter = new Matter();
                var invoice = new Invoice();

                InvoiceRepository invoiceRep = new InvoiceRepository();
                invoice = invoiceRep.First(x => x.ID == invoiceAp.Invoice_ID);

                MatterRepository matterRepository = new MatterRepository();
                matter = matterRepository.First(x => x.Matter_Reference == invoice.Matter.Matter_Reference);



                string TermURL = SystemDetailsViewModel.URL + "/" + VarConstants.TermsAndConditions + "/" + VarConstants.TermsFileName;

                var invoiceVm = new InvoiceViewModel();
                invoiceVm.MatterTitle = matter.Matter_Name;
                invoiceVm.MatterReference = matter.Matter_Reference;
                invoiceVm.MatterStatus = matter.Matter_Status != null ? matter.Matter_Status.Matter_Status1 : string.Empty;
                //JIRA-439
                invoiceVm.LeadLawyer = reassignName;
                invoiceVm.ApprovalDate = DateTime.Now.Date.ToShortDateString();
                invoiceVm.PreVat_Total = invoice.PreVat_Total;
                invoiceVm.Invoice_Total = invoice.Invoice_Total;
                invoiceVm.Vendor = invoice.Vendor != null ? invoice.Vendor.Company_Name : string.Empty;
                invoiceVm.Comments = comments;
                invoiceVm.InvoiceDate = DateTime.Parse(invoice.Invoice_Date.ToString()).Date.ToShortDateString();
                invoiceVm.Invoice_Number = invoice.Invoice_Number;
                //invoiceVm.PONumber = instruction.Payment_Clearance_Number;
                invoiceVm.User = name;
                invoiceVm.Url = TermURL;
                SendEmailInvoiceAudit(invoiceVm, true);
            }
        }

        #endregion

        #region Grv Tasks

        /// <summary>
        /// update grv status to complete or reassign
        /// </summary>
        /// <param name="grvVm"></param>
        public void UpdateGrvStatus(GrvTasksViewModel grvVm)
        {
            using (GRVTaskRepository grvTaskRepository = new GRVTaskRepository())
            {
                var grv = grvTaskRepository.First(x => x.Invoice_Number == grvVm.Invoice_Number && x.ID == grvVm.GrvId);

                if (grvVm.IsSend)
                {
                    grv.Complete = DateTime.Now;
                    grv.Status = VarConstants.Approved;
                    grvTaskRepository.Entry(grv, EntityState.Modified);
                    grvTaskRepository.SaveChanges();
                    using (InvoiceRepository invoiceRepository = new InvoiceRepository())
                    {
                        var invoice = invoiceRepository.First(x => x.Invoice_Number == grv.Invoice_Number);
                        invoice.Invoice_Status = EnumHelper<InvoiceStatus>.GetEnumDescription(InvoiceStatus.GRVComplete.ToString());
                        invoice.GRV_Received = DateTime.Now;
                        invoice.GRV_Number = grvVm.Comments;
                        invoiceRepository.Entry(invoice, EntityState.Modified);
                        invoiceRepository.SaveChanges();
                        //call method after invoice update 
                        UpdateInvoiceOperations(invoice);
                    }
                }
                else
                {
                    grv.Complete = DateTime.Now;
                    grvTaskRepository.Entry(grv, EntityState.Modified);
                    grvTaskRepository.SaveChanges();

                    var invoice = new Invoice();
                    using (InvoiceRepository invoiceRepository = new InvoiceRepository())
                    {
                        invoice = invoiceRepository.GetQueryWithInclude("Matter").First(x => x.Invoice_Number == grv.Invoice_Number);
                        var newGrv = new GRV_Task();
                        newGrv.Invoice_ID = invoice.ID;
                        newGrv.Invoice_Number = invoice.Invoice_Number;
                        newGrv.Status = VarConstants.Pending;
                        newGrv.Assigned_To_ID = PeoplePickerManager.GetPeoplePickerIDByName(grvVm.Assigned_To);
                        newGrv.Created = DateTime.Now;
                        newGrv.Comments = grvVm.Comments;
                        grvTaskRepository.Add(newGrv);
                        grvTaskRepository.SaveChanges();
                        SendEmailOnGrv(invoice, grvVm.Comments, grvVm.Assigned_To);
                    }
                }
            }
        }

        #endregion

        #region PO Tasks

        /// <summary>
        /// method to update PO details & status on complete & reassing actions
        /// </summary>
        /// <param name="poVm"></param>
        public void UpdatePOStatus(POTasksViewModel poVm)
        {
            if (poVm != null)
            {
                if (!poVm.IsSend)
                {
                    using (POTaskRepository poTaskRepository = new POTaskRepository())
                    {
                        var potask = poTaskRepository.First(x => x.ID == poVm.Id);
                        potask.Complete = DateTime.Now;
                        poTaskRepository.Entry(potask, EntityState.Modified);
                        poTaskRepository.SaveChanges();

                        var pOrder = new PO_Task();

                        pOrder.Assigned_To_ID = poVm.Assigned_To_ID;
                        pOrder.Created = DateTime.Now;

                        if (poVm.Status == VarConstants.PendingIncrease)
                            pOrder.Status = VarConstants.PendingIncrease;
                        else if (poVm.Status == VarConstants.PendingAmendment)
                            pOrder.Status = VarConstants.PendingAmendment;
                        else
                            pOrder.Status = VarConstants.PendingNew;

                        pOrder.PurchaseOrder_ID = potask.PurchaseOrder_ID;
                        pOrder.Comments = poVm.Comments;
                        poTaskRepository.Add(pOrder);
                        poTaskRepository.SaveChanges();
                        var instruction = new External_Instruction();
                        using (ExternalInstructionRepository externalInsRepository = new ExternalInstructionRepository())
                        {
                            instruction = externalInsRepository.GetQueryWithInclude("Matter").First(x => x.Instruction_Reference == poVm.Instruction);
                            var subject = string.Empty;
                            int emailType, keyType = 0;
                            if (poVm.Status == VarConstants.PendingIncrease)
                            {
                                subject = VarConstants.IncreasePurchaseOrder;
                                keyType = (int)KeywordObjectTypeEnum.IncreasePOStart;
                                emailType = (int)EmailCategoryEnum.IncreasePOStart;
                            }
                            else if (poVm.Status == VarConstants.PendingAmendment)
                            {
                                subject = VarConstants.AmendmentSubject;
                                keyType = (int)KeywordObjectTypeEnum.AmendPOTask;
                                emailType = (int)EmailCategoryEnum.AmendPOTask;
                            }
                            else
                            {
                                subject = VarConstants.NewPurchaseOrder;
                                keyType = (int)KeywordObjectTypeEnum.NewPOTask;
                                emailType = (int)EmailCategoryEnum.NewPOTask;
                            }

                            //update po contact when task is reassign
                            instruction.PO_Contact_ID = poVm.Assigned_To_ID;
                            SendMailOnNewPO(instruction, Convert.ToInt32(potask.PurchaseOrder_ID), true, poVm.Comments, subject, keyType, emailType);
                        }
                    }
                }
                else
                {
                    using (POTaskRepository poTaskRepository = new POTaskRepository())
                    {
                        var potask = poTaskRepository.First(x => x.ID == poVm.Id);
                        potask.Complete = DateTime.Now;
                        if (poVm.Status == VarConstants.PendingIncrease)
                            potask.Status = VarConstants.IncreaseComplete;
                        else if (poVm.Status == VarConstants.PendingAmendment)
                            potask.Status = VarConstants.AmendmentComplete;
                        else
                            potask.Status = VarConstants.Complete;
                        poTaskRepository.Entry(potask, EntityState.Modified);
                        poTaskRepository.SaveChanges();

                        using (PurchaseOrdersRepository purchaseOrdersRepository = new PurchaseOrdersRepository())
                        {
                            var purchase = purchaseOrdersRepository.First(x => x.ID == potask.PurchaseOrder_ID);
                            if (poVm.Status == VarConstants.PendingIncrease)
                                purchase.Status = VarConstants.POIncreased;
                            else if (poVm.Status == VarConstants.PendingAmendment)
                                purchase.Status = VarConstants.POAmended;
                            else
                            {
                                purchase.Status = VarConstants.POReceived;
                                purchase.PO_Number = poVm.PoNumber;
                            }
                            purchaseOrdersRepository.Entry(purchase, EntityState.Modified);
                            purchaseOrdersRepository.SaveChanges();

                            using (ExternalInstructionRepository externalInsRepository = new ExternalInstructionRepository())
                            {
                                var instruction = externalInsRepository.First(x => x.Instruction_Reference == poVm.Instruction);
                                if (poVm.Status == VarConstants.PendingIncrease)
                                {
                                    instruction.Estimated_Legal_Cost_Vatable = instruction.Estimated_Legal_Cost_Vatable + purchase.Vatable_Amount;
                                    instruction.Estimated_Legal_Cost_Non_Vatable = instruction.Estimated_Legal_Cost_Non_Vatable + purchase.Non_Vatable_Amount;
                                    instruction.Legal_Cost_Vatable_Balance = instruction.Legal_Cost_Vatable_Balance + purchase.Vatable_Amount;
                                    instruction.Legal_Cost_Non_Vatable_Balance = instruction.Legal_Cost_Non_Vatable_Balance + purchase.Non_Vatable_Amount;
                                    instruction.Status = VarConstants.Active;
                                    instruction.Instructions_Balance = instruction.Legal_Cost_Vatable_Balance + instruction.Legal_Cost_Non_Vatable_Balance;
                                    instruction.Instructions_Balance_Local = instruction.Legal_Cost_Vatable_Balance_Local + instruction.Legal_Cost_Non_Vatable_Balance_Local;//CI-Global_CR1(19-Sep-2018): 
                                    instruction.Legal_Cost_Vatable_Balance_Local = instruction.Legal_Cost_Vatable_Balance_Local + purchase.Vatable_Amount_Local;//CI-Global_CR1(19-Sep-2018): 
                                    instruction.Legal_Cost_Non_Vatable_Balance_Local = instruction.Legal_Cost_Non_Vatable_Balance_Local + purchase.Non_Vatable_Amount_Local;//CI-Global_CR1(19-Sep-2018): 
                                    externalInsRepository.Entry(instruction, EntityState.Modified);
                                    externalInsRepository.SaveChanges();
                                }
                                else if (poVm.Status == VarConstants.PendingAmendment)
                                {
                                    instruction.Estimated_Legal_Cost_Vatable = (instruction.Estimated_Legal_Cost_Vatable + purchase.Vatable_Amount) - purchase.Non_Vatable_Amount;
                                    instruction.Estimated_Legal_Cost_Non_Vatable = (instruction.Estimated_Legal_Cost_Non_Vatable + purchase.Non_Vatable_Amount) - purchase.Vatable_Amount;
                                    instruction.Legal_Cost_Vatable_Balance = (instruction.Legal_Cost_Vatable_Balance + purchase.Vatable_Amount) - purchase.Non_Vatable_Amount;
                                    instruction.Legal_Cost_Non_Vatable_Balance = (instruction.Legal_Cost_Non_Vatable_Balance + purchase.Non_Vatable_Amount) - purchase.Vatable_Amount;
                                    instruction.Status = VarConstants.Active;
                                    instruction.Instructions_Balance = instruction.Legal_Cost_Vatable_Balance + instruction.Legal_Cost_Non_Vatable_Balance;
                                    instruction.Instructions_Balance_Local = instruction.Legal_Cost_Vatable_Balance_Local + instruction.Legal_Cost_Non_Vatable_Balance_Local;//CI-Global_CR1(19-Sep-2018): 
                                    instruction.Legal_Cost_Vatable_Balance_Local = (instruction.Legal_Cost_Vatable_Balance_Local + purchase.Vatable_Amount_Local) - purchase.Non_Vatable_Amount_Local;//CI-Global_CR1(19-Sep-2018): 
                                    instruction.Legal_Cost_Non_Vatable_Balance_Local = (instruction.Legal_Cost_Non_Vatable_Balance_Local + purchase.Non_Vatable_Amount_Local) - purchase.Vatable_Amount_Local;//CI-Global_CR1(19-Sep-2018): 
                                    externalInsRepository.Entry(instruction, EntityState.Modified);
                                    externalInsRepository.SaveChanges();
                                }
                                else if (instruction.Status == VarConstants.Instruction_Pending_PO)
                                {
                                    instruction.Status = VarConstants.Instruction_Pending_Review;
                                    instruction.Purchase_Order_Number = poVm.PoNumber;
                                    instruction.Confirmed = CommonConstants.Yes;
                                    externalInsRepository.Entry(instruction, EntityState.Modified);
                                    externalInsRepository.SaveChanges();
                                    if (poVm.IsSendToLead && purchase.External_Instructions.SystemType_ID == (int)SystemTypes.GroupLegal)
                                    {
                                        if (purchase.External_Instructions.Matter.User != null)
                                        {
                                            SendNotificationToLL(purchase.External_Instructions.Matter.User.Email, potask, purchase);
                                        }
                                    }
                                }
                                else
                                {
                                    instruction.Confirmed = CommonConstants.Yes;
                                    instruction.Purchase_Order_Number = poVm.PoNumber;
                                    instruction.Sent_Status = VarConstants.Send_Instruction;
                                    externalInsRepository.Entry(instruction, EntityState.Modified);
                                    externalInsRepository.SaveChanges();

                                    if (poVm.IsSendToLead && purchase.External_Instructions.SystemType_ID == (int)SystemTypes.GroupLegal)

                                        if (purchase.External_Instructions.Matter.User != null)
                                        {
                                            SendNotificationToLL(purchase.External_Instructions.Matter.User.Email, potask, purchase);
                                        }

                                    InstructionManager.SetInstructionStatus(instruction.Instruction_Reference, VarConstants.Instruction_Pending_Approval, true);
                                }
                            }
                        }
                    }
                }
            }
        }

        private void SendNotificationToLL(string toEmail, PO_Task poTask, Purchase_Order purchase)
        {
            var poTaskVm = new POTasksViewModel();
            poTaskVm.Matter_Reference = purchase.External_Instructions.Matter.Matter_Reference;
            poTaskVm.Instruction = purchase.External_Instructions.Instruction_Reference;
            poTaskVm.Vendor = purchase.External_Instructions.Vendor.Company_Name;
            poTaskVm.CreatedUser = purchase.Created_By;
            poTaskVm.CreatedDate = purchase.Created != null ? DateTime.Parse(purchase.Created.ToString()).ToString(AppConstants.DATEFORMAT_SERVER, CultureInfo.InvariantCulture) : string.Empty;
            var assignedToPerson = PeoplePickerManager.GetPeoplePickerById(Convert.ToInt32(poTask.Assigned_To_ID));
            if (assignedToPerson != null)
                poTaskVm.Assigned_To = assignedToPerson.Full_Name;
            poTaskVm.PODate = poTask.Created != null ? DateTime.Parse(poTask.Created.ToString()).ToString(AppConstants.DATEFORMAT_SERVER, CultureInfo.InvariantCulture) : string.Empty;
            poTaskVm.CurrentDate = DateTime.Parse(DateTime.Now.ToString()).ToString(AppConstants.DATEFORMAT_SERVER, CultureInfo.InvariantCulture);
            poTaskVm.Payment_Clearance_Number = purchase.External_Instructions.Purchase_Order_Number;
            poTaskVm.CostCentre = purchase.External_Instructions.Cost_Centre;
            poTaskVm.Payment_Clearance_Value = Math.Round(Convert.ToDecimal(purchase.Vatable_Amount), 2);
            var emailManager = new EmailManager();
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            emailDetails.EmailTo = toEmail;
            emailDetails.EmailCC = SystemDetailsViewModel.Team;
            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.NotifyLLOnPO, (int)EmailCategoryEnum.NotifyLLOnPO, emailDetails, poTaskVm, true);
        }

        #endregion

        #region Timesheet

        // Update status of Outstanding Timesheets to complete
        public void CompleteTimesheet(int id)
        {
            using (InvoiceTimesheetRepository _invoiceTimesheetRepository = new InvoiceTimesheetRepository())
            {
                Invoice_Timesheet_Capture_Task timesheet = _invoiceTimesheetRepository.GetById(id);
                if (timesheet != null)
                {
                    timesheet.Complete = DateTime.Now;
                    timesheet.Status = VarConstants.TimesheetStatus.ToString();
                    _invoiceTimesheetRepository.SaveChanges();
                }
            }
        }

        // Save the newly created timesheet
        public void SaveTimesheet(InvoiceTimesheetsViewModel invoiceTimesheetViewModel)
        {
            if (invoiceTimesheetViewModel != null)
            {
                using (TimesheetRepository timesheetRepository = new TimesheetRepository())
                {
                    Invoice_Timesheet invoiceTimesheet = new Invoice_Timesheet
                    {
                        InvoiceID = invoiceTimesheetViewModel.InvoiceID,
                        Lawyer = invoiceTimesheetViewModel.Lawyer,
                        Date = Convert.ToDateTime(invoiceTimesheetViewModel.Date),
                        //Task = invoiceTimesheetViewModel.Task,
                        Detail = invoiceTimesheetViewModel.Detail,
                        Hours = invoiceTimesheetViewModel.Hours,
                        Amount = invoiceTimesheetViewModel.Amount,
                        Discrepancy = invoiceTimesheetViewModel.Discrepancy,
                        Invoice_Number = invoiceTimesheetViewModel.Invoice_Number
                    };

                    timesheetRepository.Add(invoiceTimesheet);
                    timesheetRepository.SaveChanges();
                }
            }
        }

        //Get timesheet by Id
        public InvoiceTimesheetsViewModel GetTimesheetById(int id)
        {
            using (TimesheetRepository timesheetRepository = new TimesheetRepository())
            {
                InvoiceTimesheetsViewModel invoiceTimesheetViewModel = new InvoiceTimesheetsViewModel();
                var timesheetDetails = timesheetRepository.GetQuery().Where(x => x.ID == id);
                if (timesheetDetails != null && timesheetDetails.Count() > 0)
                {
                    return new InvoiceTimesheetsViewModel
                    {
                        ID = timesheetDetails.FirstOrDefault().ID,
                        InvoiceID = timesheetDetails.FirstOrDefault().InvoiceID,
                        Lawyer = timesheetDetails.FirstOrDefault().Lawyer,
                        Date = timesheetDetails.FirstOrDefault().Date,
                        //Task = timesheetDetails.FirstOrDefault().Task,
                        Detail = timesheetDetails.FirstOrDefault().Detail,
                        Hours = timesheetDetails.FirstOrDefault().Hours,
                        Amount = timesheetDetails.FirstOrDefault().Amount,
                        Discrepancy = timesheetDetails.FirstOrDefault().Discrepancy,
                        Invoice_Number = timesheetDetails.FirstOrDefault().Invoice_Number,
                        strDate = DateTime.Parse(timesheetDetails.FirstOrDefault().Date.ToString()).Date.ToString(AppConstants.DATEFORMAT_SERVER)
                    };
                }
                return invoiceTimesheetViewModel;
            }
        }

        // Update timesheet
        public void UpdateTimesheet(InvoiceTimesheetsViewModel invoiceTimesheetsViewModel)
        {
            using (TimesheetRepository timesheetRepository = new TimesheetRepository())
            {
                var timesheet = timesheetRepository.First(x => x.ID == invoiceTimesheetsViewModel.ID);
                if (timesheet != null)
                {
                    timesheet.InvoiceID = invoiceTimesheetsViewModel.InvoiceID;
                    timesheet.Invoice_Number = invoiceTimesheetsViewModel.Invoice_Number;
                    timesheet.Lawyer = invoiceTimesheetsViewModel.Lawyer;
                    //timesheet.Task = invoiceTimesheetsViewModel.Task;
                    timesheet.Detail = invoiceTimesheetsViewModel.Detail;
                    timesheet.Date = invoiceTimesheetsViewModel.Date;
                    timesheet.Discrepancy = invoiceTimesheetsViewModel.Discrepancy;
                    timesheet.Hours = invoiceTimesheetsViewModel.Hours;
                    timesheet.Amount = invoiceTimesheetsViewModel.Amount;
                    timesheetRepository.SaveChanges();
                }
            }
        }

        #endregion

        /// <summary>
        /// Reassigning the payment processing contact to aother person from people picker.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="assignTo"></param>
        /// <returns></returns>
        public bool ReassignForPaymentProcessing(int id, int assignTo)
        {
            using (InvoiceRepository rep = new InvoiceRepository())
            {
                var query = rep.GetQuery().Where(m => m.ID == id);

                if (query == null || query.Count() < 1)
                    return false;

                query.ForEach(m =>
                {
                    m.Payment_Processing_ID = assignTo;
                });

                rep.SaveChanges();
            }

            return true;
        }

        #region HOD
        public static string[] GetHODSpendTrendData(string spendTrendYear, int Country)
        {
            string hodSpendTrendjsondata = string.Empty;
            string hodSpendTrendDetailjsondata = string.Empty;
            string hodYTDSpendTrendData = string.Empty;
            string hodYTDPerMatterPerVendorData = string.Empty;
            string hodYTDVendorsData = string.Empty;
            string hodYTDSpendPerBUData = string.Empty;
            string hodYTDRecievedInvoicesCountData = string.Empty;
            string[] jsondata;
            // add year parmam
            List<System.Data.SqlClient.SqlParameter> objParams = new List<System.Data.SqlClient.SqlParameter>();
            System.Data.SqlClient.SqlParameter objYearParam = new System.Data.SqlClient.SqlParameter() { ParameterName = "YEAR", DbType = System.Data.DbType.String, Value = spendTrendYear };
            System.Data.SqlClient.SqlParameter objCountryParam = new System.Data.SqlClient.SqlParameter() { ParameterName = "CountryId", DbType = System.Data.DbType.Int32, Value = Country };
            objParams.Add(objYearParam);
            objParams.Add(objCountryParam);
            // call SP
            System.Data.DataSet ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.GetSpendTrendChartData, objParams);
            if (ds != null && ds.Tables.Count > 0)
            {
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                List<Dictionary<string, object>> rows;
                Dictionary<string, object> row;
                // fill matter data
                rows = new List<Dictionary<string, object>>();
                foreach (System.Data.DataRow dr in ds.Tables[0].Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (System.Data.DataColumn col in ds.Tables[0].Columns)
                    {
                        row.Add(col.ColumnName, dr[col]);
                    }
                    rows.Add(row);
                }
                hodSpendTrendjsondata = serializer.Serialize(rows);
                rows = null;

                if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                {
                    rows = new List<Dictionary<string, object>>();
                    foreach (System.Data.DataRow dr in ds.Tables[1].Rows)
                    {
                        row = new Dictionary<string, object>();
                        foreach (System.Data.DataColumn col in ds.Tables[1].Columns)
                        {
                            row.Add(col.ColumnName, dr[col]);
                        }
                        rows.Add(row);
                    }
                    hodSpendTrendDetailjsondata = serializer.Serialize(rows);
                    rows = null;
                }

                if (ds.Tables[2] != null && ds.Tables[2].Rows.Count > 0)
                {
                    rows = new List<Dictionary<string, object>>();
                    foreach (System.Data.DataRow dr in ds.Tables[2].Rows)
                    {
                        row = new Dictionary<string, object>();
                        foreach (System.Data.DataColumn col in ds.Tables[2].Columns)
                        {
                            row.Add(col.ColumnName, dr[col]);
                        }
                        rows.Add(row);
                    }
                    hodYTDSpendTrendData = serializer.Serialize(rows);
                    rows = null;
                }
                // YTD Spend Per Matter Type Per Vendor
                if (ds.Tables[3] != null && ds.Tables[3].Rows.Count > 0)
                {
                    rows = new List<Dictionary<string, object>>();
                    foreach (System.Data.DataRow dr in ds.Tables[3].Rows)
                    {
                        row = new Dictionary<string, object>();
                        foreach (System.Data.DataColumn col in ds.Tables[3].Columns)
                        {
                            row.Add(col.ColumnName, dr[col]);
                        }
                        rows.Add(row);
                    }
                    hodYTDPerMatterPerVendorData = serializer.Serialize(rows);
                    rows = null;
                }
                // YTD Spend Per Matter Type Per Vendors list
                if (ds.Tables[4] != null && ds.Tables[4].Rows.Count > 0)
                {
                    rows = new List<Dictionary<string, object>>();
                    foreach (System.Data.DataRow dr in ds.Tables[4].Rows)
                    {
                        row = new Dictionary<string, object>();
                        foreach (System.Data.DataColumn col in ds.Tables[4].Columns)
                        {
                            row.Add(col.ColumnName, dr[col]);
                        }
                        rows.Add(row);
                    }
                    hodYTDVendorsData = serializer.Serialize(rows);
                    rows = null;
                }
                // YTD Spend Per BU
                if (ds.Tables[5] != null && ds.Tables[5].Rows.Count > 0)
                {
                    rows = new List<Dictionary<string, object>>();
                    foreach (System.Data.DataRow dr in ds.Tables[5].Rows)
                    {
                        row = new Dictionary<string, object>();
                        foreach (System.Data.DataColumn col in ds.Tables[5].Columns)
                        {
                            row.Add(col.ColumnName, dr[col]);
                        }
                        rows.Add(row);
                    }
                    hodYTDSpendPerBUData = serializer.Serialize(rows);
                    rows = null;
                }

                // YTD Recieved Invoices count
                if (ds.Tables.Count > 6)
                {
                    if (ds.Tables[6] != null && ds.Tables[6].Rows.Count > 0)
                    {
                        rows = new List<Dictionary<string, object>>();
                        foreach (System.Data.DataRow dr in ds.Tables[6].Rows)
                        {
                            row = new Dictionary<string, object>();
                            foreach (System.Data.DataColumn col in ds.Tables[6].Columns)
                            {
                                row.Add(col.ColumnName, dr[col]);
                            }
                            rows.Add(row);
                        }
                        hodYTDRecievedInvoicesCountData = serializer.Serialize(rows);
                        rows = null;
                    }
                }
            }

            jsondata = new string[] { hodSpendTrendjsondata, hodSpendTrendDetailjsondata, hodYTDSpendTrendData, hodYTDPerMatterPerVendorData, hodYTDVendorsData, hodYTDSpendPerBUData, hodYTDRecievedInvoicesCountData };
            return jsondata;
        }

        public static string[] GetInvoicesChartYTDData(int Country, string invoiceNo, string fullName, string matterRefNo, string searchText = null)
        {
            string hodOutstandingInvoicesjsondata = string.Empty;
            string hodOutstandingInvoicesBUjsonData = string.Empty;
            string hodAverageOutstandingInvoicesDaysBUjsonData = string.Empty;
            string hodAverageDaysToPaymentjsonData = string.Empty;
            string hodPaidInvAverageDaysPerBUjsonData = string.Empty;
            string hodOutstandingApprovaljsondata = string.Empty;
            string[] jsondata;
            bool isAvg = true;
            // call SP
            List<System.Data.SqlClient.SqlParameter> objParams = new List<System.Data.SqlClient.SqlParameter>();
            System.Data.SqlClient.SqlParameter objCountryParam = new System.Data.SqlClient.SqlParameter() { ParameterName = "CountryId", DbType = System.Data.DbType.Int32, Value = Country };
            objParams.Add(objCountryParam);
            System.Data.DataSet ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.GetInvoicesChartYTDData, objParams);
            if (ds != null && ds.Tables.Count > 0)
            {
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                List<Dictionary<string, object>> rows;
                Dictionary<string, object> row;
                // fill outstanding invoices data per BU.
                rows = new List<Dictionary<string, object>>();
                foreach (System.Data.DataRow dr in ds.Tables[0].Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (System.Data.DataColumn col in ds.Tables[0].Columns)
                    {
                        row.Add(col.ColumnName, dr[col]);
                    }
                    rows.Add(row);
                }
                hodOutstandingInvoicesjsondata = serializer.Serialize(rows);
                rows = null;
                // fill BU & colors..
                if (ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                {
                    rows = new List<Dictionary<string, object>>();
                    foreach (System.Data.DataRow dr in ds.Tables[1].Rows)
                    {
                        row = new Dictionary<string, object>();
                        foreach (System.Data.DataColumn col in ds.Tables[1].Columns)
                        {
                            row.Add(col.ColumnName, dr[col]);
                            if (dr[col].ToString() == "0")
                            {
                                isAvg = false;
                            }
                        }
                        rows.Add(row);
                    }

                    hodOutstandingInvoicesBUjsonData = serializer.Serialize(rows);
                    rows = null;
                }

                // fill Average Outstanding invoices days, BU & colors..
                if (ds.Tables.Count > 2)
                {
                    if (ds.Tables[2] != null && ds.Tables[2].Rows.Count > 0)
                    {
                        rows = new List<Dictionary<string, object>>();
                        foreach (System.Data.DataRow dr in ds.Tables[2].Rows)
                        {
                            row = new Dictionary<string, object>();
                            foreach (System.Data.DataColumn col in ds.Tables[2].Columns)
                            {
                                row.Add(col.ColumnName, dr[col]);
                            }
                            rows.Add(row);
                        }
                        hodAverageOutstandingInvoicesDaysBUjsonData = serializer.Serialize(rows);
                        rows = null;
                    }
                }



                // fill Average Outstanding invoices days
                if (ds.Tables.Count > 3)
                {
                    if (ds.Tables[3] != null && ds.Tables[3].Rows.Count > 0)
                    {
                        rows = new List<Dictionary<string, object>>();
                        foreach (System.Data.DataRow dr in ds.Tables[3].Rows)
                        {
                            row = new Dictionary<string, object>();
                            foreach (System.Data.DataColumn col in ds.Tables[3].Columns)
                            {
                                row.Add(col.ColumnName, dr[col]);
                            }
                            rows.Add(row);
                        }
                        hodAverageDaysToPaymentjsonData = serializer.Serialize(rows);
                        rows = null;
                    }
                }


                // fill Average paid invoices avg days, BU & colors..
                if (ds.Tables.Count > 4)
                {
                    if (ds.Tables[4] != null && ds.Tables[4].Rows.Count > 0)
                    {
                        rows = new List<Dictionary<string, object>>();
                        foreach (System.Data.DataRow dr in ds.Tables[4].Rows)
                        {
                            row = new Dictionary<string, object>();
                            foreach (System.Data.DataColumn col in ds.Tables[4].Columns)
                            {
                                row.Add(col.ColumnName, dr[col]);
                            }
                            rows.Add(row);
                        }
                        hodPaidInvAverageDaysPerBUjsonData = serializer.Serialize(rows);
                        rows = null;
                    }
                }

            }

            SqlParameter prmInvoiceNo = new SqlParameter { ParameterName = "@invoiceNo", DbType = System.Data.DbType.String, Value = invoiceNo };
            SqlParameter prmName = new SqlParameter { ParameterName = "@GroupLawyer", DbType = System.Data.DbType.String, Value = fullName };
            SqlParameter prmMatter = new SqlParameter { ParameterName = "@MatterRefNo", DbType = System.Data.DbType.String, Value = matterRefNo };
            SqlParameter prmSearchText = new SqlParameter { ParameterName = "@SearchText", DbType = System.Data.DbType.String, Value = searchText };
            SqlParameter prmCountryId = new SqlParameter { ParameterName = "@CountryId", DbType = System.Data.DbType.Int32, Value = Country };


            System.Data.DataSet ds1 = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.ExigentGetInvoiceApprovalTaskWithJurisdictionFilter, new SqlParameter[] { prmInvoiceNo, prmName, prmMatter, prmSearchText, prmCountryId });
            if (ds1 != null && ds1.Tables.Count > 0)
            {
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                List<Dictionary<string, object>> rows;
                Dictionary<string, object> row;
                // fill outstanding invoices data per BU.
                rows = new List<Dictionary<string, object>>();
                foreach (System.Data.DataRow dr in ds1.Tables[0].Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (System.Data.DataColumn col in ds1.Tables[0].Columns)
                    {
                        row.Add(col.ColumnName, dr[col]);
                    }
                    rows.Add(row);
                }
                hodOutstandingApprovaljsondata = serializer.Serialize(rows);
            }


            jsondata = new string[] { hodOutstandingInvoicesjsondata, hodOutstandingInvoicesBUjsonData, hodAverageOutstandingInvoicesDaysBUjsonData, hodAverageDaysToPaymentjsonData, hodPaidInvAverageDaysPerBUjsonData, isAvg.ToString(), hodOutstandingApprovaljsondata };
            return jsondata;
        }



        #endregion

        #region Review

        /// <summary>
        /// update invoice table for sent for payment or GRV
        /// </summary>
        /// <param name="invoiceVm"></param>
        /// <param name="user"></param>
        public static void ReviewInvoice(InvoiceViewModel invoiceVm, string user)
        {
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                var invoice = invoiceRepository.First(x => x.Invoice_Number == invoiceVm.Invoice_Number);
                invoice.Payment_Date = invoiceVm.Sent_Payment_Date;
                invoice.GRV_Received = invoiceVm.GRV_Received_Date;
                invoice.GRV_Number = invoiceVm.GRV_Number;
                invoice.Modified = DateTime.Now;
                invoice.Invoice_Status = VarConstants.Paid;
                invoice.Modified_By = user;
                invoiceRepository.Entry(invoice, EntityState.Modified);
                invoiceRepository.SaveChanges();
            }
        }

        #endregion

        public static bool MoveInvoice(string invoiceNumber, string instructionReference)
        {
            var instruction = new { ID = 0, Vendor = "", Matter_Reference = "" };

            using (var rep = new ExternalInstructionRepository())
            {
                instruction = rep.GetQuery().Where(m => m.Instruction_Reference == instructionReference).Select(m => new { ID = m.ID, Vendor = m.Vendor.Company_Name, Matter_Reference = m.Matter.Matter_Reference }).FirstOrDefault();
            }

            using (var rep = new InvoiceRepository())
            {
                var invoice = rep.GetQuery().Where(m => m.Invoice_Number == invoiceNumber).FirstOrDefault();

                if (instruction == null || string.IsNullOrEmpty(instruction.Vendor) || invoice == null || instruction.Vendor != invoice.Vendor.Company_Name || instruction.Matter_Reference != invoice.Matter.Matter_Reference)
                {
                    throw new Exception("Invalid data posted");
                }

                if (invoice.External_Instructions.Instruction_Reference == instructionReference)
                {
                    return false;
                }

                invoice.Instruction_ID = instruction.ID;
                rep.SaveChanges();
            }

            return true;
        }


        #region Reject

        /// <summary>
        /// update invoice table for Rejection of invoice
        /// </summary>
        /// <param name="invoicereject"></param>
        /// <param name="user"></param>
        public static void RejectInvoice(InvoiceViewModel invoicereject, string user)
        {
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                var invoice = invoiceRepository.First(x => x.Invoice_Number == invoicereject.Invoice_Number);
                invoice.Rejection_Reason = invoicereject.RejectionReason;
                invoice.Rejection_Date = DateTime.Now;
                invoice.Modified = DateTime.Now;
                invoice.Invoice_Status = VarConstants.Rejected;
                invoice.Modified_By = user;
                invoiceRepository.Entry(invoice, EntityState.Modified);
                invoiceRepository.SaveChanges();
            }
        }

        public static void UpdateGRVTask(GrvTasksViewModel grvVm)
        {
            using (GRVTaskRepository grvTaskRepository = new GRVTaskRepository())
            {
                var newGrv = grvTaskRepository.First(x => x.Invoice_Number == grvVm.Invoice_Number);
                newGrv.Invoice_Number = grvVm.Invoice_Number;
                newGrv.Status = VarConstants.Approved;
                newGrv.Comments = VarConstants.forceComments;
                grvTaskRepository.Entry(newGrv, EntityState.Modified);
                grvTaskRepository.SaveChanges();
            }
        }
    }

        #endregion

}
