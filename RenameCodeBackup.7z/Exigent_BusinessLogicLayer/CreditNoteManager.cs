﻿
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System;
using System.Data.Entity;
using System.Globalization;
using System.Linq;


namespace Exigent.BLL
{
    public class CreditNoteManager
    {
        /// <summary>
        /// method to save submit creditnote of invoice
        /// </summary>
        /// <param name="creditNoteVm"></param>
        /// <returns></returns>
        public int SaveCreditNote(CreditNoteViewModel creditNoteVm)
        {
            //Get Invoice Detail By Invoice Number
            InvoiceRepository invoiceRepository = new InvoiceRepository();
            var invoceDetail = invoiceRepository.Find(x => x.Invoice_Number == creditNoteVm.InvoiceNumber).FirstOrDefault();
            var result = 0;
                

                //save data to credit note table
                using (CreditNoteRepository creditRepository = new CreditNoteRepository())
                {
                    var credit = new Credit_Note
                    {
                        Vendor_ID = invoceDetail.Vendor_ID,
                        Instruction_ID= invoceDetail.Instruction_ID,
                        Matter_ID = invoceDetail.Matter_ID,
                        Invoice_ID = invoceDetail.ID,
                        Credit_Note_Date = creditNoteVm.Credit_Note_Date,
                        Credit_Note_Number = creditNoteVm.Credit_Note_Number.Trim(),
                        Modified = DateTime.Now,
                        Modified_By = VarConstants.SystemDetails
                    };

                    creditRepository.Add(credit);
                    creditRepository.SaveChanges();
                    //update invoice status on credit note created
                    UpdateInvoiceStatus(credit);
                    //send mail on credit note                   
                    SendCreditNoteEMail(creditNoteVm);
                }
            //}
            return result;
        }

        /// <summary>
        /// send email on credit note submited
        /// </summary>
        /// <param name="creditNoteVm"></param>
        private void SendCreditNoteEMail(CreditNoteViewModel creditNoteVm)
        {
            var userName = creditNoteVm.ReferenceNumber;
            var emailManager = new EmailManager();
            creditNoteVm.ReferenceNumber = DateTime.Now.ToString("dd/MM/yy") + "-" + creditNoteVm.Credit_Note_Number;
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();
            emailDetails.EmailTo = PeoplePickerManager.GetUserEmail(userName);
            emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.CreditNoteSubmission, (int)EmailCategoryEnum.CreditNoteSubmission, emailDetails, creditNoteVm, true);
        }

        /// <summary>
        /// update invoice status on credit note created
        /// </summary>
        /// <param name="creditNote"></param>
        /// <returns></returns>
        public void UpdateInvoiceStatus(Credit_Note creditNote)
        {
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                var lstInvoice = invoiceRepository.Find(x => x.Vendor_ID == creditNote.Vendor_ID  && x.ID == creditNote.Invoice_ID).ToList();                
                if (lstInvoice != null && lstInvoice.Count() == 0)
                {
                    using (CreditNoteRepository creditRepository = new CreditNoteRepository())
                    {
                        creditRepository.Delete(creditNote);
                        creditRepository.SaveChanges();
                    }
                }
                else
                {
                    var invoice = lstInvoice.FirstOrDefault();                    
                    if (!string.IsNullOrEmpty(invoice.Invoice_Status))
                    {
                        switch (invoice.Invoice_Status)
                        {
                            case VarConstants.AwaitingAudit:
                                if (invoice.Invoice_Audit.Count() > 0)
                                {
                                    var invoceAudit = invoice.Invoice_Audit.FirstOrDefault();
                                    invoceAudit.Status = InvoiceStatus.Rejected.ToString();
                                    invoceAudit.Complete = DateTime.Now;
                                    invoceAudit.Rejection_Reason = VarConstants.InvoiceCredited;
                                }

                                break;
                            case VarConstants.AwaitingApproval:
                                if (invoice.Invoice_Approval.Count() > 0)
                                {
                                    var invoceApproval = invoice.Invoice_Approval.FirstOrDefault();
                                    invoceApproval.Status = InvoiceStatus.Rejected.ToString();
                                    invoceApproval.Rejection_Reason = VarConstants.InvoiceCredited;
                                    invoceApproval.Complete = DateTime.Now;
                                }
                                break;
                            case VarConstants.AwaitingGRV:
                                if (invoice.GRV_Tasks.Count() > 0)
                                {
                                    var invoceGRV_Tasks = invoice.GRV_Tasks.FirstOrDefault();
                                    invoceGRV_Tasks.Status = InvoiceStatus.Rejected.ToString();
                                    invoceGRV_Tasks.Comments = VarConstants.InvoiceCredited;
                                    invoceGRV_Tasks.Complete = DateTime.Now;
                                }
                                UpdateExternalInstruction(invoice);
                                break;
                            case VarConstants.ReadyForPayment:
                                UpdateExternalInstruction(invoice);
                                break;
                            default:

                                break;
                        }
                    }
                    invoice.Invoice_Status = VarConstants.Credited;
                    invoiceRepository.Entry(lstInvoice.FirstOrDefault(), EntityState.Modified);
                    invoiceRepository.SaveChanges();

                    using (CreditNoteRepository creditRepository = new CreditNoteRepository())
                    {
                        creditNote.Matter_ID = lstInvoice.FirstOrDefault().Matter_ID;
                        creditNote.Instruction_ID = lstInvoice.FirstOrDefault().Instruction_ID;
                        creditRepository.Entry(creditNote, EntityState.Modified);
                        creditRepository.SaveChanges();
                    }
                }
            }
        }

        /// <summary>
        /// update instruction using instruction reference
        /// </summary>
        /// <param name="invoice"></param>
        public void UpdateExternalInstruction(Invoice invoice)
        {
            using (ExternalInstructionRepository externalInstructionRepository = new ExternalInstructionRepository())
            {
                var extInst = new External_Instruction();
                //decimal tax = Convert.ToDecimal(0.14);
                decimal tax = Convert.ToDecimal(1);
                extInst.Legal_Cost_Non_Vatable_Balance = (invoice.Invoice_Total - invoice.PreVat_Total) / tax;
                extInst.Legal_Cost_Vatable_Balance = (invoice.PreVat_Total - invoice.Invoice_Total) / tax; ;
                extInst.ID = Convert.ToInt32(invoice.Instruction_ID);
                externalInstructionRepository.SaveChanges();
            }
        }
    }
}
