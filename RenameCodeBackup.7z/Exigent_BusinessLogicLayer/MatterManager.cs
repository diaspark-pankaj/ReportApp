﻿using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.Common.Helpers;
using Exigent.DataLayer.Repository;
using Exigent.EF.Data.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Transactions;

namespace Exigent.BLL
{
    public class MatterManager
    {
        /// <summary>
        /// Get the matter overview/summary by Matter Reference Number.
        /// </summary>
        /// <param name="matterRef">String Matter Reference Number is required.</param>
        /// <returns>MatterBlock object</returns>
        public static MatterBlock GetMatterBlock(string matterRef)
        {
            MatterBlock matterBlock;
            using (MatterRepository rep = new MatterRepository())
            {
                matterBlock = rep.GetQuery()
                    .Where(m => m.Matter_Reference == matterRef)
                    .Select(m => new MatterBlock
                    {
                        Id = m.ID,
                        MatterName = m.Matter_Name,
                        MatterReferenceNumber = m.Matter_Reference,
                        BusinessUnitName = m.Business_Units.Business_Unit1,
                        MatterType = m.LegalDiscipline != null ? m.LegalDiscipline.Name : string.Empty,
                        Matter_Status = m.Matter_Status != null ? m.Matter_Status.Matter_Status1 : string.Empty,
                        Lead_Lawyer = m.User != null ? m.User.FullName : string.Empty,
                        Lead_Client = m.PeoplePicker != null ? m.PeoplePicker.Full_Name : string.Empty,
                        System = m.SystemType != null ? m.SystemType.SystemTypeName : string.Empty,
                        BusinessUnitNameId = m.Business_Unit_ID != null ? m.Business_Unit_ID.Value : 0,
                        LegalDisciplineId = m.LegalDiscipline != null ? m.LegalDiscipline.ID : 0,
                        LegalDiscipline = m.LegalDiscipline != null ? m.LegalDiscipline.Name : string.Empty,
                        LegalPraticeArea = m.LegalDiscipline != null ? m.LegalDiscipline.Name : string.Empty,
                        Country = m.CountryId != null ? m.Country.Country1 : string.Empty,
                        Operations = m.Operation_ID != null ? m.Operation.Operation1 : string.Empty
                    }).FirstOrDefault();
            }

            return matterBlock;
        }

        /// <summary>
        /// Get the matter overview/summary by Matter Id.
        /// </summary>
        /// <param name="id">Integer Id is required.</param>
        /// <returns>MatterBlock object</returns>
        public static MatterBlock GetMatterBlock(int id)
        {
            MatterBlock matterBlock;
            using (MatterRepository rep = new MatterRepository())
            {
                matterBlock = rep.GetQuery()
                    .Where(m => m.ID == id)
                    .Select(m => new MatterBlock
                    {
                        Id = m.ID,
                        MatterName = m.Matter_Name,
                        MatterReferenceNumber = m.Matter_Reference,
                        BusinessUnitName = m.Business_Units.Business_Unit1,
                        BusinessUnitNameId = m.Business_Unit_ID.Value,
                        MatterType = m.LegalDiscipline.Name,
                        Matter_Status = m.Matter_Status.Matter_Status1,
                        Lead_Lawyer = m.User.FullName,
                        Lead_Client = m.PeoplePicker.Full_Name,
                        LegalDiscipline = m.LegalDiscipline.Name,
                        LegalDisciplineId = m.LegalDiscipline.ID,
                        LegalPraticeArea = m.LegalDiscipline.Name,
                        System = m.SystemType.SystemTypeName
                    }).FirstOrDefault();
            }

            return matterBlock;
        }

        /// <summary>
        /// method to get next reference number from reference Id
        /// </summary>
        /// <param name="refId"></param>
        /// <returns></returns>
        public string GetMatterReferenceNo(int businessUnit, string refId, ref Matter_Reference matterRef)
        {
            var refNo = string.Empty;

            using (MatterReferenceRepository matterReferenceRepository = new MatterReferenceRepository())
            {
                var matterRefrence = matterReferenceRepository.Find(x => x.Title == refId && x.Year == DateTime.Now.Year);
                matterRef = matterRefrence.FirstOrDefault();
                if (matterRef.Year != DateTime.Now.Year)
                {
                    matterRef.Year = DateTime.Now.Year;
                    matterRef.NextNumber = 0;
                }

                int nextRef = Convert.ToInt32(matterRef.NextNumber) + 1;
                if (refId == SystemTypes.GroupLegal.ToString())
                    refNo = DateTime.Now.Year.ToString() + VarConstants.Hyphen + nextRef.ToString().PadLeft(5, '0');
                else
                    refNo = DateTime.Now.Year.ToString() + VarConstants.Hyphen + nextRef.ToString().PadLeft(5, '0') + VarConstants.Hyphen + VarConstants.MatterRefBU;
            }
            return refNo;
        }


        public void AddOrUpdateMatterReportClassication_Options(Matter matter, MatterViewModel matterVm)
        {
            MatterReportClassificationOptionsMappingRepository matterReportClassificationOptionsMappingRepository = new MatterReportClassificationOptionsMappingRepository();
            List<MatterReportClassificationOptionsMapping> lstMatterReportClassificationOptions;
            if (matterVm.ID > 0)
                lstMatterReportClassificationOptions = matterReportClassificationOptionsMappingRepository.Find(x => x.MatterId == matterVm.ID).ToList();
            else
                lstMatterReportClassificationOptions = new List<MatterReportClassificationOptionsMapping>();
            // set Matters members in seprate list
            List<string> strIDs = matterVm.MatterReportClassicationOptionList.Split(',').ToList();

            // remove all members first from association that are un-associated now.
            var arrRemoveItems = matter.MatterReportClassificationOptionsMappings.Where(y => !strIDs.Any(z => z == y.Id.ToString())).Select(x => x.Id).ToArray();
            // remove if any item not present in the current list
            foreach (var OptionsID in arrRemoveItems)
            {
                if (lstMatterReportClassificationOptions.Count > 0)
                {
                    var assitMember = lstMatterReportClassificationOptions.FirstOrDefault(x => x.Id == OptionsID && x.MatterId == matter.ID);
                    lstMatterReportClassificationOptions.Remove(assitMember);
                    matterReportClassificationOptionsMappingRepository.Entry(assitMember, EntityState.Deleted);
                }
            }

            // add all new members as new item.

            MatterReportClassificationOptionsMapping objMatterStreams = null;
            foreach (string assistID in strIDs)
            {
                if (Convert.ToInt32(assistID) > 0 && !matter.MatterReportClassificationOptionsMappings.Any(x => x.Id.ToString() == assistID))
                {
                    objMatterStreams = new MatterReportClassificationOptionsMapping();
                    objMatterStreams.OptionId = Convert.ToInt32(assistID);
                    objMatterStreams.MatterId = matter.ID;
                    lstMatterReportClassificationOptions.Add(objMatterStreams);
                    matterReportClassificationOptionsMappingRepository.Entry(objMatterStreams, EntityState.Added);
                }
            }
            objMatterStreams = null;
            matterReportClassificationOptionsMappingRepository.SaveChanges();
        }

        public void AddOrUpdateDraftMatterReportClassication_Options(DraftsMatter matter, MatterViewModel matterVm)
        {
            DraftMatterReportClassificationOptionsMappingRepository matterReportClassificationOptionsMappingRepository = new DraftMatterReportClassificationOptionsMappingRepository();
            List<DraftMatterReportClassificationOptionsMapping> lstMatterReportClassificationOptions;
            if (matterVm.ID > 0)
                lstMatterReportClassificationOptions = matterReportClassificationOptionsMappingRepository.Find(x => x.DraftMatterId == matterVm.ID).ToList();
            else
                lstMatterReportClassificationOptions = new List<DraftMatterReportClassificationOptionsMapping>();
            // set Matters members in seprate list
            List<string> strIDs = matterVm.MatterReportClassicationOptionList.Split(',').ToList();

            // remove all members first from association that are un-associated now.
            var arrRemoveItems = matter.DraftMatterReportClassificationOptionsMappings.Where(y => !strIDs.Any(z => z == y.Id.ToString())).Select(x => x.Id).ToArray();
            // remove if any item not present in the current list
            foreach (var OptionsID in arrRemoveItems)
            {
                if (lstMatterReportClassificationOptions.Count > 0)
                {
                    var assitMember = lstMatterReportClassificationOptions.FirstOrDefault(x => x.Id == OptionsID && x.DraftMatterId == matter.ID);
                    lstMatterReportClassificationOptions.Remove(assitMember);
                    matterReportClassificationOptionsMappingRepository.Entry(assitMember, EntityState.Deleted);
                }
            }

            // add all new members as new item.

            DraftMatterReportClassificationOptionsMapping objMatterStreams = null;
            foreach (string assistID in strIDs)
            {
                if (Convert.ToInt32(assistID) > 0 && !matter.DraftMatterReportClassificationOptionsMappings.Any(x => x.Id.ToString() == assistID))
                {
                    objMatterStreams = new DraftMatterReportClassificationOptionsMapping();
                    objMatterStreams.OptionId = Convert.ToInt32(assistID);
                    objMatterStreams.DraftMatterId = matter.ID;
                    lstMatterReportClassificationOptions.Add(objMatterStreams);
                    matterReportClassificationOptionsMappingRepository.Entry(objMatterStreams, EntityState.Added);
                }
            }
            objMatterStreams = null;
            matterReportClassificationOptionsMappingRepository.SaveChanges();
        }
        public void AddOrUpdateMatter_KeyWorkStreams(Matter matter, MatterViewModel matterVm)
        {
            Matters_KeyWorkStream_Repository matterKeyWorkStreamRepo = new Matters_KeyWorkStream_Repository();
            List<Matters_KeyWorkStream> lstKeyWorkStreams;
            if (matterVm.ID > 0)
                lstKeyWorkStreams = matterKeyWorkStreamRepo.Find(x => x.Matter_ID == matterVm.ID).ToList();
            else
                lstKeyWorkStreams = new List<Matters_KeyWorkStream>();
            // set Matters members in seprate list
            List<string> strIDs = matterVm.Key_Work_Stream.Split(';').ToList();

            // remove all members first from association that are un-associated now.
            var arrRemoveItems = matter.Matters_KeyWorkStream.Where(y => !strIDs.Any(z => z == y.KeyWorkStream_ID.ToString())).Select(x => x.KeyWorkStream_ID).ToArray();
            // remove if any item not present in the current list
            foreach (var keyworkstreamID in arrRemoveItems)
            {
                if (lstKeyWorkStreams.Count > 0)
                {
                    var assitMember = lstKeyWorkStreams.FirstOrDefault(x => x.KeyWorkStream_ID == keyworkstreamID && x.Matter_ID == matter.ID);
                    lstKeyWorkStreams.Remove(assitMember);
                    matterKeyWorkStreamRepo.Entry(assitMember, EntityState.Deleted);
                }
            }

            // add all new members as new item.

            Matters_KeyWorkStream objMatterStreams = null;
            foreach (string assistID in strIDs)
            {
                if (Convert.ToInt32(assistID) > 0 && !matter.Matters_KeyWorkStream.Any(x => x.KeyWorkStream_ID.ToString() == assistID))
                {
                    objMatterStreams = new Matters_KeyWorkStream();
                    objMatterStreams.KeyWorkStream_ID = Convert.ToInt32(assistID);
                    objMatterStreams.Matter_ID = matter.ID;
                    lstKeyWorkStreams.Add(objMatterStreams);
                    matterKeyWorkStreamRepo.Entry(objMatterStreams, EntityState.Added);
                }
            }
            objMatterStreams = null;
            matterKeyWorkStreamRepo.SaveChanges();
        }

        public void AddOrUpdateDraftMatter_KeyWorkStreams(DraftsMatter matter, MatterViewModel matterVm)
        {
            DraftMatters_KeyWorkStream_Repository matterKeyWorkStreamRepo = new DraftMatters_KeyWorkStream_Repository();
            List<DraftMatters_KeyWorkStream> lstKeyWorkStreams;
            if (matterVm.ID > 0)
                lstKeyWorkStreams = matterKeyWorkStreamRepo.Find(x => x.DraftMatter_ID == matterVm.ID).ToList();
            else
                lstKeyWorkStreams = new List<DraftMatters_KeyWorkStream>();
            // set Matters members in seprate list
            List<string> strIDs = matterVm.Key_Work_Stream.Split(';').ToList();

            // remove all members first from association that are un-associated now.
            var arrRemoveItems = matter.DraftMatters_KeyWorkStream.Where(y => !strIDs.Any(z => z == y.KeyWorkStream_ID.ToString())).Select(x => x.KeyWorkStream_ID).ToArray();
            // remove if any item not present in the current list
            foreach (var keyworkstreamID in arrRemoveItems)
            {
                if (lstKeyWorkStreams.Count > 0)
                {
                    var assitMember = lstKeyWorkStreams.FirstOrDefault(x => x.KeyWorkStream_ID == keyworkstreamID && x.DraftMatter_ID == matter.ID);
                    lstKeyWorkStreams.Remove(assitMember);
                    matterKeyWorkStreamRepo.Entry(assitMember, EntityState.Deleted);
                }
            }

            // add all new members as new item.

            DraftMatters_KeyWorkStream objMatterStreams = null;
            foreach (string assistID in strIDs)
            {
                if (Convert.ToInt32(assistID) > 0 && !matter.DraftMatters_KeyWorkStream.Any(x => x.KeyWorkStream_ID.ToString() == assistID))
                {
                    objMatterStreams = new DraftMatters_KeyWorkStream();
                    objMatterStreams.KeyWorkStream_ID = Convert.ToInt32(assistID);
                    objMatterStreams.DraftMatter_ID = matter.ID;
                    lstKeyWorkStreams.Add(objMatterStreams);
                    matterKeyWorkStreamRepo.Entry(objMatterStreams, EntityState.Added);
                }
            }
            objMatterStreams = null;
            matterKeyWorkStreamRepo.SaveChanges();
        }

        public void AddOrUpdateMatterAssistMembers(Matter matter, MatterViewModel matterVm)
        {
            Matters_AssistingTeamMembersRepository _assistRepo = new Matters_AssistingTeamMembersRepository();
            List<Matters_AssistingTeamMembers> lstmembers;
            if (matterVm.ID > 0)
                lstmembers = _assistRepo.Find(x => x.Matter_ID == matterVm.ID).ToList();
            else
                lstmembers = new List<Matters_AssistingTeamMembers>();
            // set Matters members in seprate list
            List<KeyValuePair<int, string>> strIDs = JsonConvert.DeserializeObject<List<KeyValuePair<int, string>>>(matterVm.Assisting_Team_Members_IDs);

            // remove all members first from association that are un-associated now.
            var arrRemoveItems = matter.Matters_AssistingTeamMembers.Where(y => !strIDs.Any(z => z.Key == y.Assisting_Team_Member)).Select(x => x.Assisting_Team_Member).ToArray();
            // remove if any item not present in the current list
            foreach (var memberID in arrRemoveItems)
            {
                if (lstmembers.Count > 0)
                {
                    var assitMember = lstmembers.FirstOrDefault(x => x.Assisting_Team_Member == memberID);
                    lstmembers.Remove(assitMember);
                    _assistRepo.Entry(assitMember, EntityState.Deleted);
                }
            }

            // add all new members as new item.

            Matters_AssistingTeamMembers objAssMembers = null;
            foreach (KeyValuePair<int, string> assistID in strIDs)
            {
                if (assistID.Key > 0 && !matter.Matters_AssistingTeamMembers.Any(x => x.Assisting_Team_Member == assistID.Key))
                {
                    objAssMembers = new Matters_AssistingTeamMembers();
                    objAssMembers.Assisting_Team_Member = assistID.Key;
                    objAssMembers.Matter_ID = matter.ID;
                    lstmembers.Add(objAssMembers);
                    _assistRepo.Entry(objAssMembers, EntityState.Added);
                }
            }
            objAssMembers = null;
            _assistRepo.SaveChanges();
        }

        public void AddOrUpdateDraftMatterAssistMembers(DraftsMatter matter, MatterViewModel matterVm)
        {
            DraftMatters_AssistingTeamMembersRepository _assistRepo = new DraftMatters_AssistingTeamMembersRepository();
            List<DraftMatters_AssistingTeamMembers> lstmembers;
            if (matterVm.ID > 0)
                lstmembers = _assistRepo.Find(x => x.DraftMatter_ID == matterVm.ID).ToList();
            else
                lstmembers = new List<DraftMatters_AssistingTeamMembers>();
            // set Matters members in seprate list
            List<KeyValuePair<int, string>> strIDs = JsonConvert.DeserializeObject<List<KeyValuePair<int, string>>>(matterVm.Assisting_Team_Members_IDs);

            // remove all members first from association that are un-associated now.
            var arrRemoveItems = matter.DraftMatters_AssistingTeamMembers.Where(y => !strIDs.Any(z => z.Key == y.Assisting_Team_Member)).Select(x => x.Assisting_Team_Member).ToArray();
            // remove if any item not present in the current list
            foreach (var memberID in arrRemoveItems)
            {
                if (lstmembers.Count > 0)
                {
                    var assitMember = lstmembers.FirstOrDefault(x => x.Assisting_Team_Member == memberID);
                    lstmembers.Remove(assitMember);
                    _assistRepo.Entry(assitMember, EntityState.Deleted);
                }
            }

            // add all new members as new item.

            DraftMatters_AssistingTeamMembers objAssMembers = null;
            foreach (KeyValuePair<int, string> assistID in strIDs)
            {
                if (assistID.Key > 0 && !matter.DraftMatters_AssistingTeamMembers.Any(x => x.Assisting_Team_Member == assistID.Key))
                {
                    objAssMembers = new DraftMatters_AssistingTeamMembers();
                    objAssMembers.Assisting_Team_Member = assistID.Key;
                    objAssMembers.DraftMatter_ID = matter.ID;
                    lstmembers.Add(objAssMembers);
                    _assistRepo.Entry(objAssMembers, EntityState.Added);
                }
            }
            objAssMembers = null;
            _assistRepo.SaveChanges();
        }

        /// <summary>
        /// method to save matter
        /// </summary>
        /// <param name="matterVm"></param>
        /// <returns></returns>
        public int SaveMatter(MatterViewModel matterVm)
        {
            RE_EXECUTE_CODE:
            var result = 0;
            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions { IsolationLevel = IsolationLevel.Snapshot }))
            {
                try
                {
                    Matter_Reference matterRef = new Matter_Reference();
                    using (MatterRepository matterRepository = new MatterRepository())
                    {
                        DateTime? leadDate = null;
                        var matter = new Matter();
                        if (matterVm.ID > 0)
                        {
                            matter = matterRepository.GetById(matterVm.ID);
                        }
                        else
                        {
                            matter.Matter_Status_ID = Convert.ToInt16(MatterStatus.Active);
                        }


                        if (!string.IsNullOrEmpty(matterVm.Assisting_Team_Members_IDs) && matterVm.ID > 0)
                        {
                            // add or update matter assistmembers
                            AddOrUpdateMatterAssistMembers(matter, matterVm);
                        }

                        if (!string.IsNullOrEmpty(matterVm.Key_Work_Stream) && matterVm.ID > 0)
                        {
                            // add or update matter keyworkstreams.
                            AddOrUpdateMatter_KeyWorkStreams(matter, matterVm);
                        }
                        if (!string.IsNullOrEmpty(matterVm.MatterReportClassicationOptionList) && matterVm.ID > 0)
                        {
                            //add or update matter report classification options
                            AddOrUpdateMatterReportClassication_Options(matter, matterVm);
                        }

                        if (matterVm.Business_Unit_ID > 0)
                            matter.Business_Unit_ID = matterVm.Business_Unit_ID;
                                                
                        matter.Changed_Since_Last = matterVm.Changed_Since_Last;
                        matter.Client_Action = matterVm.Client_Action;
                        matter.Context = matterVm.Context != null ? matterVm.Context.Trim() : matterVm.Context;
                        matter.Created = matterVm.ID > 0 ? matterVm.Created : DateTime.Now;
                        matter.Created_By = matterVm.ID > 0 ? matterVm.Created_By : matterVm.UserName;
                        matter.Current_Next_Step_or_Procedural_Stage = matterVm.Current_Next_Step_or_Procedural_Stage != null ? matterVm.Current_Next_Step_or_Procedural_Stage.Trim() : matterVm.Current_Next_Step_or_Procedural_Stage;
                        matter.Impact_On_Group_BU = matterVm.Impact_On_Group_BU != null ? matterVm.Impact_On_Group_BU.Trim() : matterVm.Impact_On_Group_BU;
                        //matter.Last_Lawyer_Update_Date = matterVm.System == SystemTypeEnum.BusinessUnit.ToString() ? leadDate : ((matterVm.Lead_Lawyer != null ? matterVm.Lead_Lawyer.Contains(matterVm.FullName) : false || (matterVm.Assisting_Team_Members != null ? matterVm.Assisting_Team_Members.Contains(matterVm.FullName) : false)) ? DateTime.Now : (matterVm.ID > 0 ? matterVm.Last_Lawyer_Update_Date : leadDate));
                        if (matterVm.Last_Lawyer_Update_ID > 0)
                        {
                            matter.Last_Lawyer_Update_ID = ((matterVm.Lead_Lawyer_ID > 0 ? matterVm.Lead_Lawyer.Contains(matterVm.FullName) : false || (matterVm.Assisting_Team_Members != null ? matterVm.Assisting_Team_Members.Contains(matterVm.FullName) : false)) ? matterVm.Last_Lawyer_Update_ID : (matterVm.ID > 0 ? matterVm.Last_Lawyer_Update_ID : null));
                            matter.Last_Lawyer_Update_Date = matterVm.Lead_Lawyer.Equals(matterVm.FullName) ? DateTime.Now: matterVm.Last_Lawyer_Update_Date;
                        }
                        if (matterVm.Lead_Client_ID > 0)
                            matter.Lead_Client_ID = Convert.ToInt32(matterVm.Lead_Client_ID);
                        if (matterVm.Lead_Lawyer_ID > 0)
                            matter.Lead_Lawyer_ID = Convert.ToInt32(matterVm.Lead_Lawyer_ID);
                        matter.Matter_Description = matterVm.Matter_Description != null ? matterVm.Matter_Description.Trim() : matterVm.Matter_Description;
                        matter.Matter_Name = matterVm.Matter_Name.Trim();
                        //Todo-Check role should be Admin,GLS,SLL users only
                        matter.IsHighlyConfidential = matterVm.IsHighlyConfidential;
                        matter.LegalDisciplineId = matterVm.LegalDisciplineId;
                        matter.SubDisciplineId = matterVm.SubLegalDisciplineId;
                        matter.ApplicationReportTemplateId = matterVm.ApplicationReportTemplateId;
                        matter.MatterReportClassificationOptionId = matterVm.MatterReportClassificationOptionId;

                        matter.Matter_Reference = matterVm.ID > 0 ? matterVm.Matter_Reference : GetMatterReferenceNo(matterVm.Business_Unit_ID, matterVm.System == SystemTypes.GroupLegal.ToString() ? MatterReferenceEnum.GroupLegal.ToString() : MatterReferenceEnum.BusinessUnit.ToString(), ref matterRef);
                        if (matterVm.Matter_Status_ID > 0)
                            matter.Matter_Status_ID = matterVm.Matter_Status_ID;

                        matter.Modified = DateTime.Now;
                        matter.Modified_By = matterVm.ID > 0 ? matterVm.UserName : string.Empty;
                        matter.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks = matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks != null ? matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks.Trim() : matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks;
                        if (matterVm.OperationId > 0)
                            matter.Operation_ID = matterVm.OperationId;
                        matter.Recommended_Mitigation_Steps = matterVm.Recommended_Mitigation_Steps != null ? matterVm.Recommended_Mitigation_Steps.Trim() : matterVm.Recommended_Mitigation_Steps;
                        matter.Reportable = matterVm.ID > 0 ? matterVm.Reportable : CommonConstants.No;
                        if (matterVm.Country_ID > 0)
                            matter.CountryId = matterVm.Country_ID;
                        if (!string.IsNullOrEmpty(matterVm.System))
                            matter.SystemType_ID = matterVm.System == SystemTypes.BusinessUnit.ToString() ? (int)SystemTypes.BusinessUnit : (int)SystemTypes.GroupLegal;
                        else
                            matter.SystemType_ID = matterVm.SystemType_ID;
                        matter.ReportableCount = matterVm.ReportableCount;

                        if (matterVm.ID > 0 && matterVm.ReportableStatus == VarConstants.Reportable_SentforUpdate && matterVm.Lead_Lawyer.ToLower() == matterVm.FullName.ToLower())
                        {
                            matter.ReportableStatus = VarConstants.Reportable_Updated;
                            matter.DateReturned = DateTime.Now;
                        }
                        else
                        {
                            matter.ReportableStatus = matterVm.ReportableStatus;
                            matter.DateReturned = matterVm.DateReturned;
                        }

                        matter.DateSentForUpdate = matterVm.DateSentForUpdate;
                        matter.HODComments = matterVm.HODComments;

                        if (matterVm.SystemType_ID == (int)SystemTypes.BusinessUnit)
                        {
                            matter.SubDisciplineId = matter.ApplicationReportTemplateId = matter.MatterReportClassificationOptionId = null;
                        }

                        if (matterVm.ID > 0)
                            matterRepository.Entry(matter, EntityState.Modified);
                        else
                            matterRepository.Add(matter);

                        matterRepository.SaveChanges();

                        result = matterVm.ID > 0 ? matterVm.ID : matter.ID;
                        matterVm.Matter_Reference = matter.Matter_Reference;
                        if (matterVm.ID == 0 && !string.IsNullOrEmpty(matterVm.Assisting_Team_Members_IDs))
                        {
                            AddOrUpdateMatterAssistMembers(matter, matterVm);
                        }

                        if (matterVm.ID == 0 && !string.IsNullOrEmpty(matterVm.Key_Work_Stream))
                        {
                            AddOrUpdateMatter_KeyWorkStreams(matter, matterVm);
                        }

                        if (matterVm.ID == 0 && !string.IsNullOrEmpty(matterVm.MatterReportClassicationOptionList))
                        {
                            AddOrUpdateMatterReportClassication_Options(matter, matterVm);
                        }
                    }

                    //The case exists for only new matters.
                    //In case of update matter, email only sent to Admin.
                    if (matterVm.ID == 0)
                    {
                        using (MatterReferenceRepository matterReferenceRepository = new MatterReferenceRepository())
                        {
                            Matter_Reference matterReference = matterRef;
                            matterReference.NextNumber = matterRef.NextNumber + 1;
                            matterReference.Year = DateTime.Now.Year;
                            matterReferenceRepository.Entry(matterReference, EntityState.Modified);
                            matterReferenceRepository.SaveChanges();
                        }
                        int dLeadId = 0;

                    }

                    matterVm.Lead_Lawyer = matterVm.System == SystemTypes.BusinessUnit.ToString() ? matterVm.Lead_Client : matterVm.Lead_Lawyer;
                    matterVm.System = VarConstants.System;

                    //send mail on add matter JIRA-729
                    SendMatterEmail(matterVm);

                    scope.Complete();
                    return result;
                }
                catch (SmtpFailedRecipientException ex) // JIRA - EXICHM-371, reexecute the code when mail sending fails.
                {
                    SmtpStatusCode statusCode = ex.StatusCode;
                    if (statusCode == SmtpStatusCode.MailboxBusy || statusCode == SmtpStatusCode.MailboxUnavailable || statusCode == SmtpStatusCode.TransactionFailed)
                    {
                        goto RE_EXECUTE_CODE;
                    }
                    else
                    {
                        return result;
                    }
                }
                catch (SqlException ex) // JIRA - EXICHM-371, , reexecute the code when PK violation found during multiple concurrent requests.
                {
                    if (ex.Number == 2627)
                    {
                        if (ex.Message.Contains("Unique"))
                        {
                            goto RE_EXECUTE_CODE;
                        }
                        else
                        {
                            return result;
                        }
                    }
                    else
                    {
                        return result;
                    }
                }
            }
        }


        /// <summary>
        /// method to save matter as Draft
        /// </summary>
        /// <param name="matterVm"></param>
        /// <returns></returns>
        public int SaveDraftMatter(MatterViewModel matterVm, bool isFinalized)
        {
            RE_EXECUTE_CODE:
            var result = 0;
            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required, new TransactionOptions { IsolationLevel = IsolationLevel.Snapshot }))
            {
                try
                {
                    Matter_Reference matterRef = new Matter_Reference();
                    using (DraftMattersRepository draftmatterRepository = new DraftMattersRepository())
                    {
                        DateTime? leadDate = null;
                        var draftmatter = new DraftsMatter();
                        if (matterVm.ID > 0)
                        {
                            draftmatter = draftmatterRepository.GetById(matterVm.ID);
                        }
                        else
                        {
                            draftmatter.Matter_Status_ID = Convert.ToInt16(MatterStatus.Active);
                        }
                        if (!string.IsNullOrEmpty(matterVm.Assisting_Team_Members_IDs) && matterVm.ID > 0)
                        {
                            // add or update matter assistmembers
                            AddOrUpdateDraftMatterAssistMembers(draftmatter, matterVm);
                        }
                        if (!string.IsNullOrEmpty(matterVm.Key_Work_Stream) && matterVm.ID > 0)
                        {
                            // add or update matter keyworkstreams.
                            AddOrUpdateDraftMatter_KeyWorkStreams(draftmatter, matterVm);
                        }
                        if (!string.IsNullOrEmpty(matterVm.MatterReportClassicationOptionList) && matterVm.ID > 0)
                        {
                            //add or update matter report classification options
                            AddOrUpdateDraftMatterReportClassication_Options(draftmatter, matterVm);
                        }

                        if (matterVm.Business_Unit_ID > 0)
                            draftmatter.Business_Unit_ID = matterVm.Business_Unit_ID;

                        draftmatter.Changed_Since_Last = matterVm.Changed_Since_Last;
                        draftmatter.Client_Action = matterVm.Client_Action;
                        draftmatter.Context = matterVm.Context != null ? matterVm.Context.Trim() : matterVm.Context;
                        draftmatter.Created = matterVm.ID > 0 ? matterVm.Created : DateTime.Now;
                        draftmatter.Created_By = matterVm.ID > 0 ? matterVm.Created_By : matterVm.UserName;
                        draftmatter.Current_Next_Step_or_Procedural_Stage = matterVm.Current_Next_Step_or_Procedural_Stage != null ? matterVm.Current_Next_Step_or_Procedural_Stage.Trim() : matterVm.Current_Next_Step_or_Procedural_Stage;
                        draftmatter.Impact_On_Group_BU = matterVm.Impact_On_Group_BU != null ? matterVm.Impact_On_Group_BU.Trim() : matterVm.Impact_On_Group_BU;
                        draftmatter.Last_Lawyer_Update_Date = matterVm.System == SystemTypes.BusinessUnit.ToString() ? leadDate : ((matterVm.Lead_Lawyer != null ? matterVm.Lead_Lawyer.Contains(matterVm.FullName) : false || (matterVm.Assisting_Team_Members != null ? matterVm.Assisting_Team_Members.Contains(matterVm.FullName) : false)) ? DateTime.Now : (matterVm.ID > 0 ? matterVm.Last_Lawyer_Update_Date : leadDate));
                        if (matterVm.Last_Lawyer_Update_ID > 0)
                            draftmatter.Last_Lawyer_Update_ID = ((matterVm.Lead_Lawyer_ID > 0 ? matterVm.Lead_Lawyer.Contains(matterVm.FullName) : false || (matterVm.Assisting_Team_Members != null ? matterVm.Assisting_Team_Members.Contains(matterVm.FullName) : false)) ? matterVm.Last_Lawyer_Update_ID : (matterVm.ID > 0 ? matterVm.Last_Lawyer_Update_ID : null));
                        if (matterVm.Lead_Client_ID > 0)
                            draftmatter.Lead_Client_ID = Convert.ToInt32(matterVm.Lead_Client_ID);
                        if (matterVm.Lead_Lawyer_ID > 0)
                            draftmatter.Lead_Lawyer_ID = Convert.ToInt32(matterVm.Lead_Lawyer_ID);
                        draftmatter.Matter_Description = matterVm.Matter_Description != null ? matterVm.Matter_Description.Trim() : matterVm.Matter_Description;
                        draftmatter.Matter_Name = matterVm.Matter_Name != null ? matterVm.Matter_Name.Trim() : string.Empty;
                        //Todo-Check role should be Admin,GLS,SLL users only
                        draftmatter.IsHighlyConfidential = matterVm.IsHighlyConfidential;
                        if (matterVm.LegalDisciplineId == 0)
                        {
                            draftmatter.LegalDisciplineId = null;
                        }
                        else
                        {
                            draftmatter.LegalDisciplineId = matterVm.LegalDisciplineId;
                        }
                        if (matterVm.SubLegalDisciplineId == 0)
                        {
                            draftmatter.SubDisciplineId = null;
                        }
                        else
                        {
                            draftmatter.SubDisciplineId = matterVm.SubLegalDisciplineId;
                        }
                        if (matterVm.ApplicationReportTemplateId > 0)
                            draftmatter.ApplicationReportTemplateId = matterVm.ApplicationReportTemplateId;
                        if (matterVm.MatterReportClassificationOptionId > 0)
                            draftmatter.MatterReportClassificationOptionId = matterVm.MatterReportClassificationOptionId;

                        //draftmatter.Matter_Reference = matterVm.ID > 0 ? matterVm.Matter_Reference : GetMatterReferenceNo(matterVm.Business_Unit_ID, matterVm.System == SystemTypes.GroupLegal.ToString() ? MatterReferenceEnum.GroupLegal.ToString() : MatterReferenceEnum.BusinessUnit.ToString(), ref matterRef);
                        draftmatter.Matter_Reference = "2";
                        if (matterVm.Matter_Status_ID > 0)
                            draftmatter.Matter_Status_ID = matterVm.Matter_Status_ID;

                        draftmatter.Modified = DateTime.Now;
                        draftmatter.Modified_By = matterVm.UserName;
                        draftmatter.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks = matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks != null ? matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks.Trim() : matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks;
                        if (matterVm.OperationId > 0)
                            draftmatter.Operation_ID = matterVm.OperationId;
                        draftmatter.Recommended_Mitigation_Steps = matterVm.Recommended_Mitigation_Steps != null ? matterVm.Recommended_Mitigation_Steps.Trim() : matterVm.Recommended_Mitigation_Steps;

                        draftmatter.Reportable = matterVm.ID > 0 ? matterVm.Reportable : CommonConstants.No;
                        if (matterVm.Country_ID > 0)
                            draftmatter.CountryId = matterVm.Country_ID;
                        if (!string.IsNullOrEmpty(matterVm.System))
                            draftmatter.SystemType_ID = matterVm.System == SystemTypes.BusinessUnit.ToString() ? (int)SystemTypes.BusinessUnit : (int)SystemTypes.GroupLegal;
                        else
                            draftmatter.SystemType_ID = matterVm.SystemType_ID;
                        draftmatter.ReportableCount = matterVm.ReportableCount;

                        if (matterVm.ID > 0 && matterVm.ReportableStatus == VarConstants.Reportable_SentforUpdate && matterVm.Lead_Lawyer.ToLower() == matterVm.FullName.ToLower())
                        {
                            draftmatter.ReportableStatus = VarConstants.Reportable_Updated;
                            draftmatter.DateReturned = DateTime.Now;
                        }
                        else
                        {
                            draftmatter.ReportableStatus = matterVm.ReportableStatus;
                            draftmatter.DateReturned = matterVm.DateReturned;
                        }

                        draftmatter.DateSentForUpdate = matterVm.DateSentForUpdate;
                        draftmatter.HODComments = matterVm.HODComments;

                        if (matterVm.SystemType_ID == (int)SystemTypes.BusinessUnit)
                        {
                            draftmatter.SubDisciplineId = draftmatter.ApplicationReportTemplateId = draftmatter.MatterReportClassificationOptionId = null;
                        }
                        draftmatter.isFinalized = isFinalized;

                        if (matterVm.ID > 0)
                            draftmatterRepository.Entry(draftmatter, EntityState.Modified);
                        else
                            draftmatterRepository.Add(draftmatter);

                        draftmatterRepository.SaveChanges();

                        result = matterVm.ID > 0 ? matterVm.ID : draftmatter.ID;
                        matterVm.Matter_Reference = draftmatter.Matter_Reference;
                        if (matterVm.ID == 0 && !string.IsNullOrEmpty(matterVm.Assisting_Team_Members_IDs))
                        {
                            AddOrUpdateDraftMatterAssistMembers(draftmatter, matterVm);
                        }
                        if (matterVm.ID == 0 && !string.IsNullOrEmpty(matterVm.Key_Work_Stream))
                        {
                            AddOrUpdateDraftMatter_KeyWorkStreams(draftmatter, matterVm);
                        }
                        if (matterVm.ID == 0 && !string.IsNullOrEmpty(matterVm.MatterReportClassicationOptionList))
                        {
                            AddOrUpdateDraftMatterReportClassication_Options(draftmatter, matterVm);
                        }

                    }



                    scope.Complete();
                    return result;
                }
                catch (SmtpFailedRecipientException ex) // JIRA - EXICHM-371, reexecute the code when mail sending fails.
                {
                    SmtpStatusCode statusCode = ex.StatusCode;
                    if (statusCode == SmtpStatusCode.MailboxBusy || statusCode == SmtpStatusCode.MailboxUnavailable || statusCode == SmtpStatusCode.TransactionFailed)
                    {
                        goto RE_EXECUTE_CODE;
                    }
                    else
                    {
                        return result;
                    }
                }
                catch (SqlException ex) // JIRA - EXICHM-371, , reexecute the code when PK violation found during multiple concurrent requests.
                {
                    if (ex.Number == 2627)
                    {
                        if (ex.Message.Contains("Unique"))
                        {
                            goto RE_EXECUTE_CODE;
                        }
                        else
                        {
                            return result;
                        }
                    }
                    else
                    {
                        return result;
                    }
                }
            }
        }

        /// <summary>
        /// method to get matter details by Id
        /// </summary>
        /// <param name="matterId"></param>
        /// <returns></returns>
        public MatterViewModel GetMatterById(int matterId, int? userId = 0)
        {
            var matterVm = new MatterViewModel();
            using (MatterRepository matterRepository = new MatterRepository())
            {
                var matterDetails = matterRepository.GetQuery().Where(x => x.ID == matterId);
                if (matterDetails != null && matterDetails.Count() > 0)
                {
                    var matter = matterDetails.FirstOrDefault();
                    matterVm.Assisting_Team_Members = string.Join("; ", matter.Matters_AssistingTeamMembers.Select(x => x.PeoplePicker.Full_Name.ToString()).ToArray());
                    matterVm.Assisting_Team_Members_IDs = JsonConvert.SerializeObject(matter.Matters_AssistingTeamMembers.Select(x => new KeyValuePair<int, string>(x.PeoplePicker.ID, x.PeoplePicker.Full_Name)).ToList());
                    matterVm.Business_Unit_ID = matter.Business_Units.ID;
                    matterVm.Business_Unit = matter.Business_Units.Business_Unit1;
                    matterVm.Changed_Since_Last = matter.Changed_Since_Last;
                    matterVm.Client_Action = matter.Client_Action;
                    matterVm.Context = matter.Context;
                    matterVm.Created = matter.Created;
                    matterVm.Created_By = matter.Created_By;
                    matterVm.Current_Next_Step_or_Procedural_Stage = matter.Current_Next_Step_or_Procedural_Stage;
                    matterVm.Impact_On_Group_BU = matter.Impact_On_Group_BU;
                    matterVm.Last_Lawyer_Update_Date = matter.Last_Lawyer_Update_Date;
                    matterVm.Last_Lawyer_Update_Name = matter.User != null ? matter.User.FullName : string.Empty;
                    matterVm.Last_Lawyer_Update_ID = userId > 0 && matter.Lead_Lawyer_ID > 0 && userId == matter.Lead_Lawyer_ID ? matter.Lead_Lawyer_ID : Convert.ToInt32(matter.Last_Lawyer_Update_ID);
                    matterVm.Lead_Client_ID = Convert.ToInt32(matter.Lead_Client_ID ?? 0);
                    matterVm.Lead_Lawyer_ID = Convert.ToInt32(matter.Lead_Lawyer_ID ?? 0);
                    matterVm.Lead_Lawyer = matter.User != null ? matter.User.FullName : string.Empty;
                    matterVm.Lead_Client = matter.PeoplePicker != null ? matter.PeoplePicker.Full_Name : string.Empty;
                    matterVm.Matter_Description = matter.Matter_Description;
                    //matterVm.MatterType_ID = Convert.ToInt32(matter.MatterType_ID ?? 0);
                    matterVm.Matter_Name = matter.Matter_Name;
                    matterVm.IsHighlyConfidential = matter.IsHighlyConfidential != null ? (bool)matter.IsHighlyConfidential : false;
                    matterVm.LegalDisciplineId = matter.LegalDisciplineId != null && matter.LegalDisciplineId > 0 ? (int)matter.LegalDisciplineId : 0;
                    matterVm.SubLegalDisciplineId = matter.SubDisciplineId != null && matter.SubDisciplineId > 0 ? Convert.ToInt32(matter.SubDisciplineId) : 0;
                    matterVm.ApplicationReportTemplateId = matter.ApplicationReportTemplateId != null && matter.ApplicationReportTemplateId > 0 ? (int)matter.ApplicationReportTemplateId : 0;
                    matterVm.MatterReportClassificationOptionId = matter.MatterReportClassificationOptionId != null && matter.MatterReportClassificationOptionId > 0 ? (int)matter.MatterReportClassificationOptionId : 0;
                    matterVm.Matter_Reference = matter.Matter_Reference;
                    matterVm.Matter_Status = matter.Matter_Status != null ? matter.Matter_Status.Matter_Status1 : string.Empty;
                    matterVm.Matter_Status_ID = Convert.ToInt16(matter.Matter_Status_ID ?? 0);
                    matterVm.Modified = matter.Modified;
                    matterVm.Modified_By = matter.Modified_By;
                    matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks = matter.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks;
                    //Ashish P. 22-Nov-2017 [Replaced Operation with OperationId]
                    matterVm.OperationId = Convert.ToInt32(matter.Operation_ID);
                    matterVm.Operation = (matter.Operation != null) ? matter.Operation.Operation1 : string.Empty;
                    matterVm.Recommended_Mitigation_Steps = matter.Recommended_Mitigation_Steps;
                    if (matter.LegalDiscipline != null)
                    {

                        matterVm.LegalDiscipline = matter.LegalDiscipline.Name;

                        matterVm.SubDiscipline = matter.SubDiscipline != null ? matter.SubDiscipline.Name : string.Empty;
                    }
                    matterVm.Report_Classification_ID = Convert.ToInt32(matter.LegalDisciplineId ?? 0);
                    matterVm.Reportable = matter.Reportable;
                    matterVm.Country = matter.Country != null ? matter.Country.Country1 : string.Empty;
                    matterVm.Country_ID = matter.CountryId != null ? Convert.ToInt32(matter.CountryId) : 0;
                    matterVm.System = matter.SystemType.SystemTypeName;
                    matterVm.SystemType_ID = matter.SystemType_ID;
                    matterVm.ID = matter.ID;
                    matterVm.MatterType = matter.LegalDiscipline != null ? matter.LegalDiscipline.Name : string.Empty;
                    matterVm.ReportableCount = matter.ReportableCount;
                    matterVm.ReportableStatus = matter.ReportableStatus;
                    matterVm.DateSentForUpdate = matter.DateSentForUpdate;
                    matterVm.DateReturned = matter.DateReturned;
                    matterVm.HODComments = matter.HODComments;
                    matterVm.Key_Work_Stream = string.Join(";", matter.Matters_KeyWorkStream.Select(x => x.KeyWorkStream.Key_Work_Stream.ToString()));
                    matterVm.KeyWorkStreamIDs = matter.Matters_KeyWorkStream.Select(x => x.KeyWorkStream_ID).ToList();
                }
            }
            return matterVm;
        }

        /// <summary>
        /// Send email on add matter
        /// </summary>
        /// <param name="matterVm"></param>
        public void SendMatterEmail(MatterViewModel matterVm)
        {
            var emailManager = new EmailManager();
            var emailDetails = new Exigent.Email.Configuration.EmailDetails();

            if (matterVm.ID == 0)   //Case of new email
            {
                //Get email for Discipline Lead.
                var disciplineLead = PeoplePickerManager.GetUserEmailAddress(matterVm.EmailTo);

                //Get emails for Lead Lawyer; Assisting Lawyer; Admin
                var leadLawyerEmail = PeoplePickerManager.GetUserEmailAddress(matterVm.Lead_Lawyer);
                var assistingLawyersEmails = PeoplePickerManager.GetUsersEmailAddress(matterVm.Assisting_Team_Members, ";");
                assistingLawyersEmails = string.IsNullOrEmpty(assistingLawyersEmails) ? assistingLawyersEmails : ";" + assistingLawyersEmails;

                emailDetails.EmailTo = leadLawyerEmail;    //Lead Lawyer
                emailDetails.EmailCC = SystemDetailsViewModel.Team + assistingLawyersEmails;    //Assisting Lawyer; Admin
                emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.Matter, (int)EmailCategoryEnum.CreateMatter, emailDetails, matterVm);
            }

        }


        #region Reportable Matters & Respective Features

        /// <summary>
        /// Send Matters To Lead Lawyer for Update.
        /// </summary>
        /// <param name="matterIDs"></param>
        /// <returns></returns>
        public bool SendMattersToLeadLawyerUpdate(string[] matterIDs)
        {
            var statusValues = new string[] {
                EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.Active.ToString()),
                EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.OpenForBilling.ToString())
            };

            using (MatterRepository rep = new MatterRepository())
            {
                var rec = rep.Find(m => statusValues.Contains(m.Matter_Status.Matter_Status1)
                                && m.SystemType.SystemTypeName != SystemTypes.BusinessUnit.ToString()
                                && matterIDs.Contains(m.ID.ToString())
                                && m.ReportableStatus != VarConstants.Reportable_SentforUpdate);

                if (rec.Count() > 0)
                {
                    //Updating selected matters as reportable.
                    rec.ForEach(a =>
                    {
                        a.DateSentForUpdate = DateTime.Now;
                        a.DateReturned = null;
                        a.Reportable = CommonConstants.No;
                        a.ReportableStatus = VarConstants.Reportable_SentforUpdate;
                        a.DateSendForReporting = null;
                    });

                    rep.SaveChanges();
                }
                else
                    return false;
            }

            SendEmailReportableMattersForUpdate(matterIDs);

            return true;
        }

        /// <summary>
        /// Send Email Reportable Matters For Update to lead lawyer.
        /// </summary>
        /// <param name="matterIDs"></param>
        private void SendEmailReportableMattersForUpdate(string[] matterIDs)
        {
            using (MatterRepository rep = new MatterRepository())
            {
                var mattersVM = rep.GetQuery().Where(m => matterIDs.Contains(m.ID.ToString())).Select(m => new MatterViewModel
                {
                    ID = m.ID,
                    Matter_Name = m.Matter_Name,
                    Matter_Reference = m.Matter_Reference,
                    Matter_Description = m.Matter_Description,
                    Business_Unit = m.Business_Units.Business_Unit1,
                    System = m.SystemType.SystemTypeName,
                    Matter_Status = m.Matter_Status.Matter_Status1,
                    Lead_Lawyer = (m.SystemType.SystemTypeName == SystemTypes.BusinessUnit.ToString()) ? m.PeoplePicker.Full_Name : m.User.FullName
                }).ToList();

                var emailDetails = new Exigent.Email.Configuration.EmailDetails();
                var emailManager = new EmailManager();

                mattersVM.ForEach(a =>
                {
                    a.EmailURL = SystemDetailsViewModel.URL
                                + "/Section/Matter/Manage?q="
                                + Exigent.Common.Helpers.Crypto.Encrypt(new Dictionary<string, string> { { "id", a.ID.ToString() } });

                    a.System = VarConstants.System;

                    emailDetails.EmailTo = PeoplePickerManager.GetUserEmailAddress(a.Lead_Lawyer);
                    emailDetails.EmailCC = SystemDetailsViewModel.Team;
                    emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.ReportableMatter_SentForUpdate, (int)EmailCategoryEnum.ReportableMatter_SentForUpdate, emailDetails, a, true, false);
                });
            }
        }

        /// <summary>
        /// Send the matters for HOD's approval before send them for reporting.
        /// </summary>
        /// <param name="matterIDs"></param>
        /// <returns>Boolean true/false</returns>
        public bool SendMattersToHODApproval(string[] matterIDs)
        {
            var statusValues = new string[] {
                EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.Active.ToString()),
                EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.OpenForBilling.ToString())
            };

            using (MatterRepository rep = new MatterRepository())
            {
                var rec = rep.Find(m => statusValues.Contains(m.Matter_Status.Matter_Status1)
                            && m.SystemType.SystemTypeName != SystemTypes.BusinessUnit.ToString()
                            && m.ReportableStatus != VarConstants.Reportable_PendingApproval    //== VarConstants.Reportable_Updated
                            && matterIDs.Contains(m.ID.ToString()));

                if (rec.Count() > 0)
                {
                    //Updating selected matters as pending for approval.
                    rec.ForEach(a =>
                    {
                        a.ReportableStatus = VarConstants.Reportable_PendingApproval;
                        a.Reportable = CommonConstants.No;
                    });

                    rep.SaveChanges();
                }
                else
                    return false;
            }

            SendEmailReportableMattersForApproval(matterIDs);

            return true;
        }

        /// <summary>
        /// Send Email Reportable Matters For Approval to HOD User.
        /// </summary>
        /// <param name="matterIDs"></param>
        private void SendEmailReportableMattersForApproval(string[] matterIDs)
        {
            var hodUserEmail = string.Empty;
            using (Exigent.EF.Data.Repository.UserRepository rep = new EF.Data.Repository.UserRepository())
            {
                hodUserEmail = rep.GetQuery().Where(m => m.UserType.Name == UserTypes.GroupLegalSuper.ToString()).Select(m => m.Email).FirstOrDefault();
            }

            if (string.IsNullOrEmpty(hodUserEmail))
            {
                return;
            }

            using (MatterRepository rep = new MatterRepository())
            {
                var mattersVM = rep.GetQuery().Where(m => matterIDs.Contains(m.ID.ToString())).Select(m => new MatterViewModel
                {
                    ID = m.ID,
                    Matter_Name = m.Matter_Name,
                    Matter_Reference = m.Matter_Reference,
                    Matter_Description = m.Matter_Description,
                    Business_Unit = m.Business_Units.Business_Unit1,
                    System = m.SystemType.SystemTypeName,
                    Matter_Status = m.Matter_Status.Matter_Status1,
                    Lead_Lawyer = (m.SystemType.SystemTypeName == SystemTypes.BusinessUnit.ToString()) ? m.PeoplePicker.Full_Name : m.User.FullName
                }).ToList();

                var emailDetails = new Exigent.Email.Configuration.EmailDetails();
                var emailManager = new EmailManager();

                mattersVM.ForEach(a =>
                {
                    a.EmailURL = SystemDetailsViewModel.URL
                                + "/Main/ViewMatter?q="
                                + Exigent.Common.Helpers.Crypto.Encrypt(new Dictionary<string, string> { { "id", a.ID.ToString() } });

                    a.System = VarConstants.System;

                    emailDetails.EmailTo = hodUserEmail;
                    emailDetails.EmailCC = SystemDetailsViewModel.Team;
                    emailManager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.ReportableMatter_SentForApproval, (int)EmailCategoryEnum.ReportableMatter_SentForApproval, emailDetails, a, true, false);
                });
            }
        }

        /// <summary>
        /// Matter Status: approved or rejected by HOD User for reporting.
        /// </summary>
        /// <param name="matterId"></param>
        /// <param name="reportingStatus"></param>
        /// <param name="comments"></param>
        /// <returns></returns>
        public bool UpdateMatterReportingStatusByHOD(int matterId, string reportingStatus, string comments)
        {
            var statusValues = new string[] {
                EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.Active.ToString()),
                EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.OpenForBilling.ToString())
            };

            using (MatterRepository rep = new MatterRepository())
            {
                var rec = rep.GetQuery().Where(m => statusValues.Contains(m.Matter_Status.Matter_Status1)
                            && m.SystemType.SystemTypeName != SystemTypes.BusinessUnit.ToString()
                            && m.ReportableStatus == VarConstants.Reportable_PendingApproval
                            && m.ID == matterId).FirstOrDefault();

                if (rec != null)
                {
                    //Updating selected matters reporting status as Approved or Rejected.
                    rec.ReportableStatus = reportingStatus;     //Approved or Rejected.
                    rec.HODComments = comments;
                    rep.SaveChanges();
                }
                else
                    return false;
            }

            return true;
        }

        /// <summary>
        /// Updated selected matter as reportable.
        /// </summary>
        /// <param name="matterIDs"></param>
        /// <param name="model"></param>
        /// <returns></returns>
        public bool UpdateReportableMatters(string[] matterIDs, MatterListViewModel model = null)
        {
            var statusValues = new string[] {
                EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.Active.ToString()),
                EnumHelper<MatterStatus>.GetEnumDescription(MatterStatus.OpenForBilling.ToString())
            };

            bool result = true;

            using (MatterRepository rep = new MatterRepository())
            {
                var allMatters = rep.GetAll();
                var rec = rep.Find(m => statusValues.Contains(m.Matter_Status.Matter_Status1)
                    && m.SystemType.SystemTypeName != SystemTypes.BusinessUnit.ToString());

                //Applying custom filters.
                if (model.FilterByBusinessUnit != null && model.FilterByBusinessUnit.Length > 0)
                    rec = rec.Where(m => model.FilterByBusinessUnit.Contains(m.Business_Unit_ID.ToString()));

                if (!string.IsNullOrEmpty(model.FilterByMatterStatus))
                    rec = rec.Where(m => m.Matter_Status_ID.ToString() == model.FilterByMatterStatus);

                if (model.FilterByCountry != null && model.FilterByCountry.Length > 0)
                    rec = rec.Where(m => model.FilterByCountry.Contains(m.CountryId.ToString()));

                if (model.FilterByOffice != null && model.FilterByOffice.Length > 0)
                    rec = rec.Where(m => model.FilterByOffice.Contains(m.User!=null?m.User.OfficeId.ToString():string.Empty));

                if (model.FilterByOperation != null && model.FilterByOperation.Length > 0)
                    rec = rec.Where(m => model.FilterByOperation.Contains(m.Operation_ID.ToString()));

                if (model.FilterByLegalDiscipline != null && model.FilterByLegalDiscipline.Length > 0)
                    rec = rec.Where(m => model.FilterByLegalDiscipline.Contains(m.LegalDisciplineId.ToString()));

                if (model.FilterBySubDiscipline != null && model.FilterBySubDiscipline.Length > 0)
                    rec = rec.Where(m => model.FilterBySubDiscipline.Contains(m.SubDisciplineId.ToString()));

                if (model.FilterByReportTemplate != null && model.FilterByReportTemplate.Length > 0)
                    rec = rec.Where(m => model.FilterByReportTemplate.Contains(m.ApplicationReportTemplateId.ToString()));

                if (model.FilterByMatterReportClassification != null && model.FilterByMatterReportClassification.Length > 0)
                    rec = rec.Where(m => model.FilterByMatterReportClassification.Contains(m.MatterReportClassificationOptionId.ToString()));

                if (model.FilterByLeadLawyer != null && model.FilterByLeadLawyer.Length > 0)
                    rec = rec.Where(m => model.FilterByLeadLawyer.Contains(m.Lead_Lawyer_ID.ToString()));

                //Updating selected matters as reportable.
                var recYes = rec.Where(m => matterIDs.Contains(m.ID.ToString()));
                if (recYes.Count() > 0)
                {
                    recYes.ForEach(a =>
                    {
                        a.Reportable = CommonConstants.Yes;
                        a.DateSendForReporting = DateTime.Now;

                        if (a.ReportableCount.HasValue)
                            a.ReportableCount = a.ReportableCount + 1;
                        else
                            a.ReportableCount = 1;
                    });

                    result = true;
                }
                else
                    result = false;

                //Updating rest of matters as not-reportable.
                //update all record & set Reportable as No: changed on 14-9-17(Anurag)
                allMatters.Where(m => !matterIDs.Contains(m.ID.ToString())).ForEach(a =>
                {
                    if (a.Reportable == CommonConstants.Yes)
                        a.Reportable = CommonConstants.No;
                    a.DateSendForReporting = null;
                });

                rep.SaveChanges();
            }

            return result;
        }

        public static void GetReportableMatters(MatterListViewModel model)
        {
            List<SqlParameter> lstParams = new List<SqlParameter>();

            var ds = CommonRepository.ExecuteSP_Exigent(@"GetCountOfReportableMatters", lstParams);


            if (ds != null && ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                    model.FilterByBusinessUnit = ds.Tables[0].Select().Select(m => m[0].ToString()).ToArray();

                if (ds.Tables[1].Rows.Count > 0)
                    model.FilterByReportClassification = ds.Tables[1].Select().Select(m => m[0].ToString()).ToArray();

                if (ds.Tables[2].Rows.Count > 0)
                    model.FilterByReportClassificationCategory = ds.Tables[2].Select().Select(m => m[0].ToString()).ToArray();

                if (ds.Tables[3].Rows.Count == 1)
                    model.FilterByMatterStatus = ds.Tables[3].Rows[0][0].ToString();

                if (ds.Tables[4].Rows.Count > 0)
                    model.FilterByCountry = ds.Tables[4].Select().Select(m => m[0].ToString()).ToArray();

                if (ds.Tables[5].Rows.Count > 0)
                    model.FilterByOffice = ds.Tables[5].Select().Select(m => m[0].ToString()).ToArray();

                if (ds.Tables[6].Rows.Count > 0)
                    model.FilterByOperation = ds.Tables[6].Select().Select(m => m[0].ToString()).ToArray();

                if (ds.Tables[7].Rows.Count > 0)
                    model.FilterByLegalDiscipline = ds.Tables[7].Select().Select(m => m[0].ToString()).ToArray();

                if (ds.Tables[8].Rows.Count > 0)
                    model.FilterBySubDiscipline = ds.Tables[8].Select().Select(m => m[0].ToString()).ToArray();

                if (ds.Tables[9].Rows.Count > 0)
                    model.FilterByReportTemplate = ds.Tables[9].Select().Select(m => m[0].ToString()).ToArray();

                if (ds.Tables[10].Rows.Count > 0)
                    model.FilterByMatterReportClassification = ds.Tables[10].Select().Select(m => m[0].ToString()).ToArray();
            }
        }

        #endregion

        /// <summary>
        /// method to validate invoice status to make matter closed
        /// </summary>
        /// <param name="matterRef"></param>
        /// <returns></returns>
        public bool GetMatterInvoiceStatus(string matterRef)
        {
            var result = true;
            using (InvoiceRepository invoiceRepository = new InvoiceRepository())
            {
                var pendingInv = invoiceRepository.Find(x => x.Matter.Matter_Reference == matterRef && x.Invoice_Status != InvoiceStatus.Paid.ToString() && x.Invoice_Status != InvoiceStatus.Credited.ToString()).ToList();
                result = pendingInv.Count() > 0 ? false : true;
            }
            return result;
        }

        public MatterViewModel GetMatterById(string id)
        {
            throw new NotImplementedException();
        }

        public static string GetMatterHistory(int id, string matterRef)
        {
            using (var repo = new VersionControlMatterRepository())
            {
                if (id == (int)MatterDescType.Context)
                    return repo.Find(x => x.Matter.Matter_Reference == matterRef).OrderByDescending(x => x.ID).Select(y => y.Context).FirstOrDefault();
                else if (id == (int)MatterDescType.ClientAction)
                    return repo.Find(x => x.Matter.Matter_Reference == matterRef).OrderByDescending(x => x.ID).Select(y => y.Client_Action).FirstOrDefault();
                else if (id == (int)MatterDescType.ImpactGroup)
                    return repo.Find(x => x.Matter.Matter_Reference == matterRef).OrderByDescending(x => x.ID).Select(y => y.Impact_On_Group_BU).FirstOrDefault();
                else if (id == (int)MatterDescType.MatterDescription)
                    return repo.Find(x => x.Matter.Matter_Reference == matterRef).OrderByDescending(x => x.ID).Select(y => y.Matter_Description).FirstOrDefault();
                else if (id == (int)MatterDescType.NatureIdentified)
                    return repo.Find(x => x.Matter.Matter_Reference == matterRef).OrderByDescending(x => x.ID).Select(y => y.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks).FirstOrDefault();
                else if (id == (int)MatterDescType.ProceduralStage)
                    return repo.Find(x => x.Matter.Matter_Reference == matterRef).OrderByDescending(x => x.ID).Select(y => y.Current_Next_Step_or_Procedural_Stage).FirstOrDefault();
                else
                    return repo.Find(x => x.Matter.Matter_Reference == matterRef).OrderByDescending(x => x.ID).Select(y => y.Recommended_Mitigation_Steps).FirstOrDefault();
            }
        }

        #region TimeRecording
        /// <summary>
        /// Save time record per matter in Time_recording Table
        /// </summary>
        /// <param name="matterVM"></param>
        /// <param name="timeRecordingVM"></param>
        /// <returns></returns>
        public int SaveTimeRecord(MatterViewModel matterVM, TimeRecordingViewModel timeRecordingVM)
        {
            int result = 0;
            using (TimeRecordingRepository timeRecordingRepository = new TimeRecordingRepository())
            {
                Time_Recording timeRecord = new Time_Recording();

                timeRecord.LeadLawyer_ID = timeRecordingVM.Lead_Lawyer_ID > 0?timeRecordingVM.Lead_Lawyer_ID:matterVM.Lead_Lawyer_ID;
                timeRecord.Date = timeRecordingVM.Date;
                timeRecord.Hours = timeRecordingVM.Hours;
                timeRecord.Created = DateTime.Now;
                timeRecord.Created_By = timeRecordingVM.Created_By;
                timeRecord.Matter_ID = timeRecordingVM.Matter_ID;
                timeRecordingRepository.Add(timeRecord);
                timeRecordingRepository.SaveChanges();
                result = 1;
            }
            if (matterVM.ID > 0)
            {
                result = SaveMatter(matterVM);
            }
            return result;
        }

        #endregion

        #region HOD
        public static string[] GetHODTop10MattersList(int Country)
        {
            string hodtop10mattersjsondata = string.Empty;
            string hodVendorsjsondata = string.Empty;
            string[] jsondata;

            SqlParameter CountryId = new SqlParameter { ParameterName = "@CountryId", DbType = System.Data.DbType.Int32, Value = Country };
            System.Data.DataSet ds = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.GetHODTop10Matters, new SqlParameter[] { CountryId });
            if (ds != null && ds.Tables.Count > 0)
            {
                System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                List<Dictionary<string, object>> rows;
                Dictionary<string, object> row;
                // fill matter data
                rows = new List<Dictionary<string, object>>();
                foreach (System.Data.DataRow dr in ds.Tables[0].Rows)
                {
                    row = new Dictionary<string, object>();
                    foreach (System.Data.DataColumn col in ds.Tables[0].Columns)
                    {
                        row.Add(col.ColumnName, dr[col]);
                    }
                    rows.Add(row);
                }
                hodtop10mattersjsondata = serializer.Serialize(rows);
                rows = null;

                // fill vendor data
                if (ds.Tables.Count > 1)
                {
                    rows = new List<Dictionary<string, object>>();
                    foreach (System.Data.DataRow dr in ds.Tables[1].Rows)
                    {
                        row = new Dictionary<string, object>();
                        foreach (System.Data.DataColumn col in ds.Tables[1].Columns)
                        {
                            row.Add(col.ColumnName, dr[col]);
                        }
                        rows.Add(row);
                    }
                    hodVendorsjsondata = serializer.Serialize(rows);
                    rows = null;
                }
            }

            jsondata = new string[] { hodVendorsjsondata, hodtop10mattersjsondata };
            return jsondata;
        }
        #endregion

        public static MatterViewModel GetDraftMatterById(int ID)
        {
            using (var repo = new DraftMattersRepository())
            {
                var model = new MatterViewModel();
                var tbl = repo.First(x => x.ID == ID);
                model.ID = 0;
                model.Matter_Name = tbl.Matter_Name;
                model.SystemType_ID = tbl.SystemType_ID;
                model.System = tbl.SystemType_ID == (int)SystemTypes.GroupLegal ? SystemTypes.GroupLegal.ToString() : SystemTypes.BusinessUnit.ToString();
                model.IsHighlyConfidential = tbl.IsHighlyConfidential.Value;
                model.Business_Unit_ID = tbl.Business_Unit_ID != null && tbl.Business_Unit_ID > 0 ? (int)tbl.Business_Unit_ID : 0;
                model.Business_Unit = (tbl.Business_Units != null) ? tbl.Business_Units.Business_Unit1 : string.Empty; ;
                model.OperationId = tbl.Operation_ID;
                model.OperationId = Convert.ToInt32(tbl.Operation_ID);
                model.Operation = (tbl.Operation != null) ? tbl.Operation.Operation1 : string.Empty;
                model.LegalDisciplineId = tbl.LegalDisciplineId != null && tbl.LegalDisciplineId > 0 ? (int)tbl.LegalDisciplineId : 0;
                model.SubLegalDisciplineId = tbl.SubDisciplineId != null && tbl.SubDisciplineId > 0 ? Convert.ToInt32(tbl.SubDisciplineId) : 0;
                model.MatterReportClassificationOptionId = tbl.MatterReportClassificationOptionId != null && tbl.MatterReportClassificationOptionId > 0 ? (int)tbl.MatterReportClassificationOptionId : 0;
                model.ApplicationReportTemplateId = tbl.ApplicationReportTemplateId != null && tbl.ApplicationReportTemplateId > 0 ? (int)tbl.ApplicationReportTemplateId : 0;
                model.Country = tbl.Country != null ? tbl.Country.Country1 : string.Empty;
                model.Country_ID = tbl.CountryId != null ? Convert.ToInt32(tbl.CountryId) : 0;
                model.Matter_Status = tbl.Matter_Status != null ? tbl.Matter_Status.Matter_Status1 : string.Empty;
                model.Lead_Lawyer = tbl.User != null ? tbl.User.FullName : string.Empty;
                model.Lead_Lawyer_ID = tbl.Lead_Lawyer_ID != null && tbl.Lead_Lawyer_ID > 0 ? (int)tbl.Lead_Lawyer_ID : 0;
                model.Lead_Client = tbl.PeoplePicker != null ? tbl.PeoplePicker.Full_Name : string.Empty;
                model.Lead_Client_ID = tbl.Lead_Client_ID != null && tbl.Lead_Client_ID > 0 ? (int)tbl.Lead_Client_ID : 0;
                model.Context = tbl.Context;
                model.Matter_Description = tbl.Matter_Description;
                model.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks = tbl.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks;
                model.Recommended_Mitigation_Steps = tbl.Recommended_Mitigation_Steps;
                model.Impact_On_Group_BU = tbl.Impact_On_Group_BU;
                model.Current_Next_Step_or_Procedural_Stage = tbl.Current_Next_Step_or_Procedural_Stage;
                model.Client_Action = tbl.Client_Action;
                model.Assisting_Team_Members = string.Join("; ", tbl.DraftMatters_AssistingTeamMembers.Select(x => x.PeoplePicker.Full_Name.ToString()).ToArray());
                model.Assisting_Team_Members_IDs = JsonConvert.SerializeObject(tbl.DraftMatters_AssistingTeamMembers.Select(x => new KeyValuePair<int, string>(x.PeoplePicker.ID, x.PeoplePicker.Full_Name)).ToList());
                model.Key_Work_Stream = string.Join(";", tbl.DraftMatters_KeyWorkStream.Select(x => x.KeyWorkStream.Key_Work_Stream.ToString()));
                model.KeyWorkStreamIDs = tbl.DraftMatters_KeyWorkStream.Select(x => x.KeyWorkStream_ID).ToList();
                model.Created_By = tbl.Created_By != null ? tbl.Created_By : string.Empty;

                return model;
            }
        }
    }
}
