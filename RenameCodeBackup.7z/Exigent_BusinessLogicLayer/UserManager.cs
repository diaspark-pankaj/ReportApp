﻿using Exigent.EF.Data.Repository;
using Exigent.Common.Enums;
using Exigent.Common.Helpers;
using Exigent.Models;
using Exigent_ViewModels.Admin;
using Exigent.ViewModels.Common;
using Exigent_ViewModels.Home;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Dynamic;
using Exigent.BLL;
using ChameleonInformExigent.Helpers;
using Exigent.Email.Configuration;
using Exigent.DataLayer.Repository;
using System.Data.Entity;

namespace Exigent_BusinessLogicLayer.Admin
{
    public class UserManager
    {
        // Shreya Garhwal-03/24/2017
        /// <summary>
        ///  Generate random number for verification link
        /// </summary>
        /// <param name="length">length of OTP</param>
        /// <returns></returns>
        private static int GenerateOTP(int length)
        {
            string numbers = "1234567890";

            string characters = numbers;
            string otp = string.Empty;
            for (int i = 0; i < length; i++)
            {
                string character = string.Empty;
                do
                {
                    int index = new Random().Next(0, characters.Length);
                    character = characters.ToCharArray()[index].ToString();
                } while (otp.IndexOf(character) != -1);
                otp += character;
            }
            return Convert.ToInt32(otp);
        }

        /// <summary>
        /// Generate 15 characters' OTP with hyphen between every 3 characters for two factor authentication
        /// </summary>
        /// <returns></returns>
        private static string GenerateOTP()
        {
            string numbers = "1234567890";
            int length = 5;
            string characters = numbers;
            string otp = string.Empty;
            for (int i = 0; i < length; i++)
            {
                string character = string.Empty;
                string subOTP = string.Empty;
                for (int j = 0; j < 3; j++)
                {
                    do
                    {
                        int index = new Random().Next(0, characters.Length);
                        character = characters.ToCharArray()[index].ToString();
                    } while (subOTP.IndexOf(character) != -1);
                    subOTP += character;
                }
                otp += otp.Length == 16 ? subOTP : subOTP + "-";
            }
            return otp;
        }

        public static BasicuserInfo GetUserBasicDetailById(int Id)
        {
            BasicuserInfo basicUserInfo;
            using (UserRepository _userRepository = new UserRepository())
            {
                User user = new User();
                user = _userRepository.GetById(Id);
                basicUserInfo = new BasicuserInfo
                {
                    Id = user.Id,

                    Email = user.Email
                };
                return basicUserInfo;
            }
        }

        public static int GetUserIdEmail(string email)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                return _userRepository.First(e => e.UserName == email).Id;
            }
        }


        public List<SelectedUserViewModel> GetSelectedUserList(string selectedUsers, int UserId)
        {
            DataTable usersDT = null;
            List<SqlParameter> parameters = new List<SqlParameter>();
            SqlParameter sqlParam;

            if (!string.IsNullOrEmpty(selectedUsers))
            {
                sqlParam = new SqlParameter { ParameterName = "@EntityIds", Value = selectedUsers };
                parameters.Add(sqlParam);
            }

            usersDT = CommonRepository.ExecuteSP_Exigent(StoredProcedureConstant.GetUserDetails, parameters).Tables[0];

            return usersDT.AsEnumerable()
                    .Select(dataRow => new SelectedUserViewModel
                    {
                        Id = dataRow.Field<int>("Id"),
                        UserName = dataRow.Field<string>("UserName")
                    }).Where(x => x.Id != UserId).ToList();

        }




        public static string GetEmailByUserId(int userId)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                return _userRepository.First(e => e.Id == userId).UserName;
            }
        }


        // Validate password of user
        public bool ValidateCredentials(LoginViewModel loginViewModel)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                return SaltGenerationHelper.VerifyHashedPassword(loginViewModel.PasswordHash, loginViewModel.Password);
            }
        }

        public List<UserListDetailViewModel> GetAllUser()
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                var usersList = _userRepository.GetAll();

                UserListViewModel objUserListViewModel = new UserListViewModel();

                return objUserListViewModel.UsersList = usersList.Select(r => new UserListDetailViewModel
                                                                              {
                                                                                  UserName = r.UserName,

                                                                                  id = r.Id,
                                                                                  Email = r.Email,

                                                                              }).ToList();
            }
        }

        public bool IsEmailExists(string email)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                return _userRepository.Any(q => q.Email.ToLower().Trim() == email.ToLower().Trim());
            }
        }

        // Shreya Garhwal- 03/23/2017
        // Check verification link sent in email for forgot password 

        public UserProfileAccessViewModel IsValidVerificationLink(int userId, string verificationLink)
        {
            UserProfileAccessViewModel userProfileAccessVM = new UserProfileAccessViewModel();
            using (UserProfileAccessRepository _userProfileAccessRepository = new UserProfileAccessRepository())
            {
                var result = _userProfileAccessRepository.First(q => q.UserId == userId && q.OTPURL == verificationLink);
                if (result != null)
                {
                    userProfileAccessVM.IsActive = result.IsActive;
                    userProfileAccessVM.Created = result.Created;
                    return userProfileAccessVM;
                }
                else
                    return null;
            }
        }

        public UserProfileAccessViewModel IsValidVerificationCode(int userId, string verificationCode)
        {
            UserProfileAccessViewModel userProfileAccessVM = new UserProfileAccessViewModel();
            using (UserProfileAccessRepository _userProfileAccessRepository = new UserProfileAccessRepository())
            {
                if (userId >0 && !string.IsNullOrEmpty(verificationCode))
                {
                    var result = _userProfileAccessRepository.First(q => q.UserId == userId && q.OTP == verificationCode);
                    if (result != null)
                    {
                        userProfileAccessVM.IsActive = result.IsActive;
                        userProfileAccessVM.Expiration = result.Expiration;
                        return userProfileAccessVM;
                    }
                }
                return null;
            }
        }

        // Shreya Garhwal- 03/23/2017
        // Expire verification link
        public void ExpireLinkOrOTP(int userId, string verificationLink, string verificationCode)
        {
            using (UserProfileAccessRepository _userProfileAccessRepository = new UserProfileAccessRepository())
            {
                UserProfileAccess _UserProfileAccess = new UserProfileAccess();
                if (verificationLink != null)
                {
                    _UserProfileAccess = _userProfileAccessRepository.First(q => q.UserId == userId && q.OTPURL == verificationLink);
                }
                if (verificationCode != null)
                {
                    _UserProfileAccess = _userProfileAccessRepository.First(q => q.UserId == userId && q.OTP == verificationCode);

                }
                if (_UserProfileAccess != null)
                {
                    _UserProfileAccess.IsActive = false;
                    _userProfileAccessRepository.SaveChanges();
                }

            }

        }

        public bool IsUserNameExists(string userName)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                return _userRepository.Any(q => q.UserName.ToLower().Trim() == userName.ToLower().Trim());
            }
        }
        public bool IsFullNameExists(string fullName)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                return _userRepository.Any(q => q.FullName.ToLower().Trim() == fullName.ToLower().Trim());
            }
        }

        public static int GetUserId(string fullName)
        {
            using (var rep = new UserRepository())
            {
                return rep.GetQuery()
                    .Where(q => q.FullName.ToLower().Trim() == fullName.ToLower().Trim())
                    .Select(q => q.Id).FirstOrDefault();
            }
        }

        //public bool isHODUserExits()
        //{
        //    using (UserRepository _userRepository = new UserRepository())
        //    {
        //        int HODEntityId= Convert.ToInt32(UserTypes.GroupLegalSuper);
        //        return _userRepository.Any(q => q.EntityId == HODEntityId && q.IsActive == true);
        //    }
        //}

        public bool IsEmailExistsOnEditUser(string email, int? id)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                return _userRepository.Any(q => q.Email.ToLower().Trim() == email.ToLower().Trim() && q.Id != id);
            }
        }

        public bool IsFullNameExistsOnEditUser(string fullName, int? id)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                return _userRepository.Any(q => q.FullName.ToLower().Trim() == fullName.ToLower().Trim() && q.Id != id);
            }
        }

        public string GetUserEmailsByEntityID(int entityID)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                string emails = string.Empty;
                

                return emails;
            }
        }
        public FetchedUserViewModel GetUserWithProfileById(int id)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                var user = _userRepository.GetById(id);
                FetchedUserViewModel fetchedUserViewModel = new FetchedUserViewModel
                {
                    UserId = user.Id,
                    UserName = user.UserName,
                    FullName = user.FullName,
                    ThumbImage = user.ThumbImage,
                    Email = user.Email,
                   
                    Status = user.Status,
                    FailedLoginAttempts = user.FailedLoginAttempts,
                    lockedDate = user.LockedDate,
                    LastPasswordChangeDate = user.LastPasswordChangeDate,
                    IsActive = user.IsActive,

                };

                return fetchedUserViewModel;
            }
        }


        // Get userdetails by Id
        public FetchedUserViewModel GetUserById(int id)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                User user = _userRepository.GetById(id);
                if (user != null)
                {
                    FetchedUserViewModel fetchedUserViewModel = new FetchedUserViewModel();

                    fetchedUserViewModel.UserId = user.Id;
                    fetchedUserViewModel.ThumbImage = user.ThumbImage;
                    fetchedUserViewModel.Email = user.Email;
                    fetchedUserViewModel.FullName = user.FullName;
                    fetchedUserViewModel.UserName = user.UserName;
                    fetchedUserViewModel.PasswordHash = user.PasswordHash;
                    fetchedUserViewModel.Status = user.Status;
                    fetchedUserViewModel.FailedLoginAttempts = user.FailedLoginAttempts;
                    fetchedUserViewModel.lockedDate = user.LockedDate;
                    fetchedUserViewModel.LastPasswordChangeDate = user.LastPasswordChangeDate;
                    fetchedUserViewModel.IsActive = user.IsActive;
                    fetchedUserViewModel.OfficeId = Convert.ToInt32(user.OfficeId);
                    fetchedUserViewModel.RoleLists = user.Roles.Select(x => x.Id).ToList();
                    fetchedUserViewModel.Roles = user.Roles.Select(q => new RoleViewModel
                    {
                        Id = q.Id,
                        Name = q.Name
                    }).ToList();


                    fetchedUserViewModel.UserAccessList = user.Roles.Count > 0 ? user.Roles.FirstOrDefault().RoleAccesses.Select(r => new Exigent_ViewModels.Admin.UserAccessViewModel()
                    {
                        Id = r.Id,
                        RoleId = r.RoleId.Value,
                        Rights = r.DashBoardId.Value
                    }).ToList(): new List<UserAccessViewModel>() { };

                    fetchedUserViewModel.DefaultDashboardID = Convert.ToInt32(user.DefaultDashboardID);
                        fetchedUserViewModel.UserTypeId = user.EntityId > 0 ? Convert.ToInt32(user.EntityId) : 0;
                  


					if (user.Users_BusinessUnit != null && user.Users_BusinessUnit.Count > 0)
					{
						//fetchedUserViewModel.BusinessUnitString = user.Users_BusinessUnit.Select(x => x.Business_Units.Business_Unit1).ToList();
						fetchedUserViewModel.BusinessUnitIds = user.Users_BusinessUnit.Select(x => x.BusinessUnit_ID).ToList();
					}

					if (user.Users_LPA != null && user.Users_LPA.Count > 0)
					{
						//fetchedUserViewModel.MatterTypeString = user.Users_LPA.Select(x => x.Discipline_Lead.MatterType).ToList();
                        fetchedUserViewModel.MatterTypeIds = user.Users_LPA.Where(x=>x.LegalDisciplineId.HasValue).Select(x => x.LegalDisciplineId.Value).ToList();
					}
						

                    return fetchedUserViewModel;
                }
                else
                {
                    return new FetchedUserViewModel();
                }
            }
        }
        public static string GetUserNameById(int id)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                var user = _userRepository.GetById(id);
                if (user != null)
                {
                    return user.FullName;
                }
                else
                { return string.Empty; }
            }
        }

        // Get user details by username
        public FetchedUserViewModel GetUserByUserName(string userName)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                var user = _userRepository.First(r => r.UserName == userName);
                if (user == null)
                {
                    return null;
                }
                FetchedUserViewModel fetchedUserViewModel = new FetchedUserViewModel
                {
                    UserId = user.Id,
                    ThumbImage = user.ThumbImage,
                    Email = user.Email,
                    UserName = user.UserName,
                    FullName = user.FullName,
                    PasswordHash = user.PasswordHash,
                    Status = user.Status,
                    FailedLoginAttempts = user.FailedLoginAttempts,
                    lockedDate = user.LockedDate,
                    LastPasswordChangeDate = user.LastPasswordChangeDate,
                    IsActive = user.IsActive,
                    UserTypeId = user.EntityId,
                    DefaultDashboardID = user.DefaultDashboardID,
                    Roles = user.Roles.Any() ? user.Roles.Select(q => new RoleViewModel
                    {
                        Id = q.Id,
                        Name = q.Name,
                    }).ToList() : null,
                    RoleAppActivityList = CommonManager.GetRoleAppActivity(),
                    UserAccessList = (user.Roles.Any() && user.Roles.FirstOrDefault().RoleAccesses.Count() > 0) ?
                                 user.Roles.FirstOrDefault().RoleAccesses.Select(x => new UserAccessViewModel()
                                 {
                                     Id = x.Id,
                                     Rights = x.DashBoardId.Value,
                                     AccessDashboard = new AccessDashboardViewModel()
                                     {
                                         ID = x.AccessDashboard.ID,
                                         Name = x.AccessDashboard.Name,
                                         Description = x.AccessDashboard.Description,
                                         IsActive = x.AccessDashboard.IsActive,
                                         SortOrder = x.AccessDashboard.SortOrder,
                                         DashboardURL = x.AccessDashboard.DashboardUrl,
                                         AcessDashboardPages = x.AccessDashboard.AccessDashboardsPages.Where(z => z.IsActive == true).Select(y => new AccessDashboardPageViewModel()
                                         {
                                             ID = y.ID,
                                             Name = y.Name,
                                             Description = y.Description,
                                             PageURL = y.PageURL,
                                             IsActive = y.IsActive,
                                             SortOrder = y.SortOrder,
                                             IsDropdown = y.IsDropdown.HasValue ? y.IsDropdown.Value : false,
                                             DashboardID = y.DashboardID,
                                             ImageURL = y.ImageUrl,
                                             
                                         }).ToList(),
                                     }
                                 }).ToList() : null,
                  
                };
                
                return fetchedUserViewModel;
            }
        }
        public FetchedUserViewModel GetUserByEmail(string email)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                var user = _userRepository.First(r => r.UserName == email);
                if (user == null)
                {
                    return null;
                }
                FetchedUserViewModel fetchedUserViewModel = new FetchedUserViewModel
                {
                    UserId = user.Id,
                    ThumbImage = user.ThumbImage,
                    Email = user.UserName,
                    Status = user.Status,
                    FailedLoginAttempts = user.FailedLoginAttempts,
                    lockedDate = user.LockedDate,
                    LastPasswordChangeDate = user.LastPasswordChangeDate,
                    IsActive = user.IsActive,
                    Roles = user.Roles.Select(q => new RoleViewModel
                    {
                        Id = q.Id,
                        Name = q.Name,
                    }).ToList()
                };
                if (!System.IO.File.Exists("~/Images/UserImage/" + fetchedUserViewModel.ThumbImage))
                {
                    fetchedUserViewModel.ThumbImage = string.Empty;
                }
                return fetchedUserViewModel;
            }
        }

        public void UpdateInvalidLoginAttempt(string userName, out int failedLoginAttempts, out DateTime? lockedDate, int userCurrStatus)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                var addUser = _userRepository.First(q => q.UserName == userName);
                if (addUser.FailedLoginAttempts == null)
                {
                    addUser.FailedLoginAttempts = 1;
                }
                else
                {
                    if (addUser.FailedLoginAttempts < 6)
                    {
                        addUser.FailedLoginAttempts += 1;
                        if (addUser.FailedLoginAttempts == 6)
                        {
                            addUser.LockedDate = DateTime.Now;
                            if (userCurrStatus == Convert.ToInt32(UserStatus.Active))
                            {
                                addUser.Status = Convert.ToInt32(UserStatus.LockedFromActive);
                            }
                            if (userCurrStatus == Convert.ToInt32(UserStatus.JustCreated))
                            {
                                addUser.Status = Convert.ToInt32(UserStatus.LockedFromJustCreated);
                            }
                        }
                    }
                }

                _userRepository.SaveChanges();

                failedLoginAttempts = addUser.FailedLoginAttempts ?? 1;
                lockedDate = addUser.LockedDate;
            }
        }
        public void UpdateSuccessLoginAttempt(string userName, int userCurrStatus, out int userUpdatedStatus)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                var addUser = _userRepository.First(q => q.UserName == userName);

                addUser.FailedLoginAttempts = null;
                if (userCurrStatus == Convert.ToInt32(UserStatus.LockedFromActive))
                {
                    addUser.Status = Convert.ToInt32(UserStatus.Active);
                }
                if (userCurrStatus == Convert.ToInt32(UserStatus.LockedFromJustCreated))
                {
                    addUser.Status = Convert.ToInt32(UserStatus.JustCreated);
                }
                userUpdatedStatus = addUser.Status;
                addUser.LockedDate = null;
                _userRepository.SaveChanges();
            }
        }

        //Validate password expiry : Returns true if password is expired
        public bool IsPasswordExpired(FetchedUserViewModel userModel, int passwordExpiryDaysCount)
        {
            int daysElapsedAfterLastPwdChange = (DateTime.Today - userModel.LastPasswordChangeDate).Days;
            return daysElapsedAfterLastPwdChange > passwordExpiryDaysCount;
        }

        public bool PasswordExpiryNotification(string userName, int passwordExpiryDaysCount, int passwordExpiryPriorNotificationDays, out int remainingDays)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                User addUser = _userRepository.First(r => r.UserName == userName);
                if (addUser == null)
                {
                    remainingDays = 0;
                    return false;
                }
                DateTime nextExpirationDate = addUser.LastPasswordChangeDate.AddDays(passwordExpiryDaysCount);
                DateTime notificationStartDate = nextExpirationDate.AddDays(-passwordExpiryPriorNotificationDays);
                DateTime currentDate = DateTime.Today;
                remainingDays = (nextExpirationDate - currentDate).Days;
                return currentDate >= notificationStartDate && currentDate <= nextExpirationDate;
            }
        }

        // Validates userId and updates password
        public void ChangePassword(ForceChangePasswordViewModel firstChangePasswordViewModel)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                DateTime currDateTime = DateTime.Now;

                User user = _userRepository.GetById(firstChangePasswordViewModel.UserId);
                string[] psss = SaltGenerationHelper.HashPassword(firstChangePasswordViewModel.NewPassword);
                if (psss != null && psss.Length > 0)
                {
                    user.PasswordHash = psss[0].ToString();
                }

                user.Status = 1;

                user.LastPasswordChangeDate = currDateTime;
                user.PasswordHistories = new List<PasswordHistory>
                                     {
                                         new PasswordHistory
                                         {
                                             Password = user.PasswordHash,
                                         }
                                     };

                _userRepository.SaveChanges();
            }
        }

        //Validate old password
        public bool IsOldPasswordCorrect(ForceChangePasswordViewModel firstChangePasswordViewModel)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                User user = _userRepository.GetById(firstChangePasswordViewModel.UserId);
                if (user != null)
                {
                    bool isCorrectPassword = SaltGenerationHelper.VerifyHashedPassword(user.PasswordHash, firstChangePasswordViewModel.OldPassword);
                    return isCorrectPassword;
                }
                else
                {
                    return false;
                }

            }
        }
        public bool AnyMatchFoundPasswordHistory(ForceChangePasswordViewModel firstChangePasswordViewModel, int noOfLastNonreUsablePasswords)
        {
            using (PasswordHistoryRepository passwordHistoryRepository = new PasswordHistoryRepository())
            {
                IEnumerable<PasswordHistory> passwordHistoryList = passwordHistoryRepository.Find(q => q.UserId == firstChangePasswordViewModel.UserId);
                //string encryptedPassword = EncryptionHelper.EncodetoSHA1String(firstChangePasswordViewModel.NewPassword);
                string[] pass = SaltGenerationHelper.HashPassword(firstChangePasswordViewModel.NewPassword);
                string encryptedPassword = pass != null && !string.IsNullOrEmpty(pass[0]) ? pass[0].ToString() : "";
                return passwordHistoryList.Take(noOfLastNonreUsablePasswords).Any(q => q.Password == encryptedPassword);
            }
        }

        /// <summary>
        /// Match Password from Change Password screen
        /// </summary>
        /// <param name="changePasswordViewModel"></param>
        /// <param name="noOfLastNonreUsablePasswords"></param>
        /// <param name="UserId"></param>
        /// <returns></returns>
        public bool MatchPassFromPasswordHistory(ChangePasswordViewModel changePasswordViewModel, int noOfLastNonreUsablePasswords, int UserId)
        {
            using (PasswordHistoryRepository passwordHistoryRepository = new PasswordHistoryRepository())
            {
                IEnumerable<PasswordHistory> passwordHistoryList = passwordHistoryRepository.Find(q => q.UserId == UserId);
                //string encryptedPassword = EncryptionHelper.EncodetoSHA1String(changePasswordViewModel.NewPassword);
                string[] pass = SaltGenerationHelper.HashPassword(changePasswordViewModel.NewPassword);
                string encryptedPassword = pass != null && !string.IsNullOrEmpty(pass[0]) ? pass[0].ToString() : "";
                return passwordHistoryList.Take(noOfLastNonreUsablePasswords).Any(q => q.Password == encryptedPassword);
            }
        }

        // Inserts user in User Table and sends email containing credentials to that user's email id
        public bool AddUser(AddUserViewModel createUserViewModel, int userId, out int newGenratedUserID)
        {

            DateTime currentTime = DateTime.Today;
			try
			{
				//Add
				User addUser = new User();
				addUser.UserName = createUserViewModel.UserName;
				addUser.Email = createUserViewModel.Email;
				addUser.FullName = createUserViewModel.FullName;
				addUser.PasswordHash = createUserViewModel.Password;
				addUser.SecurityStamp = createUserViewModel.SecurityStamp;
				addUser.OriginalImage = createUserViewModel.OriginalImage;
				addUser.ThumbImage = createUserViewModel.ThumbImage;
				addUser.EntityId = Convert.ToInt32(createUserViewModel.UserTypeId);
				addUser.LastPasswordChangeDate = currentTime; //This is must for pwd expiry mechanism
				addUser.Status = Convert.ToInt32(UserStatus.Active);
                addUser.OfficeId = Convert.ToInt32(createUserViewModel.OfficeId); 
				//if(createUserViewModel.UserTypeId ==(int)UserTypes.Vendor)
				addUser.IsActive = createUserViewModel.IsActive;
                switch (createUserViewModel.UserTypeId)
                {
                    case (int)UserTypes.ServiceProviderAdmin:
                        addUser.DefaultDashboardID = (int)UserAccessEnum.AdminDashboard;
                        break;
                    case (int)UserTypes.LegalProfessionalStaff:
                        addUser.DefaultDashboardID = (int)UserAccessEnum.MainDashboard;
                        break;
                    case (int)UserTypes.LegalAdminStaff:
                        addUser.DefaultDashboardID = (int)UserAccessEnum.MainDashboard;
                        break;
                    case (int)UserTypes.AuthorisedBusinessStaff:
                        addUser.DefaultDashboardID = (int)UserAccessEnum.BusinessUnitDashboard;
                        break;
                    case (int)UserTypes.SpecialGroupLegal:
                        addUser.DefaultDashboardID = (int)UserAccessEnum.MainDashboard;
                        break;
                    case (int)UserTypes.GroupLegalSuper:
                        addUser.DefaultDashboardID = (int)UserAccessEnum.MainDashboard;
                        break;
                    case (int)UserTypes.SeniorLegalLeadershipStaff:
                        addUser.DefaultDashboardID = (int)UserAccessEnum.MainDashboard;
                        break;
                    default:
                        addUser.DefaultDashboardID = (int)UserAccessEnum.AdminDashboard;
                        break;
                }
				//addUser.DefaultDashboardID = createUserViewModel.DefaultDashboardID;
				addUser.DefaultDashboard = createUserViewModel.DefaultDashboard;

				addUser.PasswordHistories = new Collection<PasswordHistory>{new PasswordHistory{
                                                    Password = createUserViewModel.Password                                                   
                                                }};
                if (!string.IsNullOrEmpty(createUserViewModel.OriginalImage) && !string.IsNullOrEmpty(createUserViewModel.ThumbImage))
                {
                    addUser.OriginalImage = createUserViewModel.OriginalImage;
                    addUser.ThumbImage = createUserViewModel.ThumbImage;
                }
                addUser.EntityId = createUserViewModel.UserTypeId;
                
                using (UserRepository _userRepository = new UserRepository())
                {
                    createUserViewModel.RoleIds = new List<int>();
                    createUserViewModel.RoleIds.Add(createUserViewModel.RoleId);
                    List<Role> roles = _userRepository.GetUserRoleListById(createUserViewModel.RoleIds);
                    addUser.Roles = new List<Role>();
                    foreach (var role in roles)
                    {
                        addUser.Roles.Add(role);
                    }

                    _userRepository.Add(addUser);
                    _userRepository.SaveChanges();

                    // Save user in people-picker table
                    //if (createUserViewModel.UserTypeId != 102)
                    //{
                    //    PeoplePicker peoplePicker = new PeoplePicker();
                    //    peoplePicker.Full_Name = createUserViewModel.FullName;
                    //    peoplePicker.Email = createUserViewModel.Email;
                    //    PeoplePickerRepository _peoplePickerRepository = new PeoplePickerRepository();
                    //    _peoplePickerRepository.Add(peoplePicker);
                    //    _peoplePickerRepository.SaveChanges();
                    //}

                    //Send Email Functionality 

                    EmailManager emailmanager = new EmailManager();
                    EmailDetails emailDetails = new EmailDetails();
                    emailDetails.EmailTo = createUserViewModel.Email;
                    createUserViewModel.UserType = EnumHelper<UserTypes>.GetEnumDescription(((UserTypes)createUserViewModel.UserTypeId).ToString());
                    emailmanager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.UserRegistration, (int)EmailCategoryEnum.UserRegistration, emailDetails, createUserViewModel);
                    int newlyGeneratedUserId = addUser.Id;
                    newGenratedUserID = newlyGeneratedUserId;
                    //_userRepository.SaveChanges();

					// after user save, add BUs & LPAs.
					if (createUserViewModel.BusinessUnitIds != null && createUserViewModel.BusinessUnitIds.Count > 0)
					{
						//	addUser.BusinessUnit = String.Join(";", createUserViewModel.BusinessUnitString);
						Users_BU_LPA_Manager.AddOrUpdateUserBUs(createUserViewModel,null,addUser.Id);
					}

					if (createUserViewModel.MatterTypeIds != null && createUserViewModel.MatterTypeIds.Count > 0)
					{
						//	addUser.MatterType = String.Join(";", createUserViewModel.MatterTypeString);
						Users_BU_LPA_Manager.AddOrUpdateUserLPAs(createUserViewModel, null, addUser.Id);
					}

				}

			}
            catch (Exception)
            {
                newGenratedUserID = 0;
                return false;
            }
            return true;
        }


        // Shreya Garhwal- 03/22/2017 
        // Sends verification link to user's email id if valid user
        public bool IsCurrentUserfromForgot(ForgotPasswordViewModel forgotPasswordViewModel)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                User result = _userRepository.First(x => x.IsActive && x.Email == forgotPasswordViewModel.Email.Trim() && x.UserName == forgotPasswordViewModel.UserName.Trim());
                if (result != null)
                {

                    string BaseUrl = SystemDetailsViewModel.URL + "/";//System.Configuration.ConfigurationManager.AppSettings["ApplicationUrl"];
                    int OTP = GenerateOTP(5);
                    //string OTP = GenerateOTP(5);
                    Dictionary<string, string> Dict = new Dictionary<string, string>();
                    Dict.Add("userId", result.Id.ToString());
                    Dict.Add("OTP", OTP.ToString());
                    _userRepository.SaveChanges();
                    BaseUrl = BaseUrl + "Login/ResetPassword?q=" + Crypto.Encrypt(Dict);
                    forgotPasswordViewModel.BaseUrl = BaseUrl;
                    EmailManager emailmanager = new EmailManager();
                    EmailDetails emailDetails = new EmailDetails();
                    emailDetails.EmailTo = forgotPasswordViewModel.Email;
                    emailDetails.EmailCC = SystemDetailsViewModel.Team;
                    bool IsEmailSent = emailmanager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.ForgotPassword, (int)EmailCategoryEnum.ForgotPassword, emailDetails, forgotPasswordViewModel);
                    if (IsEmailSent)
                    {
                        using (UserProfileAccessRepository _userProfileAccessRepository = new UserProfileAccessRepository())
                        {
                            UserProfileAccess userProfileAccess = new UserProfileAccess();
                            //userProfileAccess.OTP = OTP;
                            userProfileAccess.OTPURL = BaseUrl;
                            userProfileAccess.Created = DateTime.Now;
                            userProfileAccess.IsActive = true;
                            userProfileAccess.UserId = result.Id;
                            _userProfileAccessRepository.Add(userProfileAccess);
                            _userProfileAccessRepository.SaveChanges();
                        }

                    }

                }
                return result != null ? true : false;
            }
        }

        /// <summary>
        /// Sends verification code to user's registered email id and accordingly adds/ updates entry in UserProfileAccess table
        /// </summary>
        /// <param name="email">email id of user is required</param>
        /// <param name="userID">userid is required</param>
        /// <returns></returns>
        public bool SendVerificationCode(string email, int userID)
        {
            if (!string.IsNullOrEmpty(email) && userID >0)
            {
                UserListDetailViewModel userdetailViewModel = new UserListDetailViewModel();
                string OTP = GenerateOTP();
                userdetailViewModel.Verification_Code = OTP;
                string expirationTime = System.Configuration.ConfigurationManager.AppSettings["OTPExpirationInterval"].ToString();
                userdetailViewModel.Expiration_Time = Convert.ToInt32(expirationTime);
                EmailManager emailmanager = new EmailManager();
                EmailDetails emailDetails = new EmailDetails();
                emailDetails.EmailTo = email;
                bool IsEmailSent = emailmanager.GetEmailTemplateSendMail((int)KeywordObjectTypeEnum.TwoFactorAuthentication, (int)EmailCategoryEnum.TwoFactorAuthentication, emailDetails, userdetailViewModel);
                if (IsEmailSent)
                {
                    using (UserProfileAccessRepository _userProfileAccessRepository = new UserProfileAccessRepository())
                    {
                        UserProfileAccess userProfileAccess = _userProfileAccessRepository.First(x => x.UserId == userID && !string.IsNullOrEmpty(x.OTP));
                        //Updates data if verification code already exists for user
                        if (userProfileAccess != null)
                        {
                            userProfileAccess.OTP = OTP;
                            userProfileAccess.IsActive = true;
                            userProfileAccess.Created = DateTime.Now;
                            userProfileAccess.Expiration = DateTime.Now.AddMinutes(Convert.ToInt32(expirationTime));
                        }
                        // Add entry in UserProfileAccess table
                        else
                        {
                            UserProfileAccess _userProfileAccess = new UserProfileAccess();
                            _userProfileAccess.OTP = OTP;
                            _userProfileAccess.Created = DateTime.Now;
                            _userProfileAccess.IsActive = true;
                            _userProfileAccess.UserId = userID;
                            _userProfileAccess.Expiration = DateTime.Now.AddMinutes(Convert.ToInt32(expirationTime));
                            _userProfileAccessRepository.Add(_userProfileAccess);
                        }
                        _userProfileAccessRepository.SaveChanges();
                    }

                }
                return IsEmailSent;
            }
            return false;
        }

        // Update user details
        public bool EditUser(EditUserViewModel editUserViewModel, int userId, out string thumbImage, out string originalImage, out DateTime? modifiedDate)
        {
            using (UserRepository userRepository = new UserRepository())
            {

                DateTime currentTime = DateTime.Today;
                originalImage = string.Empty;
                thumbImage = string.Empty;
                //try
                //{
                //Edit
                if (editUserViewModel.Id.HasValue && editUserViewModel.Id.Value != 0)
                {
					//Edit an existing User
					
					var editUser = userRepository.GetQueryWithInclude("Users_BusinessUnit").Where(x => x.Id == editUserViewModel.Id.Value).FirstOrDefault();
					editUser.Email = editUserViewModel.Email;
                    editUser.FullName = editUserViewModel.FullName;
                    editUser.IsActive = editUserViewModel.IsActive;
                    editUser.OfficeId = editUserViewModel.OfficeId;
                    
                    if (!string.IsNullOrEmpty(editUserViewModel.OriginalImage) && !string.IsNullOrEmpty(editUserViewModel.ThumbImage))
                    {
                        editUser.OriginalImage = editUserViewModel.OriginalImage;
                        editUser.ThumbImage = editUserViewModel.ThumbImage;

                        originalImage = editUserViewModel.OriginalImage;
                        thumbImage = editUserViewModel.ThumbImage;
                    }
                    else
                    {
                        originalImage = editUser.OriginalImage;
                        thumbImage = editUser.ThumbImage;
                    }

					if (editUserViewModel.BusinessUnitIds != null && editUserViewModel.BusinessUnitIds.Count > 0)
					{
						//    editUser.BusinessUnit = String.Join(";", editUserViewModel.BusinessUnitString);
						Users_BU_LPA_Manager.AddOrUpdateUserBUs(null,editUserViewModel,Convert.ToInt32(editUserViewModel.Id), editUser);
					}



					if (editUserViewModel.MatterTypeIds != null && editUserViewModel.MatterTypeIds.Count > 0)
					{
						//    editUser.MatterType = String.Join(";", editUserViewModel.MatterTypeString);
						Users_BU_LPA_Manager.AddOrUpdateUserLPAs(null, editUserViewModel, Convert.ToInt32(editUserViewModel.Id), editUser);
					}


                    //List<UserAccess> userAccessList = userRepository.GetAllUserAccessByUserId(editUserViewModel.Id.Value).ToList();

                    //if (userAccessList != null && userAccessList.Count() > 0)
                    //    userRepository.DeleteuserAccess(editUserViewModel.Id.Value);

                    //foreach (var userAcc in editUserViewModel.UserAccessList)
                    //{
                    //    editUser.UserAccesses.Add(new UserAccess() { UserId = Convert.ToInt32(editUserViewModel.Id), Rights = userAcc.Rights });
                    //}

                    //IEnumerable<Role> rolesList = userRepository.GetAllRolesByUserId(editUserViewModel.Id.Value);
                    //foreach (var rolese in rolesList)
                    //{
                    //    editUser.Roles.Remove(rolese);
                    //}

                    //editUserViewModel.RoleIds = new List<int>();
                    //editUserViewModel.RoleIds.Add(editUserViewModel.RoleId);
                    //List<Role> roles = userRepository.GetUserRoleListById(editUserViewModel.RoleIds);
                    //foreach (var role in roles)
                    //{
                    //    editUser.Roles.Add(role);
                    //}

                    userRepository.SaveChanges();
                    modifiedDate = DateTime.Now;

                    return true;
                }
                //}

                //catch (Exception)
                //{
                //    modifiedDate = null;

                //    return false;
                //}
                modifiedDate = null;

                return false;
            }
        }


		// Updates user password
		// Modified by Shreya Garhwal- 03/21/2017
		public void ChangeUserPassword(ChangePasswordViewModel changePasswordViewModel, int UserId)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                User user = _userRepository.GetById(UserId);
                string[] password = SaltGenerationHelper.HashPassword(changePasswordViewModel.NewPassword);
                if (password != null && password.Length > 0)
                {
                    user.PasswordHash = password[0].ToString();
                    user.SecurityStamp = password[1].ToString();
                }
                user.Status = 1;
                user.LastPasswordChangeDate = DateTime.Now;
                user.PasswordHistories = new List<PasswordHistory>
                                     {
                                         new PasswordHistory
                                         {
                                            Password = user.PasswordHash
                                         }
                                     };
                _userRepository.SaveChanges();
            }
        }

        public bool ResetUserPassword(string Password, int SessionUserId, int UserId)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                User user = _userRepository.GetById(UserId);
                if (user != null)
                {
                    string newPassword = EncryptionHelper.EncodetoSHA1String(Password);
                    DateTime currDateTime = DateTime.Now;

                    user.PasswordHash = newPassword;

                    user.LastPasswordChangeDate = currDateTime;
                    user.Status = 1;
                    user.PasswordHistories = new List<PasswordHistory>
                                     {
                                         new PasswordHistory
                                         {
                                             Password = newPassword,
                                           
                                         }
                                     };

                    try
                    {
                        _userRepository.SaveChanges();
                        string BaseUrl = System.Configuration.ConfigurationManager.AppSettings["ApplicationURL"];
                        return true;
                    }
                    catch (Exception)
                    {
                        return false;
                    }
                }
                return false;
            }
        }

        // update user status from active to inactive and vice versa
        public bool ResetUserStatus(int UserId)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                User user = _userRepository.GetById(UserId);
                if (user != null)
                {
                    if (user.IsActive)
                        user.IsActive = false;
                    else
                        user.IsActive = true;
                    try
                    {
                        _userRepository.SaveChanges();

                        return true;
                    }
                    catch (Exception)
                    {
                        return false;
                    }
                }
                return false;
            }
        }
        public bool ResetUserImage(int SessionUserId, int UserId)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                User user = _userRepository.GetById(UserId);
                if (user != null)
                {
                    user.OriginalImage = null;
                    user.ThumbImage = null;

                    try
                    {
                        _userRepository.SaveChanges();

                        return true;
                    }
                    catch (Exception)
                    {
                        return false;
                    }
                }
                return false;
            }
        }


        #region My Profile
        public bool EditMyProfile(EditUserProfileViewModel editUserProfileViewModel, int userId, out string thumbImage, out string originalImage, out DateTime DateModified)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                originalImage = string.Empty;
                thumbImage = string.Empty;
                DateModified = DateTime.Now;
                try
                {
                    //Edit
                    if (editUserProfileViewModel.Id.HasValue && editUserProfileViewModel.Id.Value != 0)
                    {
                        //Edit an existing user
                        var editUser = _userRepository.GetById(editUserProfileViewModel.Id.Value);
                        editUser.FullName = editUserProfileViewModel.FullName;

                        editUser.Email = editUserProfileViewModel.Email;

                        if (!string.IsNullOrEmpty(editUserProfileViewModel.OriginalImage) && !string.IsNullOrEmpty(editUserProfileViewModel.ThumbImage))
                        {
                            editUser.OriginalImage = editUserProfileViewModel.OriginalImage;
                            editUser.ThumbImage = editUserProfileViewModel.ThumbImage;

                            originalImage = editUserProfileViewModel.OriginalImage;
                            thumbImage = editUserProfileViewModel.ThumbImage;
                        }
                        else
                        {
                            originalImage = editUser.OriginalImage;
                            thumbImage = editUser.ThumbImage;
                        }


                    }
                    _userRepository.SaveChanges();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
        }
        #endregion

        #region single Session

        public void CheckUserLogin(CheckLoginViewModel checkLoginViewModel, bool hasTwoFactorAuthenticated=false)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                var logins = _userRepository.GetById(checkLoginViewModel.UserId);
                if (logins.CheckLogins == null || logins.CheckLogins.Count == 0)
                {
                    logins.CheckLogins = new List<CheckLogin>();
                    logins.CheckLogins.Add(
                    new CheckLogin()
                    {
                        LoggedIn = checkLoginViewModel.LoggedIn,
                        SessionId = checkLoginViewModel.SessionId,
                        IsTwoFactorAuth = hasTwoFactorAuthenticated
                    });
                }
                else
                {
                    if (logins.CheckLogins.Count > 0)
                    {
                        logins.CheckLogins.FirstOrDefault().LoggedIn = checkLoginViewModel.LoggedIn;
                        logins.CheckLogins.FirstOrDefault().SessionId = checkLoginViewModel.SessionId;
                        logins.CheckLogins.FirstOrDefault().IsTwoFactorAuth = hasTwoFactorAuthenticated; 
                        _userRepository.Entry(logins, EntityState.Modified);
                    }
                }
                if (logins.FailedLoginAttempts != null && logins.FailedLoginAttempts > 0)
                {
                    logins.FailedLoginAttempts = 0;

                }
                _userRepository.SaveChanges();
            }
        }
        public bool CheckSession(CheckLoginViewModel checkLoginViewModel)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                var logins = _userRepository.GetById(checkLoginViewModel.UserId);

                if (logins.CheckLogins != null)
                {
                    return true;
                }
                return false;
            }
        }

        // vyom dixit, TWO-FACT-CHANGE, 20-07-2017
        // Start.......
        public bool HasTwoFactorAuth(int userId,string sessionId)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                User _user = _userRepository.GetById(userId);

                if (_user.CheckLogins != null)
                {
                    if (_user.CheckLogins.Any(x => x.SessionId==sessionId && x.IsTwoFactorAuth == true))
                        return true;
                    else
                        return false;
                }
                return false;
            }
        }
        // End....

        public void DeleteFromSession(int UserId)
        {
            using (CheckLoginRepository checkLoginRepository = new CheckLoginRepository())
            {
                var logins = checkLoginRepository.GetByUserId(UserId);
                if (logins != null)
                {
                    checkLoginRepository.Delete(logins);
                    checkLoginRepository.SaveChanges();
                }
            }
        }

        public bool IsSessionExits(int userId, string sid)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                IEnumerable<UserViewModel> logins = _userRepository.Find(q => q.CheckLogins.FirstOrDefault().LoggedIn == true && q.Id == userId && q.CheckLogins.FirstOrDefault().SessionId == sid).Select(r =>
                {
                    return new UserViewModel
                    {
                        LoggedIn = r.CheckLogins.FirstOrDefault().LoggedIn,
                        SessionId = r.CheckLogins.FirstOrDefault().SessionId
                    };
                });
                return logins.Any();
            }
        }


        public bool IsUserSessionExist(int userId)
        {
            using (UserRepository _userRepository = new UserRepository())
            {
                IEnumerable<UserViewModel> logins = _userRepository.Find(q => q.CheckLogins.FirstOrDefault().LoggedIn == true && q.Id == userId)
                .OrderByDescending(x => x.CheckLogins).Select(r =>
                {
                    return new UserViewModel
                    {
                        LoggedIn = r.CheckLogins.FirstOrDefault().LoggedIn,
                        SessionId = r.CheckLogins.FirstOrDefault().SessionId
                    };
                });
                return logins.Any();
            }
        }
        #endregion

    }
}