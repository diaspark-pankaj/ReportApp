﻿using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System.Linq;

namespace Exigent.BLL
{
    public class KeyWorkStreamManager
    {
        public static KeyWorkStreamViewModel GetKeyWorkStreamById(int id)
        {
            using (var rep = new KeyWorkStreamRepository())
            {
                var model = rep.GetQuery().Where(m => m.ID == id)
                    .Select(m => new KeyWorkStreamViewModel
                    {
                        Id = m.ID,
                        Key_Work_Stream = m.Key_Work_Stream,
                    }).FirstOrDefault();

                return model;
            }
        }

        public static bool IsExists(int id, string keyworkStream)
        {
            using (var rep = new KeyWorkStreamRepository())
            {
                return rep.Any(p => p.Key_Work_Stream == keyworkStream.Trim() && p.ID != id);
            }
        }

        public static bool UpdateKeyWorkStream(KeyWorkStreamViewModel model)
        {
            using (var rep = new KeyWorkStreamRepository())
            {
                var dt = rep.GetQuery().Where(m => m.ID == model.Id).FirstOrDefault();

                if (dt == null)
                    return false;

                dt.Key_Work_Stream = model.Key_Work_Stream;

                rep.SaveChanges();
            }
            return true;
        }

        public static int CreateKeyWorkStream(KeyWorkStreamViewModel model)
        {
            using (var rep = new KeyWorkStreamRepository())
            {
                var dt = new KeyWorkStream
                {
                    Key_Work_Stream = model.Key_Work_Stream
                };

                rep.Add(dt);
                rep.SaveChanges();

                return dt.ID;
            }
        }

    }
}
