﻿using Exigent.Common.Enums;
using Exigent.DataLayer.Repository;
using Exigent.Models;
using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.BLL
{
    public class LegalDesciplineManager
    {
        public static LegalDesciplineViewModel GetLegalDesciplineById(int id)
        {
            using (var rep = new BUVendorAccessRepository())
            {
                var model = rep.GetQuery().Where(m => m.ID == id)
                    .Select(m => new LegalDesciplineViewModel
                    {
                        Id = m.ID,
                        Vendor_ID = m.Vendor_ID,
                        Legal_Discipline_ID = m.Legal_Discipline_ID,
                        BusinessUnit_ID = m.BusinessUnit_ID,
                        Email = m.Email,
                        Legal_Discipline = m.LegalDiscipline.Name
                    }).FirstOrDefault();

                return model;
            }
        }

        public static bool UpdateLegalDescipline(LegalDesciplineViewModel model)
        {
            using (var rep = new BUVendorAccessRepository())
            {
                var dt = rep.Find(m => m.ID == model.Id).FirstOrDefault();

                if (dt == null)
                    return false;


                dt.Vendor_ID = model.Vendor_ID;
                dt.BusinessUnit_ID = model.BusinessUnit_ID;
                dt.Email = model.Email;
                dt.Legal_Discipline_ID = model.Legal_Discipline_ID;


                rep.SaveChanges();
            }

            return true;
        }

        public static int CreateLegalDescipline(LegalDesciplineViewModel model)
        {
            //if(!ReportClassificationManager.IsAValidReportClassification(model.Legal_Discipline, SystemTypeEnum.BusinessUnit))
            //{
            //    ReportClassificationManager.Create(new ReportClassificationViewModel
            //        {
            //            Report_Classification = model.Legal_Discipline,
            //            Report_Classification_Category = model.Legal_Discipline,
            //            SystemType_ID = (int)SystemTypeEnum.BusinessUnit,
            //            IsActive = true,
            //            Risk_Rating = null, //Leaving optional column as null
            //            Code = null,        //Leaving optional column as null
            //        });
            //}

            using (var rep = new BUVendorAccessRepository())
            {
                var dt = new BusinessUnitVendorAccess
                {
                    Vendor_ID = model.Vendor_ID,
                    Legal_Discipline_ID = model.Legal_Discipline_ID,
                    BusinessUnit_ID = model.BusinessUnit_ID,
                    Email = model.Email,
                  
                };

                rep.Add(dt);
                rep.SaveChanges();

                return dt.ID;
            }
        }
    }
}
