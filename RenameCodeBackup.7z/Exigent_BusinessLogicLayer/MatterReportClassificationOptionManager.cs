﻿using Exigent.DataLayer.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace Exigent.BLL
{
    public class MatterReportClassificationOptionManager
    {
        public static List<SelectListItem> GetMatterReportClassificationOption()
        {
            var lstMatterReportClassificationOption = new List<SelectListItem>();
            using (MatterReportClassificationOptionRepository matterReportClassificationOptionRepository = new MatterReportClassificationOptionRepository())
            {
                matterReportClassificationOptionRepository.Find(x => x.IsActive == true).Select(x => new { Id = x.Id, Name = x.Name }).Distinct().ToList().ForEach(y => lstMatterReportClassificationOption.Add(
                            new SelectListItem
                            {
                                Text = y.Name,
                                Value = y.Id.ToString()
                            }));

            }
            return lstMatterReportClassificationOption.OrderBy(x => x.Text).ToList();
        }
    }
}
