//[assembly: WebActivator.PreApplicationStartMethod(typeof(Exigent.StudioRG.App_Start.Combres), "PreStart")]
//namespace Exigent.StudioRG.App_Start {
//    using System.Web.Routing;
//    using global::Combres;

//    public static class Combres {
//        public static void PreStart() {
//            RouteTable.Routes.AddCombresRoute("Combres");
//        }
//    }
//}