﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.Common.Helpers;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Admin;
using Exigent.ViewModels.Common;
using Exigent_BusinessLogicLayer;
using Exigent_BusinessLogicLayer.Audit;
using Exigent_BusinessLogicLayer.DropDowns;
using Exigent_ViewModels.Common;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace ChameleonInformExigent.Areas.Main.Controllers
{
    public class MainController : BaseController
    {
        string searchText = string.Empty;
        string matterRefNo = string.Empty;


        #region AccountDashboard

        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult AccountsDashboard()
        {
            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null)
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.AccountsDashboard;

            this.RedirectBackUrl = Request.RawUrl;
            return View();
        }
        #endregion

        #region PaymentProcessing
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.PaymentProcessingDashboard })]
        public ActionResult PaymentProcessing(bool useTempData = false, string id = "")
        {
            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null)
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.PaymentProcessingDashboard;
            var model = new InvoiceDashboardViewModel();

            this.RedirectBackUrl = Request.RawUrl;
            if (useTempData)
            {
                model = new InvoiceDashboardViewModel()
                {
                    SearchInvoiceList = new SearchInvoiceListViewModel()
                    {
                        SearchField = !string.IsNullOrEmpty(id) ? id : TempData["SearchInvoice"].ToString()
                    }
                };
                TempData.Keep("SearchInvoice");
            }
            else
            {
                TempData["SearchInvoice"] = string.Empty;
                model = new InvoiceDashboardViewModel() { SearchInvoiceList = new SearchInvoiceListViewModel() { } };
            }

            return View(model);
        }
        #endregion

        #region MainDashboard
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard })]
        [CryptoValueProvider]
        public ActionResult Dashboard(string matterRef, int? filterBusinessUnit = null, int? filterOffice = null, int? filterCountry = null, int? filterLegalDiscipline = null, int mode = 0)
        {
            //Audit
            AuditManager.SaveAudit("User has visited Main Dashboard.", "/Main/Dashboard", SessionHelper.LoggedUserInfo.UserName, SessionHelper.LoggedUserInfo.UserId);

            this.RedirectBackUrl = Request.RawUrl;

            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null)
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.MainDashboard;
            Uri urlReferrer = this.ControllerContext.RequestContext.HttpContext.Request.UrlReferrer;
            MainDashboardViewModel mainDBViewModel = new MainDashboardViewModel();
            mainDBViewModel.MatterCount = 0;

            if (TempData["searchText"] != null && string.IsNullOrEmpty(matterRef))
            {
                TempData.Remove("searchText");
            }
            if (TempData["filterBusinessUnit"] != null && filterBusinessUnit > 0)
            {
                TempData.Remove("filterBusinessUnit");
            }

            if (TempData["filterOffice"] != null && filterOffice > 0)
            {
                TempData.Remove("filterOffice");
            }
            if (TempData["filterCountry"] != null && filterCountry > 0)
            {
                TempData.Remove("filterCountry");
            }
            if (TempData["filterLegalDiscipline"] != null && filterLegalDiscipline > 0)
            {
                TempData.Remove("filterLegalDiscipline");
            }

            if (!string.IsNullOrEmpty(matterRef))
            {
                mainDBViewModel.MatterList.SearchField = matterRef;
                TempData["searchText"] = matterRef;
                TempData["matterRef"] = matterRef;
                TempData.Keep("searchText");
                TempData.Keep("matterRef");
                TempData["mode"] = mode.ToString();
            }
            if (filterBusinessUnit > 0)
            {
                mainDBViewModel.FilterBusinessUnit = filterBusinessUnit;
                TempData["filterBusinessUnit"] = filterBusinessUnit;
                TempData["mode"] = mode.ToString();
                TempData.Keep("filterBusinessUnit");
            }

            if (filterOffice > 0)
            {
                mainDBViewModel.FilterOffice = filterOffice;
                TempData["filterOffice"] = filterOffice;
                TempData["mode"] = mode.ToString();
                TempData.Keep("filterOffice");
            }

            if (filterCountry > 0)
            {
                mainDBViewModel.FilterCountryId = filterCountry;
                TempData["filterCountry"] = filterCountry;
                TempData["mode"] = mode.ToString();
                TempData.Keep("filterCountry");
            }

            if (filterLegalDiscipline > 0)
            {
                mainDBViewModel.FilterLegalDisciplineId = filterLegalDiscipline;
                TempData["filterLegalDiscipline"] = filterLegalDiscipline;
                TempData["mode"] = mode.ToString();
                TempData.Keep("filterLegalDiscipline");
            }

            List<BUTimeAllocationChartViewModel> bUTimeAllocationVMList = new List<BUTimeAllocationChartViewModel>();
            BUManager bUManager = new BUManager();
            var data = new LookupManager().GetBUTimeRecordingListByRustyloading(string.Empty, string.Empty, SessionHelper.LoggedUserInfo.UserId);
            //bUTimeAllocationVMList = bUManager.GetBUTimeAllocationChartDetails(SessionHelper.LoggedUserInfo.FullName.ToString());
            var jsonSerialiser = new JavaScriptSerializer();
            if (data != null && data.ListForCurrentMonth.Any())
            {
                foreach (var item in data.ListForCurrentMonth)
                {
                    bUTimeAllocationVMList.Add(new BUTimeAllocationChartViewModel
                               {
                                   Business_Unit = item.Business_Unit,
                                   value = item.BUTimeValue,
                                   color = item.BusinessUnitColor
                               });
                }
            }

            var json = jsonSerialiser.Serialize(bUTimeAllocationVMList);
            mainDBViewModel.BUTimeAllocationChart = json;
            CommonManager commonManager = new CommonManager();
            DropDownManager dropDownManager = new DropDownManager();
            mainDBViewModel.BuisnessUnitList = CommonManager.GetAllBusinessUnits();
            ViewBag.Discipline = CommonManager.GetLegalDiscipline(SystemTypes.GroupLegal);
            mainDBViewModel.Office = dropDownManager.GetOfficesList();
            ViewBag.Countries = commonManager.GetCountries();

            return View(mainDBViewModel);
        }

        [HttpPost]
        public ActionResult SearchMatter(MainDashboardViewModel mainDashboardViewModel)
        {
            if (mainDashboardViewModel != null && mainDashboardViewModel.MatterList != null)
            {
                var qsDictionary = new Dictionary<string, string>();

                if (!string.IsNullOrEmpty(mainDashboardViewModel.MatterList.SearchField))
                {
                    TempData["searchText"] = mainDashboardViewModel.MatterList.SearchField;
                    qsDictionary.Add("matterRef", mainDashboardViewModel.MatterList.SearchField);
                }
                else
                    TempData.Remove("searchText");

                if (mainDashboardViewModel.FilterBusinessUnit > 0)
                {
                    TempData["filterBusinessUnit"] = mainDashboardViewModel.FilterBusinessUnit;
                    qsDictionary.Add("filterBusinessUnit", mainDashboardViewModel.FilterBusinessUnit.ToString());
                }
                else
                    TempData.Remove("filterBusinessUnit");

                if (mainDashboardViewModel.FilterOffice > 0)
                {
                    TempData["filterOffice"] = mainDashboardViewModel.FilterOffice;
                    qsDictionary.Add("filterOffice", mainDashboardViewModel.FilterOffice.ToString());
                }
                else
                    TempData.Remove("filterOffice");

                if (mainDashboardViewModel.FilterCountryId > 0)
                {
                    TempData["filterCountry"] = mainDashboardViewModel.FilterCountryId;
                    qsDictionary.Add("filterCountry", mainDashboardViewModel.FilterCountryId.ToString());
                }
                else
                    TempData.Remove("filterCountry");

                if (mainDashboardViewModel.FilterLegalDisciplineId > 0)
                {
                    TempData["filterLegalDiscipline"] = mainDashboardViewModel.FilterLegalDisciplineId;
                    qsDictionary.Add("filterLegalDiscipline", mainDashboardViewModel.FilterLegalDisciplineId.ToString());
                }
                else
                    TempData.Remove("filterLegalDiscipline");

                if (qsDictionary.Count > 0)
                {
                    qsDictionary.Add("AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString());
                    return RedirectToAction("Dashboard", "Main", new { area = "Main", q = Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary) });
                }
            }
            return RedirectToAction("Dashboard", "Main");
        }
        #endregion

        #region BusinessUnitDashboard
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.BusinessUnitDashboard })]
        [CryptoValueProvider]
        public ActionResult BusinessUnitDashboard(string matterRef, int? filterBusinessUnit)
        {
            this.RedirectBackUrl = Request.RawUrl;
            //Audit
            AuditManager.SaveAudit("User has visited Business Unit Dashboard.", "/Main/BusinessUnitDashboard", SessionHelper.LoggedUserInfo.UserName, SessionHelper.LoggedUserInfo.UserId);

            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null)
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.BusinessUnitDashboard;

            Uri urlReferrer = this.ControllerContext.RequestContext.HttpContext.Request.UrlReferrer;
            var mainDBViewModel = new MainDashboardViewModel();

            if (TempData["searchText"] != null && string.IsNullOrEmpty(matterRef))
                TempData.Remove("searchText");
            if (TempData["filterBusinessUnit"] != null && filterBusinessUnit > 0)
                TempData.Remove("filterBusinessUnit");

            if (!string.IsNullOrEmpty(matterRef))
            {
                mainDBViewModel.MatterList.SearchField = matterRef;
                TempData["searchText"] = matterRef;
            }
            if (filterBusinessUnit > 0)
            {
                mainDBViewModel.FilterBusinessUnit = filterBusinessUnit;
                TempData["filterBusinessUnit"] = filterBusinessUnit;
            }


            mainDBViewModel.BuisnessUnitList = CommonManager.GetAllBusinessUnits();


            return View(mainDBViewModel);
        }

        [HttpPost]
        public ActionResult SearchBusinessUnitMatter(MainDashboardViewModel mainDashboardViewModel)
        {
            if (mainDashboardViewModel != null && mainDashboardViewModel.MatterList != null)
            {
                var qsDictionary = new Dictionary<string, string>();

                if (!string.IsNullOrEmpty(mainDashboardViewModel.MatterList.SearchField))
                {
                    TempData["searchText"] = mainDashboardViewModel.MatterList.SearchField;
                    qsDictionary.Add("matterRef", mainDashboardViewModel.MatterList.SearchField);
                }
                else
                    TempData.Remove("searchText");

                if (mainDashboardViewModel.FilterBusinessUnit > 0)
                {
                    TempData["filterBusinessUnit"] = mainDashboardViewModel.FilterBusinessUnit;
                    qsDictionary.Add("filterBusinessUnit", mainDashboardViewModel.FilterBusinessUnit.ToString());
                }
                else
                    TempData.Remove("filterBusinessUnit");

                if (qsDictionary.Count > 0)
                {
                    qsDictionary.Add("AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString());
                    return RedirectToAction("BusinessUnitDashboard", "Main", new { area = "Main", q = Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary) });
                }
            }
            return RedirectToAction("BusinessUnitDashboard", "Main");
        }
        #endregion

        #region Common

        /// <summary>
        /// get matter details by id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.BusinessUnitDashboard })]
        public ActionResult ViewMatter(int id)
        {
            var matterVm = new MatterViewModel();
            var matterMgr = new MatterManager();
            matterVm = matterMgr.GetMatterById(id);
            return View(matterVm);
        }

        /// <summary>
        /// Approve the matter for reporting purpose.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="ID">Matter ID (integer) is required.</param>
        /// <param name="HODComments">HOD's reasonable comments (text) are required.</param>
        /// <returns>Redirection to the list view.</returns>
        public ActionResult ApproveMatterForReporting(int ID, string HODComments)
        {
            if (ID <= 0 || string.IsNullOrEmpty(HODComments))
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);
                return null;
            }

            var matterManager = new MatterManager();
            var isSuccess = matterManager.UpdateMatterReportingStatusByHOD(ID, VarConstants.Reportable_Approved, HODComments);

            if (isSuccess)
            {
                var backUrl = this.RedirectBackUrlKeep;
                if (backUrl != null)
                    return Redirect(backUrl);
                else
                    return RedirectToAction("Dashboard", "Main");
            }
            else
                return Redirect(Request.UrlReferrer.PathAndQuery);
        }

        /// <summary>
        /// Reject the matter for reporting purpose.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="ID">Matter ID (integer) is required.</param>
        /// <param name="HODComments">HOD's reasonable comments (text) are required.</param>
        /// <returns>Redirection to the list view.</returns>
        public ActionResult RejectMatterForReporting(int ID, string HODComments)
        {
            if (ID <= 0 || string.IsNullOrEmpty(HODComments))
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);
                return null;
            }

            var matterManager = new MatterManager();
            var isSuccess = matterManager.UpdateMatterReportingStatusByHOD(ID, VarConstants.Reportable_Rejected, HODComments);

            if (isSuccess)
            {
                var backUrl = this.RedirectBackUrlKeep;
                if (backUrl != null)
                    return Redirect(backUrl);
                else
                    return RedirectToAction("Dashboard", "Main");
            }
            else
                return Redirect(Request.UrlReferrer.PathAndQuery);
        }

        public ActionResult GetMatterList(int limit, int fromRowNumber, string sortColumn, string sortDirection, int? mode = 0)
        {
            string loggedInUserFullName = !string.IsNullOrEmpty(SessionHelper.LoggedUserInfo.FullName) ? SessionHelper.LoggedUserInfo.FullName : string.Empty;
            bool IsAdminUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)(SystemTypeEnum.ServiceProviderAdmin)) ? true : false;
            bool IsHighlyConfidentialUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)(SystemTypeEnum.ServiceProviderAdmin) || x.Id == (int)(SystemTypeEnum.SuperGroupLegal) || x.Id == (int)(SystemTypeEnum.SeniorLegalLeadershipStaff)) ? true : false;
            Uri urlReferrer = this.ControllerContext.RequestContext.HttpContext.Request.UrlReferrer;
            bool IsAdminMainDashboard = SessionHelper.LoggedUserInfo.SelectedDashboardID == (int)UserAccessEnum.MainDashboard && IsAdminUser ? true : false;
            string systemType = urlReferrer.AbsolutePath.Contains(UserAccessEnum.BusinessUnitDashboard.ToString()) ? SystemTypes.BusinessUnit.ToString() : SystemTypes.GroupLegal.ToString();
            mode = TempData["mode"] != null ? Convert.ToInt32(TempData["mode"].ToString()) : 0;

            int? filterBusinessUnit = -1;
            int? filterOffice = -1;
            int? filterCountry = -1;
            int? filterLegalDiscipline = -1;

            if (mode == 1)
            {
                TempData.Keep("mode");
                TempData.Remove("searchText");
                TempData.Remove("filterBusinessUnit");
                TempData.Remove("filterOffice");
                TempData.Remove("filterCountry");
                TempData.Remove("filterLegalDiscipline");
            }
            else
            {
                filterBusinessUnit = (TempData["filterBusinessUnit"] != null ? Convert.ToInt32(TempData["filterBusinessUnit"]) : -1);
                filterOffice = (TempData["filterOffice"] != null ? Convert.ToInt32(TempData["filterOffice"]) : -1);
                filterCountry = (TempData["filterCountry"] != null ? Convert.ToInt32(TempData["filterCountry"]) : -1);
                filterLegalDiscipline = (TempData["filterLegalDiscipline"] != null ? Convert.ToInt32(TempData["filterLegalDiscipline"]) : -1);
                searchText = (TempData["searchText"] != null ? TempData["searchText"] : "") as string;
                TempData.Keep("searchText");
                TempData.Keep("filterBusinessUnit");
                TempData.Keep("filterOffice");
                TempData.Keep("filterCountry");
                TempData.Keep("filterLegalDiscipline");
            }

            bool system = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)SystemTypeEnum.AuthorisedBusinessStaff);
            MatterListViewModel objMatterListViewModel = new MatterListViewModel();

            objMatterListViewModel.IsBu = system ? true : false;

            objMatterListViewModel.IsAdmin = false;
            objMatterListViewModel.MattersList = LookupManager.GetMattersListByRustyloading(limit, fromRowNumber, SessionHelper.LoggedUserInfo.Roles, sortColumn, sortDirection, searchText, filterBusinessUnit, filterOffice, filterCountry, filterLegalDiscipline, loggedInUserFullName, systemType, IsAdminUser, IsAdminMainDashboard, IsHighlyConfidentialUser);

            return PartialView("~/Areas/Section/Views/Shared/_MatterListPartial.cshtml", objMatterListViewModel);
        }

        public ActionResult GetMatterDraftList(int limit, int fromRowNumber, string sortColumn, string sortDirection, int? mode = 0)
        {

            string loggedInUserFullName = !string.IsNullOrEmpty(SessionHelper.LoggedUserInfo.FullName) ? SessionHelper.LoggedUserInfo.FullName : string.Empty;
            bool IsAdminUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)(SystemTypeEnum.ServiceProviderAdmin)) ? true : false;
            bool IsHighlyConfidentialUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)(SystemTypeEnum.ServiceProviderAdmin) || x.Id == (int)(SystemTypeEnum.SuperGroupLegal) || x.Id == (int)(SystemTypeEnum.SeniorLegalLeadershipStaff)) ? true : false;
            Uri urlReferrer = this.ControllerContext.RequestContext.HttpContext.Request.UrlReferrer;
            bool IsAdminMainDashboard = SessionHelper.LoggedUserInfo.SelectedDashboardID == (int)UserAccessEnum.MainDashboard && IsAdminUser ? true : false;
            string systemType = urlReferrer.AbsolutePath.Contains(UserAccessEnum.BusinessUnitDashboard.ToString()) ? SystemTypes.BusinessUnit.ToString() : SystemTypes.GroupLegal.ToString();
            mode = TempData["mode"] != null ? Convert.ToInt32(TempData["mode"].ToString()) : 0;
            int? filterBusinessUnit = -1;
            int? filterOffice = -1;
            int? filterCountry = -1;
            int? filterLegalDiscipline = -1;

            if (mode == 1)
            {
                TempData.Keep("mode");
                TempData.Remove("searchText");
                TempData.Remove("filterBusinessUnit");
                TempData.Remove("filterOffice");
                TempData.Remove("filterCountry");
                TempData.Remove("filterLegalDiscipline");
            }
            else
            {
                filterBusinessUnit = (TempData["filterBusinessUnit"] != null ? Convert.ToInt32(TempData["filterBusinessUnit"]) : -1);
                filterOffice = (TempData["filterOffice"] != null ? Convert.ToInt32(TempData["filterOffice"]) : -1);
                filterCountry = (TempData["filterCountry"] != null ? Convert.ToInt32(TempData["filterCountry"]) : -1);
                filterLegalDiscipline = (TempData["filterLegalDiscipline"] != null ? Convert.ToInt32(TempData["filterLegalDiscipline"]) : -1);
                searchText = (TempData["searchText"] != null ? TempData["searchText"] : "") as string;
                TempData.Keep("searchText");
                TempData.Keep("filterBusinessUnit");
                TempData.Keep("filterOffice");
                TempData.Keep("filterCountry");
                TempData.Keep("filterLegalDiscipline");
            }

            bool system = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)SystemTypeEnum.AuthorisedBusinessStaff);
            DraftMattersListViewModel objDraftMatterListViewModel = new DraftMattersListViewModel();

            objDraftMatterListViewModel.IsBu = system ? true : false;

            objDraftMatterListViewModel.IsAdmin = false;
            objDraftMatterListViewModel = LookupManager.GetDraftMattersListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, searchText, filterBusinessUnit, filterOffice, filterCountry, filterLegalDiscipline, loggedInUserFullName, systemType, IsAdminUser, IsAdminMainDashboard, IsHighlyConfidentialUser);
            return PartialView("~/Areas/Section/Views/Shared/_DraftMattersListPartial.cshtml", objDraftMatterListViewModel);
        }

        public ActionResult GetSingleMatterInvoiceList(int limit = 8, int fromRowNumber = 0, string sortColumn = "Invoice_Number", string sortDirection = "asc")
        {
            bool IsAdminUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)(SystemTypeEnum.ServiceProviderAdmin)) ? true : false;

            searchText = (TempData["searchText"] != null ? TempData["searchText"] : "") as string;
            searchText = !string.IsNullOrEmpty(searchText) ? searchText : TempData["matterRef"] as string;
            matterRefNo = searchText;
            TempData.Keep("searchText");
            TempData.Keep("matterRef");
            InvoiceListViewModel objInvoiceListViewModel = new InvoiceListViewModel();
            objInvoiceListViewModel.Invoices = LookupManager.GetMatterInoviceListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, searchText, IsAdminUser, matterRefNo);
            return PartialView("~/Areas/Section/Views/Shared/_InvoiceListPartial.cshtml", objInvoiceListViewModel);

        }


        public ActionResult GetPOIncreaseRequiredList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            int rcnt = 0;
            string loggedInUserFullName = !string.IsNullOrEmpty(SessionHelper.LoggedUserInfo.FullName) ? SessionHelper.LoggedUserInfo.FullName : "";
            POIncreaseRequiredViewModelList objPOIncreaseRequiredListViewModel = new POIncreaseRequiredViewModelList();
            objPOIncreaseRequiredListViewModel.POIncreaseRequiredList = LookupManager.GetPOIncreaseRequiredListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, loggedInUserFullName, out rcnt);
            objPOIncreaseRequiredListViewModel.RecordCount = rcnt;
            return PartialView("~/Areas/Main/Views/Shared/_POIncreaseRequiredList.cshtml", objPOIncreaseRequiredListViewModel);
        }

        #endregion

        #region AdminDashboard
        [HttpPost]
        public ActionResult SearchAdminMatter(MainDashboardViewModel mainDashboardViewModel)
        {
            if (mainDashboardViewModel != null && mainDashboardViewModel.MatterList != null)
            {
                if (!string.IsNullOrEmpty(mainDashboardViewModel.MatterList.SearchField))
                {
                    // JIRA : EXICHM-428 ( trimming & lowercase match)
                    TempData["searchText"] = mainDashboardViewModel.MatterList.SearchField.Trim().ToLower();
                    bool isMatterExist = LookupManager.IsMatterExist(mainDashboardViewModel.MatterList.SearchField);
                    if (isMatterExist)
                    {
                        var qsDictionary = new Dictionary<string, string>
                                {
                                    {"matterRef", mainDashboardViewModel.MatterList.SearchField.Trim().ToLower()},
                                    { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()}
                                };
                        return RedirectToAction("AdminDashboard", "Main", new { area = "Main", q = Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary) });
                    }
                    else
                    {
                        base.MessageStyle = "color:red;";
                        base.PageMessage = "Matter reference does not exist.";
                    }
                }
            }

            return RedirectToAction("SelectMatter", "Main", new { area = "Main" });
        }

        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult SelectMatter()
        {
            if (base.PageMessage != null)
            {
                ShowMessage(base.PageMessage, MessageType.danger);
            }
            //Audit
            AuditManager.SaveAudit("User has visited Admin Dashboard.", "/Main/AdminDashboard", SessionHelper.LoggedUserInfo.UserName, SessionHelper.LoggedUserInfo.UserId);

            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null)
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.AdminDashboard;

            MainDashboardViewModel mainDBViewModel = new MainDashboardViewModel();
            return View(mainDBViewModel);
        }

        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [CryptoValueProvider]
        public ActionResult AdminDashboard(string matterRef)
        {
            this.RedirectBackUrl = Request.RawUrl;

            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null)
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.AdminDashboard;

            MainDashboardViewModel mainDBViewModel = new MainDashboardViewModel();
            //mainDBViewModel.MatterList.SearchField = matterRef;
            if (!string.IsNullOrEmpty(matterRef))
            {
                TempData["searchText"] = matterRef;
                TempData.Keep("searchText");
            }
            if (!string.IsNullOrEmpty(matterRef))
            {
                TempData["matterRef"] = matterRef;
                TempData.Keep("matterRef");
            }
            if (TempData.ContainsKey("Message"))
            {
                ViewBag.MessageType = TempData["MessageType"];
                ViewBag.Message = TempData["Message"];
                ModelState.AddModelError(string.Empty, ViewBag.Message);
            }
            return View(mainDBViewModel);
        }


        public ActionResult GetSingleMatterSubMatterList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            bool IsAdminUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)(SystemTypeEnum.ServiceProviderAdmin)) ? true : false;
            matterRefNo = TempData["matterRef"] as string;
            TempData.Keep("matterRef");
            SubMatterListViewModel objSubMatterListViewModel = new SubMatterListViewModel();
            objSubMatterListViewModel.SubMattersList = LookupManager.GetSubMatterListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, searchText, IsAdminUser, matterRefNo);
            objSubMatterListViewModel.HideAction = true;
            return PartialView("~/Areas/Section/Views/Shared/_SubMatterListPartial.cshtml", objSubMatterListViewModel);
        }

        public ActionResult GetSingleMatter(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            matterRefNo = TempData["matterRef"] as string;
            TempData.Keep("matterRef");
            MatterListViewModel objMatterListViewModel = new MatterListViewModel();
            objMatterListViewModel.MattersList = LookupManager.GetMatterByReferenceNumber(matterRefNo);
            objMatterListViewModel.IsAdmin = true;
            objMatterListViewModel.IsBu = false;
            return PartialView("~/Areas/Section/Views/Shared/_MatterListPartial.cshtml", objMatterListViewModel);
        }

        [CryptoValueProvider]
        public ActionResult GetMatterInstructionsAndInvoices(string selectedMatterRef = "")
        {
            MainDashboardViewModel objMainDashboardViewModel = new MainDashboardViewModel();
            objMainDashboardViewModel.IsBuSystemType = false;
            if (!string.IsNullOrEmpty(selectedMatterRef))
            {
                bool IsAdminUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)(SystemTypeEnum.ServiceProviderAdmin)) ? true : false;
                objMainDashboardViewModel.InstructionList.InstructionList = LookupManager.GetInstructionsListByRustyloading(-1, 0, "Instruction_Reference", "desc", searchText, IsAdminUser, selectedMatterRef, SessionHelper.LoggedUserInfo.FullName);
                objMainDashboardViewModel.InvoiceList.Invoices = LookupManager.GetMatterInoviceListByRustyloading(-1, 0, "Invoice_Number", "desc", searchText, IsAdminUser, selectedMatterRef);
                objMainDashboardViewModel.SubMatterList.SubMattersList = LookupManager.GetSubMatterListByRustyloading(-1, 0, "MatterId", "desc", searchText, IsAdminUser, selectedMatterRef);
                bool system = SessionHelper.LoggedUserInfo.Roles.Any(x => (x.Id == (int)SystemTypeEnum.AuthorisedBusinessStaff || x.Id == (int)SystemTypeEnum.ServiceProviderAdmin));
                system = system == false ? (SessionHelper.LoggedUserInfo.SelectedDashboardID == (int)Exigent.Common.Enums.UserAccessEnum.BusinessUnitDashboard) : system;
                var matter = MatterManager.GetMatterBlock(selectedMatterRef);
                if (system)
                {
                    int rcnt = 0;
                    objMainDashboardViewModel.RFQList.RfqVm = LookupManager.GetMatterRFQListByRustyloading(-1, 0, "Status", "asc", selectedMatterRef, SessionHelper.LoggedUserInfo.FullName, out rcnt);
                }
                if (matter.System == SystemTypes.BusinessUnit.ToString())
                    objMainDashboardViewModel.IsBuSystemType = true;
            }
            return PartialView("~/Areas/Main/Views/Shared/_SelectMatterPartial.cshtml", objMainDashboardViewModel);
        }


        public ActionResult GetSingleMatterInstructionList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            bool IsAdminUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)(SystemTypeEnum.ServiceProviderAdmin)) ? true : false;
			bool IsGSLUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)(SystemTypeEnum.SuperGroupLegal)) ? true : false;
			if (IsGSLUser)
				ViewBag.UseOverviewLink = false;
			searchText = "" as string;
            matterRefNo = TempData["matterRef"] as string;
            TempData.Keep("matterRef");
            InstructionListViewModel objInstructionListViewModel = new InstructionListViewModel();
            objInstructionListViewModel.InstructionList = LookupManager.GetInstructionsListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, searchText, IsAdminUser, matterRefNo);
            return PartialView("~/Areas/Section/Views/Shared/_InstructionListPartial.cshtml", objInstructionListViewModel);
        }


        public ActionResult GetSingleMatterPOTaskList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            int reccount = 0;
            matterRefNo = TempData["matterRef"] as string;
            TempData.Keep("matterRef");
            POTasksViewModelList objPOTaskListViewModel = new POTasksViewModelList();
            objPOTaskListViewModel.POTasksList = LookupManager.GetMatterPOTaskListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, matterRefNo, out reccount);
            objPOTaskListViewModel.RecordCount = reccount;
            return PartialView("~/Areas/Main/Views/Shared/_MatterPOTasksListPartial.cshtml", objPOTaskListViewModel);
        }

        public ActionResult GetSingleMatterGRVTaskList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            int reccount = 0;
            matterRefNo = TempData["matterRef"] as string;
            TempData.Keep("matterRef");
            GRVTasksViewModelList objGRVTaskListViewModel = new GRVTasksViewModelList();
            objGRVTaskListViewModel.GRVTasksList = LookupManager.GetMatterGRVTaskListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, matterRefNo, out reccount);
            objGRVTaskListViewModel.RecordCount = reccount;
            return PartialView("~/Areas/Main/Views/Shared/_MatterGRVTasksListPartial.cshtml", objGRVTaskListViewModel);
        }
        #endregion

        #region BU Time Recording
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard })]
        public ActionResult BUTimeRecording()
        {

            BUTimeRecordingViewModel bUTimeRecordingViewModel = new BUTimeRecordingViewModel();

            bUTimeRecordingViewModel.BuisnessUnitList = CommonManager.GetAllBusinessUnits();
            ViewBag.Discipline = CommonManager.GetLegalDiscipline(SystemTypes.GroupLegal);

            return View(bUTimeRecordingViewModel);
        }

        public ActionResult GetBUTimeRecordingList(string sortcolumn = "", string sortdirection = "", int? userId = 0)
        {
            LookupManager _lookupManager = new LookupManager();

            var model = _lookupManager.GetBUTimeRecordingListByRustyloading(sortcolumn, sortdirection, userId);

            return PartialView("_BUTimeRecordingListPartial", model);
        }

        public ActionResult GetBUTimeRecordingListPrevious(string sortcolumn = "", string sortdirection = "", int? userId = 0)
        {
            LookupManager _lookupManager = new LookupManager();

            var model = _lookupManager.GetBUTimeRecordingListByRustyloading(sortcolumn, sortdirection, userId);

            return PartialView("_BUTimeRecordingPreviousMonth", model);
        }

        [HttpPost]
        public ActionResult BUTimeRecording(BUTimeRecordingViewModel bUTimeRecordVm)
        {
            BUManager bUManager = new BUManager();
            if (bUTimeRecordVm != null)
            {
                //Manual Validation Applied.
                if (string.IsNullOrEmpty(bUTimeRecordVm.Name))
                    return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });



                ModelState.Clear();

                if (!this.TryValidateModel(bUTimeRecordVm))
                    return View(bUTimeRecordVm);

                if (!ModelState.IsValid)
                {
                    return View(bUTimeRecordVm);
                }
                else
                {
                    var isSuccess = bUManager.SaveBUTimeRecord(bUTimeRecordVm, SessionHelper.LoggedUserInfo.UserId);
                    bUTimeRecordVm.BuisnessUnitList = CommonManager.GetAllBusinessUnits();
                    ViewBag.Discipline = CommonManager.GetLegalDiscipline(SystemTypes.GroupLegal);
                    if (!isSuccess)
                    {
                        ShowMessage(VarConstants.PercentageError, MessageType.danger, true);
                        return View(bUTimeRecordVm);
                    }
                    else
                    {
                        ShowMessage(VarConstants.TimeAdded, MessageType.success, true);
                        return View(bUTimeRecordVm);
                    }
                }
            }
            else
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
        }

        public ActionResult GetBUTimeRecordDetails(BUTimeRecordingViewModel bUTimeRecordVm)
        {
            BUManager bUManager = new BUManager();
            if (!string.IsNullOrEmpty(bUTimeRecordVm.Name) && (bUTimeRecordVm.Date != null))
            {
                string month = bUTimeRecordVm.Date.Month.ToString();
                string year = bUTimeRecordVm.Date.Year.ToString();
                var bUTimeRecordingVM = bUManager.GetExistingBUTimeRecord(bUTimeRecordVm.Name, month, year);
                return Json(bUTimeRecordingVM, JsonRequestBehavior.AllowGet);
            }
            else
                return Json(null, JsonRequestBehavior.AllowGet);
        }

        [CryptoValueProvider]

        public ActionResult EditBUTimeRecording(int id, int businessUnit)
        {
            var model = BUManager.GetBUTimeRecordingById(id, businessUnit);
            model.BuisnessUnitList = CommonManager.GetAllBusinessUnits();
            ViewBag.Discipline = CommonManager.GetLegalDiscipline(SystemTypes.GroupLegal);
            return PartialView("~/Areas/Main/Views/Shared/_EditBUTimeRecordingView.cshtml", model);
        }

        public ActionResult EditBUTimeRecord(BUTimeRecordingViewModel model)
        {
            var isSuccess = BUManager.UpdateBuTimeRecording(model, SessionHelper.LoggedUserInfo.UserId);
            model.BuisnessUnitList = CommonManager.GetAllBusinessUnits();
            ViewBag.Discipline = CommonManager.GetLegalDiscipline(SystemTypes.GroupLegal);
            model.Date = DateTime.Now;
            if (isSuccess == VarConstants.TimeAdded)
            {
                ShowMessage(VarConstants.TimeAdded, MessageType.success, true);
                return View("BUTimeRecording", model);
            }
            else
            {
                ShowMessage(isSuccess, MessageType.danger, true);
                return View("BUTimeRecording", model);
            }

        }

        #endregion

        #region Timesheet Dashboard for Admin Users

        //Timesheet Dashboard
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult TimeSheet()
        {
            InvoiceTimesheetCaptureTasksViewModel invoiceTimesheetCaptureTasksVM = new InvoiceTimesheetCaptureTasksViewModel();
            invoiceTimesheetCaptureTasksVM.TimesheetsList = new List<InvoiceTimesheetCaptureTasksListViewModel>();
            return View(invoiceTimesheetCaptureTasksVM);
        }

        // Gets the list of Outstanding Timesheets
        public ActionResult GetPendingTimesheetsList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            int count = 0;
            LookupManager lookupManager = new LookupManager();
            InvoiceTimesheetCaptureTasksViewModel invoiceTimesheetCaptureTasksVM = new InvoiceTimesheetCaptureTasksViewModel
            {
                TimesheetsList = lookupManager.GetPendingTimesheets(limit, fromRowNumber, sortColumn, sortDirection, out count).ToList()
            };
            invoiceTimesheetCaptureTasksVM.RecordCount = count;
            return PartialView("_InvoiceTimesheetsListPartial", invoiceTimesheetCaptureTasksVM);
        }

        // Redirects to TimesheetCaptureTask page
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [CryptoValueProvider]
        public ActionResult TimesheetCaptureTask(string id, string invoiceNumber)
        {
            InvoiceTimesheetCaptureTasksListViewModel invoiceTimesheetCaptureTaskslistVM = new InvoiceTimesheetCaptureTasksListViewModel();
            invoiceTimesheetCaptureTaskslistVM.ID = Convert.ToInt32(id);
            invoiceTimesheetCaptureTaskslistVM.InvoiceVM = new InvoiceViewModel()
            {
                Invoice_Number = invoiceNumber
            };
            return View(invoiceTimesheetCaptureTaskslistVM);
        }

        // Update status of Outstanding Timesheets from pending to complete
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [CryptoValueProvider]
        public ActionResult CompleteTimesheet(string id)
        {
            InvoiceManager invoiceManager = new InvoiceManager();
            if (!string.IsNullOrEmpty(id))
            {
                invoiceManager.CompleteTimesheet(Convert.ToInt32(id));
                return RedirectToAction("TimeSheet", "Main");
            }
            else
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
        }

        // Gets the Invoice details and timesheets 
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [CryptoValueProvider]
        public ActionResult InvoiceDetails(string invoiceNumber)
        {
            if (!string.IsNullOrEmpty(invoiceNumber))
            {
                var lstInvoiceVm = new List<SearchInvoiceViewModel>();
                int cnt = 0;
                lstInvoiceVm = LookupManager.GetInvoiceApprovalListByRustyloading(1, 0, string.Empty, string.Empty, invoiceNumber, string.Empty, string.Empty, out cnt);
                return View(lstInvoiceVm);
            }
            else
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });

        }

        // Create / Edit Timesheet
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [CryptoValueProvider]
        public ActionResult ManageTimesheet(string invoiceId, string invoiceNumber, int id = 0)
        {
            if (!string.IsNullOrEmpty(invoiceId) && !string.IsNullOrEmpty(invoiceNumber))
            {
                InvoiceTimesheetsViewModel invoiceTimesheetsViewModel = new InvoiceTimesheetsViewModel();
                if (id > 0)
                {
                    InvoiceManager invoiceManager = new InvoiceManager();
                    invoiceTimesheetsViewModel = invoiceManager.GetTimesheetById(id);
                }
                invoiceTimesheetsViewModel.InvoiceID = Convert.ToInt32(invoiceId);
                invoiceTimesheetsViewModel.Invoice_Number = invoiceNumber;
                invoiceTimesheetsViewModel.LawyerList = DropDownManager.GetLawyersList(invoiceNumber);
                //invoiceTimesheetsViewModel.TaskList = DropDownManager.GetTasksList();


                return View(invoiceTimesheetsViewModel);
            }
            else
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
        }

        // Save Timesheet 
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult ManageTimesheet(InvoiceTimesheetsViewModel invoiceTimesheetsViewModel)
        {
            if (invoiceTimesheetsViewModel != null)
            {
                InvoiceManager invoiceManager = new InvoiceManager();
                if (!ModelState.IsValid)
                {
                    invoiceTimesheetsViewModel.LawyerList = DropDownManager.GetLawyersList(invoiceTimesheetsViewModel.Invoice_Number);

                    //invoiceTimesheetsViewModel.TaskList = DropDownManager.GetTasksList();
                    return View(invoiceTimesheetsViewModel);
                }
                if (invoiceTimesheetsViewModel.ID == 0)
                    invoiceManager.SaveTimesheet(invoiceTimesheetsViewModel);
                else if (invoiceTimesheetsViewModel.ID > 0)
                    invoiceManager.UpdateTimesheet(invoiceTimesheetsViewModel);
                var qsDictionary = new Dictionary<string, string> { { "invoiceNumber", invoiceTimesheetsViewModel.Invoice_Number.ToString() } };

                return RedirectToAction("InvoiceDetails", "Main", new { q = Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary) });
            }
            else
            {
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
            }
        }

        // Get timesheets list
        public ActionResult GetTimesheets(int limit, int fromRowNumber, string sortColumn, string sortDirection, string invoiceNumber)
        {
            int count = 0;
            LookupManager lookupManager = new LookupManager();
            SearchInvoiceViewModel searchInvoiceViewModel = new SearchInvoiceViewModel
            {
                InvoiceTimesheetsListVM = lookupManager.GetTimesheets(limit, fromRowNumber, sortColumn, sortDirection, invoiceNumber, out count).ToList()
            };
            searchInvoiceViewModel.RecordCount = count;
            return PartialView("_TimesheetsListPartial", searchInvoiceViewModel);
        }

        #endregion

        #region Reportable Matters Tab

        /// <summary>
        /// GET method for reportable matters tab.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="mode">Specifies if should get filter data from TempData.</param>
        /// <returns></returns>
        [HttpGet]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.MainDashboard })]
        public ActionResult ReportableMatter(string mode = "")
        {

            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null && !SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)SystemTypeEnum.LegalProfessionalStaff))
            {
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.MainDashboard;

                var model = new MatterListViewModel();

                if (string.IsNullOrEmpty(model.FilterByMatterStatus))
                    model.FilterByMatterStatus = string.Empty;

                if (mode != "UseTempData")
                {
                    MatterManager.GetReportableMatters(model);
                    TempData["FirstLoad"] = true;

                    TempData["FilterByBusinessUnit"] = model.FilterByBusinessUnit;
                    TempData["FilterByMatterStatus"] = model.FilterByMatterStatus;
                    TempData["FilterByCountry"] = model.FilterByCountry;
                    TempData["FilterByOffice"] = model.FilterByOffice;
                    TempData["FilterByOperation"] = model.FilterByOperation;
                    TempData["FilterByLegalDiscipline"] = model.FilterByLegalDiscipline;
                    TempData["FilterBySubDiscipline"] = model.FilterBySubDiscipline;
                    TempData["FilterByReportTemplate"] = model.FilterByReportTemplate;
                    TempData["FilterByMatterReportClassification"] = model.FilterByMatterReportClassification;
                    TempData["FilterByLeadLawyer"] = model.FilterByLeadLawyer;
                }
                else
                {
                    TempData["FirstLoad"] = false;

                    model.FilterByBusinessUnit = GetSearchListFromTempData("FilterByBusinessUnit");
                    model.FilterByMatterStatus = GetSearchStringFromTempData("FilterByMatterStatus");
                    model.FilterByCountry = GetSearchListFromTempData("FilterByCountry");
                    model.FilterByOffice = GetSearchListFromTempData("FilterByOffice");
                    model.FilterByOperation = GetSearchListFromTempData("FilterByOperation");
                    model.FilterByLegalDiscipline = GetSearchListFromTempData("FilterByLegalDiscipline");
                    model.FilterBySubDiscipline = GetSearchListFromTempData("FilterBySubDiscipline");
                    model.FilterByReportTemplate = GetSearchListFromTempData("FilterByReportTemplate");
                    model.FilterByMatterReportClassification = GetSearchListFromTempData("FilterByMatterReportClassification");
                    model.FilterByLeadLawyer = GetSearchListFromTempData("FilterByLeadLawyer");

                }

                var commonManager = new CommonManager();
                var businessUnits = commonManager.GetBusinessUnitsList();
                //var reportClassificationDetail = commonManager.GetReportClassificationDetailList(SystemTypeEnum.GroupLegalLeadLawyers.ToString()).ToList();
                var countries = commonManager.GetCountries();
                var office = commonManager.GetOffices();
                var operation = commonManager.GetOperations();
                var legalDiscipline = commonManager.GetLegalDisciplineForReportable();
                var subDiscipline = commonManager.GetSubDiscipline();
                var reportTemplate = commonManager.GetApplicationReportTemplate();
                var matterReportClassification = commonManager.GetMatterReportClassificationOption();
                var leadLawyer = commonManager.GetLeadLawyers();
                //var reportClassificationCategories = reportClassificationDetail
                //    .Select(x => x.Value).Distinct()
                //    .Select(x => new SelectListItem
                //    {
                //        Text = x,
                //        Value = x
                //    }).ToList();

                ViewBag.BusinessUnits = businessUnits;
                ViewBag.MatterStatus = commonManager.GetMatterStatusList().Where(m => m.Text != MatterStatus.Closed.ToString()).ToList();
                ViewBag.Country = countries;
                ViewBag.Office = office;
                ViewBag.Operation = operation.GroupBy(x => x.Text).Select(x => x.First()).ToList();
                ViewBag.LegalDiscipline = legalDiscipline.GroupBy(x => x.Text).Select(x => x.First()).ToList();
                ViewBag.SubDiscipline = subDiscipline;
                ViewBag.ReportTemplate = reportTemplate;
                ViewBag.MatterReportClassificationOption = matterReportClassification;
                ViewBag.LeadLawyer = leadLawyer;
                //ViewBag.ReportClassificationCategories = reportClassificationCategories;

                return View(model);
            }
            else
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
        }


        /// <summary>
        /// Set the filters for Reportable Matters into Temp.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ReportableMatter(MatterListViewModel model = null)
        {
            if (model == null)
                model = new MatterListViewModel();

            if (string.IsNullOrEmpty(model.FilterByMatterStatus))
                model.FilterByMatterStatus = string.Empty;

            TempData["FilterByBusinessUnit"] = false;

            if (model.SearchField != "UseTempData")
            {
                TempData["FilterByBusinessUnit"] = model.FilterByBusinessUnit;
                TempData["FilterByMatterStatus"] = model.FilterByMatterStatus;
                TempData["FilterByCountry"] = model.FilterByCountry;
                TempData["FilterByOffice"] = model.FilterByOffice;
                TempData["FilterByOperation"] = model.FilterByOperation;
                TempData["FilterByLegalDiscipline"] = model.FilterByLegalDiscipline;
                TempData["FilterBySubDiscipline"] = model.FilterBySubDiscipline;
                TempData["FilterByReportTemplate"] = model.FilterByReportTemplate;
                TempData["FilterByMatterReportClassification"] = model.FilterByMatterReportClassification;
                TempData["FilterByLeadLawyer"] = model.FilterByLeadLawyer;
            }
            else
            {
                model.FilterByBusinessUnit = GetSearchListFromTempData("FilterByBusinessUnit");
                model.FilterByMatterStatus = GetSearchStringFromTempData("FilterByMatterStatus");
                model.FilterByCountry = GetSearchListFromTempData("FilterByCountry");
                model.FilterByOffice = GetSearchListFromTempData("FilterByOffice");
                model.FilterByOperation = GetSearchListFromTempData("FilterByOperation");
                model.FilterByLegalDiscipline = GetSearchListFromTempData("FilterByLegalDiscipline");
                model.FilterBySubDiscipline = GetSearchListFromTempData("FilterBySubDiscipline");
                model.FilterByReportTemplate = GetSearchListFromTempData("FilterByReportTemplate");
                model.FilterByMatterReportClassification = GetSearchListFromTempData("FilterByMatterReportClassification");
                model.FilterByLeadLawyer = GetSearchListFromTempData("FilterByLeadLawyer");
            }

            var commonManager = new CommonManager();
            var businessUnits = commonManager.GetBusinessUnitsList();
            //var reportClassificationDetail = commonManager.GetReportClassificationDetailList(SystemTypeEnum.GroupLegalLeadLawyers.ToString()).ToList();
            var countries = commonManager.GetCountries();
            var office = commonManager.GetOffices();
            var operation = commonManager.GetOperations();
            var legalDiscipline = commonManager.GetLegalDisciplineForReportable();
            var subDiscipline = commonManager.GetSubDiscipline();
            var reportTemplate = commonManager.GetApplicationReportTemplate();
            var matterReportClassification = commonManager.GetMatterReportClassificationOption();
            var leadLawyer = commonManager.GetLeadLawyers();
            //var reportClassificationCategories = reportClassificationDetail
            //    .Select(x => x.Value).Distinct()
            //    .Select(x => new SelectListItem
            //    {
            //        Text = x,
            //        Value = x
            //    }).ToList();

            ViewBag.BusinessUnits = businessUnits;
            ViewBag.MatterStatus = commonManager.GetMatterStatusList().Where(m => m.Text != MatterStatus.Closed.ToString()).ToList();
            //ViewBag.ReportClassificationCategories = reportClassificationCategories;
            ViewBag.Country = countries;
            ViewBag.Office = office;
            ViewBag.Operation = operation.GroupBy(x => x.Text).Select(x => x.First()).ToList();
            ViewBag.LegalDiscipline = legalDiscipline.GroupBy(x => x.Text).Select(x => x.First()).ToList();
            ViewBag.SubDiscipline = subDiscipline;
            ViewBag.ReportTemplate = reportTemplate;
            ViewBag.MatterReportClassificationOption = matterReportClassification;
            ViewBag.LeadLawyer = leadLawyer;
            return View(model);
        }

        /// <summary>
        /// Get the complete filtered list of Reportable Matters.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetReportableMatters(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            var model = new MatterListViewModel();

            model.FilterByBusinessUnit = GetSearchListFromTempData("FilterByBusinessUnit");
            model.FilterByMatterStatus = GetSearchStringFromTempData("FilterByMatterStatus");
            model.FilterByCountry = GetSearchListFromTempData("FilterByCountry");
            model.FilterByOffice = GetSearchListFromTempData("FilterByOffice");
            model.FilterByOperation = GetSearchListFromTempData("FilterByOperation");
            model.FilterByLegalDiscipline = GetSearchListFromTempData("FilterByLegalDiscipline");
            model.FilterBySubDiscipline = GetSearchListFromTempData("FilterBySubDiscipline");
            model.FilterByReportTemplate = GetSearchListFromTempData("FilterByReportTemplate");
            model.FilterByMatterReportClassification = GetSearchListFromTempData("FilterByMatterReportClassification");
            model.FilterByLeadLawyer = GetSearchListFromTempData("FilterByLeadLawyer");

            var recordCount = 0;
            var showReportable = false;
            if (TempData.ContainsKey("FirstLoad"))
            {
                showReportable = (bool)TempData["FirstLoad"];
            }

            //Search text is blank, displaying all records.
            model.MattersList = LookupManager.GetReportableMattersListByRustyLoading(limit, fromRowNumber, sortColumn, sortDirection, out recordCount,
                                                            model.FilterByBusinessUnit,
                                                            model.FilterByMatterStatus,
                                                            model.FilterByCountry,
                                                            model.FilterByOffice,
                                                            model.FilterByOperation,
                                                            model.FilterByLegalDiscipline,
                                                            model.FilterBySubDiscipline,
                                                            model.FilterByReportTemplate,
                                                            model.FilterByMatterReportClassification,
                                                            model.FilterByLeadLawyer,
                                                            showReportable);

            model.RecordCount = recordCount;

            return PartialView("~/Areas/Main/Views/Shared/_ReportableMatterListPartial.cshtml", model);
        }

        /// <summary>
        /// Get the list of reportable matters for approval (HOD user only).
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetMatterApprovalList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            MatterListViewModel objMatterListViewModel = new MatterListViewModel();

            objMatterListViewModel.MattersList = LookupManager.GetMattersApprovalListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection);

            return PartialView("~/Areas/Main/Views/Shared/_MatterApprovalListPartial.cshtml", objMatterListViewModel);
        }

        /// <summary>
        /// Send the reportable matters for Update to Lead Lawyer.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="matters"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult SendMatterForUpdate(string[] matters)
        {
            var model = new MatterListViewModel();

            model.FilterByBusinessUnit = GetSearchListFromTempData("FilterByBusinessUnit");
            model.FilterByMatterStatus = GetSearchStringFromTempData("FilterByMatterStatus");
            model.FilterByCountry = GetSearchListFromTempData("FilterByCountry");
            model.FilterByOffice = GetSearchListFromTempData("FilterByOffice");
            model.FilterByOperation = GetSearchListFromTempData("FilterByOperation");
            model.FilterByLegalDiscipline = GetSearchListFromTempData("FilterByLegalDiscipline");
            model.FilterBySubDiscipline = GetSearchListFromTempData("FilterBySubDiscipline");
            model.FilterByReportTemplate = GetSearchListFromTempData("FilterByReportTemplate");
            model.FilterByMatterReportClassification = GetSearchListFromTempData("FilterByMatterReportClassification");
            model.FilterByLeadLawyer = GetSearchListFromTempData("FilterByLeadLawyer");

            if (matters != null && matters.Length > 0)
            {
                matters = matters.Where(m => !string.IsNullOrEmpty(m)).ToArray();
            }

            if (matters == null || matters.Length <= 0)
            {
                ShowMessage("Please select a Matter!", MessageType.danger, true);
            }
            else
            {
                bool status = false;

                for (int i = 0; i < matters.Count(); i++)
                {
                    if (!string.IsNullOrEmpty(matters[i]))
                    {
                        var cvp = ChameleonInformExigent.Helpers.Crypto.Decrypt(matters[i], out status);

                        if (status)
                        {
                            var matterId = int.Parse(cvp["id"]);

                            matters[i] = matterId.ToString();
                        }
                    }
                }

                var matterManager = new MatterManager();
                var isSuccess = matterManager.SendMattersToLeadLawyerUpdate(matters);

                if (isSuccess)
                    ShowMessage(VarConstants.ReportableUpdatedSuccess, MessageType.success, true);
                else
                    ShowMessage(VarConstants.ReportableUpdatedError, MessageType.danger, true);
            }

            model.SearchField = "UseTempData";
            return RedirectToAction("ReportableMatter", "Main", new { mode = model.SearchField });
        }

        /// <summary>
        /// Send the reportable matters for approval to HOD.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="matters"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult SendMatterForApproval(string[] matters)
        {
            var model = new MatterListViewModel();

            model.FilterByBusinessUnit = GetSearchListFromTempData("FilterByBusinessUnit");
            model.FilterByMatterStatus = GetSearchStringFromTempData("FilterByMatterStatus");
            model.FilterByReportClassification = GetSearchListFromTempData("FilterByReportClassification");
            model.FilterByReportClassificationCategory = GetSearchListFromTempData("FilterByReportClassificationCategory");

            if (matters != null && matters.Length > 0)
            {
                matters = matters.Where(m => !string.IsNullOrEmpty(m)).ToArray();
            }

            if (matters == null || matters.Length <= 0)
            {
                ShowMessage("Please select a Matter!", MessageType.danger, true);
            }
            else
            {
                bool status = false;

                for (int i = 0; i < matters.Count(); i++)
                {
                    if (!string.IsNullOrEmpty(matters[i]))
                    {
                        var cvp = ChameleonInformExigent.Helpers.Crypto.Decrypt(matters[i], out status);

                        if (status)
                        {
                            var matterId = int.Parse(cvp["id"]);

                            matters[i] = matterId.ToString();
                        }
                    }
                }

                var matterManager = new MatterManager();
                var isSuccess = matterManager.SendMattersToHODApproval(matters);

                if (isSuccess)
                    ShowMessage(VarConstants.ReportableUpdatedSuccess, MessageType.success, true);
                else
                    ShowMessage(VarConstants.ReportableApproveError, MessageType.danger, true);
            }

            model.SearchField = "UseTempData";
            return RedirectToAction("ReportableMatter", "Main", new { mode = model.SearchField });
        }

        /// <summary>
        /// Send approved reportable matters for reporting.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="matters"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult UpdateMatterForReporting(string[] matters)
        {
            var model = new MatterListViewModel();

            model.FilterByBusinessUnit = GetSearchListFromTempData("FilterByBusinessUnit");
            model.FilterByMatterStatus = GetSearchStringFromTempData("FilterByMatterStatus");
            model.FilterByCountry = GetSearchListFromTempData("FilterByCountry");
            model.FilterByOffice = GetSearchListFromTempData("FilterByOffice");
            model.FilterByOperation = GetSearchListFromTempData("FilterByOperation");
            model.FilterByLegalDiscipline = GetSearchListFromTempData("FilterByLegalDiscipline");
            model.FilterBySubDiscipline = GetSearchListFromTempData("FilterBySubDiscipline");
            model.FilterByReportTemplate = GetSearchListFromTempData("FilterByReportTemplate");
            model.FilterByMatterReportClassification = GetSearchListFromTempData("FilterByMatterReportClassification");
            model.FilterByLeadLawyer = GetSearchListFromTempData("FilterByLeadLawyer");

            if (matters == null)
            {
                ShowMessage("Please select a Matter!", MessageType.danger, true);
            }
            else
            {
                bool status = false;

                for (int i = 0; i < matters.Count(); i++)
                {
                    if (!string.IsNullOrEmpty(matters[i]))
                    {
                        var cvp = ChameleonInformExigent.Helpers.Crypto.Decrypt(matters[i], out status);

                        if (status)
                        {
                            var matterId = int.Parse(cvp["id"]);

                            matters[i] = matterId.ToString();
                        }
                    }
                }

                var matterManager = new MatterManager();
                var isSuccess = matterManager.UpdateReportableMatters(matters, model);

                if (isSuccess)
                {
                    ShowMessage(VarConstants.ReportableReportingSuccess, MessageType.success, true);
                }

                else
                    ShowMessage(VarConstants.ReportableYesError, MessageType.danger, true);
            }

            model.SearchField = "UseTempData";
            return RedirectToAction("ReportableMatter", "Main", new { mode = model.SearchField });
        }


        [HttpPost]
        public ActionResult ExportMatters(string[] matters)
        {
            var model = new MatterListViewModel();

            model.FilterByBusinessUnit = GetSearchListFromTempData("FilterByBusinessUnit");
            model.FilterByMatterStatus = GetSearchStringFromTempData("FilterByMatterStatus");
            model.FilterByCountry = GetSearchListFromTempData("FilterByCountry");
            model.FilterByOffice = GetSearchListFromTempData("FilterByOffice");
            model.FilterByOperation = GetSearchListFromTempData("FilterByOperation");
            model.FilterByLegalDiscipline = GetSearchListFromTempData("FilterByLegalDiscipline");
            model.FilterBySubDiscipline = GetSearchListFromTempData("FilterBySubDiscipline");
            model.FilterByReportTemplate = GetSearchListFromTempData("FilterByReportTemplate");
            model.FilterByMatterReportClassification = GetSearchListFromTempData("FilterByMatterReportClassification");
            model.FilterByLeadLawyer = GetSearchListFromTempData("FilterByLeadLawyer");

            if (matters == null)
            {
                ShowMessage("Please select a Matter!", MessageType.danger, true);
            }

            var recordCount = 0;
            var showReportable = true;
            int limit = -1;
            int fromRowNumber = 0;
            string sortColumn = string.Empty;
            string sortDirection = string.Empty;
            model.MattersList = LookupManager.GetReportableMattersListByRustyLoading(limit, fromRowNumber, sortColumn, sortDirection, out recordCount,
                                                            model.FilterByBusinessUnit,
                                                            model.FilterByMatterStatus,
                                                            model.FilterByCountry,
                                                            model.FilterByOffice,
                                                            model.FilterByOperation,
                                                            model.FilterByLegalDiscipline,
                                                            model.FilterBySubDiscipline,
                                                            model.FilterByReportTemplate,
                                                            model.FilterByMatterReportClassification,
                                                            model.FilterByLeadLawyer,
                                                            showReportable);

            DataTable dt = ToDataTable(model.MattersList);

            ExcelHelper.GenerateFile(dt, VarConstants.ReportableMatters, DateTime.Now.ToShortDateString() + "_" + VarConstants.ReportableMatters + VarConstants.XLS);
            return new EmptyResult();

        }

        /// <summary>
        /// Convert List to Datatable
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>

        public DataTable ToDataTable<T>(IList<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the properties

            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (PropertyInfo prop in Props)
            {

                //Setting column names as Property names

                dataTable.Columns.Add(prop.Name);

            }

            foreach (T item in items)
            {

                var values = new object[Props.Length];

                for (int i = 0; i < Props.Length; i++)
                {

                    //inserting property values to datatable rows

                    values[i] = Props[i].GetValue(item, null);

                }

                dataTable.Rows.Add(values);

            }

            System.Data.DataView view = new System.Data.DataView(dataTable);
            System.Data.DataTable selected =
                    view.ToTable("Selected", false, "Matter_Reference", "Matter_Name", "Lead_Lawyer", "Operation", "LegalDiscipline", "SubDiscipline", "Modified", "DateSentForUpdate", "DateReturned", "ReportableStatus",
                    "Reportable", "DateSendForReporting");


            return selected;
        }



        /// <summary>
        /// Get the multiselect search parameters from temp data.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="paramName">Parameter name is required.</param>
        /// <returns>Array of strings.</returns>
        private string[] GetSearchListFromTempData(string paramName)
        {
            if (string.IsNullOrEmpty(paramName))
                return null;

            string[] filterByOption = null;

            if (TempData.ContainsKey(paramName))
            {
                filterByOption = (string[])TempData[paramName];
                TempData.Keep(paramName);
            }
            return filterByOption;
        }

        /// <summary>
        /// Get the single select search parameters from temp data.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="paramName">Parameter name is required.</param>
        /// <returns>String value.</returns>
        private string GetSearchStringFromTempData(string paramName)
        {
            if (string.IsNullOrEmpty(paramName))
                return string.Empty;

            var filterByOption = string.Empty;

            if (TempData.ContainsKey(paramName))
            {
                filterByOption = (TempData[paramName] != null ? TempData[paramName] : string.Empty) as string;
                TempData.Keep(paramName);
            }
            return filterByOption ?? string.Empty;
        }

        #endregion

        #region Search & List Inactive Matters

        /// <summary>
        /// GET method - List of Inactive Matters.
        /// Auth: Ashish P.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.MainDashboard })]
        public ActionResult InactiveMatters()
        {
            var model = new MatterListViewModel();

            if (model.MattersList == null)
                model.MattersList = new List<MatterViewModel>();

            if (model.SearchField == null)
                model.SearchField = string.Empty;

            return View(model);
        }

        /// <summary>
        /// Set the filter parameters.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.MainDashboard })]
        public ActionResult InactiveMatters(MatterListViewModel model)
        {
            TempData["searchText"] = model.SearchField;

            if (model == null)
                model = new MatterListViewModel();

            if (model.MattersList == null)
                model.MattersList = new List<MatterViewModel>();

            if (model.SearchField == null)
                model.SearchField = string.Empty;

            return View(model);
        }

        /// <summary>
        /// Get the list of all inactive matters based upon filters set.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetInactiveMatterList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            //Search Text is INSTRUCTION REF. NO. / MATTER REF. NO.
            var searchForText = (TempData["searchText"] != null ? TempData["searchText"] : string.Empty) as string;
            TempData.Keep("searchText");

            searchForText = searchForText ?? string.Empty;

            int recordCount = 0;

            MatterListViewModel model = new MatterListViewModel();
            string loggedInUserFullName = !string.IsNullOrEmpty(SessionHelper.LoggedUserInfo.FullName) ? SessionHelper.LoggedUserInfo.FullName : string.Empty;
            //Search Text is an Instruction Reference Number
            model.MattersList = LookupManager.GetInactiveMattersListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, searchForText, loggedInUserFullName, out recordCount);

            //Get the total counts of all the records in all the pages.
            model.RecordCount = recordCount;

            return PartialView("~/Areas/Main/Views/Shared/_InactiveMattersListPartial.cshtml", model);
        }

        #endregion Search & List Inactive Matters

        #region Reports Tab

        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.MainDashboard })]
        public ActionResult Reports()
        {
            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null && !SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)SystemTypeEnum.LegalProfessionalStaff))
            {
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.MainDashboard;
                return View();
            }
            else
            {
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
            }
        }

        #endregion

        #region Instruction Dashboard for Admin Users

        /// <summary>
        /// Get method to render Instructions tab for Admin user.
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Instructions()
        {
            this.RedirectBackUrl = Request.RawUrl;

            if (TempData.ContainsKey("Message"))
            {
                ViewBag.MessageType = TempData["MessageType"];
                ViewBag.Message = TempData["Message"];
                ModelState.AddModelError(string.Empty, ViewBag.Message);
            }

            TempData.Remove("searchTextCRT");

            TempData["SearchText"] = string.Empty;
            TempData["matterRef"] = string.Empty;        // fixed JIRA :EXICHM-343, vyom dixit. remove tempdata for instruction approval grid refresh.
            return View(new InstructionDashboardViewModel());
        }

        /// <summary>
        /// Post method to update search text in temp storage.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Instructions(InstructionDashboardViewModel model)
        {
            TempData["SearchText"] = model.Instructions.SearchField;

            if (model == null)
                model = new InstructionDashboardViewModel();

            if (model.Instructions.SearchField == null)
                model.Instructions.SearchField = string.Empty;

            return View(model);
        }

        /// <summary>
        /// Get the Instruction List For specified Matter Ref. or Instruction Ref.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult SearchInstructionsList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            //Search Text is INSTRUCTION REF. NO. / MATTER REF. NO.
            var searchForText = (TempData["searchText"] != null ? TempData["searchText"] : string.Empty) as string;
            TempData.Keep("searchText");

            searchForText = searchForText ?? string.Empty;

            InstructionListViewModel objInstructionListViewModel = new InstructionListViewModel();
            int recordCount = 0;

            if (searchForText.EndsWith("I"))
            {
                //Search Text is an Instruction Reference Number
                objInstructionListViewModel.InstructionList = LookupManager.SearchInstructionsListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, out recordCount, searchForText, "I");
            }

            else
            {
                //Search text is blank, displaying all records.
                objInstructionListViewModel.InstructionList = LookupManager.SearchInstructionsListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, out recordCount, searchForText);
            }

            //Get the total counts of all the records in all the pages.
            objInstructionListViewModel.RecordCount = recordCount;

            return PartialView("~/Areas/Main/Views/Shared/_SearchInstructionListPartial.cshtml", objInstructionListViewModel);
        }

        /// <summary>
        /// Get the list of pending instructions (status != Active / Closed)
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetPendingInstructionsList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            InstructionListViewModel objInstructionListViewModel = new InstructionListViewModel();
            int recordCount = 0;

            //Search text is blank, displaying all records.
            objInstructionListViewModel.InstructionList = LookupManager.GetPendingInstructionsListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, out recordCount);

            //Get the total counts of all the records in all the pages.
            objInstructionListViewModel.RecordCount = recordCount;

            return PartialView("~/Areas/Main/Views/Shared/_PendingInstructionListPartial.cshtml", objInstructionListViewModel);
        }

        /// <summary>
        /// Search by instruction/matter reference.
        /// </summary>
        /// <param name="textSearch">String parameter to search</param>
        /// <returns></returns>
        public ActionResult SearchPendingContectRequestTask(string textSearch)
        {
            var model = new InstructionDashboardViewModel();
            model.PageSize = BaseController.GridPageSize;
            TempData["searchTextCRT"] = textSearch;
            return PartialView("~/Areas/Main/Views/Shared/_PendingContactRequestTaskList.cshtml", model);
        }

        /// <summary>
        /// Get the list of all Pending Contect Request Tasks.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetPendingContectRequestTaskList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            PendingContactRequestTaskListViewModel model = new PendingContactRequestTaskListViewModel();
            int recordCount = 0;

            var textSearch = GetSearchStringFromTempData("searchTextCRT");

            //Search text is blank, displaying all records.
            model.TaskList = LookupManager.GetPendingContactRequestTaskListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, textSearch, out recordCount);

            //Get the total counts of all the records in all the pages.
            model.RecordCount = recordCount;

            return PartialView("~/Areas/Main/Views/Shared/_PendingContactRequestTaskListPartial.cshtml", model);
        }

        #endregion

        /*
        #region BU Approval

        /// <summary>
        /// 
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetBUApprovalsList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            var model = new InstructionListViewModel();
            int recordCount = 0;
            model.InstructionList = LookupManager.GetBUApprovalsListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, string.Empty, out recordCount);
            //Get the total counts of all the records in all the pages.
            model.RecordCount = recordCount;
            model.ApprovalType = BUApprovalEnum.Instruction;
            return PartialView("~/Areas/Main/Views/Shared/_BUApprovalTaskListPartial.cshtml", model);
        }

        public ActionResult GetBUApprovalsMainList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            var model = new InstructionListViewModel();
            int recordCount = 0;
            model.InstructionList = LookupManager.GetBUApprovalsListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, SessionHelper.LoggedUserInfo.FullName, out recordCount);
            //Get the total counts of all the records in all the pages.
            model.RecordCount = recordCount;
            model.ApprovalType = BUApprovalEnum.MainDashboard;
            return PartialView("~/Areas/Main/Views/Shared/_BUApprovalTaskListPartial.cshtml", model);
        }

        public ActionResult GetBUApprovalsTaskList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            var model = new InstructionListViewModel();
            int recordCount = 0;
            model.InstructionList = LookupManager.GetBUApprovalsListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, SessionHelper.LoggedUserInfo.FullName, out recordCount);
            //Get the total counts of all the records in all the pages.
            model.RecordCount = recordCount;
            model.ApprovalType = BUApprovalEnum.BUDashboard;
            return PartialView("~/Areas/Main/Views/Shared/_BUApprovalTaskListPartial.cshtml", model);
        }

        #endregion
        */

        #region RFQ Tasks

        //public ActionResult GetRFQApprovalsList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        //{
        //    var model = new RFQListViewModel();
        //    int recordCount = 0;
        //    model.RfqVm = LookupManager.GetRFQApprovalsListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, 0, string.Empty, out recordCount);
        //    //Get the total counts of all the records in all the pages.
        //    model.RecordCount = recordCount;
        //    return PartialView("~/Areas/Main/Views/Shared/_RFQApprovalTasksListPartial.cshtml", model);
        //}

        //public ActionResult GetRFQApprovalsMainList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        //{
        //    var model = new RFQListViewModel();
        //    int recordCount = 0;
        //    model.RfqVm = LookupManager.GetRFQApprovalsListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, 0, SessionHelper.LoggedUserInfo.FullName, out recordCount);
        //    //Get the total counts of all the records in all the pages.
        //    model.RecordCount = recordCount;
        //    return PartialView("~/Areas/Main/Views/Shared/_RFQApprovalTasksListPartial.cshtml", model);
        //}

        /// <summary>
        /// get rfq approval task for aaprov/reject/reaasign
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        //[CryptoValueProvider]
        //[CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.BusinessUnitDashboard, (int)UserAccessEnum.MainDashboard })]
        //public ActionResult RFQApprovalTask(int id)
        //{
        //    var lstRFQVm = new List<RFQViewModel>();
        //    var lstGrv = new List<SearchInvoiceViewModel>();
        //    if (TaskManager.CheckRFQStatus(id))
        //    {
        //        int cnt = 0;
        //        lstRFQVm = LookupManager.GetRFQApprovalsListByRustyloading(8, 0, string.Empty, string.Empty, id, string.Empty, out cnt);
        //    }
        //    return View(lstRFQVm);
        //}

        /// <summary>
        /// update rfq approval tasks status 
        /// </summary>
        /// <param name="rfqVm"></param>
        /// <returns></returns>
        //public ActionResult UpdateRFQStatus(RFQViewModel rfqVm)
        //{
        //    var rfqManager = new RFQManager();
        //    //rfqManager.UpdateRFQStatus(rfqVm);
        //    return Json(CommonConstants.Success, JsonRequestBehavior.AllowGet);
        //}

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="id"></param>
        ///// <returns></returns>
        //[CryptoValueProvider]
        //public ActionResult RFQRejection(int id, int rfqId)
        //{
        //    var rfqVm = new RFQViewModel();
        //    rfqVm.ID = id;
        //    rfqVm.RfqId = rfqId;
        //    return View(rfqVm);
        //}

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="id"></param>
        ///// <returns></returns>
        //[CryptoValueProvider]
        //public ActionResult RFQReassign(int id, int rfqId, string matter)
        //{
        //    var rfqVm = new RFQViewModel();
        //    rfqVm.ID = id; rfqVm.RfqId = rfqId; rfqVm.MatterName = matter;
        //    return View(rfqVm);
        //}

        #endregion

        #region Invoice Dashboard

        //[HttpGet]
        //[CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        //public ActionResult NewInvoice()
        //{
        //    var common = new CommonManager();
        //    var model = new NewInvoiceViewModel();
        //    ViewBag.Vendor = CommonManager.GetVendors();
        //    ViewBag.BusinessUnit = common.GetBusinessUnitsList();
        //    ViewBag.MatterReference = new List<SelectListItem>(); //CommonManager.GetMatterReference();
        //    ViewBag.GetInstructionReference = new List<SelectListItem>(); //CommonManager.GetInstructionReference();
        //    return View(model);
        //}

        [HttpGet]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Invoices(string q, bool useTempData = false)
        {
            if (!useTempData)
            {
                TempData["searchInvoiceStatus"] = string.Empty;
            }


            this.RedirectBackUrl = Request.RawUrl;
            TempData["SearchInvoice"] = string.Empty;
            string[] InvoiceStatusArray = DropDownManager.GetInvoiceStatus();
            ViewBag.InvoiceStatusArray = InvoiceStatusArray.Select(x => new SelectListItem
            {
                Text = x,
                Value = x

            }).OrderBy(x => x.Text).ToList();
            return View(new InvoiceDashboardViewModel
            {
                OutstandingInvoiceList = new OutstandingInvoicesListViewModel(),
                SearchInvoiceList = new SearchInvoiceListViewModel(),
                InvoiceStatus = GetSearchStringFromTempData("searchInvoiceStatus")
            });
        }

        [HttpPost]
        public ActionResult Invoices(InvoiceDashboardViewModel model)
        {
            if (model != null)
            {
                TempData["SearchInvoice"] = model.SearchInvoiceList != null ? model.SearchInvoiceList.SearchField : string.Empty;
                if (model.OutstandingInvoiceList == null)
                    model.OutstandingInvoiceList = new OutstandingInvoicesListViewModel();

                string[] InvoiceStatusArray = DropDownManager.GetInvoiceStatus();
                ViewBag.InvoiceStatusArray = InvoiceStatusArray.Select(x => new SelectListItem
                {
                    Text = x,
                    Value = x

                }).OrderBy(x => x.Text).ToList();
            }
            return View(model);
        }

        [HttpPost]
        public ActionResult InvoiceStatusSearch(InvoiceDashboardViewModel model)
        {
            TempData["searchInvoiceStatus"] = model.InvoiceStatus;
            return RedirectToAction("Invoices", "Main", new { q = Exigent.Common.Constants.VarConstants.Invoices, useTempData = true });
        }

        /// <summary>
        /// get invoice by invoice number
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public ActionResult GetInvoicesList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            var lstInvoiceVm = new SearchInvoiceListViewModel();
            lstInvoiceVm.isAdmin = true;
            int cnt = 0;
            var search = TempData["SearchInvoice"] != null ? TempData.Peek("SearchInvoice").ToString().Trim() : string.Empty;
            TempData.Keep("SearchInvoice");
            lstInvoiceVm.SearchInvoiceList = LookupManager.GetInvoicesListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, search, string.Empty, true, out cnt);
            lstInvoiceVm.RecordCount = cnt;
            return PartialView("~/Areas/Vendor/Views/Shared/_SearchInvoicePartial.cshtml", lstInvoiceVm);
        }

        /// <summary>
        /// get admin outstanding invoices
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortcolumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetOutstandingInvoicesList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            string invoiceStatus = TempData["searchInvoiceStatus"] as string;
            TempData.Keep("searchInvoiceStatus");
            var lstInvoiceVm = new OutstandingInvoicesListViewModel();
            lstInvoiceVm.isAdmin = true;
            int cnt = 0;
            lstInvoiceVm.OutstandingInvoiceList = LookupManager.GetOutstandingInvoicesListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, invoiceStatus, string.Empty, true, out cnt);
            lstInvoiceVm.RecordCount = cnt;
            return PartialView("~/Areas/Vendor/Views/Shared/_OutstandingInvoicesListPartial.cshtml", lstInvoiceVm);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.VendorDashboard, (int)UserAccessEnum.PaymentProcessingDashboard, (int)UserAccessEnum.BusinessUnitDashboard })]
        public ActionResult InvoiceDocument(string id, string type)
        {
            var invoiceMgr = new InvoiceManager();
            var invoiceVm = invoiceMgr.GetInvoiceByInvoiceNo(id);
            var lstInvoiceDocs = new List<InvoiceDocumentViewModel>();
            string DocURL = SystemDetailsViewModel.URL + "/" + VarConstants.Invoices + @"/" + invoiceVm.Vendor.Trim() + "/" + Convert.ToDateTime(invoiceVm.Created).Year + "/" + invoiceVm.Invoice_Number + "/";
            var directory = new DirectoryInfo(Server.MapPath("/" + VarConstants.Invoices + "/" + invoiceVm.Vendor.Trim() + @"/" + Convert.ToDateTime(invoiceVm.Created).Year + @"/" + invoiceVm.Invoice_Number + @"/"));
            if (Directory.Exists(Server.MapPath("/" + VarConstants.Invoices + "/" + invoiceVm.Vendor.Trim() + @"/" + Convert.ToDateTime(invoiceVm.Created).Year + @"/" + invoiceVm.Invoice_Number + @"/")))
            {
                foreach (FileInfo f in directory.GetFiles())
                {
                    string file = Path.GetFileNameWithoutExtension(f.Name);
                    file = !string.IsNullOrEmpty(file) ? file.Split('_')[0] : file;
                    if (file.Contains(VarConstants.Invoice))
                    {
                        lstInvoiceDocs.Add(new InvoiceDocumentViewModel
                        {
                            DocsName = VarConstants.Invoice,
                            FileName = f.Name.ToString(),
                            URL = DocURL,
                            Type = type,
                            Invoice_Number = id
                        });
                    }
                    if (file.Contains(VarConstants.Disbursement))
                    {
                        lstInvoiceDocs.Add(new InvoiceDocumentViewModel
                        {
                            DocsName = VarConstants.Disbursement,
                            FileName = f.Name.ToString(),
                            URL = DocURL,
                            Type = type,
                            Invoice_Number = id
                        });
                    }
                    if (file.Contains(VarConstants.SubCost))
                    {
                        lstInvoiceDocs.Add(new InvoiceDocumentViewModel
                        {
                            DocsName = VarConstants.SubCost,
                            FileName = f.Name.ToString(),
                            URL = DocURL,
                            Type = type,
                            Invoice_Number = id
                        });
                    }
                    if (file.Contains(VarConstants.Timesheet))
                    {
                        lstInvoiceDocs.Add(new InvoiceDocumentViewModel
                        {
                            DocsName = VarConstants.Timesheet,
                            FileName = f.Name.ToString(),
                            URL = DocURL,
                            Type = type,
                            Invoice_Number = id
                        });
                    }
                }
            }
            if (lstInvoiceDocs.Count() == 0)
            {
                lstInvoiceDocs.Add(new InvoiceDocumentViewModel
                {
                    Type = type,
                    Invoice_Number = id
                });
            }
            return View(lstInvoiceDocs);
        }

        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.PaymentProcessingDashboard, (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult ReviewInvoice(string id)
        {
            Session.Remove(VarConstants.AllVendorInstructionList);

            if (TempData.ContainsKey("useTempData"))
            {
                var useTempData = TempData["useTempData"];

                RecallMessageIfAny();
            }

            var invoiceMgr = new InvoiceManager();
            var invoiceVm = invoiceMgr.GetInvoiceByInvoiceNo(id);

            return View(invoiceVm);
        }

        [HttpPost]
        public ActionResult ReviewInvoice(InvoiceViewModel invoiceVm)
        {
            InvoiceManager.ReviewInvoice(invoiceVm, SessionHelper.LoggedUserInfo.FullName);
            return Json("", JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public ActionResult RejectionInvoice(InvoiceViewModel invoicereject)
        {
            if (invoicereject.Invoice_Status == "Awaiting GRV")
            {
                GrvTasksViewModel grvVm = new GrvTasksViewModel();
                grvVm.Invoice_Number = invoicereject.Invoice_Number;
                InvoiceManager.UpdateGRVTask(grvVm);
            }
            InvoiceManager.RejectInvoice(invoicereject, SessionHelper.LoggedUserInfo.FullName);
            return Json("", JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult MoveInvoice(string invoiceNumber, string instructionReference)
        {
            try
            {
                if (!string.IsNullOrEmpty(instructionReference))
                {
                    instructionReference = instructionReference.Split(new[] { " - " }, StringSplitOptions.RemoveEmptyEntries)[0];
                }

                var isSuccess = InvoiceManager.MoveInvoice(invoiceNumber, instructionReference);

                if (isSuccess)
                {
                    TempData["useTempData"] = "True";
                    ShowMessage("Invoice successfully moved to instruction reference " + instructionReference + ".", MessageType.success, true);
                    return Json("Success", JsonRequestBehavior.AllowGet);
                }
                else
                    return Json("Must change instruction number!", JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(ex.Message, JsonRequestBehavior.AllowGet);
            }
        }

        /// <summary>
        /// method to get list of users (user table) for autocomplete
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetAllVendorInstruction(string vendor, string matterReference)
        {
            var jSearializer = new JavaScriptSerializer();
            if (Session[VarConstants.AllVendorInstructionList] == null)
                Session[VarConstants.AllVendorInstructionList] = CommonManager.GetAllVendorInstruction(vendor, matterReference);

            var list = (List<string>)Session[VarConstants.AllVendorInstructionList];

            return Json(jSearializer.Serialize(list), JsonRequestBehavior.AllowGet);
        }

        #region Invoice Tab - Ready for Payment / Sent For Payment

        /// <summary>
        /// GET method for Invoices ready for payment view.
        /// Auth: Ashish P.
        /// </summary>
        /// <returns></returns>
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.PaymentProcessingDashboard })]
        public ActionResult InvoicesReadyForPayment()
        {
            if (!TempData.ContainsKey("useTempData"))
            {
                TempData["searchInvoiceNumber"] = string.Empty;
            }
            else
            {
                var useTempData = TempData["useTempData"];
            }

            var model = new InvoicesReadyForPaymentListViewModel();
            model.SearchField = GetSearchStringFromTempData("searchInvoiceNumber");

            return View(model);
        }

        /// <summary>
        /// Get the list of pending instructions (status != Active / Closed)
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetInvoicesReadyForPaymentList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            string searchText = TempData["searchInvoiceNumber"] as string;
            TempData.Keep("searchInvoiceNumber");

            var model = new InvoicesReadyForPaymentListViewModel();

            var recordCount = 0;

            //Search text is blank, displaying all records.
            model.InvoiceList = LookupManager.GetnvoicesReadyForPaymentByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, searchText, out recordCount);

            //Get the total counts of all the records in all the pages.
            model.RecordCount = recordCount;

            return PartialView("~/Areas/Main/Views/Shared/_InvoicesReadyForPaymentListPartial.cshtml", model);
        }

        [HttpPost]
        public string InvoiceReassign(string id, int assignTo)
        {
            if (assignTo < 0)
                return "Invalid data";

            bool status = false;
            var cvp = ChameleonInformExigent.Helpers.Crypto.Decrypt(id, out status);

            if (status)
            {
                var invoiceId = int.Parse(cvp["id"]);

                var success = new InvoiceManager().ReassignForPaymentProcessing(invoiceId, assignTo);

                if (success)
                    return "Success";
            }

            return "Failed";
        }

        [HttpPost]
        public ActionResult InvoicesReadyForPayment(InvoicesReadyForPaymentListViewModel model)
        {
            TempData["searchInvoiceNumber"] = model.SearchField;
            TempData["useTempData"] = true;

            return RedirectToAction("Invoices", "Main", new { q = Exigent.Common.Constants.VarConstants.Ready });
        }

        /// <summary>
        /// Set the invoices to Sent For Payment status.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="IDs">Multiple invoice IDs ($ delimited)</param>
        /// <returns>Redirects to same view.</returns>
        [HttpPost]
        public ActionResult ReadyForPaymentComplete(string IDs)
        {
            if (string.IsNullOrEmpty(IDs))
            {
                ShowMessage("Please select an invoice!", MessageType.warning, true);
                return RedirectToAction("Invoices", "Main", new { q = Exigent.Common.Constants.VarConstants.Ready });
            }

            IDs = IDs.Trim('$');

            var splitIDs = IDs.Split('$');

            if (splitIDs.Length <= 0)
            {
                ShowMessage("Please select an invoice!", MessageType.warning, true);
                return RedirectToAction("Invoices", "Main", new { q = Exigent.Common.Constants.VarConstants.Ready });
            }

            bool status = false;
            var invoiceManager = new InvoiceManager();
            var errInvoices = string.Empty;

            foreach (var id in splitIDs)
            {
                var cvp = ChameleonInformExigent.Helpers.Crypto.Decrypt(id, out status);

                if (status)
                {
                    var isSuccess = false;
                    var invoiceId = int.Parse(cvp["id"]);

                    isSuccess = StampInvoice(invoiceId);

                    if (isSuccess)
                        isSuccess = invoiceManager.UpdateInvoiceStatusById(invoiceId, Exigent.Common.Enums.InvoiceStatus.SentForPayment);
                    else
                    {
                        //I/O error while stamping.
                        errInvoices += ", " + invoiceId.ToString();
                    }
                }
            }

            if (string.IsNullOrEmpty(errInvoices))
                ShowMessage("Invoices sent for payment!", MessageType.success, true);
            else
            {
                errInvoices = errInvoices.Trim(',').Trim();
                //" + errInvoices + "
                ShowMessage("Invoice file(s) for one or more selected invoice(s) does not exist or invalid format!", MessageType.danger, true);
            }

            return RedirectToAction("Invoices", "Main", new { q = Exigent.Common.Constants.VarConstants.Ready });
        }

        /// <summary>
        /// Stamping the invoice PDF file.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="id">Integer Invoice ID is required</param>
        /// <returns>Returns true on success.</returns>
        private bool StampInvoice(int id)
        {
            string baseUrl = SystemDetailsViewModel.Path;

            InvoiceManager invManager = new InvoiceManager();
            var invoiceVm = invManager.GetInvoiceDocumentPathDetail(id);

            String ELF = invoiceVm.Vendor;
            String InvNo = invoiceVm.Invoice_Number;
            String Year = invoiceVm.Created.Value.Year.ToString();

            string pdfpath = baseUrl + @"\" + VarConstants.Invoices + @"\" + ELF + @"\" + Year + @"\" + InvNo + @"\";
            string documentName = VarConstants.Invoice + "_" + InvNo + ".pdf";
            string documentNameNew = "NEW_" + VarConstants.Invoice + "_" + InvNo + ".pdf";
            string imagepath = baseUrl + @"\Images\";

            string pdfIn = pdfpath + documentName;
            string pdfOut = pdfpath + documentNameNew;
            string bytes = imagepath + "EugenioSignature.png";

            if (!System.IO.File.Exists(pdfIn))
            {
                //Return back when, invoice file doesn't exists.
                //Invalid invoice / data.
                //ShowMessage("Invalid invoice or data found!", MessageType.danger);
                return false;
            }

            //Remove any previous residules of file transfer.
            if (System.IO.File.Exists(pdfOut))
            {
                System.IO.File.Delete(pdfOut);
            }
            PdfReader reader = null;
            PdfStamper stamper = null;
            try
            {
                if (System.IO.File.Exists(pdfIn))
                {
                    {
                        PdfReader.unethicalreading = true;
                        reader = new PdfReader(pdfIn);

                        FileStream fs = new FileStream(pdfOut, FileMode.Create);

                        stamper = new PdfStamper(reader, fs);

                        var pdfContentByte = stamper.GetOverContent(1);
                        iTextSharp.text.Image sigimage = iTextSharp.text.Image.GetInstance(bytes);
                        sigimage.ScalePercent(68f);
                        sigimage.SetAbsolutePosition(50, 250);
                        pdfContentByte.AddImage(sigimage);

                        stamper.FormFlattening = true; // set to true to lock pdf from being editable
                        stamper.Writer.CloseStream = true;
                        stamper.Close();
                        reader.Close();
                        fs.Close();
                    }

                    if (System.IO.File.Exists(pdfIn))
                    {
                        System.IO.File.Delete(pdfIn);
                    }

                    if (System.IO.File.Exists(pdfOut))
                    {
                        System.IO.File.Move(pdfOut, pdfIn);
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                if (reader != null)
                {
                    reader.Dispose();
                    reader.Close();
                }
                if (stamper != null)
                {
                    stamper.Close();
                }
                if (System.IO.File.Exists(pdfIn))
                    System.IO.File.Delete(pdfIn);

                //throw ex;
                return false;
            }
        }


        /// <summary>
        /// GET method for List of invoices Sent for Payment.
        /// Auth: Ashish P.
        /// </summary>
        /// <returns></returns>
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.PaymentProcessingDashboard })]
        public ActionResult InvoicesSentForPayment()
        {
            if (!TempData.ContainsKey("useTempData"))
            {
                TempData["searchInvoiceNumber"] = string.Empty;
                TempData["searchVendor"] = string.Empty;
            }
            else
            {
                var useTempData = TempData["useTempData"];
                TempData.Keep("searchInvoiceNumber");
            }

            InvoicesSentForPaymentListViewModel invoicesSentForPaymentListVM = new InvoicesSentForPaymentListViewModel();
            invoicesSentForPaymentListVM.Vendor = GetSearchStringFromTempData("searchVendor");
            invoicesSentForPaymentListVM.Invoice_Number = GetSearchStringFromTempData("searchInvoiceNumber");
            ViewBag.Vendors = CommonManager.GetVendors();

            return View(invoicesSentForPaymentListVM);
        }

        [HttpPost]
        public ActionResult InvoicesSentForPayment(InvoicesSentForPaymentListViewModel model)
        {
            TempData["searchInvoiceNumber"] = model.Invoice_Number;
            TempData["searchVendor"] = model.Vendor;
            TempData["useTempData"] = true;

            //ViewBag.Vendors = CommonManager.GetVendors();

            var backUrl = this.RedirectBackUrlKeep;
            if (backUrl != null && backUrl.Contains("/PaymentProcessing"))
                return Redirect(backUrl);
            else
                return RedirectToAction("Invoices", "Main", new { q = Exigent.Common.Constants.VarConstants.Sent });
        }

        /// <summary>
        /// Get the list of pending instructions (status != Active / Closed)
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetInvoicesSentForPaymentList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            string invoiceNumber = TempData["searchInvoiceNumber"] as string;
            TempData.Keep("searchInvoiceNumber");

            if (TempData["SearchInvoice"] != null)
                TempData.Keep("SearchInvoice");

            string vendor = TempData["searchVendor"] as string;
            TempData.Keep("searchVendor");
            var model = new InvoicesSentForPaymentListViewModel();

            //Get current user credentials.
            int currentUserID = SessionHelper.LoggedUserInfo.UserId;

            bool HasAccess = SessionHelper.LoggedUserInfo.Roles.Any(x => (x.Id == (int)SystemTypeEnum.LegalAdminStaff || x.Id == (int)SystemTypeEnum.SpecialGroupLegal || x.Id == (int)SystemTypeEnum.ServiceProviderAdmin || x.Id == (int)SystemTypeEnum.SuperGroupLegal));

            var recordCount = 0;

            //Search text is blank, displaying all records.
            model.InvoiceList = LookupManager.GetnvoicesSentForPaymentByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, invoiceNumber, vendor, out recordCount, HasAccess, currentUserID);

            //Get the total counts of all the records in all the pages.
            model.RecordCount = recordCount;

            return PartialView("~/Areas/Main/Views/Shared/_InvoicesSentForPaymentListPartial.cshtml", model);
        }

        [HttpGet]
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.PaymentProcessingDashboard })]
        public ActionResult ReassignSentForPaymentInvoice(string id, string type)
        {
            InvoicesSentForPaymentViewModel invoiceViewModel = new InvoicesSentForPaymentViewModel();
            invoiceViewModel.ID = Convert.ToInt32(id);
            invoiceViewModel.Type = type;
            return View(invoiceViewModel);
        }

        [HttpPost]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.PaymentProcessingDashboard })]
        public ActionResult ReassignSentForPaymentInvoice(InvoicesSentForPaymentViewModel invoiceViewModel)
        {
            if (!ModelState.IsValid)
            {
                return View(new InvoicesSentForPaymentViewModel());
            }
            if (invoiceViewModel != null)
            {
                InvoiceManager invMgr = new InvoiceManager();
                invMgr.UpdatePaymentProcessing(invoiceViewModel);
                //return RedirectToAction("PaymentProcessing", "Main", new { q = Exigent.Common.Constants.VarConstants.InvoiceReassigned_Success });
                return Json(CommonConstants.Success, JsonRequestBehavior.AllowGet);
            }
            return Json(CommonConstants.Error, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// method to get list of users (people picker) for autocomplete
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetSpecialUsers(string prefix)
        {
            CommonManager commonManager = new CommonManager();
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            if (Session[VarConstants.SpecialUsersList] == null)
                Session[VarConstants.SpecialUsersList] = commonManager.GetSpecialUsers();

            var userList = (List<EnumKeyValueViewModel>)Session[VarConstants.SpecialUsersList];
            userList = userList.Where(x => x.Name.Contains(prefix, StringComparison.OrdinalIgnoreCase)).Take(10).ToList();
            return Json(jSearializer.Serialize(userList), JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// Mark the invoices as Paid.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="Invoices">Ordered array of invoice id</param>
        /// <param name="PaymentDates">Array of Payment Dates in sync with invoice id array.</param>
        /// <param name="Comments">Array of comments in sync with invoice id array.</param>
        /// <returns>Redirection to the same view.</returns>
        [HttpPost]
        public ActionResult MarkForPaymentComplete(string[] Invoices, string[] PaymentDates, string[] Comments)
        {
            bool status = false;
            var invoiceManager = new InvoiceManager();

            var iInvoice = 0;
            var invoicesInError = string.Empty;

            foreach (var id in Invoices)
            {
                if (!string.IsNullOrEmpty(id))
                {
                    var cvp = ChameleonInformExigent.Helpers.Crypto.Decrypt(id, out status);

                    if (status)
                    {
                        var invoiceId = int.Parse(cvp["id"]);
                        var isSuccess = false;

                        if (string.IsNullOrEmpty(PaymentDates[iInvoice]))
                        {
                            if (Comments != null && Comments[iInvoice] != null)
                                isSuccess = invoiceManager.UpdateInvoiceStatusById(invoiceId, null, comments: Comments[iInvoice]);
                            else
                                isSuccess = invoiceManager.UpdateInvoiceStatusById(invoiceId, null, comments: null);
                        }
                        else
                        {
                            var paymentDate = DateTime.Parse(PaymentDates[iInvoice]);

                            if (Comments == null || Comments[iInvoice] == null)
                                isSuccess = invoiceManager.UpdateInvoiceStatusById(invoiceId, Exigent.Common.Enums.InvoiceStatus.Paid, paymentDate);
                            else
                                isSuccess = invoiceManager.UpdateInvoiceStatusById(invoiceId, Exigent.Common.Enums.InvoiceStatus.Paid, paymentDate, Comments[iInvoice]);
                        }

                        if (!isSuccess)
                            invoicesInError += ", " + invoiceId.ToString();
                    }
                }

                iInvoice++;
            }

            if (string.IsNullOrEmpty(invoicesInError))
                ShowMessage("Invoices marked as paid!", MessageType.success, true);
            else
            {
                //invoicesInError = invoicesInError.Trim(',').Trim();
                ShowMessage("One or more invoices have invalid data, and couldn't be updated!", MessageType.danger, true);
            }

            TempData["useTempData"] = true;

            var backUrl = this.RedirectBackUrlKeep;
            if (backUrl != null && backUrl.Contains("/PaymentProcessing"))
                return Redirect(backUrl);
            else
                return RedirectToAction("Invoices", "Main", new { q = Exigent.Common.Constants.VarConstants.Sent });
        }

        /// <summary>
        /// Saving the payment processing comments only.
        /// Auth: Ashish P.
        /// </summary>
        /// <param name="Invoices">Ordered array of invoice id</param>
        /// <param name="Comments">Array of comments in sync with invoice id array.</param>
        /// <returns>Redirection to the same view.</returns>
        [HttpPost]
        public ActionResult SavePaymentProcessingComments(string[] Invoices, string[] Comments)
        {
            bool status = false;
            var invoiceManager = new InvoiceManager();

            var iInvoice = 0;
            var invoicesInError = string.Empty;

            foreach (var id in Invoices)
            {
                if (!string.IsNullOrEmpty(id))
                {
                    var cvp = ChameleonInformExigent.Helpers.Crypto.Decrypt(id, out status);

                    if (status)
                    {
                        var invoiceId = int.Parse(cvp["id"]);
                        var isSuccess = false;

                        isSuccess = invoiceManager.UpdateInvoiceStatusById(invoiceId, null, comments: Comments[iInvoice]);

                        if (!isSuccess)
                            invoicesInError += ", " + invoiceId.ToString();
                    }
                }

                iInvoice++;
            }

            if (string.IsNullOrEmpty(invoicesInError))
                ShowMessage("Comments saved!", MessageType.success, true);
            else
            {
                //invoicesInError = invoicesInError.Trim(',').Trim();
                ShowMessage("One or more invoices have invalid data, and couldn't be updated!", MessageType.danger, true);
            }

            TempData["useTempData"] = true;

            return RedirectToAction("PaymentProcessing", "Main");
        }

        #endregion

        #endregion

        #region Invoice Audit

        /// <summary>
        /// method to get invoice audit 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard })]
        public ActionResult InvoiceAuditTask(string id)
        {
            var lstInvoiceVm = new List<SearchInvoiceViewModel>();
            int cnt = 0;
            lstInvoiceVm = LookupManager.GetInvoiceAuditListByRustyloading(8, 0, string.Empty, string.Empty, id, out cnt);
            return View(lstInvoiceVm);
        }

        /// <summary>
        /// method to show list of invoice audit
        /// </summary>
        /// <returns></returns>
        public ActionResult InvoiceAudit()
        {
            var invoice = new InvoiceDashboardViewModel();
            invoice.InvoiceAuditList = new SearchInvoiceListViewModel();
            return PartialView("~/Areas/Main/Views/Shared/_InvoiceAuditTaskPartial.cshtml", invoice);
        }

        /// <summary>
        /// method to get Invoice Audit task list
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public ActionResult GetInvoiceAuditList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            int cnt = 0;
            var lstInvoiceVm = new SearchInvoiceListViewModel();
            lstInvoiceVm.SearchInvoiceList = LookupManager.GetInvoiceAuditListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, string.Empty, out cnt);
            lstInvoiceVm.RecordCount = cnt;
            return PartialView("~/Areas/Main/Views/Shared/_InvoiceAuditPartial.cshtml", lstInvoiceVm);
        }

        /// <summary>
        /// update invoice audit status
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="comments"></param>
        /// <param name="isSend"></param>
        /// <returns></returns>
        public ActionResult UpdateInvoiceAuditStatus(InvoiceAuditViewModel invoiceAudit)
        {
            var invoice = new InvoiceManager();
            invoice.UpdateInvoiceAuditStatus(invoiceAudit, SessionHelper.LoggedUserInfo.UserName, SessionHelper.LoggedUserInfo.FullName);
            return Json(CommonConstants.Success, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Invoice Approval

        /// <summary>
        /// method to get invoice Approval 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.BusinessUnitDashboard })]
        public ActionResult InvoiceApprovalTask(string id, string admin)
        {
            var lstInvoiceVm = new List<SearchInvoiceViewModel>();
            int cnt = 0;
            lstInvoiceVm = LookupManager.GetInvoiceApprovalListByRustyloading(8, 0, string.Empty, string.Empty, id, string.Empty, string.Empty, out cnt);
            if (lstInvoiceVm.Count() > 0)
                lstInvoiceVm.FirstOrDefault().isAdmin = Convert.ToBoolean(admin);
            return View(lstInvoiceVm);
        }

        /// <summary>
        /// method to show list of invoice audit
        /// </summary>
        /// <returns></returns>
        public ActionResult InvoiceApproval(bool isAdmin)
        {
            if (!TempData.ContainsKey("useTempData"))
            {
                TempData["searchInvoiceNumber"] = string.Empty;
            }
            else
            {
                var useTempData = TempData["useTempData"];
            }

            var invoice = new InvoiceDashboardViewModel();
            invoice.InvoiceApprovalList = new SearchInvoiceListViewModel();
            invoice.isAdmin = isAdmin;
            invoice.InvoiceApprovalList.SearchField = GetSearchStringFromTempData("searchInvoiceNumber");

            return PartialView("~/Areas/Main/Views/Shared/_InvoiceApprovalTaskPartial.cshtml", invoice);
        }

        [HttpPost]
        public ActionResult InvoiceApproval(InvoiceDashboardViewModel model)
        {
            TempData["searchInvoiceNumber"] = model.InvoiceApprovalList.SearchField;
            TempData["useTempData"] = true;

            return RedirectToAction("Invoices", "Main", new { q = Exigent.Common.Constants.VarConstants.Approval });
        }

        [HttpPost]
        public ActionResult SearchInvoice(InvoiceDashboardViewModel model)
        {
            if (model != null)
            {
                TempData["SearchInvoice"] = model.SearchInvoiceList.SearchField;
            }
            var qs = new Dictionary<string, string> { { "useTempData", "true" } };
            return RedirectToAction("PaymentProcessing", "Main", new { q = Exigent.Common.Helpers.Crypto.Encrypt(qs) });
        }

        /// <summary>
        /// method to get Invoice Audit task list
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public ActionResult GetInvoiceApprovalList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            string searchText = TempData["searchInvoiceNumber"] as string;
            TempData.Keep("searchInvoiceNumber");

            int cnt = 0;
            var lstInvoiceVm = new SearchInvoiceListViewModel();
            lstInvoiceVm.SearchInvoiceList = LookupManager.GetInvoiceApprovalListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, string.Empty, string.Empty, string.Empty, out cnt, searchText);
            lstInvoiceVm.RecordCount = cnt;
            lstInvoiceVm.isAdmin = true;
            lstInvoiceVm.ApprovalType = BUApprovalEnum.MainDashboard;
            return PartialView("~/Areas/Main/Views/Shared/_InvoiceApprovalPartial.cshtml", lstInvoiceVm);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetInvoiceApprovalAdminList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            int cnt = 0;
            string matterRefNo = TempData["matterRef"] as string;
            TempData.Keep("matterRef");
            var lstInvoiceVm = new SearchInvoiceListViewModel();
            lstInvoiceVm.SearchInvoiceList = LookupManager.GetInvoiceApprovalListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, string.Empty, string.Empty, matterRefNo, out cnt);
            lstInvoiceVm.RecordCount = cnt;
            lstInvoiceVm.isAdmin = false;
            lstInvoiceVm.ApprovalType = BUApprovalEnum.MainDashboard;
            return PartialView("~/Areas/Main/Views/Shared/_InvoiceApprovalPartial.cshtml", lstInvoiceVm);
        }

        /// <summary>
        /// update invoice approval status
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="comments"></param>
        /// <param name="isSend"></param>
        /// <returns></returns>
        public ActionResult UpdateInvoiceApproval(int invoiceId, int type, string comments, string reassignTo, int appId, string reassignName = "")
        {
            var invoice = new InvoiceManager();
            invoice.UpdateInvoiceApproval(invoiceId, type, comments, reassignTo, appId, SessionHelper.LoggedUserInfo.FullName, reassignName);
            return Json(CommonConstants.Success, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// method for invoice reassign 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="appId"></param>
        /// <returns></returns>
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard })]
        public ActionResult InvoiceReassign(int id, int appId, string admin, int systemId = 0)
        {
            var invoice = new SearchInvoiceViewModel();
            invoice.ID = id; invoice.AppId = appId;
            invoice.isAdmin = Convert.ToBoolean(admin);
            invoice.SystemType_ID = systemId;
            return View(invoice);
        }

        /// <summary>
        /// method for invoice rejection
        /// </summary>
        /// <param name="id"></param>
        /// <param name="g"></param>
        /// <returns></returns>
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard })]
        public ActionResult InvoiceRejection(int id, int appId, string admin)
        {
            var invoice = new SearchInvoiceViewModel();
            invoice.ID = id; invoice.AppId = appId;
            invoice.isAdmin = Convert.ToBoolean(admin);
            return View(invoice);

        }

        public ActionResult GetInvoiceApprovalBUList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            int cnt = 0;
            var lstInvoiceVm = new SearchInvoiceListViewModel();
            lstInvoiceVm.SearchInvoiceList = LookupManager.GetInvoiceApprovalListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, string.Empty, SessionHelper.LoggedUserInfo.FullName, string.Empty, out cnt);
            lstInvoiceVm.RecordCount = cnt;
            lstInvoiceVm.isAdmin = false;
            lstInvoiceVm.ApprovalType = BUApprovalEnum.BUDashboard;
            return PartialView("~/Areas/Main/Views/Shared/_InvoiceApprovalPartial.cshtml", lstInvoiceVm);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetInvoiceApprovalGLList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            int cnt = 0;
            var lstInvoiceVm = new SearchInvoiceListViewModel();
            lstInvoiceVm.SearchInvoiceList = LookupManager.GetInvoiceApprovalListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, string.Empty, SessionHelper.LoggedUserInfo.FullName, string.Empty, out cnt);
            lstInvoiceVm.RecordCount = cnt;
            lstInvoiceVm.isAdmin = false;
            lstInvoiceVm.ApprovalType = BUApprovalEnum.MainDashboard;
            return PartialView("~/Areas/Main/Views/Shared/_InvoiceApprovalPartial.cshtml", lstInvoiceVm);
        }

        #endregion

        #region Grv Tasks

        /// <summary>
        /// isMail is accessed from mail
        /// </summary>
        /// <param name="id"></param>
        /// <param name="isAdmin"></param>
        /// <param name="isMail"></param>
        /// <returns></returns>
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult GRVTasks(string id, bool isAdmin, bool isMail = false)
        {
            var lstGrv = new List<SearchInvoiceViewModel>();
            if (TaskManager.CheckGrvStatus(id))
            {
                lstGrv = LookupManager.GetGrvTasks(false, string.Empty, id);
                if (lstGrv.Count() > 0)
                {
                    lstGrv.FirstOrDefault().isAdmin = isAdmin;
                    lstGrv.FirstOrDefault().isMail = isMail;
                }
            }
            return View(lstGrv);
        }

        /// <summary>
        /// method to show list of grv tasks
        /// </summary>
        /// <returns></returns>
        public ActionResult GrvTask()
        {
            if (!TempData.ContainsKey("useTempData"))
            {
                TempData["SearchGrvAcc"] = string.Empty;
                TempData["SearchGrv"] = string.Empty;
            }
            else
            {
                var useTempData = TempData["useTempData"];
            }

            var invoice = new InvoiceDashboardViewModel();
            invoice.GrvTasksList = new GrvTasksListViewModel();
            invoice.GrvTasksListAccount = new GrvTasksListViewModel();
            invoice.GrvTasksList.SearchField = GetSearchStringFromTempData("SearchGrv");
            invoice.GrvTasksListAccount.SearchField = GetSearchStringFromTempData("SearchGrvAcc");


            return PartialView("~/Areas/Main/Views/Shared/_GrvTaskPartial.cshtml", invoice);
        }

        /// <summary>
        /// method to search grv task
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult GrvTaskSearch(string id)
        {
            TempData["SearchGrv"] = id;
            var invoice = new InvoiceDashboardViewModel();
            invoice.GrvTasksList = new GrvTasksListViewModel();
            invoice.GrvTasksList.SearchField = id;
            return PartialView("~/Areas/Main/Views/Shared/_SearchGrvPartial.cshtml", invoice);
        }

        /// <summary>
        /// method to get list of grv tasks exigent
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortcolumn"></param>
        /// <param name="sortDirection"></param>
        /// <param name="mode"></param>
        /// <returns></returns>
        public ActionResult GetGrvTasksList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            var lstInvoiceVm = new GrvTasksListViewModel();
            var search = string.Empty;

            if (TempData.ContainsKey("SearchGrv"))
            {
                search = TempData["SearchGrv"] != null ? TempData.Peek("SearchGrv").ToString() : string.Empty;
                TempData.Keep("SearchGrv");
            }

            int cnt = 0;
            lstInvoiceVm.GrvTasksList = LookupManager.GetGrvTasksList(limit, fromRowNumber, sortColumn, sortDirection, false, search, out cnt);
            lstInvoiceVm.SearchField = search;
            lstInvoiceVm.RecordCount = cnt;
            return PartialView("~/Areas/Main/Views/Shared/_GrvPartial.cshtml", lstInvoiceVm);
        }

        /// <summary>
        /// Search method for GRV Tasks Assigned To Accounts only.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public void GrvTaskSearchAccount(string id)
        {
            TempData["SearchGrvAcc"] = id;
            TempData["useTempData"] = true;


        }


        /// <summary>
        /// method to get list of grv tasks account
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        public ActionResult GetGrvTasksListAccount(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            int cnt = 0;
            var lstInvoiceVm = new GrvTasksListViewModel();

            var search = TempData["SearchGrvAcc"] != null ? TempData.Peek("SearchGrvAcc").ToString() : string.Empty;
            TempData.Keep("SearchGrvAcc");

            var backUrl = this.RedirectBackUrlKeep;

            if (!string.IsNullOrEmpty(backUrl) && backUrl.Contains("AccountsDashboard"))
            {
                lstInvoiceVm.GrvTasksList = LookupManager.GetGrvTasksList(limit, fromRowNumber, sortColumn, sortDirection, true, search, out cnt);
            }
            else
                lstInvoiceVm.GrvTasksList = LookupManager.GetGrvTasksList(limit, fromRowNumber, sortColumn, sortDirection, true, search, out cnt);

            lstInvoiceVm.RecordCount = cnt;
            return PartialView("~/Areas/Main/Views/Shared/_GrvPartial.cshtml", lstInvoiceVm);
        }

        /// <summary>
        /// update grv status to complete or reassign
        /// </summary>
        /// <param name="grvVm"></param>
        /// <returns></returns>
        public ActionResult UpdateGrvStatus(GrvTasksViewModel grvVm)
        {
            var invoice = new InvoiceManager();
            invoice.UpdateGrvStatus(grvVm);
            return Json(CommonConstants.Success, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// method to reassign grv tasks
        /// </summary>
        /// <param name="id"></param>
        /// <param name="g"></param>
        /// <returns></returns>
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult GrvReassign(string id, string grvId)
        {
            var invoice = new GrvTasksViewModel();
            invoice.Invoice_Number = id;
            invoice.GrvId = Convert.ToInt32(grvId);
            return View(invoice);
        }

        #endregion

        #region PO Tasks

        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult POTasks(string id, string status, bool isAdmin = false)
        {
            var lstInvoiceVm = new List<SearchInvoiceViewModel>();
            if (TaskManager.CheckPoStatus(Convert.ToInt32(id)))
            {
                int cnt = 0;
                lstInvoiceVm = LookupManager.GetPOTaskListByRustyloading(8, 0, string.Empty, string.Empty, Convert.ToInt32(id), out cnt);
                if (lstInvoiceVm.Count() > 0)
                {
                    lstInvoiceVm.FirstOrDefault().Status = status;
                    lstInvoiceVm.FirstOrDefault().isAdmin = isAdmin;
                }
            }
            return View(lstInvoiceVm);
        }

        /// <summary>
        /// method to get po tasks list
        /// </summary>
        /// <returns></returns>
        public ActionResult POTask()
        {
            var invoice = new InvoiceDashboardViewModel();
            invoice.POTaskList = new SearchInvoiceListViewModel();
            return PartialView("~/Areas/Main/Views/Shared/_POTaskPartial.cshtml", invoice);
        }

        /// <summary>
        /// method to complete- update po tasks status 
        /// </summary>
        /// <param name="poVm"></param>
        /// <returns></returns>
        public ActionResult UpdatePOStatus(POTasksViewModel poVm)
        {
            var invoice = new InvoiceManager();
            invoice.UpdatePOStatus(poVm);
            return Json(CommonConstants.Success, JsonRequestBehavior.AllowGet);
        }

        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult ReassignPOTask(string status, int id, string ins)
        {
            var poVm = new POTasksViewModel();
            poVm.Status = status;
            poVm.Id = id; poVm.Instruction = ins;
            return View(poVm);
        }

        /// <summary>
        /// method to get potasks list
        /// </summary>
        /// <param name="limit"></param>
        /// <param name="fromRowNumber"></param>
        /// <param name="sortColumn"></param>
        /// <param name="sortDirection"></param>
        /// <returns></returns>
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult GetPOTaskList(int limit, int fromRowNumber, string sortColumn, string sortDirection)
        {
            int cnt = 0;
            var lstInvoiceVm = new SearchInvoiceListViewModel();

            var backUrl = this.RedirectBackUrlKeep;
            if (!string.IsNullOrEmpty(backUrl) && backUrl.Contains("AccountsDashboard"))
            {
                lstInvoiceVm.SearchInvoiceList = LookupManager.GetPOTaskListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, 0, out cnt);
                //, SessionHelper.LoggedUserInfo.FullName
            }
            else
                lstInvoiceVm.SearchInvoiceList = LookupManager.GetPOTaskListByRustyloading(limit, fromRowNumber, sortColumn, sortDirection, 0, out cnt);

            lstInvoiceVm.RecordCount = cnt;
            lstInvoiceVm.isAdmin = true;
            return PartialView("~/Areas/Main/Views/Shared/_POPartial.cshtml", lstInvoiceVm);
        }

        #endregion

        #region Reports
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard })]
        public ActionResult WeeklyMatterReport()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.Weekly_MatterReport.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
        }


        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard })]
        public ActionResult InvoicesOutsideCI()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.InvoicesOutsideCI.ToString()}
                                    };
            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
        }


        public ActionResult WeeklyMatterReportFY()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.Weekly_MatterReport_FY.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
            // return Redirect("/Common/UnderConstruction/");

        }

        public ActionResult YTDPreVATAttorneyFeeSpendPerELF()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.YTD_Pre_VAT_Attorney_Fee_Spend_per_ELF.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
        }

        public ActionResult YTDPreVATSpendByELFPerBusinessUnit()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.YTD_Pre_VAT_Spend_by_ELF_per_Business_Unit.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
        }

        public ActionResult YTDELFInvoicesByStatusPerBusinessUnit()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.YTD_ELF_Invoices_by_Status_per_Business_Unit.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));

        }
        public ActionResult YTDPreVATAttorneyFeeSpendPerELFPerBusinessUnit()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.YTD_Pre_VAT_Attorney_Fee_Spend_per_ELF_per_Business_Unit.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
        }

        public ActionResult ActivityByLeadLawyer()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.Activity_by_Lead_Lawyer.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
            //return Redirect("/Common/UnderConstruction/");

        }
        public ActionResult ActivityPerMatterPerLeadLawyer()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.Activity_Per_Matter_Per_Lead_Lawyer.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
            //return Redirect("/Common/UnderConstruction/");

        }
        public ActionResult ActivityReportPerLeadLawyer()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.Activity_Report_Per_Lead_Lawyer.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
            //return Redirect("/Common/UnderConstruction/");

        }
        public ActionResult RebateReport()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName",Exigent.Common.Helpers.EnumHelper<ReportEnum>.GetEnumDescription(ReportEnum.Rebate_Report.ToString())}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
            //return Redirect("/Common/UnderConstruction/");

        }
        public ActionResult AllMatters()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.All_Matters.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
        }

        public ActionResult AllInvoices()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.All_Invoices.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
        }

        public ActionResult AllInstructions()
        {
            var qsDictionary = new Dictionary<string, string>
                                    {
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()},
                                         {"ReportName", ReportEnum.All_Instructions.ToString()}
                                    };

            return Redirect("../Report/Reportviewer.aspx" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary));
        }


        #endregion

        #region PeoplePicker

        [HttpPost]
        public ActionResult AddPeoplePickerDetails(PeoplePickerViewModel peoplePickerViewModel)
        {
            if (ModelState.IsValid)
            {
                PeoplePickerManager peoplePickerManager = new PeoplePickerManager();
                bool isFullNameExist = peoplePickerManager.IsFullNameExists(peoplePickerViewModel.Full_Name);
                if (isFullNameExist)
                {
                    return Json(CommonConstants.Error, JsonRequestBehavior.AllowGet);
                }
                peoplePickerManager.AddUserInPeoplePicker(peoplePickerViewModel);
                Session[VarConstants.UsersList] = null;
                return Json(CommonConstants.Success, JsonRequestBehavior.AllowGet);
            }
            return null;
        }
        /// <returns></returns>
        [HttpPost]
        public ActionResult SaveSubMatter(SubMattersViewModel subMattersViewModel)
        {
            if (subMattersViewModel != null)
            {
                //Edit 
                if (subMattersViewModel.Id > 0)
                {

                }
                else//Add new
                {
                    subMattersViewModel.FileUploadDate = DateTime.Now;
                    subMattersViewModel.UploadBy = SessionHelper.LoggedUserInfo.UserId;
                    subMattersViewModel.FileName = subMattersViewModel.File.FileName;
                }

                string fileName, oldFileName, matterRef;
                SubMattersManager.AddEditSubMatters(subMattersViewModel, out fileName, out oldFileName, out matterRef);

                //Upload file 
                if (subMattersViewModel.File != null)
                {
                    //File stored Directory path
                    string creditNoteDirectory = SystemDetailsViewModel.Path + @"\" + SystemDetailsViewModel.SubMatterPath + @"\";
                    if (!Directory.Exists(creditNoteDirectory))
                        Directory.CreateDirectory(creditNoteDirectory);

                    if (subMattersViewModel.Id > 0 && !string.IsNullOrEmpty(fileName))
                    {
                        //Remove existing file
                        subMattersViewModel.FileName = fileName;
                        if (System.IO.File.Exists(creditNoteDirectory + oldFileName))
                            System.IO.File.Delete(creditNoteDirectory + oldFileName);
                    }
                    string fileNamePath = !string.IsNullOrEmpty(fileName) ? creditNoteDirectory + fileName : creditNoteDirectory + matterRef + "_" + subMattersViewModel.File.FileName;

                    //string filePath = !string.IsNullOrEmpty(subMattersViewModel.FileName) ? creditNoteDirectory + subMattersViewModel.FileName : creditNoteDirectory + subMattersViewModel.File.FileName;
                    subMattersViewModel.File.SaveAs(fileNamePath);

                }

                return Json("Success", JsonRequestBehavior.AllowGet);
            }
            return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult EditSubMatter(int id = 0, string type = "")
        {
            SubMattersViewModel SubMattersViewModel = new SubMattersViewModel();
            SubMattersViewModel = SubMattersManager.GetSubMattersById(id);
            return View("~/Areas/Main/Views/Shared/_AddSubMatterPartial.cshtml", SubMattersViewModel);
        }

        public ActionResult DeleteSubMatter(int id = 0)
        {
            SubMattersViewModel SubMattersViewModel = new SubMattersViewModel();
            int returnVal = SubMattersManager.DeleteSubMattersById(id);
            if (returnVal > 0)
                return Json("success", JsonRequestBehavior.AllowGet);
            else
                return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult CheckDuplicateSubMatterName(int Id, string Name, int MatterId)
        {
            SubMattersViewModel SubMattersViewModel = new SubMattersViewModel();
            int returnVal = SubMattersManager.CheckDuplicateSubMatterName(Id, Name, MatterId);
            if (returnVal > 0)
                return Json("exist", JsonRequestBehavior.AllowGet);
            else
                return Json("", JsonRequestBehavior.AllowGet);
        }

        public ActionResult CheckDuplicateSubMatterFileName(int Id, string FileName, int MatterId)
        {
            var matterVm = new MatterViewModel();
            var matterMgr = new MatterManager();

            //Check FileName contains Matter-Ref
            if (!string.IsNullOrEmpty(FileName))
            {
                if (FileName.Split('_').Length > 1)
                {
                    //Its contains matter ref
                    FileName = FileName.Split('.').Length > 1 ? FileName.Split('.')[0] : FileName;
                }
                else
                {
                    FileName = FileName.Split('.').Length > 1 ? FileName.Split('.')[0] : FileName;
                    matterVm = matterMgr.GetMatterById(MatterId);
                    FileName = matterVm.Matter_Reference + "_" + FileName;
                }
            }

            SubMattersViewModel SubMattersViewModel = new SubMattersViewModel();
            int returnVal = SubMattersManager.CheckDuplicateSubMatterFileName(Id, FileName, MatterId);
            if (returnVal > 0)
                return Json("exist", JsonRequestBehavior.AllowGet);
            else
                return Json("", JsonRequestBehavior.AllowGet);
        }


        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult DownloadSubMatterFile(string id)
        {
            int MatterId = !string.IsNullOrEmpty(id) ? Convert.ToInt16(id) : 0;
            SubMattersViewModel SubMattersViewModel = new SubMattersViewModel();
            SubMattersViewModel = SubMattersManager.GetSubMattersById(MatterId);

            if (SubMattersViewModel != null)
            {
                string contentType = "application/xlxs";
                string fileDirectory = SystemDetailsViewModel.Path + @"\" + SystemDetailsViewModel.SubMatterPath + @"\" + SubMattersViewModel.FileName;
                if (System.IO.File.Exists(fileDirectory))
                    return File(fileDirectory, contentType, SubMattersViewModel.FileName);

                return Redirect(SystemDetailsViewModel.URL + "/Common/NotFound");
            }

            return Redirect(SystemDetailsViewModel.URL + "/Common/NotFound");
        }


        #endregion

        #region Static HTML Contents

        /// <summary>
        /// Get Html Contents
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="comments"></param>
        /// <param name="isSend"></param>
        /// <returns></returns>
        [HttpGet]
        public string GetHtmlContent(int id = 1)
        {
            return CommonManager.GetHtmlContent(id);
        }

        #endregion

        #region Capture Invoices Processed from Outside of CI system

        /// <summary>
        /// Load the page to capture outside invoices.
        /// </summary>
        /// <param name="isPostBack">Used to indicate the postback after save event.</param>
        /// <returns></returns>
        [HttpGet]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult ExternalInvoices(bool isPostBack = false)
        {
            var invoiceVm = new ExternalInvoiceViewModel();

            ViewBag.BusinessUnitList = new CommonManager().GetBusinessUnitsList(false);
            ViewBag.VendorList = CommonManager.GetVendors();

            return View(invoiceVm);
        }

        /// <summary>
        /// Save procedure to capture outside invoices. 
        /// </summary>
        /// <param name="invoiceVm"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SaveExternalInvoice(ExternalInvoiceViewModel invoiceVm)
        {
            if (invoiceVm != null)
            {
                var invoiceManager = new InvoiceManager();

                invoiceManager.SaveExternalInvoice(invoiceVm);
            }


            ShowMessage(VarConstants.InvoiceSubmit, MessageType.success, true);


            return RedirectToAction("Invoices", "Main", new { q = "ExtInv", isPostBack = true });
        }

        /// <summary>
        /// method to validate invoice status & exists
        /// </summary>
        /// <param name="invoiceNo"></param>
        /// <returns></returns>
        public ActionResult ValidateInvoiceNo(string vendor, string invoiceNo)
        {
            var invoiceManager = new InvoiceManager();

            var result = invoiceManager.ValidateInvoiceNo(vendor, invoiceNo, false, true);
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Method to validate Instruction status & invoice status
        /// </summary>
        /// <param name="insNo"></param>
        /// <returns></returns>
        public ActionResult ValidateInstructionRef(string instructionNumber)
        {
            var instruction = InstructionManager.GetInstructionSummary(instructionNumber);

            var result = new
            {
                data = instruction,
                isSuccess = (instruction != null)
            };

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Export Tasks

        [HttpPost]
        public ActionResult ExportPOTasks()
        {
            var dt = LookupManager.GetPOTaskListByRustyloading(string.Empty, string.Empty, 0);
            ExcelHelper.GenerateFile(dt, VarConstants.POTask, DateTime.Now.ToShortDateString() + "_" + VarConstants.POTask + VarConstants.XLS);
            return new EmptyResult();
        }

        [HttpPost]
        public ActionResult ExportGRVTasks()
        {
            var dt = LookupManager.GetGrvTasksList(string.Empty, string.Empty, false, string.Empty);
            ExcelHelper.GenerateFile(dt, VarConstants.GRVTask, DateTime.Now.ToShortDateString() + "_" + VarConstants.GRVTask + VarConstants.XLS);
            return new EmptyResult();
        }

        #endregion


    }
}