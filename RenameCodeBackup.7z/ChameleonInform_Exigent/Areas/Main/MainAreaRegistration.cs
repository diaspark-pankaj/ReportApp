﻿using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Main
{
    public class MainAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "Main";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "Main_default",
                "Main/{action}/{id}",
                new { controller="Main", action = "Dashboard", id = UrlParameter.Optional }
            );
        }
    }
}