﻿//using ChameleonInformExigent.Controllers;
//using Exigent.BLL;
//using Exigent.Common.Constants;
//using Exigent.Common.Enums;
//using Exigent.CustomAttributes;
//using Exigent.Helpers.CustomAttributes;
//using Exigent.ViewModels.Common;
//using Exigent_BusinessLogicLayer;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Web.Mvc;
//using System.Web.Script.Serialization;
//using Exigent.Common.Helpers;

//namespace ChameleonInformExigent.Areas.Master.Controllers
//{
//    public class ReportClassificationsController : BaseController
//    {
//        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
//        public ActionResult Index(bool showMessage = false)
//        {
//            if (showMessage)
//                RecallMessageIfAny();

//            TempData["SearchText"] = "";

//            return View(new ReportClassificationListViewModel());
//        }

//        // Post data of search field
//        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
//        [HttpPost]
//        public ActionResult Index(ReportClassificationListViewModel model)
//        {
//            if (model.SearchField != null)
//            {
//                model.SearchField = model.SearchField.Trim();
//                TempData["searchText"] = model.SearchField;
//            }
//            else
//            {
//                TempData["searchText"] = model.SearchField;
//            }
//            return View(model);
//        }

//        // Gets list fo users
//        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
//        {
//            var _lookupManager = new LookupManager();
//            var searchText = TempData["searchText"] as string;
//            TempData.Keep("searchText");

//            var model = _lookupManager.GetRCListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

//            return PartialView("_RCListPartialView", model);
//        }

//        //
//        // GET: /Master/ReportClassifications/Create
//        public ActionResult Create()
//        {
//            var model = new ReportClassificationViewModel();
//            var commonManager = new CommonManager();
//            model.SystemTypeList = CommonManager.GetSystemTypes();

//            return View(model);
//        }

//        //
//        // POST: /Master/ReportClassifications/Create
//        [HttpPost]
//        public ActionResult Create(ReportClassificationViewModel model)
//        {
//            try
//            {
//                if (!ModelState.IsValid)
//                {
//                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
//                    return View(model);
//                }

//                if (ReportClassificationManager.IsExists(model.ID, model.Report_Classification))
//                {
//                    model.SystemTypeList = CommonManager.GetSystemTypes();
//                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Report Classification"), MessageType.danger);
//                    return View(model);
//                }

//                var id = ReportClassificationManager.Create(model);

//                if (id > 0)
//                {
//                    Session.Remove(VarConstants.AllReportClassCat);
//                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
//                }

//                return RedirectToAction("Index", new { showMessage = true });
//            }
//            catch
//            {
//                ShowMessage(CommonConstants.SaveError, MessageType.danger);
//                return View(model);
//            }
//        }

//        //
//        // GET: /Master/ReportClassifications/Edit/5
//        [CryptoValueProvider]
//        public ActionResult Edit(int id)
//        {
//            var model = ReportClassificationManager.GetById(id);
//            var commonManager = new CommonManager();
//            model.SystemTypeList = CommonManager.GetSystemTypes();

//            return View(model);
//        }

//        //
//        // POST: /Master/ReportClassifications/Edit/5
//        [HttpPost]
//        public ActionResult Edit(int id, ReportClassificationViewModel model)
//        {
//            try
//            {
//                this.ModelState.Remove("Report_Classification");

//                if (id != model.ID || !ModelState.IsValid)
//                {
//                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
//                    return View(model);
//                }

//                var success = ReportClassificationManager.Update(model);

//                if (success)
//                {
//                    Session.Remove(VarConstants.AllReportClassCat);
//                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
//                }

//                return RedirectToAction("Index", new { showMessage = true });
//            }
//            catch
//            {
//                ShowMessage(CommonConstants.SaveError, MessageType.danger);
//                return View(model);
//            }
//        }

//        /// <summary>
//        /// method to get list of report classification categories for autocomplete
//        /// </summary>
//        /// <returns></returns>
//        [HttpPost]
//        public JsonResult GetAllCategories(string prefix)
//        {
//			//CommonManager commonManager = new CommonManager();
//			//JavaScriptSerializer jSearializer = new JavaScriptSerializer();
//			//if (Session[VarConstants.AllReportClassCat] == null)
//			//    Session[VarConstants.AllReportClassCat] = commonManager.GetReportClassificationCategoryList();

//			//var list = (List<string>)Session[VarConstants.AllReportClassCat];
//			//list = list.Where(x => x.Contains(prefix, StringComparison.OrdinalIgnoreCase)).Take(10).ToList();
//			//return Json(jSearializer.Serialize(list), JsonRequestBehavior.AllowGet);
//			return null;
//        }

//        //
//        //// GET: /Master/ReportClassifications/Delete/5
//        //public ActionResult Delete(int id)
//        //{
//        //    return View();
//        //}

//        //
//        // POST: /Master/ReportClassifications/Delete/5
//        //[HttpPost]
//        //public ActionResult Delete(int id, ReportClassificationViewModel model)
//        //{
//        //    try
//        //    {
//        //        // TODO: Add delete logic here

//        //        return RedirectToAction("Index");
//        //    }
//        //    catch
//        //    {
//        //        return View();
//        //    }
//        //}
//    }
//}