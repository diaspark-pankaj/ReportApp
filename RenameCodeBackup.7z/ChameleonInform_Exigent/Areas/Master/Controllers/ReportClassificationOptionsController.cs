﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent_BusinessLogicLayer;
using Exigent_ViewModels.Common;
using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class ReportClassificationOptionsController : BaseController
    {
        // GET: Master/ReportClassificationOptions
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(bool showMessage = false)
        {
            if (showMessage)
                RecallMessageIfAny();

            TempData["SearchText"] = "";

            return View(new ReportClassificationOptionsListViemModel());
        }

        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(ReportClassificationOptionsListViemModel model)
        {
            if (model.SearchField != null)
            {
                model.SearchField = model.SearchField.Trim();
                TempData["searchText"] = model.SearchField;
            }
            else
            {
                TempData["searchText"] = model.SearchField;
            }
            return View(model);
        }

        //Get list of Report Classification
        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            var _lookupManager = new LookupManager();
            var searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");

            var model = _lookupManager.GetReportClassificationOptionListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

            return PartialView("_ReportClassificationOptionsListPartialView", model);
        }

        //
        // GET: /Master/ReportClassificationOption/Create
        public ActionResult Create()
        {
            return View(new ReportClassificationsOptionsViewModel());
        }

        //
        // POST: /Master/ReportClassificationOption/Create
        [HttpPost]
        public ActionResult Create(ReportClassificationsOptionsViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View(model);
                }

                if (ReportClassificationOptionManager.IsExists(model))
                {
                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Name"), MessageType.danger);
                    return View(model);
                }

                var Name = ReportClassificationOptionManager.CreateReportClassificationsOption(model);

                if (!string.IsNullOrEmpty(Name))
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);

                return View(model);
            }
        }


        //
        // GET: /Master/ReportClassificationOption/Edit/5
        [CryptoValueProvider]
        public ActionResult Edit(int id)
        {
            var model = ReportClassificationOptionManager.GetReportClassificationsOptionsById(id);

            return View(model);
        }

        //
        // POST: /Master/ReportClassificationOption/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, ReportClassificationsOptionsViewModel model)
        {
            try
            {
                ModelState.Remove("Name");

                if (id != model.Id || !ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View();
                }

                if (ReportClassificationOptionManager.IsExists(model))
                {
                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Name"), MessageType.danger);
                    return View(model);
                }

                var success = ReportClassificationOptionManager.UpdateReportClassificationOption(model);
                if (success)
                {
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
                }

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);
                return View(model);
            }
        }




    }
}