﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using Exigent_BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using Exigent.Common.Helpers;

namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class VendorLawyersController : BaseController
    {
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(bool showMessage = false)
        {
            if (showMessage)
                RecallMessageIfAny();

            TempData["SearchText"] = "";

            return View(new VendorLawyerListViewModel());
        }

        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(VendorLawyerListViewModel model)
        {
            if (model.SearchField != null)
            {
                model.SearchField = model.SearchField.Trim();
                TempData["searchText"] = model.SearchField;
            }
            else
            {
                TempData["searchText"] = model.SearchField;
            }
            return View(model);
        }

        // Gets list for VendorLawyers
        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            var _lookupManager = new LookupManager();
            var searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");

            var model = _lookupManager.GetVendorLawyerListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

            return PartialView("_VendorLawyerPartialView", model);
        }

        //
        // GET: /Master/VendorLawyers/Create
        public ActionResult Create()
        {
            var model = new VendorLawyerViewModel();
            model.VendorList = CommonManager.GetVendors();
            return View(model);
        }

        //
        // POST: /Master/VendorLawyers/Create
        [HttpPost]
        public ActionResult Create(VendorLawyerViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    model.VendorList = CommonManager.GetVendors();
                    return View(model);
                }

                if (VendorLawyerManager.IsExists(model.Id, model.Vendor1, model.Lawyer))
                {
                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Vendor-Lawyer"), MessageType.danger);
                    model.VendorList = CommonManager.GetVendors();
                    return View(model);
                }

                var id = VendorLawyerManager.CreateVendorLawyer(model);

                if (id > 0)
                {
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
                }

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);
                model.VendorList = CommonManager.GetVendors();
                return View(model);
            }
        }

        //
        // GET: /Master/VendorLawyers/Edit/5
        [CryptoValueProvider]
        public ActionResult Edit(int id)
        {
            var model = VendorLawyerManager.GetVendorLawyerById(id);
            model.VendorList = CommonManager.GetVendors();
            return View(model);
        }

        //
        // POST: /Master/VendorLawyers/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, VendorLawyerViewModel model)
        {
            try
            {
                if (id != model.Id || !ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    model.VendorList = CommonManager.GetVendors();
                    return View();
                }

                if (VendorLawyerManager.IsExists(model.Id, model.Vendor1, model.Lawyer))
                {
                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Vendor-Lawyer"), MessageType.danger);
                    model.VendorList = CommonManager.GetVendors();
                    return View(model);
                }

                var success = VendorLawyerManager.UpdateVendorLawyer(model);

                if (success)
                {
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
                }

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                model.VendorList = CommonManager.GetVendors();

                ShowMessage(CommonConstants.SaveError, MessageType.warning);

                return View(model);
            }
        }

        //
        //// GET: /Master/VendorLawyers/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //
        // POST: /Master/VendorLawyers/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, VendorLawyerViewModel collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
	}
}