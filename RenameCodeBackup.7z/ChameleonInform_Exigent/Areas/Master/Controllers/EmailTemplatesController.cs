﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent_BusinessLogicLayer;
using Exigent_ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class EmailTemplatesController : BaseController
    {
        EmailManager repo = new EmailManager();

        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(bool showMessage = false)
        {
            if (showMessage)
                RecallMessageIfAny();

            TempData["SearchText"] = "";

            return View(new EmailTemplatesListViewModel());
        }

        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(EmailTemplatesListViewModel model)
        {
            if (model.SearchField != null)
            {
                model.SearchField = model.SearchField.Trim();
                TempData["searchText"] = model.SearchField;
            }
            else
            {
                TempData["searchText"] = model.SearchField;
            }
            return View(model);
        }


        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            var _lookupManager = new LookupManager();
            var searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");

            var model = _lookupManager.GetEmailTemplatesListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

            return PartialView("_EmailTemplatesListPartialView", model);
        }
        
        [CryptoValueProvider]
        public ActionResult Manage(int id = 0)
        {
            ViewBag.EmailCategoryList = CommonManager.GetEmailCategoryList();
            var model = new EmailTemplateViewModel();
            if (id > 0)
                model = EmailManager.GetEmailTemplateById(id);

            if (Convert.ToInt32(Session["categoryId"]) > 0)
                model.CategoryId = (int)Session["categoryId"];

            return View(model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Manage(EmailTemplateViewModel model)
        {
            try
            {
                repo.SaveTemplates(model);
                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);
                return View(model);
            }
        }

        public ActionResult GetKeywordByObjectId(int id)
        {
            return PartialView("_SelectKeyWordPartial", repo.GetKeywordByObjectId(id));
        }

        public ActionResult GetTemplateById(int id)
        {
            var tid = repo.GetEmailTemplateByCatId(id);
            Session["categoryId"] = id;
            var Url = "../EmailTemplates/Manage" + "?q=" + Exigent.Common.Helpers.Crypto.Encrypt(new Dictionary<string, string> { { "id", tid.ToString() } });
            return Json(Url, JsonRequestBehavior.AllowGet);
        }

    }
}