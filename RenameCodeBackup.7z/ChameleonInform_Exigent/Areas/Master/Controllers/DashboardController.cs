﻿using ChameleonInformExigent.Controllers;
using ChameleonInformExigent.Helpers;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using System.Web.Mvc;
using System.Linq;
namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class DashboardController : BaseController
    {
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index()
        {
            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null && SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)SystemTypeEnum.ServiceProviderAdmin))
            {
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.AdminDashboard;
                return View();
            }
            else
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
        }
	}
}