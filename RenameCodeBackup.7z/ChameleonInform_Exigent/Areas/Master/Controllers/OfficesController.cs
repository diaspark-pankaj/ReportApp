﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent_BusinessLogicLayer;
using Exigent_ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class OfficesController : BaseController
    {
        OfficeManager repo = new OfficeManager();
        // GET: Master/Offices
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(bool showMessage = false)
        {
            if (showMessage)
                RecallMessageIfAny();

            TempData["SearchText"] = "";

            return View(new OfficesListViewModel());
        }

        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(OfficesListViewModel model)
        {
            if (model.SearchField != null)
            {
                model.SearchField = model.SearchField.Trim();
                TempData["searchText"] = model.SearchField;
            }
            else
            {
                TempData["searchText"] = model.SearchField;
            }
            return View(model);
        }
        
        //Get list of offices
        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            var _lookupManager = new LookupManager();
            var searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");

            var model = _lookupManager.GetOfficeListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

            return PartialView("_OfficeListPartialView", model);
        }

        [CryptoValueProvider]
        public ActionResult Edit(int id = 0)
        {
            ViewBag.CountryList = CommonManager.GetCountryList();
            var model = new OfficesViewModel();
            if (id > 0)
                model = OfficeManager.GetOfficeById(id);

            if (Convert.ToInt32(Session["CountryId"]) > 0)
                model.CountryId = (int)Session["CountryId"];

            return View(model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Edit(OfficesViewModel model)
        {
            try
            {
                model.IsActive = true;
                repo.SaveOffice(model);
                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);
                return View(model);
            }
        }


    }
}