﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using Exigent_BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using Exigent.Common.Helpers;

namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class LegalDesciplinesController : BaseController
    {
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(bool showMessage = false)
        {
            if (showMessage)
                RecallMessageIfAny();

            TempData["SearchText"] = "";

            return View(new LegalDesciplineListViewModel());
        }

        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(LegalDesciplineListViewModel model)
        {
            if (model.SearchField != null)
            {
                model.SearchField = model.SearchField.Trim();
                TempData["searchText"] = model.SearchField;
            }
            else
            {
                TempData["searchText"] = model.SearchField;
            }
            return View(model);
        }

        // Gets list of legal disciplines
        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            var _lookupManager = new LookupManager();
            var searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");

            var model = _lookupManager.GetLegalDesciplineListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

            return PartialView("_LegalDesciplineListPartialView", model);
        }

        //
        // GET: /Master/LegalDesciplines/Create
        public ActionResult Create()
        {
            var commonManager = new CommonManager();

            var model = new LegalDesciplineViewModel();
            model.LegalDisciplineList = CommonManager.GetLegalDiscipline(SystemTypes.BusinessUnit);

            PopulateModelEssentials(model);

            return View(model);
        }

        //
        // POST: /Master/LegalDesciplines/Create
        [HttpPost]
        public ActionResult Create(LegalDesciplineViewModel model)
        {
            try
            {
                var id = LegalDesciplineManager.CreateLegalDescipline(model);

                if (id > 0)
                {
                    Session.Remove(VarConstants.AllReportClass);
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
                }

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                PopulateModelEssentials(model);

                ShowMessage(CommonConstants.SaveError, MessageType.danger);

                return View(model);
            }
        }

        //
        // GET: /Master/LegalDesciplines/Edit/5
        [CryptoValueProvider]
        public ActionResult Edit(int id)
        {
            var model = LegalDesciplineManager.GetLegalDesciplineById(id);
            model.LegalDisciplineList = CommonManager.GetLegalDiscipline(SystemTypes.BusinessUnit);
            PopulateModelEssentials(model);

            return View(model);
        }

        //
        // POST: /Master/LegalDesciplines/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, LegalDesciplineViewModel model)
        {
            try
            {
                if (id != model.Id)
                {
                    PopulateModelEssentials(model);
                    return View();
                }

                var success = LegalDesciplineManager.UpdateLegalDescipline(model);

                if (success)
                {
                    Session.Remove(VarConstants.AllReportClass);
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
                }
                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                PopulateModelEssentials(model);

                ShowMessage(CommonConstants.SaveError, MessageType.warning);

                return View(model);
            }
        }

        private void PopulateModelEssentials(LegalDesciplineViewModel model)
        {
            var commonManager = new CommonManager();

            model.BusinessUnitList = commonManager.GetBusinessUnitsList();
            model.VendorList = CommonManager.GetVendors();
        }

        /// <summary>
        /// method to get list of report classifications for autocomplete
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetAllReportClassifications(string prefix)
        {
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
			if (Session[VarConstants.AllReportClass] == null)
				Session[VarConstants.AllReportClass] = CommonManager.GetLegalDiscipline(SystemTypes.BusinessUnit);
		

            var list = (List<SelectListItem>)Session[VarConstants.AllReportClass];
            list = list.Where(x => x.Text.Contains(prefix, StringComparison.OrdinalIgnoreCase)).Take(10).ToList();
            return Json(jSearializer.Serialize(list), JsonRequestBehavior.AllowGet);
        }

        //
        //// GET: /Master/LegalDesciplines/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //
        // POST: /Master/LegalDesciplines/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, LegalDesciplineViewModel model)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
	}
}