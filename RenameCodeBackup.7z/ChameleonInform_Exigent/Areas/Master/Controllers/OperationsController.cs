﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using Exigent_BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using Exigent.Common.Helpers;

namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class OperationsController : BaseController
    {
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(bool showMessage = false)
        {
            if (showMessage)
                RecallMessageIfAny();

            TempData["SearchText"] = "";

            return View(new OperationListViewModel());
        }

        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(OperationListViewModel model)
        {
            if (model.SearchField != null)
            {
                model.SearchField = model.SearchField.Trim();
                TempData["searchText"] = model.SearchField;
            }
            else
            {
                TempData["searchText"] = model.SearchField;
            }
            return View(model);
        }

        // Gets list for Operations
        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            var _lookupManager = new LookupManager();
            var searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");

            var model = _lookupManager.GetOperationListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

            return PartialView("_OperationPartialView", model);
        }

        //
        // GET: /Master/Operations/Create
        public ActionResult Create()
        {
            return View(new OperationViewModel());
        }

        //
        // POST: /Master/Operations/Create
        [HttpPost]
        public ActionResult Create(OperationViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View(model);
                }

                if (OperationManager.IsExists(model.Id, model.Operation))
                {
                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Operation"), MessageType.danger);
                    return View(model);
                }

                var id = OperationManager.CreateOperation(model);

                if (id > 0)
                {
                    Session.Remove(VarConstants.AllBUList);
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
                }

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);

                return View(model);
            }
        }

        //
        // GET: /Master/Operations/Edit/5
        [CryptoValueProvider]
        public ActionResult Edit(int id)
        {
            var model = OperationManager.GetOperationById(id);

            return View(model);
        }

        //
        // POST: /Master/Operations/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, OperationViewModel model)
        {
            try
            {
                if (id != model.Id)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View();
                }

                var success = OperationManager.UpdateOperation(model);

                if (success)
                {
                    Session.Remove(VarConstants.AllBUList);
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
                }

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.warning);

                return View(model);
            }
        }

        /// <summary>
        /// method to get list of users (user table) for autocomplete
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetAllBU(string prefix)
        {
            CommonManager commonManager = new CommonManager();
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            if (Session[VarConstants.AllBUList] == null)
                Session[VarConstants.AllBUList] = commonManager.GetBusinessUnitsList().ToList();

            var list = (List<SelectListItem>)Session[VarConstants.AllBUList];
            list = list.Where(x => x.Text.Contains(prefix, StringComparison.OrdinalIgnoreCase)).Take(10).ToList();
            return Json(jSearializer.Serialize(list), JsonRequestBehavior.AllowGet);
        }

        //
        //// GET: /Master/Operations/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //
        // POST: /Master/Operations/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, OperationViewModel collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
    }
}