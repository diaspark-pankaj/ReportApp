﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using Exigent_BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class CountriesController : BaseController
    {
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(bool showMessage = false)
        {
            if (showMessage)
                RecallMessageIfAny();

            TempData["SearchText"] = "";

            return View(new CountryListViewModel());
        }

        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(CountryListViewModel model)
        {
            if (model.SearchField != null)
            {
                model.SearchField = model.SearchField.Trim();
                TempData["searchText"] = model.SearchField;
            }
            else
            {
                TempData["searchText"] = model.SearchField;
            }
            return View(model);
        }

        // Gets list fo users
        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            var _lookupManager = new LookupManager();
            var searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");

            var model = _lookupManager.GetCountryListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

            return PartialView("_CountryPartialView", model);
        }

        //
        // GET: /Master/Countries/Create
        public ActionResult Create()
        {
            return View(new CountryViewModel());
        }

        //
        // POST: /Master/Countries/Create
        [HttpPost]
        public ActionResult Create(CountryViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View(model);
                }

                if (CountryManager.IsExists(model))
                {
                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Country or Code"), MessageType.danger);
                    return View(model);
                }

                var CountryCode = CountryManager.CreateCountry(model);

                if (!string.IsNullOrEmpty(CountryCode))
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);

                return View(model);
            }
        }

        //
        // GET: /Master/Countries/Edit/5
        [CryptoValueProvider]
        public ActionResult Edit(int id)
        {
            var model = CountryManager.GetCountryById(id);

            return View(model);
        }

        //
        // POST: /Master/Countries/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, CountryViewModel model)
        {
            try
            {
                ModelState.Remove("Country");

                if (id != model.Id || !ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View();
                }

                if (CountryManager.IsExists(model))
                {
                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Country or Code"), MessageType.danger);
                    return View(model);
                }

                var success = CountryManager.UpdateCountry(model);
                if (success)
                {
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
                }

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);
                return View(model);
            }
        }

        //
        //// GET: /Master/Countries/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //
        // POST: /Master/Countries/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, CountryViewModel collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
    }
}