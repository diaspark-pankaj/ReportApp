﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using Exigent_BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using Exigent.Common.Helpers;

namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class ClientCompaniesController : BaseController
    {
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(bool showMessage = false)
        {
            if (showMessage)
                RecallMessageIfAny();

            TempData["SearchText"] = "";

            return View(new ClientCompanyListViewModel());
        }

        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(ClientCompanyListViewModel model)
        {
            if (model.SearchField != null)
            {
                model.SearchField = model.SearchField.Trim();
                TempData["searchText"] = model.SearchField;
            }
            else
            {
                TempData["searchText"] = model.SearchField;
            }
            return View(model);
        }

        // Gets list for ClientCompanies
        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            var _lookupManager = new LookupManager();
            var searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");

            var model = _lookupManager.GetClientCompanyListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

            return PartialView("_ClientCompanyPartialView", model);
        }

        //
        // GET: /Master/ClientCompanies/Create
        public ActionResult Create()
        {
            return View(new ClientCompanyViewModel());
        }

        //
        // POST: /Master/ClientCompanies/Create
        [HttpPost]
        public ActionResult Create(ClientCompanyViewModel model)
        {
            try
            {
                if(!ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View(model);
                }

                if (ClientCompanyManager.IsExists(model.Id, model.Company_Name))
                {
                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Client Company"), MessageType.danger);
                    return View(model);
                }

                if(string.IsNullOrEmpty(model.Vat_Number))
                {
                    model.Vat_Number = "Not Registered";
                }

                var id = ClientCompanyManager.CreateClientCompany(model);

                if (id > 0)
                {
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
                }

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);

                return View(model);
            }
        }

        //
        // GET: /Master/ClientCompanies/Edit/5
        [CryptoValueProvider]
        public ActionResult Edit(int id)
        {
            var model = ClientCompanyManager.GetClientCompanyById(id);

            return View(model);
        }

        //
        // POST: /Master/ClientCompanies/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, ClientCompanyViewModel model)
        {
            try
            {
               // this.ModelState.Remove("Company_Name");

                if (id != model.Id || !ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View();
                }

                if (string.IsNullOrEmpty(model.Vat_Number))
                {
                    model.Vat_Number = "Not Registered";
                }

                var success = ClientCompanyManager.UpdateClientCompany(model);

                if (success)
                {
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
                }

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);

                return View(model);
            }
        }

        /// <summary>
        /// method to get list of users (user table) for autocomplete
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetAllBU(string prefix)
        {
            CommonManager commonManager = new CommonManager();
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            if (Session[VarConstants.AllBUList] == null)
                Session[VarConstants.AllBUList] = commonManager.GetBusinessUnitsList().Select(m => m.Text).ToList();

            var list = (List<string>)Session[VarConstants.AllBUList];
            list = list.Where(x => x.Contains(prefix, StringComparison.OrdinalIgnoreCase)).Take(10).ToList();
            return Json(jSearializer.Serialize(list), JsonRequestBehavior.AllowGet);
        }

        //
        //// GET: /Master/ClientCompanies/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //
        // POST: /Master/ClientCompanies/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, ClientCompanyViewModel collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
	}
}