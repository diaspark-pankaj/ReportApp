﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using Exigent_BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class VendorsController : BaseController
    {
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(bool showMessage = false)
        {
            if (showMessage)
                RecallMessageIfAny();

            TempData["SearchText"] = "";

            return View(new VendorListViewModel());
        }

        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(VendorListViewModel model)
        {
            if (model.SearchField != null)
            {
                model.SearchField = model.SearchField.Trim();
                TempData["searchText"] = model.SearchField;
            }
            else
            {
                TempData["searchText"] = model.SearchField;
            }
            return View(model);
        }

        // Gets list fo users
        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            var _lookupManager = new LookupManager();
            var searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");

            var model = _lookupManager.GetVendorListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

            return PartialView("_VendorListPartialView", model);
        }

        //
        // GET: /Master/Vendors/Create
        public ActionResult Create()
        {
            return View(new VendorViewModel());
        }

        //
        // POST: /Master/Vendors/Create
        [HttpPost]
        public ActionResult Create(VendorViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View(model);
                }

                if (VendorManager.IsExists(model.Id, model.Company_Name))
                {
                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Vendor"), MessageType.danger);
                    return View(model);
                }

                var id = VendorManager.CreateVendor(model);

                if (id > 0)
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);

                return View(model);
            }
        }

        //
        // GET: /Master/Vendors/Edit/5
        [CryptoValueProvider]
        public ActionResult Edit(int id)
        {
            var model = VendorManager.GetVendorById(id);

            return View(model);
        }

        //
        // POST: /Master/Vendors/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, VendorViewModel model)
        {
            try
            {
                if (id != model.Id)
                    return View();

                this.ModelState.Remove("Company_Name");

                if (!ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View(model);
                }
                
                var success = VendorManager.UpdateVendor(model);

                ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);

                return View(model);
            }
        }

        //
        //// GET: /Master/Vendors/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //
        // POST: /Master/Vendors/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, VendorViewModel model)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
	}
}