﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using Exigent_BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class CurrenciesController : BaseController
    {
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(bool showMessage = false)
        {
            if (showMessage)
                RecallMessageIfAny();

            TempData["SearchText"] = "";

            return View(new CurrencyListViewModel());
        }

        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(CurrencyListViewModel model)
        {
            if (model.SearchField != null)
            {
                model.SearchField = model.SearchField.Trim();
                TempData["searchText"] = model.SearchField;
            }
            else
            {
                TempData["searchText"] = model.SearchField;
            }
            return View(model);
        }

        // Gets list fo users
        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            var _lookupManager = new LookupManager();
            var searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");

            var model = _lookupManager.GetCurrencyListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

            return PartialView("_CurrencyPartialView", model);
        }

        //
        // GET: /Master/Currencies/Create
        public ActionResult Create()
        {
            return View(new CurrencyViewModel());
        }

        //
        // POST: /Master/Currencies/Create
        [HttpPost]
        public ActionResult Create(CurrencyViewModel model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View(model);
                }

                if (CurrencyManager.IsExists(model))
                {
                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Currency or Code"), MessageType.danger);
                    return View(model);
                }

                var id = CurrencyManager.CreateCurrency(model);

                if (!string.IsNullOrEmpty(id))
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.warning);
                return View(model);
            }
        }

        //
        // GET: /Master/Currencies/Edit/5
        [CryptoValueProvider]
        public ActionResult Edit(int id)
        {
            var model = CurrencyManager.GetCurrencyById(id);

            return View(model);
        }

        //
        // POST: /Master/Currencies/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, CurrencyViewModel model)
        {
            try
            {
                ModelState.Remove("Currency");

                if (id != model.Id || !ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View();
                }

                var success = CurrencyManager.UpdateCurrency(model);

                ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);
                return View(model);
            }
        }

        //
        //// GET: /Master/Currencies/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //
        // POST: /Master/Currencies/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, CurrencyViewModel collection)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
    }
}