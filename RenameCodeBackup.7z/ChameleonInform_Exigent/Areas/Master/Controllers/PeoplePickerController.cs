﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using Exigent_BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Master.Controllers
{
    public class PeoplePickerController : BaseController
    {
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(bool showMessage = false)
        {
            if (showMessage)
                RecallMessageIfAny();

            TempData["SearchText"] = "";

            return View(new PeoplePickerListViewModel());
        }

        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(PeoplePickerListViewModel model)
        {
            if (model.SearchField != null)
            {
                model.SearchField = model.SearchField.Trim();
                TempData["searchText"] = model.SearchField;
            }
            else
            {
                TempData["searchText"] = model.SearchField;
            }
            return View(model);
        }

        // Gets list fo users
        public ActionResult GetList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            var _lookupManager = new LookupManager();
            var searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");

            var model = _lookupManager.GetPeoplePickerListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText);

            return PartialView("_PeoplePickerListPartialView", model);
        }

        //
        // GET: /Master/PeoplePicker/Create
        public ActionResult Create()
        {
            return View(new PeoplePickerViewModel());
        }

        //
        // POST: /Master/PeoplePicker/Create
        [HttpPost]
        public ActionResult Create(PeoplePickerViewModel model)
        {
            try
            {
                if(!ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View(model);
                }

                if (PeoplePickerManager.IsExists(model.ID, model.Full_Name))
                {
                    ShowMessage(CommonConstants.FieldAlreadyExists.Replace("<Field>", "Name"), MessageType.danger);
                    return View(model);
                }

                var id = PeoplePickerManager.CreatePeoplePicker(model);

                if (id > 0)
                    ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);

                return View(model);
            }
        }

        //
        // GET: /Master/PeoplePicker/Edit/5
        [CryptoValueProvider]
        public ActionResult Edit(int id)
        {
            var model = PeoplePickerManager.GetPeoplePickerById(id);

            return View(model);
        }

        //
        // POST: /Master/PeoplePicker/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, PeoplePickerViewModel model)
        {
            try
            {
                if (id != model.ID)
                    return View();

                this.ModelState.Remove("Full_Name");

                if (!ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.ModelInvalidError, MessageType.danger);
                    return View(model);
                }

                var success = PeoplePickerManager.UpdatePeoplePicker(model);

                ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);

                return RedirectToAction("Index", new { showMessage = true });
            }
            catch
            {
                ShowMessage(CommonConstants.SaveError, MessageType.danger);

                return View(model);
            }
        }

        //
        //// GET: /Master/PeoplePicker/Delete/5
        //public ActionResult Delete(int id)
        //{
        //    return View();
        //}

        //
        // POST: /Master/PeoplePicker/Delete/5
        //[HttpPost]
        //public ActionResult Delete(int id, PeoplePickerViewModel model)
        //{
        //    try
        //    {
        //        // TODO: Add delete logic here

        //        return RedirectToAction("Index");
        //    }
        //    catch
        //    {
        //        return View();
        //    }
        //}
    }
}