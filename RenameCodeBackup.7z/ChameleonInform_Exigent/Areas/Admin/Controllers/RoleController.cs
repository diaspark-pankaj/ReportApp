﻿using Exigent_BusinessLogicLayer.Admin;
using Exigent_BusinessLogicLayer.Audit;
using Exigent.Common.Enums;
using Exigent.Helpers;
using ChameleonInformExigent.Controllers;
using Exigent.CustomAttributes;
using Exigent_ViewModels.Admin;
using System;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;
using ChameleonInformExigent.Helpers;

namespace ChameleonInformExigent.Areas.Admin.Controllers
{
    public class RoleController : BaseController
    {
        RoleManager roleManager = new RoleManager();
        string SearchText = null;
        int New_Genrated_Role_id;
        string CustomMessage;

        #region Actions

        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(int? mode)
        {
            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null && SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)SystemTypeEnum.ServiceProviderAdmin))
            {
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.AdminDashboard;
                var roleListViewModel = new RoleListViewModel
                {
                    RoleList = roleManager.GetAllRoles("").OrderBy(s => s.Name).ToList()
                };

                if (mode != 0 && mode != null)
                {
                    string msg;
                    switch (mode)
                    {
                        case (int)Mode.Add: //Add
                            msg = "Role has been created successfully.";
                            break;
                        case (int)Mode.Edit: //Edit
                            msg = "Role has been updated successfully.";
                            break;

                        default:
                            msg = "";
                            break;
                    }
                    ShowMessage(msg, MessageType.success);

                }

                return View(roleListViewModel);
            }
            else
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
        }

        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(RoleListViewModel roleViewModel)
        {

            SearchText = roleViewModel.searchField;
            SaveSearchFields();

            Expression<Func<RoleViewModel, bool>> objExpression;

            objExpression = (i => (string.IsNullOrEmpty(searchFields.RoleName) || i.Name.Contains(searchFields.RoleName)));


            var searchList = new RoleListViewModel
            {
                RoleList = roleManager.searchRole((objExpression))
            };


            return View(searchList);
        }

        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult CreateRole()
        {

            RoleViewModel createUserRoleViewModel = new RoleViewModel();
            {
                createUserRoleViewModel = roleManager.GetRole(0);

            };

            TempData["EditID"] = 0;
            return View(createUserRoleViewModel);
        }

        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult EditRole(int? RoleId)
        {

            TempData["EditID"] = RoleId;
            RoleViewModel rolesViewModel;
            if (RoleId.HasValue)
                rolesViewModel = roleManager.GetRole(RoleId.Value);

            else
                rolesViewModel = new RoleViewModel();

            return View("CreateRole", rolesViewModel);
        }

        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult SaveRole(RoleViewModel userRoleViewModel, FormCollection forms)
        {

            string permission = forms.Get("rolepermission");
            SessionHelper sessionHelper = (SessionHelper)Session["User"];
            int id = sessionHelper.LoggedUserInfo.UserId;

            int[] ids = { 0 };
            if (!string.IsNullOrEmpty(permission))

                ids = Array.ConvertAll<string, int>(permission.Split('|'), int.Parse);

            if (ids.Count() > 0)
            {

                //string message = "That role name has already been used";
                if (ModelState.IsValid)
                {

                    if (roleManager.IsRoleExists(userRoleViewModel.Name, userRoleViewModel.Id))
                    {
                        AuditManager.SaveAudit("Role already exists", "Role/SaveRole", sessionHelper.LoggedUserInfo.UserId);
                        ShowMessage("That role name has already been used.", MessageType.danger);
                        Int32 ID = 0;

                        if (!string.IsNullOrEmpty(TempData["EditID"].ToString()))
                        {
                            ID = Convert.ToInt32(TempData["EditID"].ToString());
                            TempData["EditID"] = ID;
                        }

                        RoleViewModel rolesViewModel;
                        if (ID != 0)
                            rolesViewModel = roleManager.GetRole(ID);
                        else
                            rolesViewModel = roleManager.GetRole(0);

                        return View("CreateRole", rolesViewModel);

                    }

                }


                bool RoleStatus = roleManager.SaveRole(userRoleViewModel, id, ids, out New_Genrated_Role_id);
            }
            if (userRoleViewModel.Id == 0)
            {
                CustomMessage = "Saved Role - " + userRoleViewModel.Name + " (" + New_Genrated_Role_id + ")";
                AuditManager.SaveAudit(CustomMessage, "Role/SaveRole", sessionHelper.LoggedUserInfo.UserId);
                return RedirectToAction("Index", "Role", new { mode = Convert.ToInt32(Mode.Add) });
            }

            else
            {
                CustomMessage = "Edited Role - " + userRoleViewModel.Name + " (" + userRoleViewModel.Id + ")";
                AuditManager.SaveAudit(CustomMessage, "Role/SaveRole", sessionHelper.LoggedUserInfo.UserId);
                return RedirectToAction("Index", "Role", new { mode = Convert.ToInt32(Mode.Edit) });
            }


        }

        #endregion

        #region Search
        [Serializable]
        struct SearchFields
        {
            public string RoleName;
        }

        /// <summary>
        /// To save search criteria.
        /// </summary>
        private void SaveSearchFields()
        {
            var _searchFields = new SearchFields();
            _searchFields.RoleName = SearchText;
            searchFields = _searchFields;
        }

        private SearchFields searchFields
        {
            get
            {
                return (TempData["SearchFields"] == null ? new SearchFields() : (SearchFields)TempData["SearchFields"]);
            }
            set
            {
                TempData["SearchFields"] = value;
            }
        }
        #endregion
    }
}