﻿using Exigent_BusinessLogicLayer.Admin;
using Exigent_BusinessLogicLayer.Audit;
using Exigent_BusinessLogicLayer.DropDowns;
using Exigent.Common.Enums;
using Exigent.Common.Helpers;
using Exigent.Helpers;
using Exigent.Common;
using ChameleonInformExigent.Controllers;
using Exigent.Helpers.CustomAttributes;
using Exigent_ViewModels.Admin;
using Exigent_ViewModels.DropDowns;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Web;
using System.Web.Mvc;
using Exigent.CustomAttributes;
using Exigent_BusinessLogicLayer.Admin.Exigent;
using ChameleonInformExigent.Helpers;
using Exigent_BusinessLogicLayer;
using Exigent.BLL;
using Exigent.ViewModels.Common;
using System.Web.Script.Serialization;
using Exigent.Common.Constants;
using Exigent_ViewModels.Common;

namespace ChameleonInformExigent.Areas.Admin.Controllers
{
    public class UserController : BaseController
    {
        UserManager _userManager;
        DropDownManager _dropDownManager = new DropDownManager();
       
        static string searchText;

        #region Actions

        public ActionResult Test()
        {

            return View();
        }

        // GET: /UserManagement/User/
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [CryptoValueProvider]
        public ActionResult Index(int? mode)
        {
            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null && SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)SystemTypeEnum.ServiceProviderAdmin || x.Id == (int)SystemTypeEnum.SuperGroupLegal))
            {
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.AdminDashboard;
            TempData["SearchText"] = "";
            UserListViewModel userListViewModel = new UserListViewModel();
            userListViewModel.UsersList = new List<UserListDetailViewModel>();
            string userResetMsg = TempData["userReset"] as string;
            if (!string.IsNullOrEmpty(userResetMsg))
                ShowMessage(userResetMsg, MessageType.success);
            return View(userListViewModel);
        }
            else
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
        }


        // Shreya Garhwal- 03/06/2017
        // Gets list fo users
        public ActionResult GetUsersList(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode)
        {
            int count = 0;
            LookupManager _lookupManager = new LookupManager();
            searchText = TempData["searchText"] as string;
            TempData.Keep("searchText");
            var userListViewModel = new UserListViewModel
            {
                UsersList = _lookupManager.GetUsersListByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, searchText, out count).ToList()
            };
            if (mode != 0 && mode != null)
            {
                string msg;
                switch (mode)
                {
                    case (int)Mode.Add: //Add
                        msg = "User has been created successfully.";
                        break;
                    case (int)Mode.Edit: //Edit
                        msg = "User has been updated successfully.";
                        break;
                    case (int)Mode.Delete: //Delete
                        msg = "User has been deleted successfully.";
                        break;
                    case (int)Mode.Reset: //Delete
                        msg = "Password has been reset successfully.";
                        break;
                    default:
                        msg = "";
                        break;
                }
                ShowMessage(msg, MessageType.success);
            }
            userListViewModel.RecordCount = count;
            return PartialView("_UserListPartial", userListViewModel);

        }

        // Shreya Garhwal - 03/09/2017
        // Post data of search field
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult Index(UserListViewModel userListViewModel)
        {
            if (userListViewModel.SearchField != null)
            {
                userListViewModel.SearchField = userListViewModel.SearchField.Trim();
                TempData["searchText"] = userListViewModel.SearchField;
            }
            else
            {
                TempData["searchText"] = userListViewModel.SearchField;
            }
            return View(userListViewModel);
        }

        /// <summary>
        /// method to get list of Law Firms for autocomplete
        /// </summary>
        /// <returns></returns>
         
         //Remove lawfirm dropdown as per requirement from user page ...........  By Mahwish Khan (12/6/2018)

        //[HttpPost]
        //public JsonResult GetLawFirmsFromFirmsPicker(string prefix)
        //{
        //    CommonManager commonManager = new CommonManager();
        //    JavaScriptSerializer jSearializer = new JavaScriptSerializer();
        //    if (Session[VarConstants.LawFirmsList] == null)
        //        Session[VarConstants.LawFirmsList] = commonManager.GetLawFirmsFromFirmsPicker();

        //    var firmsList = (List<EnumKeyValueViewModel>)Session[VarConstants.LawFirmsList];
        //    firmsList = firmsList.Where(x => x.Name.Contains(prefix, StringComparison.OrdinalIgnoreCase)).Take(10).ToList();
        //    return Json(jSearializer.Serialize(firmsList), JsonRequestBehavior.AllowGet);
        //}

        //Modified by-Shreya Garhwal- 04/04/2017
        // GET: /Admin/User/AddUser
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult AddUser()
        {
            var addUserViewModel = new AddUserViewModel();
            addUserViewModel.UserTypes = new DropDownManager().GetUserTypes().Select(x => new SelectListItem()
            {
                Value = x.Id.ToString(),
                Text = x.Description
            }).ToList();

            addUserViewModel.Office = new DropDownManager().GetOfficesList().Select(x => new SelectListItem()
            {
                Value = x.Id.ToString(),
                Text = x.OfficeName
            }).ToList();

            addUserViewModel.RoleList = new RoleManager().GetAllRoles("")
               .Select(x => new SelectListItem()
            {
                Value = x.Id.ToString(),
                Text = x.Description
            }).ToList();

            var roleAccessList = RoleManager.GetAccessByRole((int)SystemTypeEnum.ServiceProviderAdmin);
            addUserViewModel.UserAccessList = roleAccessList.Select(r => new UserAccessViewModel()
            {
                Rights = Convert.ToInt32(r.Key),
                AccessDashboard = new AccessDashboardViewModel()
                {
                    Description = r.Name
                }
            }).ToList();
            addUserViewModel.Dashboards = roleAccessList.Select(x => new SelectListItem()
            {
                Value = x.Key.ToString(),
                Text = x.Name
            }).ToList();
            addUserViewModel.BusinessUnitList = CommonManager.GetAllBusinessUnits().Select(m => new KeyValuePair<int, string>(m.Id, m.Business_Unit)).ToList();

            var commonManager = new CommonManager();
			addUserViewModel.MatterTypeList = CommonManager.GetLegalDiscipline(SystemTypes.BusinessUnit);
            addUserViewModel.DefaultDashboardID = roleAccessList.Select(x => x.DashBoardId).FirstOrDefault();

            addUserViewModel.IsActive = true;
            return View(addUserViewModel);
        }


        // //Modified by -Shreya Garhwal- 04/04/2017
        // GET: /Admin/User/EditUser
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [CryptoValueProvider]
        public ActionResult EditUser(int? userId)
        {
            _userManager = new UserManager();
            if (Session["User"] != null)
            {
                var sessionHelper = (SessionHelper)Session["User"];
            }

            //Edit
            if (userId.HasValue && userId.Value != 0)
            {
                FetchedUserViewModel fetchedUserViewModel = _userManager.GetUserById(userId.Value);
                if (fetchedUserViewModel.UserId > 0)
                {
                    var editUserViewModel = new EditUserViewModel
                                            {
                                                Id = fetchedUserViewModel.UserId,
                                                Email = fetchedUserViewModel.Email.Trim(),
                                                UserName = fetchedUserViewModel.UserName.Trim(),
                                                FullName = fetchedUserViewModel.FullName,
                                                ThumbImage = fetchedUserViewModel.ThumbImage,
                                                IsActive = fetchedUserViewModel.IsActive,
                                                UserTypeId = fetchedUserViewModel.UserTypeId,
                                                UserAccessString = fetchedUserViewModel.UserAccessList.Select(x => x.Rights).ToList(),
                                                UserAccessList = fetchedUserViewModel.UserAccessList,
                                                LawFirm = fetchedUserViewModel.LawFirm,
                                                DefaultDashboardID= fetchedUserViewModel.DefaultDashboardID,
                                                OfficeId = fetchedUserViewModel.OfficeId
                                            };

                    if (fetchedUserViewModel.RoleLists.Count > 0)
                        editUserViewModel.RoleId = fetchedUserViewModel.RoleLists[0];
                    if (fetchedUserViewModel.RoleLists != null)
                        editUserViewModel.RoleIds = fetchedUserViewModel.RoleLists;

                    if (fetchedUserViewModel.BusinessUnitIds != null)
						editUserViewModel.BusinessUnitIds = fetchedUserViewModel.BusinessUnitIds;
						

					if (fetchedUserViewModel.MatterTypeIds != null)
                        editUserViewModel.MatterTypeIds = fetchedUserViewModel.MatterTypeIds;


					var useragent = Request.UserAgent;

                    if (useragent != null)
                    {
                        if (useragent.ToLower().Contains("android"))
                        {
                            editUserViewModel.IsMobileRequest = true;
                        }
                        else
                        {
                            editUserViewModel.IsMobileRequest = Request.Browser.IsMobileDevice;
                        }
                    }

                    string CompId = string.Empty;

                    editUserViewModel.UserTypes = new DropDownManager().GetUserTypes().Select(x => new SelectListItem()
                    {
                        Value = x.Id.ToString(),
                        Text = x.Description
                    }).ToList();

                    editUserViewModel.Office = new DropDownManager().GetOfficesList().Select(x => new SelectListItem()
                    {
                        Value = x.Id.ToString(),
                        Text = x.OfficeName
                    }).ToList();

                    editUserViewModel.RoleList = new RoleManager().GetAllRoles("")
                    .Select(x => new SelectListItem()
                    {
                        Value = x.Id.ToString(),
                        Text = x.Description
                    }).ToList();
                   
                    var roleAccessList = RoleManager.GetAccessByRole(editUserViewModel.RoleId);
                    editUserViewModel.UserAccessList = roleAccessList.Select(r => new UserAccessViewModel()
                    {
                        Rights = Convert.ToInt32(r.Key),
                        AccessDashboard = new AccessDashboardViewModel()
                        {
                            Description = r.Name
                        }
                    }).ToList();
                    editUserViewModel.Dashboards = roleAccessList.Select(x => new SelectListItem()
                    {
                        Value = x.Key.ToString(),
                        Text = x.Name
                    }).ToList();
                    editUserViewModel.BusinessUnitList = CommonManager.GetAllBusinessUnits().Select(m => new KeyValuePair<int, string>(m.Id, m.Business_Unit)).ToList();

					
					editUserViewModel.MatterTypeList = CommonManager.GetLegalDiscipline(SystemTypes.BusinessUnit);
                    editUserViewModel.DefaultDashboardID = roleAccessList.Select(x => x.DashBoardId).FirstOrDefault();


                    return View(editUserViewModel);
                }
                ShowMessage("Data doesn't exist for this user", MessageType.danger);
                return RedirectToAction("Index", "User");
            }
            return RedirectToAction("AddUser", "User");
        }

        // Adds User in database
        //Modified by-Shreya Garhwal- 04/04/2017
        // POST: /Admin/User/AddUser
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        public ActionResult AddUser(AddUserViewModel addUserViewModel, HttpPostedFileBase file)
        {
            _userManager = new UserManager();
            //Server-side validation

            if (!ModelState.IsValid)
            {

                addUserViewModel.UserTypes = new DropDownManager().GetUserTypes().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();

                addUserViewModel.Office = new DropDownManager().GetOfficesList().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.OfficeName
                }).ToList();


                addUserViewModel.RoleList = new RoleManager().GetAllRoles("")
              .Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();

                var userAccessList = CommonManager.GetAccessDashboards();
                addUserViewModel.UserAccessList = userAccessList.Select(r => new UserAccessViewModel()
                {
                    Rights = r.ID,
                    AccessDashboard = new AccessDashboardViewModel()
                    {
                        Description = r.Description
                    }
                }).ToList();

                addUserViewModel.Dashboards = userAccessList.Select(x => new SelectListItem()
                {
                    Value = x.ID.ToString(),
                    Text = x.Description
                }).ToList();

                addUserViewModel.BusinessUnitList = CommonManager.GetAllBusinessUnits().Select(m => new KeyValuePair<int, string>(m.Id, m.Business_Unit)).ToList();

				
				addUserViewModel.MatterTypeList = CommonManager.GetLegalDiscipline(SystemTypes.BusinessUnit);

                addUserViewModel.IsActive = false;
                return View(addUserViewModel);
            }

            //Get Session Values
            var sessionHelper = (SessionHelper)Session["User"];

            addUserViewModel.IsActive = addUserViewModel.IsActive;

            //Username and FullName Duplicacy Check - only for add case

            bool isUserExist = _userManager.IsUserNameExists(addUserViewModel.UserName);
            bool isFullNameExist = _userManager.IsFullNameExists(addUserViewModel.FullName);
            //bool isHODUserExist = false;
            //if (addUserViewModel.UserTypeId == Convert.ToInt32(UserTypes.GroupLegalSuper))
            //{
            //    isHODUserExist = _userManager.isHODUserExits();
            //}
            if (isUserExist || isFullNameExist)
            {
                addUserViewModel.UserTypes = new DropDownManager().GetUserTypes().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();

                addUserViewModel.Office = new DropDownManager().GetOfficesList().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.OfficeName
                }).ToList();

                addUserViewModel.RoleList = new RoleManager().GetAllRoles("")
             .Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();

                var userAccessList = CommonManager.GetAccessDashboards();
                addUserViewModel.UserAccessList = userAccessList.Select(r => new UserAccessViewModel()
                {
                    Rights = r.ID,
                    AccessDashboard = new AccessDashboardViewModel()
                    {
                        Description = r.Description
                    }
                }).ToList();

                addUserViewModel.Dashboards = userAccessList.Select(x => new SelectListItem()
                {
                    Value = x.ID.ToString(),
                    Text = x.Description
                }).ToList();

                addUserViewModel.BusinessUnitList = CommonManager.GetAllBusinessUnits().Select(m => new KeyValuePair<int, string>(m.Id, m.Business_Unit)).ToList();

				
				addUserViewModel.MatterTypeList = CommonManager.GetLegalDiscipline(SystemTypes.BusinessUnit);

                addUserViewModel.IsActive = false;
                //if (isHODUserExist)
                //{
                //    ShowMessage(VarConstants.HODUserExists, MessageType.danger);
                //}
                if (isUserExist && isFullNameExist)
                {
                    AuditManager.SaveAudit("Saving User Name and Full Name" + addUserViewModel.UserName + " ," + addUserViewModel.FullName + "already exist", "User/AddUser", sessionHelper.LoggedUserInfo.UserId);
                    ShowMessage(VarConstants.UserNameFullNameExist, MessageType.danger);
                }
                else if (isUserExist)
                {
                    AuditManager.SaveAudit("Saving User Name " + addUserViewModel.UserName + "already exists", "User/AddUser", sessionHelper.LoggedUserInfo.UserId);
                    ShowMessage(VarConstants.UserNameExists, MessageType.danger);
                }
                else if (isFullNameExist)
                {
                    AuditManager.SaveAudit("Saving Full Name " + addUserViewModel.FullName + "already exists", "User/AddUser", sessionHelper.LoggedUserInfo.UserId);
                    ShowMessage(VarConstants.FullNameExits, MessageType.danger);
                }
                return View(addUserViewModel);
            }

            if (file != null)
            {
                //Upload Image
                var fileName = DateTime.Now.ToString("ssmmhhddMMyy") + "_" + Path.GetFileName(file.FileName);
                var originalFileName = fileName;
                var thumbFileName = "thumb_" + fileName;
                var originalPath = Path.Combine(Server.MapPath("~/Images/UserImage"), originalFileName);
                var thumbPath = Path.Combine(Server.MapPath("~/Images/UserImage"), thumbFileName);

                // Load image
                Image image = Image.FromStream(file.InputStream, true, true);

                // Compute thumbnail size
                Size thumbnailSize = CommonHelper.GetThumbnailSize(image);

                if (thumbnailSize.Width > 0 && thumbnailSize.Height > 0)
                {
                    // Get thumbnail
                    Image thumbnail = image.GetThumbnailImage(thumbnailSize.Width,
                        thumbnailSize.Height, null, IntPtr.Zero);

                    // Save thumbnail
                    thumbnail.Save(thumbPath);
                    addUserViewModel.ThumbImage = thumbFileName;
                }
                file.SaveAs(originalPath);
                ModelState.Clear();

                //set images in object
                addUserViewModel.OriginalImage = originalFileName;
            }

            //Generate Random Password
            //addUserViewModel.Password = RandomPassword.Generate(7);
            //Generate Salt password...using MD5.
            //var newKey = SaltGenerationHelper.GenerateSaltForPassword(32);

            var password = SaltGenerationHelper.HashPassword(addUserViewModel.Password);

            addUserViewModel.Password = password[0].ToString();
            addUserViewModel.SecurityStamp = password[1].ToString();

            // addUserViewModel.RoleList = new List<RolesViewModel>();
            //Re-create form            
            //foreach (var role in addUserViewModel.RoleIds)
            //{
            //    addUserViewModel.RoleList.Add(new RolesViewModel() { Id = Convert.ToInt32(role.ToString()) });
            //}
            //addUserViewModel.RoleList.Add(addUserViewModel.RoleId);

            //addUserViewModel.UserAccessList = new List<UserAccessViewModel>();
            //foreach (var userAccess in addUserViewModel.HiddenUserAccessString)
            //{
            //    addUserViewModel.UserAccessList.Add(new UserAccessViewModel() { Rights = userAccess });
            //}

            //Save User Detail.
            int newGenratedUserID;
            addUserViewModel.RoleId = addUserViewModel.hdRoleId;
            bool addStatus = _userManager.AddUser(addUserViewModel, sessionHelper.LoggedUserInfo.UserId, out newGenratedUserID);



            if (addStatus)
            {

                string cusstomMessage = "Added User - " + addUserViewModel.Email + " (" + newGenratedUserID + ")";

                //AuditManager.SaveAudit(cusstomMessage, "User/AddUser", sessionHelper.LoggedUserInfo.UserId);

                //QueryString
                var qsDictionary = new Dictionary<string, string>
                                   {
                                       {"mode", Convert.ToInt32(Mode.Add).ToString()}
                                   };

                return RedirectToAction("Index", "User", new { q = Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary) });
            }
            else
            {
                
                addUserViewModel.UserTypes = new DropDownManager().GetUserTypes().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();

                addUserViewModel.Office = new DropDownManager().GetOfficesList().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.OfficeName
                }).ToList();

                addUserViewModel.RoleList = new RoleManager().GetAllRoles("")
              .Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();

                var userAccessList = CommonManager.GetAccessDashboards();
                addUserViewModel.UserAccessList = userAccessList.Select(r => new UserAccessViewModel()
                {
                    Rights = r.ID,
                    AccessDashboard = new AccessDashboardViewModel()
                {
                    Description = r.Description
                }
                }).ToList();

                addUserViewModel.Dashboards = userAccessList.Select(x => new SelectListItem()
                {
                    Value = x.ID.ToString(),
                    Text = x.Description
                }).ToList();

                addUserViewModel.BusinessUnitList = CommonManager.GetAllBusinessUnits().Select(m => new KeyValuePair<int, string>(m.Id, m.Business_Unit)).ToList();

                var commonManager = new CommonManager();
				
				addUserViewModel.MatterTypeList = CommonManager.GetLegalDiscipline(SystemTypes.BusinessUnit);

                addUserViewModel.IsActive = false;
                ShowMessage("Some error occured while saving. Please try again", MessageType.danger);
            }
            return View(addUserViewModel);
        }

        //Modified by -Shreya Garhwal- 04/04/2017
        // POST: /Admin/User/EditUser
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditUser(EditUserViewModel editUserViewModel, HttpPostedFileBase file)
        {
            _userManager = new UserManager();
            //editUserViewModel.Email = editUserViewModel.Email.Trim();
            //Server-side validation
            if (!ModelState.IsValid)
            {
                editUserViewModel.UserTypes = new DropDownManager().GetUserTypes().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();

                editUserViewModel.Office = new DropDownManager().GetOfficesList().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.OfficeName
                }).ToList();

                editUserViewModel.RoleList = new RoleManager().GetAllRoles("")
               .Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();

                var userAccessList = CommonManager.GetAccessDashboards();
                
                editUserViewModel.Dashboards = userAccessList.Select(x => new SelectListItem()
                {
                    Value = x.ID.ToString(),
                    Text = x.Description
                }).ToList();

                editUserViewModel.BusinessUnitList = CommonManager.GetAllBusinessUnits().Select(m => new KeyValuePair<int, string>(m.Id, m.Business_Unit)).ToList();

				
				editUserViewModel.MatterTypeList = CommonManager.GetLegalDiscipline(SystemTypes.BusinessUnit);

				return View(editUserViewModel);
            }

            //Get Session Values
            var sessionHelper = (SessionHelper)Session["User"];

            //User Duplicacy Check 
            if (_userManager.IsFullNameExistsOnEditUser(editUserViewModel.FullName, editUserViewModel.Id))
            {
                editUserViewModel.OriginalImage = editUserViewModel.OriginalImage;
                editUserViewModel.ThumbImage = editUserViewModel.ThumbImage;

                editUserViewModel.UserTypes = new DropDownManager().GetUserTypes().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();

                editUserViewModel.Office = new DropDownManager().GetOfficesList().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.OfficeName
                }).ToList();

                editUserViewModel.RoleList = new RoleManager().GetAllRoles("")
               .Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();


                var userAccessList = CommonManager.GetAccessDashboards();
                editUserViewModel.UserAccessList = userAccessList.Select(r => new UserAccessViewModel()
                {
                    Rights = r.ID,
                    AccessDashboard = new AccessDashboardViewModel()
                {
                    Description = r.Description
                }
                }).ToList();

                editUserViewModel.Dashboards = userAccessList.Select(x => new SelectListItem()
                {
                    Value = x.ID.ToString(),
                    Text = x.Description
                }).ToList();

                editUserViewModel.BusinessUnitList = CommonManager.GetAllBusinessUnits().Select(m => new KeyValuePair<int, string>(m.Id, m.Business_Unit)).ToList();

				
				editUserViewModel.MatterTypeList = CommonManager.GetLegalDiscipline(SystemTypes.BusinessUnit);

				ShowMessage("Full Name already exists. Try for another", MessageType.danger);
                return View(editUserViewModel);
            }

            if (file != null)
            {
                //Upload Image
                var fileName = DateTime.Now.ToString("ssmmhhddMMyy") + "_" + Path.GetFileName(file.FileName);
                var originalFileName = fileName;
                var thumbFileName = "thumb_" + fileName;
                var originalPath = Path.Combine(Server.MapPath("~/Images/UserImage"), originalFileName);
                var thumbPath = Path.Combine(Server.MapPath("~/Images/UserImage"), thumbFileName);

                // Load image
                Image image = Image.FromStream(file.InputStream, true, true);

                // Compute thumbnail size
                Size thumbnailSize = CommonHelper.GetThumbnailSize(image);

                // Get thumbnail
                if (thumbnailSize.Width > 0 && thumbnailSize.Height > 0)
                {
                    Image thumbnail = image.GetThumbnailImage(thumbnailSize.Width,
                        thumbnailSize.Height, null, IntPtr.Zero);

                    // Save thumbnail
                    thumbnail.Save(thumbPath);
                    editUserViewModel.ThumbImage = thumbFileName;
                }
                file.SaveAs(originalPath);
                ModelState.Clear();

                //set images in object
                editUserViewModel.OriginalImage = originalFileName;
            }

            //Update User Detail.
            string thumbImage;
            string originalImage;
            DateTime? modifiedDate;

            if (editUserViewModel.UserAccessList == null)
                editUserViewModel.UserAccessList = new List<UserAccessViewModel>();

            //foreach (var userAccess in editUserViewModel.UserAccessString)
            //{
            //    if (!editUserViewModel.UserAccessList.Any(x => x.Rights.Equals(userAccess)))
            //    {
            //        editUserViewModel.UserAccessList.Add(new UserAccessViewModel() { Rights = Convert.ToInt32(userAccess) });
            //    }
            //    else
            //    {
            //        //var userAcc = editUserViewModel.UserAccessList.Find(x => x.Rights == userAccess.ToString());
            //        //editUserViewModel.UserAccessList.Remove(userAcc);
            //    }
            //}

            //save user modified data...
            bool editStatus = _userManager.EditUser(editUserViewModel, sessionHelper.LoggedUserInfo.UserId, out thumbImage, out originalImage, out modifiedDate);

            //Set new values to session.
            if (editUserViewModel.Id == sessionHelper.LoggedUserInfo.UserId)
            {
                if (modifiedDate.HasValue)
                {

                    sessionHelper.LoggedUserInfo.DateModified = modifiedDate.Value;
                }
                Session["User"] = sessionHelper;
            }

            //Re-create form
            editUserViewModel.OriginalImage = originalImage;
            editUserViewModel.ThumbImage = thumbImage;

            if (editStatus)
            {
                //Audit Login
                string CusstomMessage = "Edited User - " + editUserViewModel.Email + " (" + editUserViewModel.Id + ")";

                // AuditManager.SaveAudit(CusstomMessage, "User/EditUser", sessionHelper.LoggedUserInfo.UserId);

                //QueryString
                var qsDictionary = new Dictionary<string, string>
                                   {
                                       {"mode", Convert.ToInt32(Mode.Add).ToString()}
                                   };
                ShowMessage("User has been updated successfully", MessageType.success);
                return RedirectToAction("Index", "User", new { q = Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary) });
            }
            else
            {
                editUserViewModel.UserTypes = new DropDownManager().GetUserTypes().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();

                editUserViewModel.Office = new DropDownManager().GetOfficesList().Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.OfficeName
                }).ToList();

                editUserViewModel.RoleList = new RoleManager().GetAllRoles("")
                .Select(x => new SelectListItem()
                {
                    Value = x.Id.ToString(),
                    Text = x.Description
                }).ToList();
                var userAccessList = CommonManager.GetAccessDashboards();
                editUserViewModel.UserAccessList = userAccessList.Select(r => new UserAccessViewModel()
                {
                    Rights = r.ID,
                    AccessDashboard = new AccessDashboardViewModel()
                    {
                        Description = r.Description
                    }
                }).ToList();

                editUserViewModel.Dashboards = userAccessList.Select(x => new SelectListItem()
                {
                    Value = x.ID.ToString(),
                    Text = x.Description
                }).ToList();

                editUserViewModel.BusinessUnitList = CommonManager.GetAllBusinessUnits().Select(m => new KeyValuePair<int, string>(m.Id, m.Business_Unit)).ToList();

				
				editUserViewModel.MatterTypeList = CommonManager.GetLegalDiscipline(SystemTypes.BusinessUnit);
			}
            //Audit Login
            // AuditManager.SaveAudit("Edited User Failed", "User/EditUser", sessionHelper.LoggedUserInfo.UserId);
            ShowMessage("Some error occured while saving. Please try again", MessageType.danger);

            return View(editUserViewModel);
        }

        [HttpPost]
        public ActionResult GetRoleAccessList(int RoleId)
        {           
            var List = RoleManager.GetAccessByRole(RoleId);
            return Json(List, JsonRequestBehavior.AllowGet);
        }

        // Update user status from active to inactive and vice versa
        // GET: /Admin/User/ResetUser
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        [CryptoValueProvider]
        public ActionResult ResetUser(int? userId)
        {
            _userManager = new UserManager();

            //Get Session Values            
            var sessionHelper = (SessionHelper)Session["User"];

        
            if (_userManager.ResetUserStatus(userId.Value))
            {
              
                TempData["userReset"] = "User has been reset successfully";
            }
            else
            {
                
                ShowMessage("Due to some error reset user failed", MessageType.danger);
            }

            //QueryString
            var qsDictionary = new Dictionary<string, string>
                                   {
                                       {"mode", Convert.ToInt32(Mode.Reset).ToString()}
                                   };

            return RedirectToAction("Index", "User", new { q = Exigent.Common.Helpers.Crypto.Encrypt(qsDictionary) });

        }

        [HttpPost]
        public bool ResetUserImage(int? userId)
        {
            string CusstomMessage = "Edited User - " + userId + "";
            _userManager = new UserManager();

            if (_userManager.ResetUserImage(SessionHelper.LoggedUserInfo.UserId, userId.Value))
            {
                // AuditManager.SaveAudit(CusstomMessage, "User/EditUser", SessionHelper.LoggedUserInfo.UserId);
                SessionHelper.LoggedUserInfo.ThumbImage = null;

                Session["User"] = null;
                Session["User"] = SessionHelper;
            }
            else
            {
                //Audit Login
                //AuditManager.SaveAudit("Reset Password Failed", "User/ResetUser", SessionHelper.LoggedUserInfo.UserId);
                ShowMessage("Due to some error password not reset yet.", MessageType.danger);
            }
            return true;

        }

        public ActionResult ChangePassword()
        {
            ChangePasswordViewModel _ChangePasswordViewModel = new ChangePasswordViewModel();
            return View(_ChangePasswordViewModel);
        }

        //
        // POST: /Admin/User/ChangePassword
        //[CustomAuthorization(PageSecurityDisabled = false, PageViewActivity = AppActivityEnum.UserManagement_View, PageEditActivity = AppActivityEnum.UserManagement_Edit, PageAddActivity = AppActivityEnum.UserManagement_Add)]
        [HttpPost]
        public ActionResult ChangePassword(ChangePasswordViewModel changePasswordViewModel)
        {
            _userManager = new UserManager();
            LoginViewModel loginViewModel = new LoginViewModel();
            loginViewModel.UserName = SessionHelper.LoggedUserInfo.UserName;
            loginViewModel.Password = changePasswordViewModel.OldPassword;
            var user = _userManager.GetUserByUserName(loginViewModel.UserName);
            if (user == null)
            {
                ShowMessage("Username does not exist. Please try again", MessageType.danger);
                return RedirectToAction("Index", "Login");
            }
            loginViewModel.PasswordHash = user.PasswordHash;
            bool result = _userManager.ValidateCredentials(loginViewModel);
            if (!result)
            {
                //Audit Login
                //AuditManager.SaveAudit("Incorrect Old Password", "User/ChangePassword", SessionHelper.LoggedUserInfo.UserId);

                ShowMessage("Please enter correct Old Password.", MessageType.danger);
                return View(changePasswordViewModel);
            }

            int noOfLastNonreUsablePasswords = Convert.ToInt32(CoreManager.GetAllAppConfigSettings().Where(i => i.AppKey == "NoOfLastNonreUsablePasswords").First().AppVaue);

            var sessionHelper = (SessionHelper)Session["User"];

            //Check last 12 passwords
            if (_userManager.MatchPassFromPasswordHistory(changePasswordViewModel, noOfLastNonreUsablePasswords, sessionHelper.LoggedUserInfo.UserId))
            {
                //Audit Login
                //AuditManager.SaveAudit("Password connot be same", "User/ChangePassword", SessionHelper.LoggedUserInfo.UserId);

                ShowMessage("New password connot be same as last " + noOfLastNonreUsablePasswords + " passwords", MessageType.danger);
                return View(changePasswordViewModel);
            }

            //Audit Login
            string CustomMessage = "Changed Password - " + " (" + SessionHelper.LoggedUserInfo.UserId + ")";
            // AuditManager.SaveAudit(CustomMessage, "User/ChangePassword", SessionHelper.LoggedUserInfo.UserId);

            _userManager.ChangeUserPassword(changePasswordViewModel, SessionHelper.LoggedUserInfo.UserId);
            ShowMessage("Password Changed Successfully", MessageType.success);
            changePasswordViewModel.OldPassword = "";
            changePasswordViewModel.NewPassword = "";
            changePasswordViewModel.ConfirmPassword = "";
            return RedirectToAction("MyProfile", "Home", new { area = "Home" });
        }

        #endregion
    }
}