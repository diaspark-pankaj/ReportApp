﻿using Exigent_BusinessLogicLayer.Admin.Exigent;
using Exigent_BusinessLogicLayer.Audit;
using Exigent.Common.Enums;
using ChameleonInformExigent.Controllers;
using Exigent_ViewModels.Admin.Exigent;
using Resources;
using System;
using System.Collections.Generic;
using System.Web.Mvc;
namespace ChameleonInformExigent.Areas.Admin.Controllers
{
    /// <summary>
    /// core methods
    /// </summary>
    public class CoreController : BaseController
    {
        #region Methods
        public void ShowMessage(string message, MessageType messageType)
        {
            ViewBag.MessageType = messageType;
            ModelState.AddModelError(string.Empty, message);
        }
        #endregion

        #region Actions
        #endregion
        //
        // GET: /Admin/Core/
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AppConfig(int? mode)
        {
            if (mode != 0 && mode != null)
            {
                string updateMsg;
                switch (mode)
                {
                    case (int)Mode.Edit: //Update
                        updateMsg = AppConfigResource.UpdateMessage;
                        break;

                    default:
                        updateMsg = String.Empty;
                        break;
                }
                ShowMessage(updateMsg, MessageType.success);

            }
            AppConfigViewModel AppConfigViewModelList = new AppConfigViewModel
            {
                AppConfigList = CoreManager.GetAllAppConfigSettings()
            };

            AuditManager.SaveAudit("AppConfigVisited", "Admin/AppConfig", SessionHelper.LoggedUserInfo.UserId);

            return View(AppConfigViewModelList.AppConfigList);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult UpdateAppConfig(List<AppConfigViewModel> appConfigViewModel)
        {
            CoreManager.UpdateAppConfigSettings(appConfigViewModel, SessionHelper.LoggedUserInfo.UserId);
            AuditManager.SaveAudit("Edited", "Admin/UpdateAppConfig", SessionHelper.LoggedUserInfo.UserId);
            return RedirectToAction("AppConfig", "Core", new { mode = Convert.ToInt32(Mode.Edit) });
        }

    }
}