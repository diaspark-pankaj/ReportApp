﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Admin.Controllers
{
    public class HtmlContentController : BaseController
    {
        //
        // GET: /Admin/HtmlContent/
        public ActionResult Update(int id = 1)
        {
            ViewBag.HtmlContents = CommonManager.GetHtmlContent(id);

            return View();
        }

        /// <summary>
        /// Update Html Contents
        /// </summary>
        /// <param name="description"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Update(string description, int id = 1)
        {
            CommonManager.UpdateHtmlContent(id, description);

            ViewBag.HtmlContents = description;

            return View();
        }
	}
}