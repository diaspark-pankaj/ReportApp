﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.ViewModels.Admin;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Admin.Controllers
{
    public class ManageLoginPageController : BaseController
    {
        //
        // GET: /Admin/ManageLogin/
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard})]
        public ActionResult Index()
        {
            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null && SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)SystemTypeEnum.ServiceProviderAdmin || x.Id == (int)SystemTypeEnum.SuperGroupLegal))
            {
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.AdminDashboard;
                ManageLoginPageViewModel manageLoginPageViewModel = new ManageLoginPageViewModel();
                ManageLoginPageManager manageLoginPageManager = new ManageLoginPageManager();
                manageLoginPageViewModel = manageLoginPageManager.GetLoginPageAttributes();
                return View(manageLoginPageViewModel);
            }
            else
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
        }

        [HttpPost]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Index(ManageLoginPageViewModel manageLoginPageViewModel, HttpPostedFileBase file)
        {
            ManageLoginPageManager manageLoginPageManager = new ManageLoginPageManager();

            //if ((string.IsNullOrEmpty(manageLoginPageViewModel.NotificationBoardMessage)) && (string.IsNullOrEmpty(manageLoginPageViewModel.File)))
            //{
            //    ShowMessage("Atleast one field required (either File or Notification Board Message)", MessageType.danger);
            //}

            //if (string.IsNullOrEmpty(manageLoginPageViewModel.File))
            //{
            //    ShowMessage("File is required", MessageType.danger);
            //    return View(manageLoginPageViewModel);
            //}

            //if ((!string.IsNullOrEmpty(manageLoginPageViewModel.NotificationBoardMessage)) || (!string.IsNullOrEmpty(manageLoginPageViewModel.File)))
            //{
                if (file != null)
                {
                    //Upload Image
                    var fileName = Path.GetFileName(file.FileName);
                    var originalFileName = fileName;
                    var originalPath = Path.Combine(Server.MapPath("~/Images/Login"), originalFileName);
                    //var thumbPath = Path.Combine(Server.MapPath("~/Images/Login"), thumbFileName);

                    // Load image
                    Image image = Image.FromStream(file.InputStream, true, true);

                    file.SaveAs(originalPath);
                    ModelState.Clear();

                    //set images in object
                    manageLoginPageViewModel.File = originalFileName;
                }

                manageLoginPageManager.SaveLoginPageAttributes(manageLoginPageViewModel);
                return RedirectToAction("SelectMatter", "Main", new { area = "Main" });
            //}

        }
	}
}