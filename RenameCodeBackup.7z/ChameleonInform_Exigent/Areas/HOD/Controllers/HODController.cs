﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent_BusinessLogicLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.HOD.Controllers
{
    public class HODController : BaseController
    {
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.HODDashboard, (int)UserAccessEnum.MainDashboard })]
        public ActionResult Dashboard()
        {
            ViewBag.CountryList = CommonManager.GetCountryList();
            if (SessionHelper != null && SessionHelper.LoggedUserInfo != null && !SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)SystemTypeEnum.LegalProfessionalStaff))
            {
                SessionHelper.LoggedUserInfo.SelectedDashboardID = (int)UserAccessEnum.MainDashboard;
                return View();
            }
            else
            {
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
            }
        }

        [HttpGet]
        public ActionResult GetTop10Matters(int selectedcountry)
        {
            // do code to fill top 10 reportable matters graph data...
            int Country = selectedcountry;
            string[] jsonData = MatterManager.GetHODTop10MattersList(Country);
            return Json(jsonData, "json", JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetInvoices(int selectedcountry)
        {
            int Country = selectedcountry;
            TempData["CountryIdentity"] = Country;
            string[] jsonData = InvoiceManager.GetInvoicesChartYTDData(Country, string.Empty, string.Empty, string.Empty, null);
            return Json(jsonData, "json", JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetLegendSpendTrend(int selectedcountry)
        {
            int Country = selectedcountry;
            string yearValue = System.Configuration.ConfigurationManager.AppSettings["SpendTrendYear"];
            string[] jsonData = InvoiceManager.GetHODSpendTrendData(yearValue, Country);
            return Json(jsonData, "json", JsonRequestBehavior.AllowGet);
        }


    }
}