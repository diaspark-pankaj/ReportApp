﻿using Exigent.Common;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers;
using ChameleonInformExigent.Controllers;
using Exigent.Helpers.CustomAttributes;
using Exigent_BusinessLogicLayer;
using Exigent_BusinessLogicLayer.Admin;
using Exigent_BusinessLogicLayer.Admin.Exigent;
using Exigent_BusinessLogicLayer.Audit;
using Exigent_BusinessLogicLayer.DropDowns;
using Exigent_ViewModels.Admin;
using Exigent_ViewModels.Admin.Exigent;
using Exigent_ViewModels.Home;
using Resources;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Windows.Documents;
using Image = System.Drawing.Image;
using ChameleonInformExigent.Helpers;
using Exigent.Common.Constants;

namespace ChameleonInformExigent.Areas.Home.Controllers
{
    public class HomeController : BaseController
    {
        #region Var
      
        UserManager _userManager;
        DropDownManager _dropDownManager;
        
        #endregion

        #region Actions
        public ActionResult MyProfile()
        {
            //Get Session Values
            var sessionHelper = (SessionHelper)Session["User"];
            _userManager = new UserManager();
            _dropDownManager = new DropDownManager();
           
            //Get user values
            FetchedUserViewModel fetchedUserViewModel = _userManager.GetUserWithProfileById(sessionHelper.LoggedUserInfo.UserId);

            //Convert values to Viewmodel
            var editUserProfileViewModel = new EditUserProfileViewModel
                                                                {
                                                                    Id = fetchedUserViewModel.UserId,
                                                                    UserName = fetchedUserViewModel.UserName,
                                                                    Email = fetchedUserViewModel.Email,
                                                                    FullName= fetchedUserViewModel.FullName
                                                                };

            if (fetchedUserViewModel.FetchedUserProfileViewModel != null)
            {
                editUserProfileViewModel.FullName = fetchedUserViewModel.FetchedUserProfileViewModel.FullName;
                editUserProfileViewModel.AltEmail = fetchedUserViewModel.FetchedUserProfileViewModel.EmailAlt;                
            }
            else
            {
                
            }

            bool Flag = false; 
            editUserProfileViewModel.IsVendor = Flag;

            return View(editUserProfileViewModel);
        }

        [HttpPost]
        public ActionResult MyProfile(EditUserProfileViewModel editUserProfileViewModel, HttpPostedFileBase file)
        {
            //Get Session Values
            var sessionHelper = (SessionHelper)Session["User"];
            _userManager = new UserManager();
            _dropDownManager = new DropDownManager();
            
            //Server-side validation
            if (!ModelState.IsValid)
            {
                //Re-create form
                return View(editUserProfileViewModel);
            }

            if (file != null)
            {
                //Upload Image
                var fileName = DateTime.Now.ToString("ssmmhhddMMyy") + "_" + Path.GetFileName(file.FileName);
                var originalFileName = fileName;
                var thumbFileName = "thumb_" + fileName;
                var originalPath = Path.Combine(Server.MapPath("~/Images/UserImage"), originalFileName);
                var thumbPath = Path.Combine(Server.MapPath("~/Images/UserImage"), thumbFileName);

                // Load image
                Image image = Image.FromStream(file.InputStream, true, true);

                // Compute thumbnail size
                Size thumbnailSize = CommonHelper.GetThumbnailSize(image);

                // Get thumbnail
                if (thumbnailSize.Width > 0 && thumbnailSize.Height > 0)
                {
                    Image thumbnail = image.GetThumbnailImage(thumbnailSize.Width,
                        thumbnailSize.Height, null, IntPtr.Zero);

                    // Save thumbnail
                    thumbnail.Save(thumbPath);
                    editUserProfileViewModel.ThumbImage = thumbFileName;
                }
                file.SaveAs(originalPath);
                ModelState.Clear();
                ViewBag.Message = CommonConstants.FileUploadSuccess;

                //set images in object
                editUserProfileViewModel.OriginalImage = originalFileName;

                //Set new image values in session
                sessionHelper.LoggedUserInfo.FullName = editUserProfileViewModel.FullName;
                          
                sessionHelper.LoggedUserInfo.ThumbImage = thumbFileName;
                sessionHelper.LoggedUserInfo.DateModified = DateTime.Now;
                Session["User"] = sessionHelper;
            }

            //User Duplicacy Check 
            if (_userManager.IsFullNameExistsOnEditUser(editUserProfileViewModel.FullName, editUserProfileViewModel.Id))
            {
                //Re-create form
                
                editUserProfileViewModel.ThumbImage = editUserProfileViewModel.ThumbImage;
                editUserProfileViewModel.UserTypeId = 101;
                
                ShowMessage(VarConstants.FullNameExits, MessageType.danger);
                return View(editUserProfileViewModel);
            }

            //Update User Detail.
            string thumbImage;
            string originalImage;
            DateTime dateModified;
            bool editStatus = _userManager.EditMyProfile(editUserProfileViewModel, sessionHelper.LoggedUserInfo.UserId, out thumbImage, out originalImage, out dateModified);

            //Set new image values in session
            sessionHelper.LoggedUserInfo.FullName = editUserProfileViewModel.FullName;
            
            sessionHelper.LoggedUserInfo.DateModified = dateModified;
            
            //Re-create form
            editUserProfileViewModel.OriginalImage = originalImage;
            editUserProfileViewModel.ThumbImage = thumbImage;

            if (editStatus)
            {
                //Re-create form
                editUserProfileViewModel.ThumbImage = editUserProfileViewModel.ThumbImage;
            
                //Audit Login
                //string CustomMessage = "Updated MyProfile - " + "(" + editUserProfileViewModel.Id + ")";

                ShowMessage(VarConstants.ProfileUpdated, MessageType.success);
                return View(editUserProfileViewModel);
            }

            editUserProfileViewModel.ThumbImage = editUserProfileViewModel.ThumbImage;
            
            ShowMessage(CommonConstants.SaveError, MessageType.danger);
            return View(editUserProfileViewModel);
        }

    }
        #endregion
}