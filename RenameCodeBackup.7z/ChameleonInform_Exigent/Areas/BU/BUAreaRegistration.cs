﻿using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.BU
{
    public class BUAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "BU";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "BU_default",
                "BU/{action}/{id}",
                new { controller = "BU", action = "Dashboard", id = UrlParameter.Optional }
            );
        }
    }
}