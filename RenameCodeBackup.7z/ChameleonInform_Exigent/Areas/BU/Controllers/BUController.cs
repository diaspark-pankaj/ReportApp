﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using System;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.BU.Controllers
{
    public class BUController : BaseController
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.BusinessUnitDashboard })]
        public ActionResult Instruction(int matterId = 0)
        {
            CommonManager commonManager = new CommonManager();
            ViewBag.Currencies = commonManager.GetCurrencies();
            var model = new InstructionViewModel();
            model.MatterDetail = MatterManager.GetMatterBlock(matterId);
            model.Matter_Reference = model.MatterDetail.MatterReferenceNumber;
            PopulateDBLists(model.MatterDetail.BusinessUnitNameId, model.MatterDetail.LegalDisciplineId);
            return View(model);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="businessUnitNameId"></param>
        /// <param name="legalDis"></param>
        private void PopulateDBLists(int businessUnitNameId, int legalDis)
        {
            ViewBag.Billing_Entities = CommonManager.GetClientCompanies(businessUnitNameId);
            ViewBag.Vendors = CommonManager.GetVendors(businessUnitNameId, legalDis);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Instruction(InstructionViewModel model)
        {
            if (model != null)
            {
                string instructionRef = string.Empty;
                model.Created_By = SessionHelper.LoggedUserInfo.FullName;
                model.Email = CommonManager.GetBusinessUnitEmail(Convert.ToInt32(model.Vendor), model.MatterDetail.BusinessUnitNameId, model.MatterDetail.LegalDisciplineId);
                //Create the new instruction in database.
                if (!string.IsNullOrEmpty(model.Payment_Clearance_Number))
                    model.Confirmed = CommonConstants.Yes;
                else
                    model.Confirmed = CommonConstants.No;
                InstructionManager.CreateInstruction(model, SystemTypes.BusinessUnit,out instructionRef);
            }
            return Redirect("~/Main/BusinessUnitDashboard");
        }

    }
}