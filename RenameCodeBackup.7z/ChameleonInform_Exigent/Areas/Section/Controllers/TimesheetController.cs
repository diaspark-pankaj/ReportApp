﻿using Exigent.Helpers.CustomAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Section.Controllers
{
    public class TimesheetController : Controller
    {
        // GET: Section/Timesheet
        [CryptoValueProvider]
        public ActionResult Manage(int id=0)
        {
            return View();
        }
    }
}