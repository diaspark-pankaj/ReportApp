﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Section.Controllers
{
    public class RFQController : BaseController
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [CryptoValueProvider]
        public ActionResult Manage(string id)
        {
            var rfq = new RFQViewModel();
            rfq.Matter_Reference = id;
            return View(rfq);
        }

        /// <summary>
        ///  method to save rfq of matter
        /// </summary>
        /// <param name="rfqVm"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Manage(RFQViewModel rfqVm)
        {
            RFQManager.SaveRFQ(rfqVm);
            return Json(CommonConstants.Success, JsonRequestBehavior.AllowGet);
        }
    }
}