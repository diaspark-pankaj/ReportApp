﻿using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.ViewModels.Common;
using System.Collections.Generic;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using System.Linq;
using ChameleonInformExigent.Helpers;
using ChameleonInformExigent.Controllers;
using System;
using Exigent.Common.Helpers;
using Exigent.Helpers.CustomAttributes;
using Exigent.CustomAttributes;
using Exigent_ViewModels.Common;
using Exigent.Common;
using iTextSharp.text;
using System.Text;
using System.Web;
using System.IO;
using Rotativa.Options;

namespace ChameleonInformExigent.Areas.Section.Controllers
{
    public class MatterController : BaseController
    {

        #region Manage Matter

        /// <summary>
        /// method load matter page
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>        
        /// 
        
        [Exigent.Helpers.CustomAttributes.CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.BusinessUnitDashboard })]
        public ActionResult Manage(int id = 0, string type = "")
        {
            CommonManager commonManager = new CommonManager();
            int userId = SessionHelper.LoggedUserInfo.UserId;
            var isBUUser = !string.IsNullOrEmpty(type) ? true : false;
            bool system = !string.IsNullOrEmpty(type) ? false : true;
            var isAdmin = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id==(int)(SystemTypeEnum.ServiceProviderAdmin) || x.Id== (int)(SystemTypeEnum.ServiceProviderAdmin)) ? true : false;
            ViewBag.BusinessUnit = commonManager.GetBusinessUnitsList(isAdmin ? false : isBUUser, SessionHelper.LoggedUserInfo.UserName);
            ViewBag.MatterStatus = commonManager.GetMatterStatusList();
           
            ViewBag.Discipline = CommonManager.GetLegalDiscipline(isBUUser ? SystemTypes.BusinessUnit : SystemTypes.GroupLegal);
            ViewBag.SubDiscipline = new List<SelectListItem>();
            ViewBag.ReportClassifications = MatterReportClassificationOptionManager.GetMatterReportClassificationOption();
            ViewBag.ApplicationReportTemplate = ApplicationReportTemplateManager.GetApplicationReportTemplate();
            var list = commonManager.GetUsersFromPeoplePicker().Select(x => x.Name).ToList();
            ViewBag.PeopleList = string.Join(";", list);

            ViewBag.KeyWorkStream = commonManager.GetKeyWorkStream();
            ViewBag.CountryList = commonManager.GetCountries();
            ViewBag.Operations = new List<SelectListItem>();
            ViewBag.DraftId = 0;
            Session["DraftId"] = null;
            var model = new MatterViewModel();
            model.IsHighlyConfidential = false;
            if (id > 0)
            {
                MatterManager matterMgr = new MatterManager();
                model = matterMgr.GetMatterById(id, userId);                
                Session[VarConstants.MatterModel + "_" + id] = model;

                if (TempData.ContainsKey("ExportMatterData"))
                    TempData.Remove("ExportMatterData");

                TempData.Add("ExportMatterData", model);
            }
            model.System = system ? SystemTypes.GroupLegal.ToString() : SystemTypes.BusinessUnit.ToString();
            model.SystemType_ID = system ? (int)SystemTypes.GroupLegal : (int)SystemTypes.BusinessUnit;
            model.ReportClassificationOptionList = ReportClassificationOptionManager.GetReportClassificationOption(id);
            model.IsBusinessUnit = !string.IsNullOrEmpty(type) ? true : false;
            return View(model);
        }

        /// <summary>
        /// get operation from business unit
        /// </summary>
        /// <param name="businessUnit"></param>
        /// <returns></returns>
        public ActionResult GetOperationByBUList(int businessUnitID)
        {
            var commonManager = new CommonManager();
            return Json(commonManager.GetOperationByBUList(businessUnitID));
        }
              
        /// <summary>
        /// method to save matter
        /// </summary>
        /// <param name="matterVm"></param>
        /// <returns></returns>                
        [HttpPost]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.BusinessUnitDashboard })]
        public ActionResult Manage(MatterViewModel matterVm)
        {

            if (matterVm.SystemType_ID == (int)SystemTypes.BusinessUnit)
            {
                if (ModelState.ContainsKey("matterVm.Context"))
                    ModelState["matterVm.Context"].Errors.Clear();

                if (ModelState.ContainsKey("matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks"))
                    ModelState["matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks"].Errors.Clear();

                if (ModelState.ContainsKey("matterVm.Client_Action"))
                    ModelState["matterVm.Client_Action"].Errors.Clear();
            }            
            if (!string.IsNullOrEmpty(matterVm.Report_Classification_Category))
            {
                if (!ModelState.IsValid && matterVm.Report_Classification_Category.Equals("Highly Confidential Matters"))
                    ModelState.Clear();
            }

            MatterManager matterManager = new MatterManager();
            matterVm.System = matterVm.System;
            matterVm.SystemType_ID = matterVm.System == SystemTypes.BusinessUnit.ToString() ? (int)SystemTypes.BusinessUnit : (int)SystemTypes.GroupLegal;
            matterVm.FullName = SessionHelper.LoggedUserInfo.FullName;
            matterVm.UserName = SessionHelper.LoggedUserInfo.UserName;
            if (matterVm.ID > 0 && Convert.ToInt32(Session["DraftId"]) == 0 && Session["DraftId"] == null)
            {
                var matterDetails = Session[VarConstants.MatterModel + "_" + matterVm.ID] != null ? (MatterViewModel)Session[VarConstants.MatterModel + "_" + matterVm.ID] : new MatterViewModel();
                matterVm.Created_By = matterDetails.Created_By;
                matterVm.Created = matterDetails.Created;
                matterVm.System = matterDetails.System;
                matterVm.Last_Lawyer_Update_Date = matterDetails.Last_Lawyer_Update_Date;
                matterVm.Last_Lawyer_Update_Name = matterDetails.Last_Lawyer_Update_Name;                
                matterVm.Reportable = matterDetails.Reportable;
                matterVm.ReportableStatus = matterDetails.ReportableStatus;
                matterVm.ReportableCount = matterDetails.ReportableCount;
                matterVm.HODComments = matterDetails.HODComments;
                matterVm.DateSentForUpdate = matterDetails.DateSentForUpdate;
                matterVm.DateReturned = matterDetails.DateReturned;

                //EXICHM-369: Only admin user is allowed to edit/select key work stream.
                var isAdminUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id==(int)(SystemTypeEnum.ServiceProviderAdmin)) ? true : false;
                if (!isAdminUser)
                {
                    matterVm.KeyWorkStream = matterDetails.KeyWorkStream;
                }
            }
            else
            {
                //EXICHM-369: Only admin user is allowed to edit/select key work stream.
                var isAdminUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id==(int)(SystemTypeEnum.ServiceProviderAdmin)) ? true : false;
                if (!isAdminUser)
                {
                    matterVm.KeyWorkStream = null;
                }
            }
            if (matterVm.IsHighlyConfidential == true)
            {
                ModelState.Remove("matterVm.Context");
                ModelState.Remove("matterVm.Matter_Description");
                ModelState.Remove("matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks");
                ModelState.Remove("matterVm.Client_Action");
            }
            ModelState.Remove("matterVm.Report_Classification");
            ModelState.Remove("matterVm.Report_Classification_Category");


            if (ModelState.IsValid)
            {
                if (Convert.ToInt32(Session["DraftId"]) != 0 && Session["DraftId"] != null)
                {
                    matterVm.ID = Convert.ToInt32(Session["DraftId"]);
                    bool isFinalized = true;
                    int resultofdraft = matterManager.SaveDraftMatter(matterVm, isFinalized);
                    matterVm.ID = 0;
                }
                int result = matterManager.SaveMatter(matterVm);


                if (result > 0)
                    return Json(CommonConstants.Success.ToString(), JsonRequestBehavior.AllowGet);
                else
                    return Json(CommonConstants.Error.ToString(), JsonRequestBehavior.AllowGet);
            }
            else
                return Json(CommonConstants.Error.ToString(), JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// method to save matter as draft
        /// </summary>
        /// <param name="matterVm"></param>
        /// <returns></returns>        
        [HttpPost]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.BusinessUnitDashboard })]
        public ActionResult ManageDraft(MatterViewModel matterVm)
        {
            if (Convert.ToInt32(Session["DraftId"]) != 0 && Session["DraftId"] != null)
            {
                matterVm.ID = Convert.ToInt32(Session["DraftId"]);
            }
            if (matterVm.SystemType_ID == (int)SystemTypes.BusinessUnit)
            {
                if (ModelState.ContainsKey("matterVm.Context"))
                    ModelState["matterVm.Context"].Errors.Clear();

                if (ModelState.ContainsKey("matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks"))
                    ModelState["matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks"].Errors.Clear();

                if (ModelState.ContainsKey("matterVm.Client_Action"))
                    ModelState["matterVm.Client_Action"].Errors.Clear();
            }

            if (!string.IsNullOrEmpty(matterVm.Report_Classification_Category))
            {
                if (!ModelState.IsValid && matterVm.Report_Classification_Category.Equals("Highly Confidential Matters"))
                    ModelState.Clear();


            }

            MatterManager matterManager = new MatterManager();
            matterVm.System = matterVm.System;
            matterVm.SystemType_ID = matterVm.System == SystemTypes.BusinessUnit.ToString() ? (int)SystemTypes.BusinessUnit : (int)SystemTypes.GroupLegal;
            matterVm.FullName = SessionHelper.LoggedUserInfo.FullName;
            matterVm.UserName = SessionHelper.LoggedUserInfo.UserName;
            if (matterVm.ID > 0)
            {
                var matterDetails = Session["DraftMatter_" + matterVm.ID] != null ? (MatterViewModel)Session["DraftMatter_" + matterVm.ID] : new MatterViewModel();
                matterVm.Created_By = matterDetails.Created_By;
                matterVm.Created = matterDetails.Created;
                matterVm.System = matterDetails.System;
                matterVm.Last_Lawyer_Update_Date = matterDetails.Last_Lawyer_Update_Date;
                matterVm.Last_Lawyer_Update_Name = matterDetails.Last_Lawyer_Update_Name;

                matterVm.Reportable = matterDetails.Reportable;
                matterVm.ReportableStatus = matterDetails.ReportableStatus;
                matterVm.ReportableCount = matterDetails.ReportableCount;
                matterVm.HODComments = matterDetails.HODComments;
                matterVm.DateSentForUpdate = matterDetails.DateSentForUpdate;
                matterVm.DateReturned = matterDetails.DateReturned;


                var isAdminUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id==(int)(SystemTypeEnum.ServiceProviderAdmin)) ? true : false;
                if (!isAdminUser)
                {
                    matterVm.KeyWorkStream = matterDetails.KeyWorkStream;
                }
            }
            else
            {

                var isAdminUser = SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id==(int)(SystemTypeEnum.ServiceProviderAdmin)) ? true : false;
                if (!isAdminUser)
                {
                    matterVm.KeyWorkStream = null;
                }
            }
            if (matterVm.IsHighlyConfidential == true)
            {
                ModelState.Remove("matterVm.Context");
                ModelState.Remove("matterVm.Matter_Description");
                ModelState.Remove("matterVm.Nature_Of_identified_Risk_In_Matter_And_Any_Consequential_Risks");
                ModelState.Remove("matterVm.Client_Action");
            }
            ModelState.Remove("matterVm.Report_Classification");
            ModelState.Remove("matterVm.Report_Classification_Category");

            bool isFinalized = false;
            int result = matterManager.SaveDraftMatter(matterVm, isFinalized);

            if (result > 0)
                return Json(CommonConstants.Success.ToString(), JsonRequestBehavior.AllowGet);
            else
                return Json(CommonConstants.Error.ToString(), JsonRequestBehavior.AllowGet);
        }


        /// <summary>
        /// method to edit draft matter
        /// </summary>
        /// <param name="matterVm"></param>
        /// <returns></returns>        
        [CryptoValueProvider]

        public ActionResult EditDraft(string id)
        {
            //ViewBag.CountryList = CommonManager.GetCountryList();
            int ID = Convert.ToInt32(id);
            Session["DraftId"] = ID;
            ViewBag.DraftId = ID;
            var model = new MatterViewModel();
            if (ID > 0)
                model = MatterManager.GetDraftMatterById(ID);
            Session["DraftMatter_" + ID] = model;
            CommonManager commonManager = new CommonManager();
            ViewBag.BusinessUnit = commonManager.GetBusinessUnitsList();
            ViewBag.MatterStatus = commonManager.GetMatterStatusList();
            ViewBag.LegalPracticeArea = CommonManager.GetLegalDiscipline(SystemTypes.GroupLegal);
            ViewBag.KeyWorkStream = commonManager.GetKeyWorkStream();
            ViewBag.CountryList = commonManager.GetCountries();
            ViewBag.Operations = new List<SelectListItem>();
            ViewBag.ReportClassifications = new List<SelectListItem>();
            ViewBag.Discipline = CommonManager.GetLegalDiscipline(SystemTypes.GroupLegal);
            ViewBag.SubDiscipline = new List<SelectListItem>();
            ViewBag.ReportClassifications = MatterReportClassificationOptionManager.GetMatterReportClassificationOption();
            ViewBag.ApplicationReportTemplate = ApplicationReportTemplateManager.GetApplicationReportTemplate();
            model.ReportClassificationOptionList = ReportClassificationOptionManager.GetReportClassificationOptionForDraft(ID);
            return View(model);
        }




        /// <summary>
        /// method to get list of users (people picker) for autocomplete
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetUsersFromPeoplePicker(string prefix)
        {
            CommonManager commonManager = new CommonManager();
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            if (Session[VarConstants.UsersList] == null)
                Session[VarConstants.UsersList] = commonManager.GetUsersFromPeoplePicker();

            var userList = (List<EnumKeyValueViewModel>)Session[VarConstants.UsersList];
            userList = userList.Where(x => x.Name.Contains(prefix, StringComparison.OrdinalIgnoreCase)).Take(10).ToList();
            return Json(jSearializer.Serialize(userList), JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// method to get list of users (user table) for autocomplete
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetGSSUsers(string prefix)
        {
            CommonManager commonManager = new CommonManager();
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            if (Session[VarConstants.UsersList] == null)
                // Changed as per client discussion for reassignment of invoice
                Session[VarConstants.UsersList] = commonManager.GetSpecialUsers();


            var userList = (List<EnumKeyValueViewModel>)Session[VarConstants.UsersList];
            userList = userList.Where(x => x.Name.Contains(prefix, StringComparison.OrdinalIgnoreCase)).Take(10).ToList();
            return Json(jSearializer.Serialize(userList), JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// method to get list of users (user table) for autocomplete
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResult GetAllUsers(string prefix)
        {
            CommonManager commonManager = new CommonManager();
            JavaScriptSerializer jSearializer = new JavaScriptSerializer();
            if (Session[VarConstants.AllUsersList] == null)
                Session[VarConstants.AllUsersList] = commonManager.GetAllUsers();

            var userList = (List<EnumKeyValueViewModel>)Session[VarConstants.AllUsersList];
            userList = userList.Where(x => x.Name.Contains(prefix, StringComparison.OrdinalIgnoreCase)).Take(10).ToList();
            return Json(jSearializer.Serialize(userList), JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// method to validate invoice status to make matter closed
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public ActionResult GetMatterInvoiceStatus(string id)
        {
            var matter = new MatterManager();
            return Json(matter.GetMatterInvoiceStatus(id));
        }

        public ActionResult GetMatterHistory(int id, string matterRef)
        {
            var result = MatterManager.GetMatterHistory(id, matterRef);
            return Json(result == null ? string.Empty : result, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Time Recording

        /// <summary>
        /// Loads Time Recording page 
        /// </summary>
        /// <param name="id"></param>
        /// <param name="authUID"></param>
        /// <returns></returns>
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard })]
        public ActionResult TimeRecording(string id, string authUID, string isMatterUpdate)
        {
            CommonManager commonManager = new CommonManager();
            ViewBag.BusinessUnit = commonManager.GetBusinessUnitsList();
            ViewBag.MatterStatus = commonManager.GetMatterStatusList();
            ViewBag.LegalPracticeArea = CommonManager.GetLegalDiscipline(SystemTypes.GroupLegal);
            ViewBag.KeyWorkStream = commonManager.GetKeyWorkStream();
            ViewBag.CountryList = commonManager.GetCountries();
            ViewBag.Operations = new List<SelectListItem>();
            ViewBag.ReportClassifications = new List<SelectListItem>();            
            var model = new MatterViewModel();            
            model.System = SystemTypes.GroupLegal.ToString();
            if (Convert.ToInt32(id) > 0)
            {
                int userId = SessionHelper.LoggedUserInfo.UserId;
                MatterManager matterMgr = new MatterManager();
                model = matterMgr.GetMatterById(Convert.ToInt32(id),userId);
                Session[VarConstants.MatterModel + "_" + id] = model;
            }

            ViewBag.Discipline = CommonManager.GetLegalDiscipline(SystemTypes.GroupLegal);
            ViewBag.SubDiscipline = new List<SelectListItem>();
            ViewBag.ReportClassifications = MatterReportClassificationOptionManager.GetMatterReportClassificationOption();
            ViewBag.ApplicationReportTemplate = ApplicationReportTemplateManager.GetApplicationReportTemplate();
            model.ReportClassificationOptionList = ReportClassificationOptionManager.GetReportClassificationOption(model.ID);

            TimeRecordingViewModel timeRecordingViewModel = new TimeRecordingViewModel();
            model.isFromTimeRecord = true;
            timeRecordingViewModel.MatterVM = model;
            timeRecordingViewModel.Matter_ID = model.ID;
            timeRecordingViewModel.Lead_Lawyer_ID = model.Lead_Lawyer_ID;
            timeRecordingViewModel.CanUpdateMatter = Convert.ToBoolean(isMatterUpdate);

            return View(timeRecordingViewModel);
        }

        /// <summary>
        /// Records time per matter 
        /// </summary>
        /// <param name="matterVM"></param>
        /// <param name="timeRecordingVm"></param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult TimeRecording(MatterViewModel matterVm, TimeRecordingViewModel timeRecordingVm)
        {
            MatterManager matterManager = new MatterManager();            
            matterVm.FullName = SessionHelper.LoggedUserInfo.FullName;
            matterVm.UserName = SessionHelper.LoggedUserInfo.UserName;
            if (matterVm.ID > 0)
            {
                var matterDetails = Session[VarConstants.MatterModel + "_" + matterVm.ID] != null ? (MatterViewModel)Session[VarConstants.MatterModel + "_" + matterVm.ID] : new MatterViewModel();
                matterVm.Created_By = matterDetails.Created_By;
                matterVm.Created = matterDetails.Created;
                matterVm.Last_Lawyer_Update_Date = matterDetails.Last_Lawyer_Update_Date;
                matterVm.Last_Lawyer_Update_Name = matterDetails.Last_Lawyer_Update_Name;                
                matterVm.Reportable = matterDetails.Reportable;
                matterVm.ReportableStatus = matterDetails.ReportableStatus;
                matterVm.HODComments = matterDetails.HODComments;
                matterVm.DateSentForUpdate = matterDetails.DateSentForUpdate;
                matterVm.DateReturned = matterDetails.DateReturned;
            }
            timeRecordingVm.Created_By = SessionHelper.LoggedUserInfo.UserName;
            if (matterVm.ID > 0)
                timeRecordingVm.Matter_ID = matterVm.ID;

            int result = matterManager.SaveTimeRecord(matterVm, timeRecordingVm);
            if (result > 0)
                return Json(CommonConstants.Success.ToString(), JsonRequestBehavior.AllowGet);
            else
                return Json(CommonConstants.Error.ToString(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetSubDisciplineList(int legalDisciplineId)
        {
            var commonManager = new CommonManager();
            return Json(SubDisciplineManager.GetSubLegalDisciplineByLegalDiscId(Convert.ToInt32(legalDisciplineId)));
        }
        #endregion

        #region Export        
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult ExportToWord(string id)
        {
            int MatterId = !string.IsNullOrEmpty(id) ? Convert.ToInt16(id) : 0;
            var model = new MatterViewModel();
            if (TempData.ContainsKey("ExportMatterData"))
            {
                model = TempData["ExportMatterData"] as MatterViewModel;
                TempData.Keep();
            }
            else
            {
                MatterManager matterMgr = new MatterManager();
                model = matterMgr.GetMatterById(MatterId);
            }
            
            string htmlText = RenderActionResultToString(View(model));
            byte[] file = WordHelper.HtmlToWord(htmlText);
            return File(file,
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document", model.Matter_Name + ".doc");
        }

        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult ExportToPDF(string id)
        {
            int MatterId = !string.IsNullOrEmpty(id) ? Convert.ToInt16(id) : 0;
            var model = new MatterViewModel();
            if (TempData.ContainsKey("ExportMatterData"))
            {
                model = TempData["ExportMatterData"] as MatterViewModel;
                TempData.Keep();
            }
            else
            {
                MatterManager matterMgr = new MatterManager();
                model = matterMgr.GetMatterById(MatterId);
            }

            return new Rotativa.PartialViewAsPdf("ExportMatterView", model)
            {
                FileName = model.Matter_Name + ".pdf"
            };
        }

        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult ExportMatterView(string id)
        {
            int MatterId = !string.IsNullOrEmpty(id) ? Convert.ToInt16(id) : 0;
            var model = new MatterViewModel();
            if (TempData.ContainsKey("ExportMatterData"))
            {
                model = TempData["ExportMatterData"] as MatterViewModel;
                TempData.Keep();
            }
            else
            {
                MatterManager matterMgr = new MatterManager();
                model = matterMgr.GetMatterById(MatterId);
            }          
            return new Rotativa.ViewAsPdf("ExportMatterView", model);          
        }

        protected string RenderActionResultToString(ActionResult result)
        {            
            var sb = new StringBuilder();
            var memWriter = new StringWriter(sb);
            var fakeResponse = new HttpResponse(memWriter);
            var fakeContext = new HttpContext(System.Web.HttpContext.Current.Request, fakeResponse);
            var fakeControllerContext = new ControllerContext(
                new HttpContextWrapper(fakeContext),
                ControllerContext.RouteData,
                ControllerContext.Controller);
            var oldContext = System.Web.HttpContext.Current;
            System.Web.HttpContext.Current = fakeContext;

            result.ExecuteResult(fakeControllerContext);
            System.Web.HttpContext.Current = oldContext;

            memWriter.Flush();
            return sb.ToString();
        }
        #endregion
    }
}