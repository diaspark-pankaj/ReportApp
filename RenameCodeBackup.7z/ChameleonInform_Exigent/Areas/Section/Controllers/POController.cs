﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Section.Controllers
{
    public class POController : BaseController
    {
        //
        // GET: /Section/PO/
        public ActionResult Manage()
        {
            return View();
        }

        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.MainDashboard })]
        public ActionResult CreatePOTask(int id)
        {
            var model = new PurchaseOrderViewModel();

            var instruction = InstructionManager.GetInstruction(id);
            model.External_Instructions = instruction;
            model.External_Instructions.MatterDetail = MatterManager.GetMatterBlock(instruction.Matter_Reference);


            model.Cost_Centre = instruction.Cost_Centre;
            model.Instruction_Reference = instruction.Instruction_Reference;
            model.Vatable_Amount = instruction.Estimated_Legal_Cost_Vatable;
            model.Non_Vatable_Amount = instruction.Estimated_Legal_Cost_Non_Vatable;
            model.Vendor = instruction.Vendor;

            model.External_Instructions.Matter_Reference = instruction.Matter_Reference;
            model.External_Instructions.Matter_Name = model.External_Instructions.MatterDetail.MatterName;

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreatePOTaskSave(PurchaseOrderViewModel model)
        {
            var instruction = InstructionManager.GetInstruction(model.External_Instructions.ID);
            model.External_Instructions = instruction;
            model.External_Instructions.MatterDetail = MatterManager.GetMatterBlock(instruction.Matter_Reference);

            model.Instruction_ID = instruction.ID;
            model.Cost_Centre = instruction.Cost_Centre;
            model.Instruction_Reference = instruction.Instruction_Reference;
            model.Vatable_Amount = instruction.Estimated_Legal_Cost_Vatable;
            model.Non_Vatable_Amount = instruction.Estimated_Legal_Cost_Non_Vatable;
            model.Vendor = instruction.Vendor;
            model.Vendor_ID = instruction.Vendor_ID;
            model.External_Instructions.Matter_Reference = instruction.Matter_Reference;
            model.External_Instructions.Matter_Name = model.External_Instructions.MatterDetail.MatterName;
            model.External_Instructions.PO_Contact_ID = instruction.PO_Contact_ID;
            model.Status = VarConstants.PendingNew;

            model.Created_By = SessionHelper.LoggedUserInfo.UserName;
            var purchaseOrderId = POManager.CreatePurchaseOrder(model);

            if (purchaseOrderId > 0)
            {
                var poTask = new POTaskViewModel
                {
                    PurchaseOrderID = purchaseOrderId,
                    Status = VarConstants.PendingNew,
                    Assigned_To_ID = instruction.PO_Contact_ID,
                    Assigned_To = model.External_Instructions.PO_Contact,
                    Complete = null,
                    Comments = null,
                    Created = DateTime.Now
                };

                var poTaskId = POManager.CreatePOTask(poTask);

                if (poTaskId > 0)
                {
                    InstructionManager.SetInstructionStatus(model.Instruction_Reference, VarConstants.Instruction_Pending_PO);

                    poTask.ID = poTaskId;
                    poTask.Purchase_Orders = model;
                    poTask.Purchase_Orders.External_Instructions.Cost = (model.Vatable_Amount.Value) + model.Non_Vatable_Amount.Value;
                    poTask.BusinessUnit = model.External_Instructions.MatterDetail.BusinessUnitName;
                    poTask.Country = model.External_Instructions.MatterDetail.Country;
                    poTask.Operations = model.External_Instructions.MatterDetail.Operations;
                    poTask.Lead_Lawyer = model.External_Instructions.MatterDetail.Lead_Lawyer;
                    poTask.Taxable_Amount = model.External_Instructions.Estimated_Legal_Cost_Vatable;
                    poTask.Non_Taxable_Amount = model.External_Instructions.Estimated_Legal_Cost_Non_Vatable;
                    poTask.Currency = CommonConstants.Currency;
                    poTask.Vendor_Number = model.External_Instructions.Vendor_ID != null ? model.External_Instructions.Vendor_ID.ToString() : string.Empty;
                    POManager.SendEmailNewPOAndNewPOTaskAndPOContact(poTask);
                }
            }


            var backUrl = this.RedirectBackUrl;
            if (string.IsNullOrEmpty(backUrl))
            {
                return Redirect("~/Main");
            }
            return Redirect(backUrl);
        }

        #region "Increase PO"
        //EXICHM-359
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.MainDashboard})]
        public ActionResult IncreasePO(string instruction_reference)
        {
            IncreasePOViewModel objModel = new IncreasePOViewModel();
            if (!string.IsNullOrEmpty(instruction_reference))
            {
                objModel = InstructionManager.GetIncreasePODetail(instruction_reference);
            }
            if (TempData["MESSAGE"] != null)
            {
                string msg = TempData["MESSAGE"].ToString();
                ShowMessage(msg, MessageType.warning);
            }
            return View(objModel);
        }

        //EXICHM-359
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult IncreasePOStart(IncreasePOViewModel objModel)
        {
            if (ModelState.IsValid)
            {
                int successStartValue = InstructionManager.UpdateIncreasePO(objModel, SessionHelper.LoggedUserInfo.UserName);
                if (successStartValue > 0)
                {
                    return RedirectToAction("Dashboard", "Main", new { area = "Main" });
                }
                else
                {
                    var qsInstructionRef = new Dictionary<string, string> { { "instruction_reference", objModel.Instruction_Reference } };
                    TempData["MESSAGE"] = "Unable to start the Increase PO";
                  
                    return RedirectToAction("IncreasePO", "PO", new { area = "Section", q = Exigent.Common.Helpers.Crypto.Encrypt(qsInstructionRef) });
                }
            }
            else
            {
                var qsInstructionRef = new Dictionary<string, string> { { "instruction_reference", objModel.Instruction_Reference } };
                TempData["MESSAGE"] = CommonConstants.InvalidModel;
                
                return RedirectToAction("IncreasePO", "PO", new { area = "Section", q = Exigent.Common.Helpers.Crypto.Encrypt(qsInstructionRef) });
            }
        }

        #endregion

        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.MainDashboard })]
        public ActionResult AmendPO(string instruction_reference)
        {
            var model = new IncreasePOViewModel();
            if (!string.IsNullOrEmpty(instruction_reference))
                model = InstructionManager.GetIncreasePODetail(instruction_reference);

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AmendPOStart(IncreasePOViewModel model)
        {
            if (ModelState.IsValid)
            {
                POManager.AmendPurchaseOrder(model, SessionHelper.LoggedUserInfo.UserName);
            }
            return RedirectToAction("Dashboard", "Main", new { area = "Main" });
        }
    }
}