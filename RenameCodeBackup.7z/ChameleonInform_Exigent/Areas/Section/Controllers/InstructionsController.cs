﻿using ChameleonInformExigent.Controllers;
using Exigent.BLL;
using Exigent.Common.Constants;
using Exigent.Common.Enums;
using Exigent.CustomAttributes;
using Exigent.Helpers.CustomAttributes;
using Exigent.ViewModels.Common;
using Exigent_BusinessLogicLayer;
using Exigent_ViewModels.Audit;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
//using System.Web.Helpers;
using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Section.Controllers
{
    public class InstructionsController : BaseController
    {
        #region Instruction - Create / Update / Send

        /// <summary>
        /// Create new instruction respective to a matter.
        /// </summary>
        /// <param name="matterId">Matter Id is required.</param>
        /// <param name="id">Instruction Id is required.</param>
        /// <returns>Returns the view</returns>
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard })]
        public ActionResult Manage(int matterId = 0, int id = 0)
        {
            InstructionViewModel model = model = new InstructionViewModel();
            CommonManager commonManager = new CommonManager();
            ViewBag.Currencies = commonManager.GetCurrencies();
            if (id > 0)
            {
                //Check if current user is not Admin/GLS(Super Group Legal User).
                //So only admin/GLS(Super Group Legal User) and LPS can edit an instruction.
                if (!SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)SystemTypeEnum.ServiceProviderAdmin || x.Id == (int)SystemTypeEnum.LegalProfessionalStaff || x.Id == (int)SystemTypeEnum.SuperGroupLegal || x.Id == (int)SystemTypeEnum.SpecialGroupLegal || x.Id == (int)SystemTypeEnum.SeniorLegalLeadershipStaff))
                {
                    return Redirect(Request.UrlReferrer.AbsoluteUri);
                }

                //This section will be available for admin users only.
                model = InstructionManager.GetInstruction(id);

                if (model == null)
                {
                    ShowMessage("Please specify a valid instruction reference!", MessageType.danger);
                    return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
                }

                //Get GRV value from Client Companies table
                model.GRV = CommonManager.GetGRVForClientCompany(model.Billing_Entity);

                var isResolved = InstructionManager.ResolveContacts(model, model.Instruction_Reference, model.Billing_Entity, model.GRV);

                model.MatterDetail = MatterManager.GetMatterBlock(model.Matter_Reference);

                PopulateStaticLists(model.System);

                //Show / hide the PO related buttons.
                ShowPOButtons(model.FrameworkOrder, model.Status, model.GRV, model.Payment_Clearance_Number, model.Cost_Centre, model.PO_Contact, model.Confirmed);
            }
            else
            {
                if (matterId <= 0)
                {
                    ShowMessage("Incorrect url, please contact Admin!", MessageType.danger);
                    return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
                }

                model.MatterDetail = MatterManager.GetMatterBlock(matterId);
                model.Matter_Reference = model.MatterDetail.MatterReferenceNumber;
                model.System = model.MatterDetail.System;
            }


            model.EditMode = (id > 0);


            PopulateDBLists(model.MatterDetail.BusinessUnitNameId);

            if (TempData["PostBack"] == "Yes")
            {
                ViewBag.MessageType = TempData["MessageType"];
                ViewBag.Message = TempData["Message"];
                ModelState.AddModelError(string.Empty, ViewBag.Message);
            }
            else
                ViewBag.MessageType = string.Empty;

            return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
        }

        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.BusinessUnitDashboard, (int)UserAccessEnum.MainDashboard })]
        public ActionResult Overview(int id)
        {
            InstructionViewModel model = model = new InstructionViewModel();

            if (id <= 0)
            {
                return Redirect(Request.UrlReferrer.AbsoluteUri);
            }

            //Check if current user is not Admin.
            //So only admin can edit an instruction.
            //update code because lead lawyer access can page
            if (!SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)SystemTypeEnum.ServiceProviderAdmin || x.Id == (int)SystemTypeEnum.LegalProfessionalStaff || x.Id == (int)SystemTypeEnum.LegalAdminStaff || x.Id == (int)SystemTypeEnum.SuperGroupLegal))
            {
                return Redirect(Request.UrlReferrer.AbsoluteUri);
            }

            //This section will be available for admin users only.
            model = InstructionManager.GetInstruction(id);
            //Get GRV value from Client Companies table
            model.GRV = CommonManager.GetGRVForClientCompany(model.Billing_Entity);
            //Get Matter specific details
            model.MatterDetail = MatterManager.GetMatterBlock(model.Matter_Reference);
            //Update model with Invoice amounts.
            model = InstructionManager.GetInvoiceStatistics(model);

            if (model == null)
            {
                return Redirect(Request.UrlReferrer.AbsoluteUri);
            }

            model.InvoiceListModel = new InvoiceListViewModel();

            TempData["instructionRef"] = model.Instruction_Reference;

            return View("~/Areas/Section/Views/Instructions/Overview.cshtml", model);
        }

        public ActionResult GetInvoicesListForInstruction(int limit, int fromRowNumber, string sortcolumn, string sortdirection, int? mode = 0)
        {
            var model = new InvoiceListViewModel();

            var instructionRef = (TempData["instructionRef"] != null ? TempData["instructionRef"] : string.Empty) as string;
            TempData.Keep("instructionRef");

            instructionRef = instructionRef ?? string.Empty;

            var recordCount = 0;
            //Search text is blank, displaying all records.
            model.Invoices = LookupManager.GetnvoicesForInstructionByRustyloading(limit, fromRowNumber, sortcolumn, sortdirection, out recordCount, instructionRef);

            //Get the total counts of all the records in all the pages.
            model.RecordCount = recordCount;

            return PartialView("~/Areas/Section/Views/Shared/_OverviewInvoiceListPartial.cshtml", model);
        }

        /// <summary>
        /// Populate the ViewBag with dropdown lists from db.
        /// </summary>
        /// <param name="businessUnitNameId"></param>
        private void PopulateDBLists(int businessUnitNameId)
        {
            if (businessUnitNameId > 0)
                ViewBag.Billing_Entities = CommonManager.GetClientCompanies(businessUnitNameId);

            ViewBag.Vendors = CommonManager.GetVendors();
        }

        /// <summary>
        /// Populate the ViewBag dropdown static items like status & yes/no options.
        /// </summary>
        private void PopulateStaticLists(string systemType = "")
        {
            List<SelectListItem> statusList = new List<SelectListItem>();
            if (!string.IsNullOrEmpty(systemType) && systemType == SystemTypes.BusinessUnit.ToString())
            {
                //statusList.Add(new SelectListItem { Text = VarConstants.AwaitingApproval });
                statusList.Add(new SelectListItem { Text = VarConstants.Instruction_Active });
                statusList.Add(new SelectListItem { Text = VarConstants.Instruction_Closed });
            }
            else
            {
                statusList.Add(new SelectListItem { Text = VarConstants.Instruction_Pending_Review });
                statusList.Add(new SelectListItem { Text = VarConstants.Instruction_Pending_Contacts });
                //statusList.Add(new SelectListItem { Text = VarConstants.Instruction_Pending_Approval });
                statusList.Add(new SelectListItem { Text = VarConstants.Instruction_Pending_PO });
                statusList.Add(new SelectListItem { Text = VarConstants.Instruction_Pending_PO_Increase });
                statusList.Add(new SelectListItem { Text = VarConstants.Instruction_Pending_PO_Amendment });
                statusList.Add(new SelectListItem { Text = VarConstants.Instruction_PO_Increase_Required });
                statusList.Add(new SelectListItem { Text = VarConstants.Instruction_Active });
                statusList.Add(new SelectListItem { Text = VarConstants.Instruction_Closed });
            }

            ViewBag.StatusList = statusList;

            List<SelectListItem> yesNoList = new List<SelectListItem>();
            yesNoList.Add(new SelectListItem { Text = CommonConstants.Yes });
            yesNoList.Add(new SelectListItem { Text = CommonConstants.No });
            ViewBag.YesNoList = yesNoList;
        }

        /// <summary>
        /// Get the Payment Clearance Number
        /// </summary>
        /// <param name="reportClassification">Report classification is required</param>
        /// <param name="billingEntity">Billing Entity is required</param>
        /// <param name="vendor">Vendor's full name is required</param>
        /// <returns>Returns string value (Payment Clearance Number)</returns>
        public ActionResult GetPaymentClearanceNumber(string matterReference, string billingEntity, string vendor)
        {
            string paymentClearanceNumber = null;
            var legalPracticeArea = CommonManager.GetLegalPracticeArea(matterReference);

            if (!string.IsNullOrEmpty(legalPracticeArea) && !string.IsNullOrEmpty(billingEntity) && !string.IsNullOrEmpty(vendor))
            {
                paymentClearanceNumber = CommonManager.GetPaymentClearanceNumber(legalPracticeArea, billingEntity, vendor);
            }

            return Json(new { data = paymentClearanceNumber }, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Get the Payment Clearance Number
        /// </summary>
        /// <param name="reportClassification">Report classification is required</param>
        /// <param name="billingEntity">Billing Entity is required</param>
        /// <param name="vendor">Vendor's full name is required</param>
        /// <returns>Returns string value (Payment Clearance Number)</returns>
        public string GetGRVRequired(string billingEntity)
        {
            string grvRequired = "Yes";

            if (!string.IsNullOrEmpty(billingEntity))
            {
                grvRequired = CommonManager.GetGRVForClientCompany(billingEntity);
            }

            return grvRequired;
        }

        public decimal? ConvertEstimateAmountInUSD(int selectedCurrencyId, string cost)
        {
            decimal? convertedCost = null;
            decimal amountToUSD = 0;
            decimal? costToConvert = Convert.ToDecimal(cost);
            string CurrencyCode = selectedCurrencyId > 0 ? CurrencyManager.GetCurrencyById(selectedCurrencyId).CurrencyCode : string.Empty;
            if (!string.IsNullOrEmpty(CurrencyCode))
            {
                //Check if conversion amount available on cache
                Dictionary<string, decimal> ConvertAmountCollection = HttpRuntime.Cache["ConvertAmountCollection"] as Dictionary<string, decimal>;
                if (ConvertAmountCollection != null && ConvertAmountCollection.ContainsKey(CurrencyCode.ToLower()))
                {

                    amountToUSD = CurrencyConverterManager.GetConversionAvailableInCache(CurrencyCode, ConvertAmountCollection);
                    amountToUSD = amountToUSD > 0 ? amountToUSD : CurrencyConverterManager.ConvertCurrencyToUSD(1, "USD", CurrencyCode, ConvertAmountCollection);
                }
                else
                    amountToUSD = CurrencyConverterManager.ConvertCurrencyToUSD(1, "USD", CurrencyCode, ConvertAmountCollection);

                if (amountToUSD > 0)
                    convertedCost = CurrencyConverterManager.CalculateAmount(costToConvert, amountToUSD);
            }

            return convertedCost;
        }

        /// <summary>
        /// Called when clicking "Sending Instruction" button on Create / Edit Instruction page.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SendInstruction(InstructionViewModel model)
        {
            if (model == null)
            {
                return RedirectToAction("UnauthorizedAccess", "Common", new { area = "" });
            }

            //Get the matter detail populated by default.
            //It may not be available from page.
            if (!string.IsNullOrEmpty(model.Matter_Reference))
                model.MatterDetail = MatterManager.GetMatterBlock(model.Matter_Reference);

            //Get GRV value from Client Companies table
            model.GRV = CommonManager.GetGRVForClientCompany(model.Billing_Entity, Convert.ToInt32(model.Billing_Entity_ID));

            //Check GL Account
            if (string.IsNullOrEmpty(model.GLAccount) && ModelState.ContainsKey("GLAccount"))
                ModelState["GLAccount"].Errors.Clear();

            if (!ModelState.IsValid || string.IsNullOrEmpty(model.Matter_Reference))
            {
                ShowMessage(CommonConstants.InvalidModel, MessageType.warning);

                PopulateDBLists(model.MatterDetail.BusinessUnitNameId);
                PopulateStaticLists(model.System);

                //Show / hide the PO related buttons.
                ShowPOButtons(model.FrameworkOrder, model.Status, model.GRV, model.Payment_Clearance_Number, model.Cost_Centre, model.PO_Contact, model.Confirmed);

                return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
            }

            if (!string.IsNullOrEmpty(model.Payment_Clearance_Number))
                model.Confirmed = CommonConstants.Yes;
            else
                model.Confirmed = CommonConstants.No;

            var systemType = SystemTypes.GroupLegal;

            var userRoles = SessionHelper.LoggedUserInfo.Roles.FirstOrDefault();

            if (model.MatterDetail.System == SystemTypes.BusinessUnit.ToString())
                systemType = SystemTypes.BusinessUnit;
            else
                systemType = SystemTypes.GroupLegal;


            var success = false;
            string instructionRef = string.Empty;
            if (string.IsNullOrEmpty(model.Instruction_Reference))
            {
                model.Created_By = SessionHelper.LoggedUserInfo.FullName;

                //Create the new instruction in database.
                success = InstructionManager.CreateInstruction(model, systemType, out instructionRef);
                //Upload File
                if (model.File != null && success)
                {
                    SaveFile(model, instructionRef, "");
                }
            }
            else
            {
                //Check if current user is not Admin.
                //So only admin can edit an instruction.
                if (!SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)(SystemTypeEnum.ServiceProviderAdmin) || x.Id == (int)(SystemTypeEnum.SeniorLegalLeadershipStaff) || x.Id == (int)(SystemTypeEnum.SuperGroupLegal) || x.Id == (int)(SystemTypeEnum.LegalProfessionalStaff)))
                {
                    return Redirect(Request.UrlReferrer.AbsoluteUri);
                }

                if ((model.PO_Contact_ID != null) && (model.GRV_Contact_ID != null) && !string.IsNullOrEmpty(model.Payment_Clearance_Number))
                {
                    if (model.Status == VarConstants.Instruction_Pending_Review)
                        model.Status = VarConstants.Instruction_Pending_Approval;

                }

                model.Sent_Status = VarConstants.Send_Instruction;

                //Update the instruction in database.
                model.Modified_By = SessionHelper.LoggedUserInfo.FullName;
                success = InstructionManager.UpdateInstruction(model, model.Instruction_Reference);

                //update po task
                InstructionManager.UpdatePO(model, model.Instruction_Reference);

                //Check & Insert POContact to External Instruction Confirm PO.
                success = InstructionManager.InsertInstructionsConfirmPO(model);

                if (model.File != null && success)
                {
                    SaveFile(model, model.Instruction_Reference, model.OldFileName);
                }
            }


            if (success)
            {
                ModelState.Clear();
            }

            if (success)
            {
                ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);

                var backUrl = this.RedirectBackUrl;
                if (string.IsNullOrEmpty(backUrl))
                {
                    return Redirect("~/Main/Instructions");
                }
                return Redirect(backUrl);
            }
            else
            {
                PopulateDBLists(model.MatterDetail.BusinessUnitNameId);
                PopulateStaticLists(model.System);
                //Show / hide the PO related buttons.
                ShowPOButtons(model.FrameworkOrder, model.Status, model.GRV, model.Payment_Clearance_Number, model.Cost_Centre, model.PO_Contact, model.Confirmed);

                ShowMessage(CommonConstants.Error, MessageType.danger);
            }

            return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
        }

        public bool SaveFile(InstructionViewModel model, string instructionRef, string oldFileName)
        {
            var fileName = Path.GetFileName(model.File.FileName);
            var originalFileName = fileName;

            //Directory
            string POSubmitDirectory = SystemDetailsViewModel.Path + @"\" + ConfigurationManager.AppSettings["POSubmitEmailPath"] + @"\";
            if (!Directory.Exists(POSubmitDirectory))
                Directory.CreateDirectory(POSubmitDirectory);

            if (model.ID > 0 && !string.IsNullOrEmpty(fileName))
            {
                //Remove existing file
                model.FileName = fileName;
                if (System.IO.File.Exists(POSubmitDirectory + oldFileName))
                    System.IO.File.Delete(POSubmitDirectory + oldFileName);
            }

            model.FileName = instructionRef + "_" + fileName;
            string filePath = POSubmitDirectory + @"\" + model.FileName;
            model.File.SaveAs(filePath);
            return true;
        }

        /// <summary>
        /// Called when clicking "Save Instruction" button on Edit Instruction page.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SaveInstruction(InstructionViewModel model)
        {
            //Check if current user is not Admin/GLS(Super Group Legal User).
            //So only admin/GLS(Super Group Legal User) can edit an instruction.
            if (!SessionHelper.LoggedUserInfo.Roles.Any(x => x.Id == (int)(SystemTypeEnum.SeniorLegalLeadershipStaff) || x.Id == (int)SystemTypeEnum.ServiceProviderAdmin || x.Id == (int)SystemTypeEnum.LegalProfessionalStaff || x.Id == (int)SystemTypeEnum.SuperGroupLegal))
            {
                return Redirect(Request.UrlReferrer.AbsoluteUri);
            }

            //Check GL Account
            if (ModelState.ContainsKey("GLAccount"))
                ModelState["GLAccount"].Errors.Clear();

            if (!ModelState.IsValid || model == null)
            {
                ShowMessage(CommonConstants.InvalidModel, MessageType.warning);

                PopulateDBLists(model.MatterDetail.BusinessUnitNameId);
                PopulateStaticLists(model.System);
                //Show / hide the PO related buttons.
                ShowPOButtons(model.FrameworkOrder, model.Status, model.GRV, model.Payment_Clearance_Number, model.Cost_Centre, model.PO_Contact, model.Confirmed);

                return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
            }

            if (!string.IsNullOrEmpty(model.Payment_Clearance_Number))
                model.Confirmed = CommonConstants.Yes;
            else
                model.Confirmed = CommonConstants.No;

            //Avoid sending instruction by fault.
            model.Sent_Status = string.Empty;

            //Updating instruction.
            var success = InstructionManager.UpdateInstruction(model, model.Instruction_Reference);

            if (success)
            {
                //Check & Insert POContact to External Instruction Confirm PO.
                success = InstructionManager.InsertInstructionsConfirmPO(model);
            }

            if (success)
            {
                TempData["PostBack"] = "Yes";
                ShowMessage(CommonConstants.UpdateSuccessful, MessageType.success, true);
                var qsd = new Dictionary<string, string>
                                    {
                                        {"id", model.ID.ToString()},
                                        { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()}
                                    };
                return RedirectToAction("Manage", "Instructions", new { area = "Section", q = Exigent.Common.Helpers.Crypto.Encrypt(qsd) });
            }
            else
            {
                //Get GRV value from Client Companies table
                model.GRV = CommonManager.GetGRVForClientCompany(model.Billing_Entity);
                model.MatterDetail = MatterManager.GetMatterBlock(model.Matter_Reference);
                PopulateDBLists(model.MatterDetail.BusinessUnitNameId);
                PopulateStaticLists(model.System);
                //Show / hide the PO related buttons.
                ShowPOButtons(model.FrameworkOrder, model.Status, model.GRV, model.Payment_Clearance_Number, model.Cost_Centre, model.PO_Contact, model.Confirmed);

                ShowMessage(CommonConstants.Error, MessageType.danger);
            }

            if (model.File != null && success)
            {
                SaveFile(model, model.Instruction_Reference, model.OldFileName);
            }

            return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
        }

        #endregion

        /// <summary>
        /// Show / hide the PO related buttons.
        /// </summary>
        /// <param name="frameWorkOrder"></param>
        /// <param name="status"></param>
        /// <param name="grv"></param>
        /// <param name="pcn"></param>
        /// <param name="costCentre"></param>
        /// <param name="poContact"></param>
        /// <param name="confirmed"></param>
        public void ShowPOButtons(string frameWorkOrder, string status, string grv, string pcn, string costCentre, string poContact, string confirmed)
        {
            ViewBag.IncreasePOVisible = true;
            ViewBag.AmendPOVisible = true;
            ViewBag.RequestPOVisible = true;

            if (!string.IsNullOrEmpty(frameWorkOrder) && frameWorkOrder == CommonConstants.Yes)
            {
                ViewBag.IncreasePOVisible = false;
                ViewBag.AmendPOVisible = false;
                ViewBag.RequestPOVisible = false;
            }
            else
            {
                if (status != VarConstants.Instruction_Closed)
                {

                    if (grv == CommonConstants.Yes)
                    {
                        if (string.IsNullOrEmpty(pcn))
                        {
                            if (!string.IsNullOrEmpty(costCentre))
                            {
                                if (!string.IsNullOrEmpty(poContact))
                                {
                                    ViewBag.RequestPOVisible = true;
                                }
                                else
                                {
                                    ViewBag.RequestPOVisible = false;
                                }
                            }
                            ViewBag.IncreasePOVisible = false;
                            ViewBag.AmendPOVisible = false;
                        }
                        else
                        {
                            if (confirmed == CommonConstants.No)
                            {
                                ViewBag.IncreasePOVisible = false;
                                ViewBag.AmendPOVisible = false;
                            }
                            else
                            {
                                if (string.IsNullOrEmpty(poContact))
                                {
                                    ViewBag.IncreasePOVisible = false;
                                    ViewBag.AmendPOVisible = false;
                                }
                                else
                                {
                                    ViewBag.IncreasePOVisible = true;
                                    ViewBag.AmendPOVisible = true;
                                }

                            }
                            ViewBag.RequestPOVisible = false;
                        }
                    }
                    else
                    {
                        ViewBag.RequestPOVisible = false;
                        ViewBag.AmendPOVisible = false;
                        ViewBag.IncreasePOVisible = false;
                    }

                }
                else
                {
                    ViewBag.RequestPOVisible = false;
                    ViewBag.AmendPOVisible = false;
                    ViewBag.IncreasePOVisible = false;
                }
            }


        }

        #region Instruction - PO Tasks

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RequestPO(InstructionViewModel model)
        {
            //Check GL Account
            if (ModelState.ContainsKey("GLAccount"))
                ModelState["GLAccount"].Errors.Clear();

            if (!ModelState.IsValid || model == null)
            {
                ShowMessage(CommonConstants.InvalidModel, MessageType.warning);

                PopulateDBLists(model.MatterDetail.BusinessUnitNameId);
                PopulateStaticLists();
                //Show / hide the PO related buttons.
                ShowPOButtons(model.FrameworkOrder, model.Status, model.GRV, model.Payment_Clearance_Number, model.Cost_Centre, model.PO_Contact, model.Confirmed);

                return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
            }

            //Avoid sending instruction by fault.
            model.Sent_Status = string.Empty;

            //Updating instruction.
            var success = InstructionManager.UpdateInstruction(model, model.Instruction_Reference);

            if (model.File != null && success)
            {
                SaveFile(model, model.Instruction_Reference, model.OldFileName);
            }

            if (!success)
            {
                ShowMessage(CommonConstants.Error, MessageType.warning);

                PopulateDBLists(model.MatterDetail.BusinessUnitNameId);
                PopulateStaticLists();
                //Show / hide the PO related buttons.
                ShowPOButtons(model.FrameworkOrder, model.Status, model.GRV, model.Payment_Clearance_Number, model.Cost_Centre, model.PO_Contact, model.Confirmed);

                return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
            }

            var qsdInstruction = new Dictionary<string, string>
                                            {
                                                {"id", model.ID.ToString()},
                                                { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString()}
                                            };

            return RedirectToAction("CreatePOTask", "PO", new { q = Exigent.Common.Helpers.Crypto.Encrypt(qsdInstruction) });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AmendPO(InstructionViewModel model)
        {
            if (string.IsNullOrEmpty(model.GLAccount) && ModelState.ContainsKey("GLAccount"))
                ModelState["GLAccount"].Errors.Clear();

            //null check EXICHM-446
            if (model != null)
            {
                if (!ModelState.IsValid)
                {
                    ShowMessage(CommonConstants.InvalidModel, MessageType.warning);

                    PopulateDBLists(model.MatterDetail.BusinessUnitNameId);
                    PopulateStaticLists();
                    //Show / hide the PO related buttons.
                    ShowPOButtons(model.FrameworkOrder, model.Status, model.GRV, model.Payment_Clearance_Number, model.Cost_Centre, model.PO_Contact, model.Confirmed);

                    return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
                }

                //Avoid sending instruction by fault.
                model.Sent_Status = string.Empty;

                //Updating instruction.
                InstructionManager.UpdateInstruction(model, model.Instruction_Reference);

                if (model.File != null)
                {
                    SaveFile(model, model.Instruction_Reference, model.OldFileName);
                }

                //return RedirectToAction("UnderConstruction", "Common", new { area = "" });
                // added by vyom dixit, regarding JIRA - EXICHM-359.
                var qsInstructionRef = new Dictionary<string, string> { { "instruction_reference", model.Instruction_Reference }, { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString() } };

                return RedirectToAction("AmendPO", "PO", new { area = "Section", q = Exigent.Common.Helpers.Crypto.Encrypt(qsInstructionRef) });
            }
            return null;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult IncreasePO(InstructionViewModel model)
        {
            if (string.IsNullOrEmpty(model.GLAccount) && ModelState.ContainsKey("GLAccount"))
                ModelState["GLAccount"].Errors.Clear();

            if (!ModelState.IsValid || model == null)
            {
                ShowMessage(CommonConstants.InvalidModel, MessageType.warning);

                PopulateDBLists(model.MatterDetail.BusinessUnitNameId);
                PopulateStaticLists();
                //Show / hide the PO related buttons.
                ShowPOButtons(model.FrameworkOrder, model.Status, model.GRV, model.Payment_Clearance_Number, model.Cost_Centre, model.PO_Contact, model.Confirmed);

                return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
            }

            //Avoid sending instruction by fault.
            model.Sent_Status = string.Empty;

            //Updating instruction.
            var success = InstructionManager.UpdateInstruction(model, model.Instruction_Reference);

            if (model.File != null && success)
            {
                SaveFile(model, model.Instruction_Reference, model.OldFileName);
            }

            if (!success)
            {
                ShowMessage(CommonConstants.Error, MessageType.warning);

                PopulateDBLists(model.MatterDetail.BusinessUnitNameId);
                PopulateStaticLists();
                //Show / hide the PO related buttons.
                ShowPOButtons(model.FrameworkOrder, model.Status, model.GRV, model.Payment_Clearance_Number, model.Cost_Centre, model.PO_Contact, model.Confirmed);

                return View("~/Areas/Section/Views/Instructions/Manage.cshtml", model);
            }

            //return RedirectToAction("UnderConstruction", "Common", new { area = "" });
            // added by vyom dixit, regarding JIRA - EXICHM-359.
            var qsInstructionRef = new Dictionary<string, string> { { "instruction_reference", model.Instruction_Reference }, { "AuthUID", SessionHelper.LoggedUserInfo.UserId.ToString() } };

            return RedirectToAction("IncreasePO", "PO", new { area = "Section", q = Exigent.Common.Helpers.Crypto.Encrypt(qsInstructionRef) });
        }

        #endregion

        #region Instruction - Contact Request Task

        /// <summary>
        /// Contact Request Task - Page Render
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpGet]
        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard })]
        public ActionResult ContactsRequestTask(int id)
        {
            var model = new ContactRequestTaskViewModel();

            if (id <= 0)
            {
                ShowMessage(CommonConstants.InvalidModel, MessageType.warning);
                return View("~/Areas/Section/Views/Instructions/ContactsRequestTask.cshtml", model);
            }

            //Get data to show on page in view state.
            model = InstructionManager.GetContactRequestTaskDetail(id);

            //Check if task is already complete.
            if (InstructionManager.IsContactRequestTaskComplete(id))
            {
                //Redirect to complete message page.
                model.Status = VarConstants.POContactTask_Complete;
                return View("~/Areas/Section/Views/Instructions/ContactsRequestTask.cshtml", model);
            }



            if (model == null)
            {
                ShowMessage(CommonConstants.InvalidModel, MessageType.warning);
                return View("~/Areas/Section/Views/Instructions/ContactsRequestTask.cshtml", model);
            }

            return View("~/Areas/Section/Views/Instructions/ContactsRequestTask.cshtml", model);
        }

        /// <summary>
        /// Contact Request Task - Set to Complete.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ContactsRequestTaskComplete(ContactRequestTaskViewModel model)
        {
            if (model == null)
            {
                ShowMessage(CommonConstants.InvalidModel, MessageType.warning);
                return View("~/Areas/Section/Views/Instructions/ContactsRequestTask.cshtml", model);
            }

            //Disable non required validations.
            this.ModelState.Remove("Assigned_To_ID");
            this.ModelState.Remove("Comments");

            if (!ModelState.IsValid)
            {
                ShowMessage(CommonConstants.InvalidModel, MessageType.warning);
                return View("~/Areas/Section/Views/Instructions/ContactsRequestTask.cshtml", model);
            }

            model.Status = VarConstants.POContactTask_Complete;

            //Update status as Complete.
            InstructionManager.CompleteContactRequestTask(model);

            var backUrl = this.RedirectBackUrl;
            if (string.IsNullOrEmpty(backUrl))
            {
                return Redirect("~/Main");
            }
            return Redirect(backUrl);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="refNo"></param>
        /// <returns></returns>
        [CryptoValueProvider]
        public ActionResult ContactsRequestTaskReassign(string Id, string refNo, string Instruction_ID = "")
        {
            if (string.IsNullOrEmpty(Id) && string.IsNullOrEmpty(refNo))
                return null;

            var model = new ContactRequestTaskViewModel();
            model.ID = Convert.ToInt32(Id);
            model.Instruction_Reference = refNo;
            model.Instruction_ID = !string.IsNullOrEmpty(Instruction_ID) ? Convert.ToInt32(Instruction_ID) : 0;
            return View(model);
        }

        [CryptoValueProvider]
        [CustomAuthorization(PageSecurityDisabled = false, ParentDashboardIds = new int[] { (int)UserAccessEnum.MainDashboard, (int)UserAccessEnum.AdminDashboard, (int)UserAccessEnum.AccountsDashboard })]
        public ActionResult DownloadInstructionEmailFile(string id, string instructionRef, bool isAdmin = false)
        {
            string FileName = InstructionManager.GetInstructionByInstructionRef(instructionRef);

            if (!string.IsNullOrEmpty(FileName))
            {
                string contentType = "application/msg";
                string fileDirectory = SystemDetailsViewModel.Path + @"\" + ConfigurationManager.AppSettings["POSubmitEmailPath"] + @"\" + FileName;
                if (System.IO.File.Exists(fileDirectory))
                    return File(fileDirectory, contentType, FileName);

                return Redirect(SystemDetailsViewModel.URL + "/Common/NotFound");
            }
            return Redirect(SystemDetailsViewModel.URL + "/Common/NotFound");
        }

        /// <summary>
        /// Contact Request Task - Reassign to another user.
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ContactsRequestTaskReassign(ContactRequestTaskViewModel model)
        {
            if (model == null)
            {
                ShowMessage(CommonConstants.InvalidModel, MessageType.warning);
                return View("~/Areas/Section/Views/Instructions/ContactsRequestTaskReassign.cshtml", model);
            }

            //Disable non required validations.
            this.ModelState.Remove("PO_Contact");
            this.ModelState.Remove("GRV_Contact");
            this.ModelState.Remove("PO_Contact_ID");
            this.ModelState.Remove("GRV_Contact_ID");


            if (!ModelState.IsValid)
            {
                ShowMessage(CommonConstants.InvalidModel, MessageType.warning);
                return View("~/Areas/Section/Views/Instructions/ContactsRequestTaskReassign.cshtml", model);
            }

            //Open (Create) a new instruction approval task for new assignee.
            InstructionManager.ReassignContactRequestTask(model);

            //TODO: Sending Email to Assignee.

            var backUrl = this.RedirectBackUrl;
            if (string.IsNullOrEmpty(backUrl))
            {
                return Redirect("~/Main");
            }
            return Redirect(backUrl);
        }

        #endregion

        public ActionResult CloseInstruction(string insRef)
        {
            new InstructionManager().CloseInstruction(insRef);
            return Json("Success", JsonRequestBehavior.AllowGet);
        }
    }
}