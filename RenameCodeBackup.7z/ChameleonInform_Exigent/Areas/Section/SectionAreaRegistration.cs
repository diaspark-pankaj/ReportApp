﻿using System.Web.Mvc;

namespace ChameleonInformExigent.Areas.Section
{
    public class SectionAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Section";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Section_default",
                "Section/{controller}/{action}/{id}",
                new { controller = "Matter", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}