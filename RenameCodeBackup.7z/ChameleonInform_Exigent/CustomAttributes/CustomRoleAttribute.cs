﻿using ChameleonInformExigent.Helpers;
using Exigent.Common.Enums;
using Exigent.Common.Helpers;
using Exigent.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Web.Routing;

namespace Exigent.CustomAttributes
{
    public sealed class CustomAuthorizationAttribute : FilterAttribute, IActionFilter
    {
        public bool PageSecurityDisabled;
        public int[] ParentDashboardIds;
        public int RequestingUserId;        
        private SessionHelper _sessionHelper;

        private bool _canEdit = true;
        private bool _canAdd = true;

        public CustomAuthorizationAttribute()
        {
            PageSecurityDisabled = true;
            ParentDashboardIds = new int[] { };
            RequestingUserId = 0;
        }

        void IActionFilter.OnActionExecuted(ActionExecutedContext filterContext)
        {

        }

        void IActionFilter.OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext.HttpContext.Session != null)
            {
                _sessionHelper = (SessionHelper)filterContext.HttpContext.Session["User"];
                CheckPageSecurity(filterContext);
            }
        }

        private void CheckPageSecurity(ActionExecutingContext filterContext)
        {
            _canEdit = true;
            _canAdd = true;
            bool status = false;
            if (!PageSecurityDisabled)
            {              
                if (!string.IsNullOrEmpty(filterContext.RequestContext.HttpContext.Request.QueryString["q"]))
                {
                    var urlKeys = Common.Helpers.Crypto.Decrypt(filterContext.RequestContext.HttpContext.Request.QueryString["q"], out status);
                    if (urlKeys != null && urlKeys.Keys.Any(x => x.ToUpper() == "AUTHUID"))
                    {
                        RequestingUserId = Convert.ToInt32(urlKeys.Where(x => x.Key.ToUpper() == "AUTHUID").FirstOrDefault().Value);
                        status = true;
                    }
                    else
                        status = false;
                }
                else
                    status = false;

                if (!_sessionHelper.LoggedUserInfo.AccessDashboardPages.Any(q => q.ID == _sessionHelper.LoggedUserInfo.SelectedDashboardID))
                {
                    _canEdit = false;
                    _canAdd = false;
                    filterContext.Controller.ViewBag.CanAdd = _canAdd;
                    filterContext.Controller.ViewBag.CanEdit = _canEdit;
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "action", "UnauthorizedAccess" }, { "controller", "Common" }, { "area", "" } });
                }
                else if (!_sessionHelper.LoggedUserInfo.UserId.Equals(RequestingUserId) && status)
                {
                    _canEdit = false;
                    _canAdd = false;
                    filterContext.Controller.ViewBag.CanAdd = _canAdd;
                    filterContext.Controller.ViewBag.CanEdit = _canEdit;
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "action", "UnauthorizedAccess" }, { "controller", "Common" }, { "area", "" } });
                }
                else if (!_sessionHelper.LoggedUserInfo.AccessDashboardPages.Any(q => ParentDashboardIds.Contains(q.ID)))
                {
                    _canEdit = false;
                    _canAdd = false;
                    filterContext.Controller.ViewBag.CanAdd = _canAdd;
                    filterContext.Controller.ViewBag.CanEdit = _canEdit;
                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "action", "UnauthorizedAccess" }, { "controller", "Common" }, { "area", "" } });
                }
                else
                {
                    filterContext.Controller.ViewBag.CanAdd = _canAdd;
                    filterContext.Controller.ViewBag.CanEdit = _canEdit;
                }
            }
            else //Not in use right now
            {
                _canAdd = true;
                _canEdit = true;

                filterContext.Controller.ViewBag.CanAdd = _canAdd;
                filterContext.Controller.ViewBag.CanEdit = _canEdit;
            }
        }
    }
}
public sealed class CustomAuthrizeActivitiesAttribute : FilterAttribute, IActionFilter
{
    public int[] RoleActivitiesIds;
    private SessionHelper _sessionHelper;

    private bool _canEdit = true;
    private bool _canAdd = true;
    public string IdParamName { get; set; }
    public CustomAuthrizeActivitiesAttribute()
    {
        RoleActivitiesIds = new int[] { };
    }

    void IActionFilter.OnActionExecuted(ActionExecutedContext filterContext)
    {

    }

    void IActionFilter.OnActionExecuting(ActionExecutingContext filterContext)
    {
        if (filterContext.HttpContext.Session != null)
        {
            _sessionHelper = (SessionHelper)filterContext.HttpContext.Session["User"];
            CheckPageSecurity(filterContext);
        }
    }

    private void CheckPageSecurity(ActionExecutingContext filterContext)
    {
        _canEdit = true;
        _canAdd = true;

        if (!_sessionHelper.LoggedUserInfo.RoleAppActivityList.Any(q => RoleActivitiesIds.Contains(q.AppActivityId) && _sessionHelper.LoggedUserInfo.Roles.Select(x => x.Id).ToArray().Contains(q.RoleId))
        )
        {
            _canEdit = false;
            _canAdd = false;
            filterContext.Controller.ViewBag.CanAdd = _canAdd;
            filterContext.Controller.ViewBag.CanEdit = _canEdit;
            filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary { { "action", "UnauthorizedAccess" }, { "controller", "Common" }, { "area", "" } });
        }
        else
        {
            filterContext.Controller.ViewBag.CanAdd = _canAdd;
            filterContext.Controller.ViewBag.CanEdit = _canEdit;
        }
    }
}

