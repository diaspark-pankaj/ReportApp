﻿using ChameleonInformExigent.Helpers;
using Exigent.Common.Helpers;
using Exigent.Helpers;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;

namespace Exigent.Helpers.CustomAttributes
{
    public class UserAccessValidationAttribute : FilterAttribute, IActionFilter
    {
        public string UnitIdVarName;
       
        public bool EncryptionFlag;

        private int _unitId;
        private SessionHelper _sessionHelper;
       

        void IActionFilter.OnActionExecuted(ActionExecutedContext filterContext)
        {

        }

        void IActionFilter.OnActionExecuting(ActionExecutingContext filterContext)
        {
            
            bool isAccessToUnit=false;
            if (EncryptionFlag == true)
            {
                var querystring = HttpContext.Current.Request.QueryString["q"];
                bool status;
                Dictionary<string, string> _dictionary = ChameleonInformExigent.Helpers.Crypto.Decrypt(querystring, out status);
                if (_dictionary != null)
                {
                    if (_dictionary.ContainsKey("" + UnitIdVarName + ""))
                    {
                        _unitId = Convert.ToInt32(_dictionary["" + UnitIdVarName + ""]);
                    }
                }
                else
                {
                    filterContext.Result = new RedirectToRouteResult(
                       new System.Web.Routing.RouteValueDictionary
                        {
                            {"action", "Index"},
                            {"controller", "Home"},
                            {"area", "Home"},
                            //{"mode", (int)Mode.RERNoExist}
                        });
                }
            }
            else
                _unitId = Convert.ToInt32(HttpContext.Current.Request.QueryString[UnitIdVarName]);

            if (filterContext.HttpContext.Session != null)
                _sessionHelper = (SessionHelper)filterContext.HttpContext.Session["User"];

            if (!isAccessToUnit)
            {
                filterContext.Result = new RedirectToRouteResult(
                        new System.Web.Routing.RouteValueDictionary
                        {
                            {"action", "UnauthorizedAccess"},
                            {"controller", "Common"},
                            {"area", ""}
                        });
            }
        }
    }
}