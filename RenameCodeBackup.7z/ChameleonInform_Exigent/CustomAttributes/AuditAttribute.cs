﻿using System;
using System.Web.Mvc;
using Exigent_ViewModels.Audit;
using Exigent_BusinessLogicLayer.Audit;
using Exigent.Helpers;


namespace ChameleonInformExigent.Helpers.Auditing
{
    public sealed class AuditAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext != null)
            {

                //Stores the Request in an Accessible object
                var request = filterContext.HttpContext.Request;
                string LoggedInUser = string.Empty;
                if (filterContext.HttpContext.Session["User"] != null)
                    LoggedInUser = ((SessionHelper)(filterContext.HttpContext.Session["User"])).LoggedUserInfo.FullName;
                //Generate an audit
                AuditViewModel audit = new AuditViewModel()
                {
                    AuditID = Guid.NewGuid(),
                    IPAddress = request.ServerVariables["HTTP_X_FORWARDED_FOR"] ?? request.UserHostAddress,
                    URLAccessed = request.RawUrl,
                    TimeAccessed = DateTime.UtcNow,
                    UserName = (LoggedInUser != string.Empty) ? LoggedInUser : "Anonymous",
                };

                AuditManager objAuditManager = new AuditManager();
                objAuditManager.SaveAudit(audit);
            }
           
        }

        public  void SaveCustomAudit(AuditViewModel AuditData)
        {
            AuditManager objAuditManager = new AuditManager();
            objAuditManager.SaveAudit(AuditData);

        }
    }
}