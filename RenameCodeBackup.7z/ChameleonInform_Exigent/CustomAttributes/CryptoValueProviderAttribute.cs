﻿using System.Web.Mvc;
using Exigent.Helpers;
using ChameleonInformExigent.Helpers;

namespace Exigent.Helpers.CustomAttributes
{
    public class CryptoValueProviderAttribute : FilterAttribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationContext filterContext)
        {
            filterContext.Controller.ValueProvider = new CryptoValueProvider(filterContext.RouteData);
        }
    }
}