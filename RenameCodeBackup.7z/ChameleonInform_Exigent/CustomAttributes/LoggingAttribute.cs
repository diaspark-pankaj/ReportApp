﻿//using System;
//using System.Collections.Generic;
//using System.Diagnostics;
//using System.Linq;
//using System.Web;
//using System.Web.Mvc;

//namespace Exigent.CustomAttributes
//{
  
//    public class LoggingAttribute : ActionFilterAttribute
//    {
//        private readonly Stopwatch _sw;

//        public LoggingAttribute()
//        {
//            _sw = new Stopwatch();
//        }

//        public override void OnActionExecuting(ActionExecutingContext filterContext)
//        {
//            _sw.Start();
//            Debug.WriteLine("Beginning executing: " + GetControllerAndActionName(filterContext.ActionDescriptor));
//        }

//        public override void OnActionExecuted(ActionExecutedContext filterContext)
//        {
//            _sw.Stop();
//            var ms = _sw.ElapsedMilliseconds;
           
//            Debug.WriteLine("Finishing executing: " + GetControllerAndActionName(filterContext.ActionDescriptor));
//            Debug.WriteLine("Time elapsed: " + TimeSpan.FromMilliseconds(ms).TotalSeconds);

//            if (filterContext.Result is ViewResult)
//            { //Make sure the request is a ViewResult, ie. a page
//                ((ViewResult)filterContext.Result).ViewData["ExecutionTime"] = TimeSpan.FromMilliseconds(ms).TotalSeconds; //Set the viewdata dictionary
//            }
//        }

//        private string GetControllerAndActionName(ActionDescriptor actionDescriptor)
//        {
//            return actionDescriptor.ControllerDescriptor.ControllerName + " - " + actionDescriptor.ActionName;
//        }
//    }
//}