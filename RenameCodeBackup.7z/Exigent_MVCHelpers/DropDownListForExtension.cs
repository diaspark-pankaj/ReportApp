﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using System.Web.Routing;

namespace Exigent.MVCHelpers
{
    public static class DropDownListForExtension
    {
        /*
            @Html.CustomDropDownListFor(model => Model.Country, new SelectList(Model.Address.CountryList, "CountryId", "CountryName"),
         Model.Address.CountryValidationTypeList, modelState, "--Select--", new { id = "ShippingAddressWidgetRender_ShippingAddressWidgetViewModelList_" + index + "-Country", name = "ShippingAddressWidgetRender.ShippingAddressWidgetViewModelList[" + index + "].Country", @class = "form-control" })
        
         public static MvcHtmlString CustomDropDownListFor<TModel, TProperty>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TProperty>> expression, IEnumerable<SelectListItem> selectList, string optionLabel, object htmlAttributes) 
         
         */

        public static MvcHtmlString Custom_DropdownList(string text)
        {
            return MvcHtmlString.Create("<label>" + text + "</label>");
        }


        public static MvcHtmlString Custom_DropdownList(object helper , SelectList selectList, string selectedValue, string optionLabel, object htmlAttributes)
        {
            // return MvcHtmlString.Create("<label> 4 " + text + "</label>");
            //Created StringBuilder object to store option data fetched oen by one from list.
            TagBuilder dropDownTagBuilder = new TagBuilder("select");
         
            StringBuilder optionStringBuilder = new StringBuilder();
            //Iterated over the IEnumerable list.
            if (optionLabel != "")
            {
                //Default Value
                TagBuilder defaultOptionBuilder = new TagBuilder("option");
                defaultOptionBuilder.MergeAttribute("value", null);
                defaultOptionBuilder.InnerHtml = optionLabel;
                optionStringBuilder.Append(defaultOptionBuilder.ToString());
            }
            foreach (SelectListItem selectListItem in selectList)
            {
                TagBuilder optionBuilder = new TagBuilder("option");
                optionBuilder.MergeAttribute("value", selectListItem.Value);
                optionBuilder.InnerHtml = selectListItem.Text;
                if (String.Equals(selectListItem.Value, selectedValue, StringComparison.Ordinal))
                {
                    optionBuilder.MergeAttribute("selected", "selected");
                }

 //if(String.Compare(selectListItem.Value,selectedValue,false)
 //{
 //      optionBuilder.MergeAttribute("selected", "selected");
 //}
                //if (selectListItem.Value == selectedValue)
                //{
                  
               // }
                optionStringBuilder.Append(optionBuilder.ToString());
            }

            //assigned all the options to the dropdown using innerHTML property.
            dropDownTagBuilder.InnerHtml = optionStringBuilder.ToString();
            //Assigning the attributes passed as a htmlAttributes object.
            dropDownTagBuilder.MergeAttributes(new RouteValueDictionary(htmlAttributes));
            //Returning the entire select or dropdown control in HTMLString format.
            return MvcHtmlString.Create(dropDownTagBuilder.ToString(TagRenderMode.Normal));




        }

        public static MvcHtmlString Custom_DropdownList(this HtmlHelper helper, string text)
        {
            return MvcHtmlString.Create("<label> 5 " + text + "</label>");
        }

        ////This overload is extension method that accepts two parameters i.e. name and Ienumerable list of values to populate.
        //public static MvcHtmlString Custom_DropdownList(this HtmlHelper helper, string name, List<SelectList> list)
        //{
        //    //This method in turns calls below overload.
        //    return Custom_DropdownList(helper, name, list, "", null);
        //}

        ////This overload is extension method accepts name, list and htmlAttributes as parameters.
        //public static MvcHtmlString Custom_DropdownList(this HtmlHelper helper, string name, List<SelectList> selectList, string optionLabel, object htmlAttributes)
        //{
        //    string attemptedValue = string.Empty;
        //    //if (modelState1.Key != null)
        //    //{
        //    //    attemptedValue = modelState1.Value.Value.AttemptedValue;
        //    //}

        //    //Created StringBuilder object to store option data fetched oen by one from list.
        //    TagBuilder dropDownTagBuilder = new TagBuilder("select");
        //    StringBuilder optionStringBuilder = new StringBuilder();
        //    //Iterated over the IEnumerable list.
        //    if (optionLabel != "")
        //    {
        //        //Default Value
        //        TagBuilder defaultOptionBuilder = new TagBuilder("option");
        //        defaultOptionBuilder.MergeAttribute("value", null);
        //        defaultOptionBuilder.InnerHtml = optionLabel;
        //        optionStringBuilder.Append(defaultOptionBuilder.ToString());
        //    }
        //    foreach (SelectList selectListItem in selectList)
        //    {
        //        TagBuilder optionBuilder = new TagBuilder("option");
        //        optionBuilder.MergeAttribute("value", selectListItem.DataValueField);
        //        optionBuilder.InnerHtml = selectListItem.DataTextField;
        //        if (selectListItem.DataValueField == attemptedValue)
        //        {
        //            optionBuilder.MergeAttribute("selected", "selected");
        //        }
        //        optionStringBuilder.Append(optionBuilder.ToString());
        //    }

        //    //assigned all the options to the dropdown using innerHTML property.
        //    dropDownTagBuilder.InnerHtml = optionStringBuilder.ToString();

        //    //Assigning the attributes passed as a htmlAttributes object.
        //    dropDownTagBuilder.MergeAttributes(new RouteValueDictionary(htmlAttributes));
        //    //Returning the entire select or dropdown control in HTMLString format.
        //    return MvcHtmlString.Create(dropDownTagBuilder.ToString(TagRenderMode.Normal));
        //}
    }

}




