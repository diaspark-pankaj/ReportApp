﻿using System.Web.Mvc;

namespace Exigent.MVCHelpers
{

    public static class MvcHtmlStringExtensions
    {
        public static MvcHtmlString If(this MvcHtmlString value, bool check)
        {
            if (check)
            {
                return value;
            }

            return null;
        }

        public static MvcHtmlString Else(this MvcHtmlString value, MvcHtmlString alternate)
        {
            if (!string.IsNullOrEmpty(value.ToString()))
            {
                return alternate;
            }

            return value;
        }
    }
}
