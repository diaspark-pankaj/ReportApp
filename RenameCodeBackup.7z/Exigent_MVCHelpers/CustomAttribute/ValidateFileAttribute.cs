﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using Image = System.Drawing.Image;

namespace Exigent.MVCHelpers.CustomAttribute
{
    //Customized data annotation validator for uploading file
    public class ValidateFileAttribute : ValidationAttribute
    {
        // private readonly int _maxWidth = Convert.ToInt32(ConfigurationManager.AppSettings["ImageMaxWidth"]);
        //private readonly int _maxHeight = Convert.ToInt32(ConfigurationManager.AppSettings["ImageMaxHeight"]);

        private const int MaxWidth = 1024; //TODO: DJ - These values comes from appsetting
        private const int MaxHeight = 768;

        private bool IsImageDimensionsValid(HttpPostedFileBase file)
        {
            Image uploadedImage = Image.FromStream(file.InputStream);

            Single widthuploadedimg = uploadedImage.PhysicalDimension.Width;
            Single heightuploadedimg = uploadedImage.PhysicalDimension.Height;

            return !(widthuploadedimg > MaxWidth) && !(heightuploadedimg > MaxHeight);
        }

        public override bool IsValid(object value)
        {
            const int maxContentLength = 1024 * 1024 * 3; //3 MB
            string[] allowedFileExtensions = { ".jpg", ".gif", ".png", ".JPG", ".GIF", ".PNG" };//, ".pdf"

            var file = value as HttpPostedFileBase;

            //Check for Image
            if (file == null)
            {
                //ErrorMessage = "Please Upload Your file";
                return true;
            }

            if (file.ContentLength > 0)
            {
                if (!allowedFileExtensions.Contains(file.FileName.Substring(file.FileName.LastIndexOf('.'))))
                {
                    ErrorMessage = "Please use image as type of file: " + string.Join(", ", allowedFileExtensions);
                    return false;
                }

                if (file.ContentLength > maxContentLength)
                {
                    ErrorMessage = "Your image is too large, maximum allowed size is: " + (maxContentLength / 1024) + " MB";
                    return false;
                }

                if (!IsImageDimensionsValid(file))
                {
                    ErrorMessage = "Maximum allowed image dimension is " + MaxWidth + "*" + MaxHeight;
                    return false;
                }
                return true;
            }
            return false;
        }
    }
}


