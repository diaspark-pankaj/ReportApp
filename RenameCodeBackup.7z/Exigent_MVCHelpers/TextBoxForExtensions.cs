﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web.Mvc;


namespace Exigent.MVCHelpers
{
    public static class TextBoxForExtensions
    {
        public static MvcHtmlString TextBoxPlaceHolderFor<TModel, TProperty>(this HtmlHelper html, Expression<Func<TModel, TProperty>> expression, object htmlAttributes)
        {
            var dict = new Dictionary<string, object>();
            return html.TextBoxPlaceHolderFor(expression, dict);
        }
        public static MvcHtmlString TextBoxPlaceHolderFor<TModel, TProperty>(this HtmlHelper html, Expression<Func<TModel, TProperty>> expression)
        {
            var htmlAttributes = new Dictionary<string, object>();
            return html.TextBoxPlaceHolderFor(expression, htmlAttributes);
        }

        public static MvcHtmlString TextBoxPlaceHolderFor<TModel, TProperty>(this HtmlHelper html, Expression<Func<TModel, TProperty>> expression, IDictionary htmlAttributes)
        {
            ModelMetadata metadata = ModelMetadata.FromLambdaExpression(expression, (ViewDataDictionary<TModel>)html.ViewData);
            string htmlFieldName = ExpressionHelper.GetExpressionText(expression);
            string labelText = metadata.ShortDisplayName ?? metadata.DisplayName ?? metadata.PropertyName ?? htmlFieldName.Split('.').Last();
            if (!String.IsNullOrEmpty(labelText))
            {
                if (htmlAttributes == null)
                {
                    htmlAttributes = new Dictionary<string, object>();
                }
                htmlAttributes.Add("placeholder", labelText);
            }
            return System.Web.Mvc.Html.InputExtensions.TextBoxFor((HtmlHelper<TModel>)html, expression);
        }

    }
}
