﻿using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web.Mvc;
using System.Web.Routing;

namespace Azmbl.MVCHelpers
{
    public static class EncodedActionLinkExtension
    {
        public static MvcHtmlString EncodedActionLink(string linkText, string actionName, string controllerName, object routeValues, object htmlAttributes)
        {
            string queryString = string.Empty;
            string htmlAttributesString = string.Empty;
            if (routeValues != null)
            {
                var d = new RouteValueDictionary(routeValues);

                for (int i = 0; i < d.Keys.Count; i++)
                {
                    if (i > 0)
                    {
                        queryString += "?";
                    }
                    if (d.ElementAt(i).Key == "area" || d.ElementAt(i).Key == "Area")
                    {
                        queryString += d.Keys.ElementAt(i) + "=" + d.Values.ElementAt(i);
                    }
                }
            }

            if (htmlAttributes != null)
            {
                var d = new RouteValueDictionary(htmlAttributes);
                for (int i = 0; i < d.Keys.Count; i++)
                {
                    htmlAttributesString += " " + d.Keys.ElementAt(i) + "=" + d.Values.ElementAt(i);
                }
            }

            //<a href="/Answer?questionId=14">What is Entity Framework??</a>
            var ancor = new StringBuilder();
            ancor.Append("<a ");
            if (String.IsNullOrEmpty(htmlAttributesString))
            {
                ancor.Append(htmlAttributesString);
            }
            ancor.Append(" href='");
            if (String.IsNullOrEmpty(controllerName))
            {
                ancor.Append("/" + controllerName);
            }

            if (actionName != "Index")
            {
                ancor.Append("/" + actionName);
            }
            if (String.IsNullOrEmpty(queryString))
            {
                ancor.Append("?q=" + Encrypt(queryString));
            }
            ancor.Append("'");
            ancor.Append(">");
            ancor.Append(linkText);
            ancor.Append("</a>");
            return new MvcHtmlString(ancor.ToString());
        }

        private static string Encrypt(string plainText)
        {
            string key = ConfigurationManager.AppSettings["QueryStringEncrypDecrypkey"];
            byte[] iv = { 55, 34, 87, 64, 87, 195, 54, 21 };
            byte[] encryptKey = Encoding.UTF8.GetBytes(key.Substring(0, 8));
            var des = new DESCryptoServiceProvider();
            byte[] inputByte = Encoding.UTF8.GetBytes(plainText);
            var mStream = new MemoryStream();
            var cStream = new CryptoStream(mStream, des.CreateEncryptor(encryptKey, iv), CryptoStreamMode.Write);
            cStream.Write(inputByte, 0, inputByte.Length);
            cStream.FlushFinalBlock();
            return Convert.ToBase64String(mStream.ToArray());
        }
    }
}
