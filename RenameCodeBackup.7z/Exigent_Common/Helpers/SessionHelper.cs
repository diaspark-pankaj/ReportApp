﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azmbl.Common.Helpers
{
    public class SessionHelper
    {
        public LoggedUserInfo LoggedUserInfo { get; set; }

        public SessionHelper()
        {
            LoggedUserInfo = new LoggedUserInfo();
        }
    }

    public class LoggedUserInfo
    {
        public int UserId { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Email { get; set; }

        public string EmployeeId { get; set; }

        public string OrganizationName { get; set; }
    }
}
