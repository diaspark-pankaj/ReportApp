﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.Common.Helpers
{
    public static class ImageHelper
    {
        private static readonly int MaxiSizeOfAnyDimensionOfThumbnailImage = Convert.ToInt32(ConfigurationManager.AppSettings["MaxiSizeOfAnyDimensionOfThumbnailLogoImage"]);
        private static readonly int LogoHeight = Convert.ToInt32(ConfigurationManager.AppSettings["LogoHeight"]);
        private static readonly int LogoWidth = Convert.ToInt32(ConfigurationManager.AppSettings["LogoWidth"]);
        private static readonly int BrandWidth = Convert.ToInt32(ConfigurationManager.AppSettings["BrandWidth"]);

        public static Size GetThumbnailSize(System.Drawing.Image original, int ExpectedHeight , int ExpectedWidth)
        {
            // Maximum size of any dimension.
            int maxPixels = MaxiSizeOfAnyDimensionOfThumbnailImage;

            // Width and height.
            int originalWidth = original.Width;
            int originalHeight = original.Height;

            // Compute best factor to scale entire image based on larger dimension.
            //double factor;
            //if (originalWidth > originalHeight)
            //{
            //    factor = (double)maxPixels / originalWidth;
            //}
            //else
            //{
            //    factor = (double)maxPixels / originalHeight;
            //}

            //// Return thumbnail size.
            //return new Size((int)(originalWidth * factor), (int)(originalHeight * factor));
       
            return new Size(ExpectedWidth ,ExpectedHeight);
        }

        public static Stream ToStream(this Image image, ImageFormat formaw)
        {
            var stream = new MemoryStream();
            image.Save(stream, formaw);
            stream.Position = 0;
            return stream;
        }

        public static string ReplaceLastOccurrence(string source, string find, string replace)
        {
            int place = source.LastIndexOf(find, StringComparison.Ordinal);
            string result = source.Remove(place, find.Length).Insert(place, replace);
            return result;
        }

        public static Stream GetThumbnailStream(Stream fileData)
        {
            //Save Thumbnail
            // Load image
            Image image = Image.FromStream(fileData, true);

            // Compute thumbnail size
            Size thumbnailSize = GetThumbnailSize(image, LogoHeight, LogoWidth);

            // Get thumbnail
            Image thumbnail = image.GetThumbnailImage(thumbnailSize.Width, thumbnailSize.Height, null, IntPtr.Zero);

            image.Dispose();

            // return for save
            return thumbnail.ToStream(ImageFormat.Jpeg);
        }

        public static Stream GetThumbnailStream(string fileName , string imgName)
        {
            //Save Thumbnail
            // Load image
            Image image = Image.FromFile(fileName, true);
            Size thumbnailSize= new Size() ;
            if (imgName.ToUpper() == "LOGO.PNG")
            {
               if (ResizeImage(imgName, image.Height, image.Width))
                {
                   thumbnailSize = GetThumbnailSize(image, LogoHeight, LogoWidth);
                }
               else
                {
                    thumbnailSize.Width = image.Width;
                    thumbnailSize.Height = image.Height;
                }
            }
            else
            {
                if (ResizeImage(imgName, image.Height, image.Width))
                {
                    thumbnailSize = GetThumbnailSize(image, BrandWidth, BrandWidth);

               }
                else {
                    thumbnailSize.Width = image.Width;
                   thumbnailSize.Height = image.Height;
                }
            }
            // Compute thumbnail size
           

            // Get thumbnail
         Image thumbnail = image.GetThumbnailImage(thumbnailSize.Width, thumbnailSize.Height, null, IntPtr.Zero);

            image.Dispose();

            // return for save
            return thumbnail.ToStream(ImageFormat.Png);
        }

        public static bool ResizeImage(string imgName ,int height ,int width)
        {
            bool Isresize = true;
            if (imgName.ToUpper() == "LOGO.PNG")
            {
                if(height <= LogoHeight && width <= LogoWidth)
                {
                    Isresize = false;
                }
                else {
                    Isresize = true;
                }
            }
            else if (imgName.ToLower().Contains("ico-brand"))
            {
                if (height <= BrandWidth && width <= BrandWidth)
                {
                    Isresize = false;
                }
                else
                {
                    Isresize = true;
                }
            }
            return Isresize;
        }

       
    }
}