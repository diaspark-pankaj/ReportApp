﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HtmlAgilityPack;
using Exigent.Common.Constants;
using System.Reflection;
using System.Collections;

namespace Exigent.Common.Helpers
{
    public static class KeywordReplacementHelper
    {
        #region Keyword Replacement Logic

        private static string GetBetween(string strSource, string strStart, string strEnd)
        {
            if (strSource.Contains(strStart) && strSource.Contains(strEnd))
            {
                int start = strSource.IndexOf(strStart, 0, StringComparison.Ordinal) + strStart.Length;
                int end = strSource.IndexOf(strEnd, start, StringComparison.Ordinal);
                return strSource.Substring(start, end - start);
            }
            return "";
        }

        private static object GetValueByPropertyName<T>(string propertyName, T expectedObject)
        {
            Type t = expectedObject.GetType();
            object val;

            if (propertyName.Contains("[")) //object is of list type
            {
                int listObjectIndex = Convert.ToInt32(GetBetween(propertyName, "[", "]"));
                var listObjectName = propertyName.Split('[')[0];

                PropertyInfo propertyInfo = t.GetProperty(listObjectName);
                val = ((IList)propertyInfo.GetValue(expectedObject))[listObjectIndex];
            }
            else
            {
                PropertyInfo propertyInfo = t.GetProperty(propertyName);
                val = propertyInfo.GetValue(expectedObject);
            }

            return val;
        }

        private static object GetValueByPropertyName<T>(string propertyName, T expectedObject, out bool isReplace, int KeyWordType = 1)
        {
            Type t = expectedObject.GetType();
            object val = null;
            isReplace = false;
            if (propertyName.Contains(AppConstants.KeywordSplitterStart)) //object is of list type
            {
                int listObjectIndex = Convert.ToInt32(GetBetween(propertyName, AppConstants.KeywordSplitterStart, AppConstants.KeywordSplitterEnd));
                var listObjectName = propertyName.Split(AppConstants.KeywordSplitterStart.ToArray())[0];

                PropertyInfo propertyInfo = t.GetProperty(listObjectName);
                if (propertyInfo != null)
                {
                    val = ((IList)propertyInfo.GetValue(expectedObject))[listObjectIndex];
                    isReplace = true;
                }
            }
            else
            {


                PropertyInfo propertyInfo = t.GetProperty(propertyName.ToUpper(), BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);

                if (propertyInfo != null)
                {
                    val = propertyInfo.GetValue(expectedObject);
                    //GET FIRST LIST OBJECT WITHOUT LOOP
                    if (val != null && (propertyInfo.PropertyType.FullName.Contains("ICollection") || propertyInfo.PropertyType.FullName.Contains("IList") || propertyInfo.PropertyType.FullName.Contains("List")) && KeyWordType == 1)
                    {
                        object collectionObject = val;
                        if (collectionObject != null)
                        {
                            IEnumerable<object> listObject = ((IEnumerable<object>)collectionObject).ToList();
                            val = listObject.FirstOrDefault();
                        }
                    }
                    isReplace = true;
                }
                else
                {
                    if (t.FullName.Contains("List") && KeyWordType == 3)
                    {
                        var listObject = ((IEnumerable<object>)expectedObject).ToList();
                        if (listObject != null)
                        {
                            for (var count = 0; count < listObject.Count; count++)
                            {
                                Type objType = listObject[count].GetType();
                                PropertyInfo propInfo = objType.GetProperty(propertyName.ToUpper(), BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);
                                if (propInfo != null)
                                {
                                    var value = propInfo.GetValue(listObject[count]);
                                    val = val != null ? val + ", " + value.ToString() : value.ToString();
                                }
                                isReplace = true;
                            }
                        }

                    }
                }
            }

            return val;
        }

        private static object GetValueByObjectAccessStr<T>(string objectAccessKey, IEnumerable<KeywordViewModel> keywordViewModelList, T expectedObject)
        {
            string objectAccessStr = string.Empty;
            int keywordType = 1;
            bool isListProperty = objectAccessKey.Contains("List.");
            if (objectAccessKey != null)
                objectAccessKey = objectAccessKey.Trim();

            if (!isListProperty)
            {
                KeywordViewModel keywordViewModel = keywordViewModelList.FirstOrDefault(g => g.Name == objectAccessKey);

                if (keywordViewModel != null)
                {
                    objectAccessStr = keywordViewModel.Value;
                    keywordType = Convert.ToInt32(keywordViewModel.Type);
                }
            }
            else
            {
                objectAccessStr = objectAccessKey;
            }

            int initiatingValue = isListProperty ? 1 : 0;
            var sVals = objectAccessStr.Split('.').ToList();
            object lastObject = null;
            bool isReplace = false;
            for (int i = initiatingValue; i < sVals.Count; i++)
            {
                try
                {
                    lastObject = GetValueByPropertyName(sVals[i], lastObject ?? expectedObject, out isReplace, keywordType);
                }
                catch
                {

                    return string.Empty;
                }

                if (i == (sVals.Count - 1))
                {

                    if (isReplace)
                    {
                        return lastObject;
                    }
                    else
                    {
                        if (string.IsNullOrEmpty(objectAccessStr))
                        {
                            return objectAccessKey;
                        }
                        else
                        {
                            return string.Empty;
                        }
                    }
                }
            }

            return null;
        }

        private static string ReplaceKeyword<T>(string htmlStr, IEnumerable<KeywordViewModel> keywordViewModelList, T scalarObject)
        {
            List<string> output = htmlStr.Split(new[] { AppConstants.KeywordSplitterStart }, StringSplitOptions.RemoveEmptyEntries).Select(d =>
            {
                string[] ucSplits = d.Split(new[] { AppConstants.KeywordSplitterEnd }, StringSplitOptions.None);

                if (ucSplits.Length == 1) //html
                {
                    return d;
                }
                if (ucSplits.Length == 2) //widget
                {
                    object keywordValue = null;
                    keywordValue = GetValueByObjectAccessStr(ucSplits[0], keywordViewModelList, scalarObject);


                    return Convert.ToString(keywordValue) + ucSplits[1];
                }
                return d;
            }).ToList();

            return String.Join("", output.Select(a => String.Join("", a)));
        }

        public static string ReplaceConditionalTagKeyword<T>(string htmlStr, List<KeywordViewModel> keywordViewModelList, T expectedObject)
        {
            try
            {
                HtmlDocument doc = new HtmlDocument();
                if (!string.IsNullOrEmpty(htmlStr))
                    doc.LoadHtml(htmlStr);
                else
                    return string.Empty;

                IEnumerable<HtmlNode> htmlNodeList = doc.DocumentNode.Descendants("pcs:flowcontrol");

                foreach (HtmlNode htmlNode in htmlNodeList.ToList())
                {
                    //Get attribute list
                    HtmlAttributeCollection htmlAttributeList = htmlNode.Attributes;
                    Dictionary<string, string> attrDictionary = htmlAttributeList.ToDictionary(ha => ha.Name, ha => ha.Value);

                    string source = GetBetween(attrDictionary["source"], AppConstants.KeywordSplitterStart, AppConstants.KeywordSplitterEnd);
                    string flowType = attrDictionary["flow_type"];

                    switch (flowType)
                    {
                        case "IF":
                            {
                                string compareType = attrDictionary["compare_type"];
                                string compareWith = attrDictionary["compare_with"];
                                string compareWithValue = string.Empty;
                                string sourceValue = string.Empty;

                                switch (compareType)
                                {
                                    case "VALUE":
                                        {
                                            compareWithValue = compareWith;
                                            sourceValue = Convert.ToString(GetValueByObjectAccessStr(source, keywordViewModelList, expectedObject));
                                            break;
                                        }
                                    case "KEYWORD":
                                        {
                                            //Get compareWith value
                                            compareWith = GetBetween(compareWith, AppConstants.KeywordSplitterStart, AppConstants.KeywordSplitterEnd);
                                            compareWithValue = Convert.ToString(GetValueByObjectAccessStr(compareWith, keywordViewModelList, expectedObject));
                                            sourceValue = Convert.ToString(GetValueByObjectAccessStr(source, keywordViewModelList, expectedObject));
                                            break;
                                        }
                                }


                                HtmlNode innerHtmlNode = HtmlNode.CreateNode("<span>"); //Span is used to initiate node
                                if (sourceValue.ToUpper() == compareWithValue.ToUpper())
                                {
                                    var tempHtml = ForInnerCondition(htmlNode.InnerHtml, expectedObject, keywordViewModelList);

                                    string innerHtml = tempHtml.Contains(AppConstants.KeywordSplitterStart) && tempHtml.Contains(AppConstants.KeywordSplitterEnd)
                                                        ? ReplaceKeyword(tempHtml, keywordViewModelList, expectedObject)
                                                        : tempHtml;
                                    innerHtmlNode.InnerHtml = innerHtml;

                                }
                                else if ("NOTNULL" == compareWithValue.ToUpper())
                                {
                                    if (!string.IsNullOrEmpty(sourceValue) && !sourceValue.Contains(AppConstants.KeywordSplitterEnd))
                                    {
                                        var tempHtml = ForInnerCondition(htmlNode.InnerHtml, expectedObject, keywordViewModelList);

                                        string innerHtml = tempHtml.Contains(AppConstants.KeywordSplitterStart) && tempHtml.Contains(AppConstants.KeywordSplitterEnd)
                                                       ? ReplaceKeyword(tempHtml, keywordViewModelList, expectedObject)
                                                       : tempHtml;
                                        innerHtmlNode.InnerHtml = innerHtml;

                                    }
                                    else
                                    { innerHtmlNode = HtmlNode.CreateNode(string.Empty); }
                                }
                                else if ("NULL" == compareWithValue.ToUpper())
                                {
                                    if (string.IsNullOrEmpty(sourceValue) && !sourceValue.Contains(AppConstants.KeywordSplitterEnd))
                                    {
                                        var tempHtml = ForInnerCondition(htmlNode.InnerHtml, expectedObject, keywordViewModelList);

                                        string innerHtml = tempHtml.Contains(AppConstants.KeywordSplitterStart) && tempHtml.Contains(AppConstants.KeywordSplitterEnd)
                                                       ? ReplaceKeyword(tempHtml, keywordViewModelList, expectedObject)
                                                       : tempHtml;
                                        innerHtmlNode.InnerHtml = innerHtml;

                                    }
                                    else
                                    { innerHtmlNode = HtmlNode.CreateNode(string.Empty); }
                                }
                                else if ("NOTZERO" == compareWithValue.ToUpper())
                                {
                                    decimal result = 0;
                                    if (decimal.TryParse(sourceValue, out result))
                                    {
                                        if (result != 0)
                                        {

                                            var tempHtml = ForInnerCondition(htmlNode.InnerHtml, expectedObject, keywordViewModelList);

                                            string innerHtml = tempHtml.Contains(AppConstants.KeywordSplitterStart) && tempHtml.Contains(AppConstants.KeywordSplitterEnd)
                                                            ? ReplaceKeyword(tempHtml, keywordViewModelList, expectedObject)
                                                            : tempHtml;


                                            innerHtmlNode.InnerHtml = innerHtml;
                                        }
                                    }
                                    else
                                    { innerHtmlNode = HtmlNode.CreateNode(string.Empty); }
                                }
                                else
                                {
                                    innerHtmlNode = HtmlNode.CreateNode(string.Empty);
                                }
                                if (htmlNode.ParentNode != null)
                                {
                                    htmlNode.ParentNode.ReplaceChild(innerHtmlNode, htmlNode);
                                }
                                break;
                            }
                        case "LOOP":
                            {
                                object collectionObject = GetValueByObjectAccessStr(source, keywordViewModelList, expectedObject);

                                if (collectionObject is IEnumerable<object>)
                                {
                                    IEnumerable<object> listObject = ((IEnumerable<object>)collectionObject).ToList();

                                    HtmlNode innerHtmlNode = HtmlNode.CreateNode("<span>"); //Span is used to initiate node

                                    //Create Html Node
                                    HtmlNode tempHtmlNode = htmlNode;

                                    listObject.ForEach(o =>
                                    {
                                        #region For Inner Condition

                                        string tempHtml = ForInnerCondition(tempHtmlNode.InnerHtml, o, keywordViewModelList);

                                        #endregion


                                        innerHtmlNode.InnerHtml += tempHtml.Contains(AppConstants.KeywordSplitterStart) && tempHtml.Contains(AppConstants.KeywordSplitterEnd)
                                                                ? ReplaceKeyword(tempHtml, keywordViewModelList, o)
                                                                : tempHtml;
                                    });

                                    if (htmlNode.ParentNode != null)
                                    {
                                        htmlNode.ParentNode.ReplaceChild(innerHtmlNode, htmlNode);
                                    }

                                }
                                else
                                {
                                    HtmlNode innerHtmlNode = HtmlNode.CreateNode("<span>");
                                    if (htmlNode.ParentNode != null)
                                    {
                                        htmlNode.ParentNode.ReplaceChild(innerHtmlNode, htmlNode);
                                    }
                                }
                                break;
                            }
                    }
                }

                //Replace non-conditional Keywords
                string replacedHtmlStr = ReplaceKeyword(doc.DocumentNode.OuterHtml, keywordViewModelList, expectedObject);



                return replacedHtmlStr;
            }
            catch (Exception ex)
            {
                return htmlStr;
            }
        }

        private static string ForInnerCondition<T>(string htmlStr, T expectedObject, List<KeywordViewModel> keywordViewModelList)
        {
            HtmlDocument doc = new HtmlDocument();
            if (!string.IsNullOrEmpty(htmlStr))
                doc.LoadHtml(htmlStr);
            else
                return string.Empty;


            IEnumerable<HtmlNode> htmlNodeList = doc.DocumentNode.Descendants("pcd:flowcontrol");

            foreach (HtmlNode htmlNode in htmlNodeList.ToList())
            {
                //Get attribute list
                HtmlAttributeCollection htmlAttributeList = htmlNode.Attributes;
                Dictionary<string, string> attrDictionary = htmlAttributeList.ToDictionary(ha => ha.Name, ha => ha.Value);

                string source = GetBetween(attrDictionary["source"], AppConstants.KeywordSplitterStart, AppConstants.KeywordSplitterEnd);
                string flowType = attrDictionary["flow_type"];

                switch (flowType)
                {
                    case "IF":
                        {
                            string compareType = attrDictionary["compare_type"];
                            string compareWith = attrDictionary["compare_with"];
                            string compareWithValue = string.Empty;
                            string sourceValue = string.Empty;

                            switch (compareType)
                            {
                                case "VALUE":
                                    {
                                        compareWithValue = compareWith;
                                        sourceValue = Convert.ToString(GetValueByObjectAccessStr(source, keywordViewModelList, expectedObject));
                                        break;
                                    }
                                case "KEYWORD":
                                    {
                                        //Get compareWith value
                                        compareWith = GetBetween(compareWith, AppConstants.KeywordSplitterStart, AppConstants.KeywordSplitterEnd);
                                        compareWithValue = Convert.ToString(GetValueByObjectAccessStr(compareWith, keywordViewModelList, expectedObject));
                                        sourceValue = Convert.ToString(GetValueByObjectAccessStr(source, keywordViewModelList, expectedObject));

                                        break;
                                    }
                            }


                            HtmlNode innerHtmlNode = HtmlNode.CreateNode("<span>"); //Span is used to initiate node
                            if (sourceValue.ToUpper() == compareWithValue.ToUpper())
                            {

                                var tempHtml = ForInnerCondition(htmlNode.InnerHtml, expectedObject, keywordViewModelList);

                                string innerHtml = tempHtml.Contains(AppConstants.KeywordSplitterStart) && tempHtml.Contains(AppConstants.KeywordSplitterEnd)
                                                    ? ReplaceKeyword(tempHtml, keywordViewModelList, expectedObject)
                                                    : tempHtml;
                                innerHtmlNode.InnerHtml = innerHtml;

                            }
                            else if ("NOTNULL" == compareWithValue.ToUpper())
                            {
                                if (!string.IsNullOrEmpty(sourceValue) && !sourceValue.Contains(AppConstants.KeywordSplitterStart))
                                {
                                    var tempHtml = ForInnerCondition(htmlNode.InnerHtml, expectedObject, keywordViewModelList);

                                    string innerHtml = tempHtml.Contains(AppConstants.KeywordSplitterStart) && tempHtml.Contains(AppConstants.KeywordSplitterEnd)
                                                   ? ReplaceKeyword(tempHtml, keywordViewModelList, expectedObject)
                                                   : tempHtml;
                                    innerHtmlNode.InnerHtml = innerHtml;
                                }
                                else
                                { innerHtmlNode = HtmlNode.CreateNode(string.Empty); }
                            }
                            else if ("NULL" == compareWithValue.ToUpper())
                            {
                                if (string.IsNullOrEmpty(sourceValue) && !sourceValue.Contains(AppConstants.KeywordSplitterStart))
                                {
                                    var tempHtml = ForInnerCondition(htmlNode.InnerHtml, expectedObject, keywordViewModelList);

                                    string innerHtml = tempHtml.Contains(AppConstants.KeywordSplitterStart) && tempHtml.Contains(AppConstants.KeywordSplitterEnd)
                                                   ? ReplaceKeyword(tempHtml, keywordViewModelList, expectedObject)
                                                   : tempHtml;
                                    innerHtmlNode.InnerHtml = innerHtml;
                                }
                                else
                                { innerHtmlNode = HtmlNode.CreateNode(string.Empty); }
                            }
                            else if ("NOTZERO" == compareWithValue.ToUpper())
                            {
                                decimal result = 0;
                                if (decimal.TryParse(sourceValue, out result))
                                {
                                    if (result != 0)
                                    {
                                        var tempHtml = ForInnerCondition(htmlNode.InnerHtml, expectedObject, keywordViewModelList);

                                        string innerHtml = tempHtml.Contains(AppConstants.KeywordSplitterStart) && tempHtml.Contains(AppConstants.KeywordSplitterEnd)
                                                        ? ReplaceKeyword(tempHtml, keywordViewModelList, expectedObject)
                                                        : tempHtml;

                                        innerHtmlNode.InnerHtml = innerHtml;
                                    }
                                }
                                else
                                { innerHtmlNode = HtmlNode.CreateNode(string.Empty); }
                            }
                            else
                            {
                                innerHtmlNode = HtmlNode.CreateNode(string.Empty);
                            }
                            if (htmlNode.ParentNode != null)
                            {
                                htmlNode.ParentNode.ReplaceChild(innerHtmlNode, htmlNode);
                            }
                            break;
                        }
                }
            }

            return doc.DocumentNode.OuterHtml;
        }


        #endregion
    }
    public class KeywordViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public int ObjectId { get; set; }
        public byte Type { get; set; }
        public bool IsActive { get; set; }
    }
}
