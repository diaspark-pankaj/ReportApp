﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Exigent.Common.Enums;

namespace Exigent.Common.Helpers
{
    public static class ConceptHelper
    {
        public static ConceptType GetConceptTypeByConceptId(string conceptId)
        {
            var count = conceptId.Count();

            switch(count)
            {
                case 7:
                    return ConceptType.Company;
                case 9:
                    return ConceptType.Brand;
                case 10:
                    return ConceptType.Concept;
                default:
                    return ConceptType.None;
            }
        }
    }
}
