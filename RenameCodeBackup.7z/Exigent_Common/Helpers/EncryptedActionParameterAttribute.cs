﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//using System.Data.Entity;
//using System.Data.Entity.Infrastructure;
using System.Threading;
using System.Web.Mvc;
//using WebMatrix.WebData;
//using IgnouBuddy.Models;
using System.Security.Cryptography;
using System.IO;
using System.Text.RegularExpressions;
namespace Exigent.Common.Helpers
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class EncryptedActionParameterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {


            int Id;

            Dictionary<string, object> decryptedParameters = new Dictionary<string, object>();
            if (HttpContext.Current.Request.QueryString.Get("q") != null)
            {
                string encryptedQueryString = HttpContext.Current.Request.QueryString.Get("q");
                string decrptedString = Decrypt(encryptedQueryString.ToString());
                string[] paramsArrs = decrptedString.Split('?');

                for (int i = 0; i < paramsArrs.Length; i++)
                {
                    string[] paramArr = paramsArrs[i].Split('=');
                    //Commented on 19Jan2017decryptedParameters.Add(paramArr[0], Convert.ToInt32(paramArr[1]));
                    decryptedParameters.Add(paramArr[0],paramArr[1]);//Added on 19Jan2017
                }
            }
            else if (!HttpContext.Current.Request.Url.ToString().Contains("?"))
            {
                //if (int.TryParse(Decrypt(HttpContext.Current.Request.Url.ToString().Split('/').Last()), out Id))
                if (int.TryParse(Decrypt(HttpContext.Current.Request.Url.ToString().Split('/').Last()), out Id))
                {
                    string id = Id.ToString();
                    decryptedParameters.Add("id", id);
                }
            }
            else if (HttpContext.Current.Request.Url.ToString().Contains("?"))
            {
                //if (int.TryParse(Decrypt(HttpContext.Current.Request.Url.ToString().Split('/').Last().Split('?')[0]), out Id))
                if (int.TryParse(Decrypt(HttpContext.Current.Request.Url.ToString().Split('/').Last().Split('?')[0]), out Id))
                {
                    string id = Id.ToString();
                    if (id.Contains('?'))
                    {
                        id = id.Split('?')[0];
                    }
                    decryptedParameters.Add("id", id);
                }

                string[] paramsArrs = HttpContext.Current.Request.Url.ToString().Split('/').Last().Split('?');
                for (int i = 1; i < paramsArrs.Length; i++)
                {
                    
                    string[] paramArr = paramsArrs[i].Split('=');

                    if (paramArr.Length == 2)
                    {
                        decryptedParameters.Add(paramArr[0], Convert.ToInt32(paramArr[1]));
                    }
                    else if (paramArr.Length > 2)
                    {
                        string secVal = paramArr[1];
                        if (!secVal.Contains("&"))
                        {
                            decryptedParameters.Add(paramArr[0], Convert.ToInt32(paramArr[1]));
                        }
                        else if (secVal.Contains("&"))
                        {

                        }
                    }
                }
            }

            for (int i = 0; i < decryptedParameters.Count; i++)
            {
                filterContext.ActionParameters[decryptedParameters.Keys.ElementAt(i)] = decryptedParameters.Values.ElementAt(i);
            }
            base.OnActionExecuting(filterContext);


        }

        private string Decrypt(string encryptedText)
        {  
           // bool res = isAlphaNumeric(encryptedText);
            bool res = isNumeric(encryptedText);
       
            if (!res)
            {
                if ((encryptedText != "AddAsset") && (encryptedText != "OutletDetails") && (encryptedText != "AddAssetFromLink"))
                {
                    string key = "jdsg432387#";
                    byte[] DecryptKey = { };
                    byte[] IV = { 55, 34, 87, 64, 87, 195, 54, 21 };
                    byte[] inputByte = new byte[encryptedText.Length];

                    DecryptKey = System.Text.Encoding.UTF8.GetBytes(key.Substring(0, 8));
                    DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                    string altercipherText = encryptedText.Replace(" ", "+");
                   // string altercipherText = encryptedText.Replace("+", " ");
                    inputByte = Convert.FromBase64String(altercipherText);
                    MemoryStream ms = new MemoryStream();
                    CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(DecryptKey, IV), CryptoStreamMode.Write);
                    cs.Write(inputByte, 0, inputByte.Length);
                    cs.FlushFinalBlock();
                    System.Text.Encoding encoding = System.Text.Encoding.UTF8;
                    return encoding.GetString(ms.ToArray());
                }
                else
                {
                    return encryptedText;

                }
            }
            else
            {
                return encryptedText;

            }
           
        }

        public Boolean isAlphaNumeric(string strToCheck)
        {
            if (!string.IsNullOrEmpty(strToCheck))
            {
                Regex rg = new Regex(@"^[a-zA-Z0-9\s,]*$");
                return rg.IsMatch(strToCheck);
            }
            else
            {
                return true;
            }
        }

         public Boolean isNumeric(string strToCheck)
        {
            if (!string.IsNullOrEmpty(strToCheck))
            {
                Regex rg = new Regex(@"^[0-9]*$");
                return rg.IsMatch(strToCheck);
            }
            else
            {
                return true;
            }
        }



        
    }
}