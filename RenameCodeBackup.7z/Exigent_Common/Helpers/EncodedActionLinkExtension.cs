﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using System.Web.Routing;
using System.Security.Cryptography;
using System.IO;


namespace Exigent.Common.Helpers
{
    public static class EncodedActionLinkExtension
    {
       


        public static MvcHtmlString EncodedActionLink(this HtmlHelper htmlHelper, string linkText, string Action, string ControllerName, string Area, object routeValues, object htmlAttributes)
        {
            string queryString = string.Empty;
            string htmlAttributesString = string.Empty;
            //My Changes
            bool IsRoute = false;
            if (routeValues != null)
            {
                RouteValueDictionary d = new RouteValueDictionary(routeValues);
                for (int i = 0; i < d.Keys.Count; i++)
                {
                    //My Changes
                    if (!d.Keys.Contains("IsRoute"))
                    {
                        if (i > 0)
                        {
                            queryString += "?";
                        }
                        queryString += d.Keys.ElementAt(i) + "=" + d.Values.ElementAt(i);
                    }
                    else
                    {
                        //My Changes
                        if (!d.Keys.ElementAt(i).Contains("IsRoute"))
                        {
                            queryString += d.Values.ElementAt(i);
                            IsRoute = true;
                        }
                    }
                }
            }

            if (htmlAttributes != null)
            {
                RouteValueDictionary d = new RouteValueDictionary(htmlAttributes);
                for (int i = 0; i < d.Keys.Count; i++)
                {
                   //Commented on 18Jan2017 htmlAttributesString += " " + d.Keys.ElementAt(i) + "=" + d.Values.ElementAt(i);  

                    htmlAttributesString += " " + d.Keys.ElementAt(i) + @"=""" + d.Values.ElementAt(i) + @"""";
                }
            }


            StringBuilder ancor = new StringBuilder();
            ancor.Append("<a ");
            if (htmlAttributesString != string.Empty)
            {
                ancor.Append(htmlAttributesString);
            }
            ancor.Append(" href='");
            if (Area != string.Empty)
            {
                ancor.Append("/" + Area);
            }

            if (ControllerName != string.Empty)
            {
                ancor.Append("/" + ControllerName);
            }

            if (Action != "Index")
            {
                ancor.Append("/" + Action);
            }
            //My Changes
            if (queryString != string.Empty)
            {
                if (IsRoute == false)
                    ancor.Append("?q=" + Encrypt(queryString));
                else
                    ancor.Append("/" + Encrypt(queryString));
            }
            ancor.Append("'");
            ancor.Append(">");
            ancor.Append(linkText);
            ancor.Append("</a>");
            return new MvcHtmlString(ancor.ToString());
        }


        // Extension method
        //public static MvcHtmlString ActionImage(this HtmlHelper html, string action, object routeValues, string imagePath, string alt ,string cls)
        //{
        //    var url = new UrlHelper(html.ViewContext.RequestContext);

        //    // build the <img> tag
        //    var imgBuilder = new TagBuilder("img");
        //    imgBuilder.MergeAttribute("src", url.Content(imagePath));
        //    imgBuilder.MergeAttribute("alt", alt);
        //    imgBuilder.MergeAttribute("class", cls);//Added by amb
        //    string imgHtml = imgBuilder.ToString(TagRenderMode.SelfClosing);

        //    // build the <a> tag
        //    var anchorBuilder = new TagBuilder("a");
        //    anchorBuilder.MergeAttribute("href", url.Action(action, routeValues));
        //    anchorBuilder.InnerHtml = imgHtml; // include the <img> tag inside
        //    string anchorHtml = anchorBuilder.ToString(TagRenderMode.Normal);

        //    return MvcHtmlString.Create(anchorHtml);
        //}



      //  this HtmlHelper htmlHelper, string linkText, string Action, string ControllerName, string Area, object routeValues, object htmlAttributes)
        public static MvcHtmlString ActionImage(this HtmlHelper html, string linkText, string Action, string ControllerName, string Area, object routeValues, string imagePath, string alt, string cls)
        {
            var url = new UrlHelper(html.ViewContext.RequestContext);

            // build the <img> tag
            var imgBuilder = new TagBuilder("img");
            imgBuilder.MergeAttribute("src", url.Content(imagePath));
            imgBuilder.MergeAttribute("alt", alt);
            imgBuilder.MergeAttribute("title", alt);
            imgBuilder.MergeAttribute("class", cls);//Added by amb
            string imgHtml = imgBuilder.ToString(TagRenderMode.SelfClosing);


          
            var anchorBuilder = new TagBuilder("a");


            StringBuilder ancor = new StringBuilder();


            string queryString = string.Empty;
            string htmlAttributesString = string.Empty;
            //My Changes
            bool IsRoute = false;
            if (routeValues != null)
            {
                RouteValueDictionary d = new RouteValueDictionary(routeValues);
                for (int i = 0; i < d.Keys.Count; i++)
                {
                    //My Changes
                    if (!d.Keys.Contains("IsRoute"))
                    {
                        if (i > 0)
                        {
                            queryString += "?";
                        }
                        queryString += d.Keys.ElementAt(i) + "=" + d.Values.ElementAt(i);
                    }
                    else
                    {
                        //My Changes
                        if (!d.Keys.ElementAt(i).Contains("IsRoute"))
                        {
                            queryString += d.Values.ElementAt(i);
                            IsRoute = true;
                        }
                    }
                }
            }



            if (Area != string.Empty)
            {
                ancor.Append("/" + Area);
            }

            if (ControllerName != string.Empty)
            {
                ancor.Append("/" + ControllerName);
            }

            if (Action != "Index")
            {
                ancor.Append("/" + Action);
            }
            //My Changes
            if (queryString != string.Empty)
            {
                if (IsRoute == false)
                    ancor.Append("?q=" + Encrypt(queryString));
                else
                    ancor.Append("/" + Encrypt(queryString));
            }






            anchorBuilder.MergeAttribute("href", ancor.ToString());
            //anchorBuilder.MergeAttribute("href", url.Action(action, routeValues));
            anchorBuilder.InnerHtml = imgHtml; // include the <img> tag inside
            string anchorHtml = anchorBuilder.ToString(TagRenderMode.Normal);

            return MvcHtmlString.Create(anchorHtml);
        }


       // private static string Encrypt(string plainText)
        public static string Encrypt(string plainText)
        {
            string key = "jdsg432387#";
            byte[] EncryptKey = { };
            byte[] IV = { 55, 34, 87, 64, 87, 195, 54, 21 };
            EncryptKey = System.Text.Encoding.UTF8.GetBytes(key.Substring(0, 8));
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            byte[] inputByte = Encoding.UTF8.GetBytes(plainText);
            MemoryStream mStream = new MemoryStream();
            CryptoStream cStream = new CryptoStream(mStream, des.CreateEncryptor(EncryptKey, IV), CryptoStreamMode.Write);
            cStream.Write(inputByte, 0, inputByte.Length);
            cStream.FlushFinalBlock();
           // return Convert.ToBase64String(mStream.ToArray());

            string res = Convert.ToBase64String(mStream.ToArray());
           // res = res.Replace(" ", "+"); //Added on 24Jan2017
            return res;
        }
    }
}