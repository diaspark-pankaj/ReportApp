﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Security;

namespace Exigent.Common.Helpers
{
    public class CloudServiceHelper
    {
        public static void SetBasicAuthHeader(WebRequest req, HttpCookie authcookie)
        {
            //HttpCookie authcookie = HttpContext.Current.Request.Cookies[FormsAuthentication.FormsCookieName];

            if (authcookie != null)
            {
                string ticket = authcookie.Value;
                req.Headers.Add("authticket", ticket);
            }
            else if (HttpContext.Current.Request.Headers.Count > 0 && HttpContext.Current.Request.Headers["authticket"] != null)
            {
                req.Headers.Add("authticket", HttpContext.Current.Request.Headers["authticket"].ToString());
            }
            authcookie = null;
        }
    }
}
