﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.Common.Helpers
{
    public static class NullableTypeHelper
    {
        public static T? ToNullable<T>(this string inputString) where T : struct
        {
            var result = new T?();
           // bool xyz;
            if (!string.IsNullOrEmpty(inputString) && inputString.Trim().Length > 0)
            {
                TypeConverter conv = TypeDescriptor.GetConverter(typeof (T));
                var convertFrom = conv.ConvertFrom(inputString);
                if (convertFrom != null) result = (T) convertFrom;
            }

            return result;
        }
    }
}
