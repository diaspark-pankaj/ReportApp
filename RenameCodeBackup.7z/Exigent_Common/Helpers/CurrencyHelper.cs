﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.Common.Helpers
{
    public class CurrencyHelper
    {

        public static string ConvertCurrency(decimal? amount, string fromCurrency, string toCurrency)
        {
            string api_Url = ConfigurationManager.AppSettings["CurrencyConverterApiUrl"];//live
            string access_Key = ConfigurationManager.AppSettings["CurrencyConverterApiAccessKey"];//79aa8fb110842f70331b4d0240281365
            //string requestUrl = "http://www.apilayer.net/api/live?access_key=79aa8fb110842f70331b4d0240281365";//http://apilayer.net/api/convert?access_key=YOUR_ACCESS_KEY&from=USD&to=GBP&amount=10
            string requestUrl = api_Url + "access_key=" + access_Key + "&from=" + fromCurrency + "&to=" + toCurrency + "&amount=" + amount;
            string statusCode = string.Empty;
            string responseData = string.Empty;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(requestUrl);
            request.Headers.Add("ContentType", "application/json");
            request.Method = "POST";
            request.Timeout = 99000000;
            using (StreamWriter requestWriter = new StreamWriter(request.GetRequestStream()))
            {
                requestWriter.Write(requestUrl);
            }

            HttpWebResponse httpWResp = (HttpWebResponse)request.GetResponse();

            statusCode = httpWResp.StatusCode.ToString();
            using (StreamReader responseReader = new StreamReader(request.GetResponse().GetResponseStream()))
            {
                if (!string.IsNullOrEmpty(statusCode) && statusCode.ToLower().Contains("ok"))
                {
                    return responseReader.ReadToEnd();
                }
            }
            return responseData;
        }
    }
}
