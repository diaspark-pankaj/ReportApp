﻿using System.Security.Cryptography;
using System.Text;

namespace Exigent.Common.Helpers
{
    public static class EncryptionHelper
    {
        /// <summary>
        /// EncodetoSHA1String.
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public static string EncodetoSHA1String(string message)
        {
            if (string.IsNullOrEmpty(message))
                return string.Empty;
            SHA1 sha = new SHA1Managed();
            ASCIIEncoding ae = new ASCIIEncoding();
            byte[] data = ae.GetBytes(message);
            byte[] digest = sha.ComputeHash(data);
            return GetAsString(digest);
            //return message;
        }

        private static string GetAsString(byte[] bytes)
        {
            StringBuilder s = new StringBuilder();
            int length = bytes.Length;
            for (int n = 0; n < length; n++)
            {
                s.Append((int)bytes[n]);
                if (n != length - 1) { s.Append(' '); }
            }
            return s.ToString();
        }
    }
}
