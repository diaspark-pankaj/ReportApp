﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Exigent.Common.Helpers
{
    public class RegularExpressionHelper
    {
        public static bool VerifyRegEx(string testPattern)
        {
            bool isValid = true;
            if ((testPattern != null) && (testPattern.Trim().Length > 0))
            {
                try
                {
                    Match match = Regex.Match("", testPattern);
                }
                catch (ArgumentException)
                {
                    // BAD PATTERN: Syntax error
                    isValid = false;
                }
            }
            else
            {
                //BAD PATTERN: Pattern is null or blank
                isValid = false;
            }
            return (isValid);
        }
    }
}
