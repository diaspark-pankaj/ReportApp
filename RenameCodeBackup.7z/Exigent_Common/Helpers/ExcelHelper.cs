﻿using ClosedXML.Excel;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using Excel = Microsoft.Office.Interop.Excel;

namespace Exigent.Common.Helpers
{
    public class ExcelHelper
    {
        public static void ConvertDataTableToExcel(string filePathName, DataTable dt)
        {
            if (dt != null)
            {
                if (dt.Rows.Count > 0)
                {
                    Excel.Application excelApp = new Excel.Application();
                    excelApp.Application.Workbooks.Add(Type.Missing);
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        excelApp.Cells[1, j + 1] = dt.Columns[j].ColumnName;
                    }

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        for (int j = 0; j < dt.Columns.Count; j++)
                        {
                            excelApp.Cells[i + 2, j + 1] = dt.Rows[i][j].ToString();
                        }
                    }
                    // save excel file 
                    excelApp.ActiveWorkbook.ActiveSheet.Columns.Autofit();
                    excelApp.ActiveWorkbook.SaveAs(filePathName);
                    excelApp.ActiveWorkbook.Saved = true;
                    excelApp.ActiveWorkbook.Close();
                    excelApp.Quit();
                }
            }
        }

        /// <summary>
        /// To generate Identifier as per passed pre-stored max identifier value.
        /// Not used currently. Previously we were using it.
        /// </summary>
        /// <param name="Identi"></param>
        /// <returns></returns>
        public static string GenerateCID(string Identi)
        {
            if (!string.IsNullOrEmpty(Identi))
            {
                int number = -1;
                bool converted = false;
                converted = Int32.TryParse(Identi.Substring(Identi.Length - 1, 1), out number);
                if (converted && number >= 0)
                {
                    string last = Identi.Length > 1 ? Identi.Substring(Identi.Length - 1, 1) : string.Empty;
                    if (last == "9")
                    {
                        last = "a";
                    }
                    else
                    {
                        last = (int.Parse(last) + 1).ToString();
                    }
                    Identi = Identi.Substring(0, Identi.Length - 1) + last;
                }
                else
                {
                    char letter = Convert.ToChar(Identi.Substring(Identi.Length - 1, 1));
                    char nextChar;
                    string currentChar = "";
                    if (letter == 'z')
                    {
                        currentChar = "z";
                        nextChar = '0';
                    }
                    else if (letter == 'Z')
                    {
                        currentChar = "Z";
                        nextChar = '0';
                    }
                    else
                        nextChar = (char)(((int)letter) + 1);

                    Identi = Identi.Substring(0, Identi.Length - 1) + currentChar + nextChar;
                }

                return Identi;
            }

            return string.Empty;
        }

        /// <summary>
        /// To get uniquly char-num combination value. It would be unique in lacs of records.
        /// We can use this if customer wants unique char-num combination of characters and not want integer incremental value.
        /// </summary>
        /// <returns></returns>
        public static string GenerateUniqueKey()
        {
              int maxSize  = 8 ;
              //int minSize = 5 ;
              char[] chars = new char[62];
              string a;
              a = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
              chars = a.ToCharArray();
              int size  = maxSize ;
              byte[] data = new byte[1];
              RNGCryptoServiceProvider  crypto = new RNGCryptoServiceProvider();
              crypto.GetNonZeroBytes(data) ;
              size =  maxSize ;
              data = new byte[size];
              crypto.GetNonZeroBytes(data);
              StringBuilder result = new StringBuilder(size) ;
              foreach(byte b in data )
              { 
                  result.Append(chars[b % (chars.Length)]); 
              }
            return result.ToString();
        }

        /// <summary>
        /// To get next identifier (replica of PK) incremental value
        /// Using currently, as discussed.
        /// </summary>
        /// <param name="preIdentifier"></param>
        /// <returns></returns>
        public static int GetNextIdentifer(int preIdentifier)
        {
            int Identifier = 0;
            Identifier = (preIdentifier + 1);
            return Identifier;
        }

        public static void GenerateFile(DataTable dt, string sheetName, string fileName)
        {
            using (XLWorkbook wb = new XLWorkbook())
            {
                wb.Worksheets.Add(dt, sheetName);
                HttpContext.Current.Response.Clear();
                HttpContext.Current.Response.Buffer = true;
                HttpContext.Current.Response.Charset = "";
                HttpContext.Current.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                HttpContext.Current.Response.AddHeader("content-disposition", "attachment;filename=" + fileName);
                using (MemoryStream MyMemoryStream = new MemoryStream())
                {
                    wb.SaveAs(MyMemoryStream);
                    MyMemoryStream.WriteTo(HttpContext.Current.Response.OutputStream);
                    HttpContext.Current.Response.Flush();
                    HttpContext.Current.Response.End();
                }
            }
        }
    }
}
