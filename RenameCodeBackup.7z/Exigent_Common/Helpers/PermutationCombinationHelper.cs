﻿using System;
using System.Collections.Generic;

namespace Exigent.Common.Helpers
{
    public class PermutationCombinationHelper
    {
        public static IEnumerable<IEnumerable<T>> Combinations<T>(IEnumerable<IEnumerable<T>> input)
        {
            IEnumerable<IEnumerable<T>> result = new T[0][];
            foreach (IEnumerable<T> item in input)
                result = Combine(result, Combination(item));
            return result;
        }

        private static IEnumerable<IEnumerable<T>> Combination<T>(IEnumerable<T> input)
        {
            foreach (T item in input)
                yield return new T[] { item };
        }

        public static IEnumerable<IEnumerable<T>> Combine<T>(IEnumerable<IEnumerable<T>> a, IEnumerable<IEnumerable<T>> b)
        {
            Boolean found = false;
            foreach (IEnumerable<T> groupa in a)
            {
                found = true;
                foreach (IEnumerable<T> groupB in b)
                    yield return Append(groupa, groupB);
            }
            if (!found)
                foreach (IEnumerable<T> groupB in b)
                    yield return groupB;
        }

        // add the new item at the beginning of the collection
        public static IEnumerable<T> Append<T>(IEnumerable<T> a, IEnumerable<T> b)
        {
            //yield return a;
            foreach (T item in a) yield return item;
            foreach (T item in b) yield return item;
        }

        /// <summary>
        /// create permutation on basis of same collection items.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        public static IEnumerable<KeyValuePair<object, object>> CreateDistinctGroups<T>(IEnumerable<T> group)
        {
            List<KeyValuePair<object, object>> DistinctGroupCollection = new List<KeyValuePair<object, object>>();
            foreach (T item1 in group)
            {
                foreach (T item2 in group)
                {
                    if (!item1.Equals(item2) && !DistinctGroupCollection.Exists(x => x.Key.Equals(item1) && x.Value.Equals(item2)) && !DistinctGroupCollection.Exists(y => y.Key.Equals(item2) && y.Value.Equals(item1)))
                    {
                        DistinctGroupCollection.Add(new KeyValuePair<object, object>(item1, item2));
                    }
                }
            }
            return DistinctGroupCollection;
        }
    }
}
