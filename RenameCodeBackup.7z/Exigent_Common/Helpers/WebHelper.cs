﻿
using System;
using System.Configuration;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;

namespace Exigent.Common.Helpers
{
    public class WebHelper
    {
        private static HttpWebRequest _webRequest;

        public static void CopyBlobImage(string sourcePath, string destiPath)
        {
            string url = ConfigurationManager.AppSettings["AzureStorageServiceCopyUrl"] + "srcDirPath=" + sourcePath + "&dstnDirPath=" + destiPath;

            try
            {

                var getRequest = (HttpWebRequest)WebRequest.Create(url);
                getRequest.Method = FormMethod.Get.ToString();

                var getResponse = (HttpWebResponse)getRequest.GetResponse();
            }
            catch (Exception ex)
            {
            }
        }

        public static void AsyncCopyBlobImage(string sourcePath, string destiPath, string fileName, Action<IAsyncResult, HttpWebRequest, string, string, HttpCookie> onCompleteWebRequestMethodAddress, HttpCookie httpCookie)
        {
            string url = ConfigurationManager.AppSettings["AzureStorageServiceCopyUrl"] + "srcDirPath=" + sourcePath + "&dstnDirPath=" + destiPath;

            _webRequest = (HttpWebRequest)WebRequest.Create(url);
            _webRequest.Method = FormMethod.Get.ToString();
            _webRequest.BeginGetResponse(r => onCompleteWebRequestMethodAddress(r, _webRequest, sourcePath, fileName, httpCookie), null);
        }

        public static void AsyncDeleteBlobImage(string filePath, string fileName, Action<IAsyncResult, HttpWebRequest> onCompleteWebRequestMethodAddress, HttpCookie httpCookie)
        {
            string url = System.Web.Configuration.WebConfigurationManager.AppSettings["AzureStorageServiceBaseUrl"] + "?filePath=" + filePath + "" + "&fileName=" + fileName;

            _webRequest = (HttpWebRequest)WebRequest.Create(url);
            _webRequest.Method = "DELETE";
            // add authorization header to request header..
            CloudServiceHelper.SetBasicAuthHeader(_webRequest, httpCookie);
            _webRequest.BeginGetResponse(r => onCompleteWebRequestMethodAddress(r, _webRequest), null);
        }
    }
}