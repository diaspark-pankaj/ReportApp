﻿using System;

namespace Exigent.Common.Enums
{
    [Flags]
    public enum DaysOfWeek
    {
        //None = 0x0,
        Monday = 0x1,
        Tuesday =0x2,
        Wednesday = 0x4,
        Thursday = 0x8,
        Friday = 0x10,
        Saturday = 0x20,
        Sunday = 0x40,
        //Weekends = Saturday | Sunday,
        //Weekdays = Monday | Tuesday | Wednesday | Thursday | Friday,
        //MonThruThur = Monday | Tuesday | Wednesday | Thursday,
        //Everyday = Monday | Tuesday | Wednesday | Thursday | Friday | Saturday | Sunday
    }
}
