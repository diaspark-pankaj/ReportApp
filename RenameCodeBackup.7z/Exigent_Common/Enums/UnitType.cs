﻿using System;
using System.ComponentModel;

namespace Exigent.Common.Enums
{
    public enum UnitType
    {
        None = 0,

        PlanningUnit = 1,

        RealEstateUnit = 2
    }
}