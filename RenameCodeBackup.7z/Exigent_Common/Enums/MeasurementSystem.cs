﻿
namespace Azmbl.Common.Enums
{
    public enum MeasurementSystem
    {
        NotSet = 0,
        Metric = 1,
        StandardUS = 2,
        ImperialUK = 3,
        International = 4
    }
}