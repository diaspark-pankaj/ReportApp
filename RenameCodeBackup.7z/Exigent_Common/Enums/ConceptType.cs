﻿using System;
using System.ComponentModel;

namespace Azmbl.Common.Enums
{
    public enum ConceptType
    {
        None = 0,

        Company = 1,

        Brand = 2,

        Concept = 3,

        Variant = 4
    }
}
