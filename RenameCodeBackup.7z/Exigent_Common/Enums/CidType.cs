﻿using System;
using System.ComponentModel;

namespace Azmbl.Common.Enums
{
    public enum CidType
    {
        [Description("None")]
        None = 0,

        [Description("Entity")]
        Entity = 1,

        [Description("Brand")]
        Brand = 2,

        [Description("Company")]
        Company = 3,

        [Description("Concept")]
        Concept = 4,

        [Description("Concept Variant")]
        ConceptVariant = 5,

        [Description("Market")]
        Market = 6,

        [Description("Market Variant")]
        MarketVariant = 7
    }
}
