﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Azmbl.Common.Enums
{
    public enum Electricalenum
    {
        [Description("1 Phase")]
        OnePhase=1,
        [Description("3 Phase")]
        ThreePhase=3,
    }
}
