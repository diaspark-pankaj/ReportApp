﻿
namespace Azmbl.Common.Enums
{
    public enum RFIStatus
    {
        OPEN = 1,
        CLOSE = 2
    }
}
