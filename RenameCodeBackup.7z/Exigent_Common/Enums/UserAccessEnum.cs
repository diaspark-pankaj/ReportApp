﻿using System.ComponentModel;

namespace Exigent.Common.Enums
{
     public enum UserAccessEnum
    {
        [Description("Accounts Dashboard")]
        AccountsDashboard = 201,
        [Description("Admin Dashboard")]
        AdminDashboard = 202,
        [Description("Business Unit Dashboard")]
        BusinessUnitDashboard = 203,
        [Description("Main Dashboard")]
        MainDashboard = 204,
        [Description("Payment Processing Dashboard")]
        PaymentProcessingDashboard = 205,
        [Description("HOD Dashboard")]
        HODDashboard = 206,
        [Description("Home")]
        VendorDashboard=207,
    }

    public enum UserTypes
    {
        //[Description("Exigent Admin")]
        //ExigentAdmin = 101,
        [Description("Service Provider Admin")]
        ServiceProviderAdmin = 101,
       
        //[Description("HOD")]
        //HOD = 103,
        //[Description("Lead Lawyer")]
        //LeadLawyer = 104,
        [Description("Legal Professional Staff")]
        LegalProfessionalStaff = 102,
        //[Description("GSS")]
        //LegalAdminStaff = 105,
        //[Description("Reporting Admin User")]
        //ReportingAdminUser = 106,
        //[Description("AccountUser")]
        //AccountUser = 107,
        [Description("Legal Admin Staff")]
        LegalAdminStaff = 103,
        //[Description("Business Unit User")]
        //BusinessUnitUser = 108,
        [Description("Authorised Business Staff")]
        AuthorisedBusinessStaff = 104,

        [Description("Special Group Legal")]
        SpecialGroupLegal = 105,

        [Description("Group Legal User")]
        GroupLegalSuper = 106,

        [Description("Senior Legal Leadership Staff")]
        SeniorLegalLeadershipStaff = 107,

        //[Description("Discipline Lead")]
        //DisciplineLead = 109,
    
     
    }

    public enum PortalTypes
    {
        //[Description("Vendor Portal")]
        //Vendor = 301,
        [Description("Legal Matter Management")]
        MatterManagement = 302
    }

    public enum InvoiceStatus {
        [Description("Active")]
        Active=401,
        [Description("Credited")]
        Credited=402,
        [Description("Rejected")]
        Rejected=403,
        [Description("No ELF Instruction")]
        NoELFInstruction=404,
        [Description("Awaiting Approval")]
        AwaitingApproval=405,
        [Description("Sent For Payment")]
        SentForPayment=406,
        [Description("Paid")]
        Paid=407,
        [Description("Pending Audit")]
        PendingAudit=408,
        [Description("Awaiting GRV")]
        AwaitingGRV=409,
        [Description("Awaiting GRV – PO Amendment")]
        AwaitingGRVPOAmendment=410,
        [Description("Awaiting GRV – Other")]
        AwaitingGRVOther=411,
        [Description("Ready for Payment")]
        ReadyforPayment=412,
        [Description("Sent for Payment")]
        SentforPayment=413,
        [Description("Approved")]
        Approved = 414,
        [Description("GRV Complete")]
        GRVComplete = 415,
    }

    public enum InstructionStatus
    {
        [Description("Active")]
        Active=501,
        [Description("Pending Review")]
        PendingReview=502,
        [Description("Pending Contacts")]
        PendingContacts=503,
        [Description("PendingPO")]
        PendingPO=504,
        [Description("Pending PO Increase")]
        PendingPOIncrease=505,
        [Description("Pending PO Amendment")]
        PendingPOAmendment=506,
        [Description("PO Increase Requested")]
        POIncreaseRequested=507,
        [Description("PO Increase Required")]
        POIncreaseRequired=508,
        [Description("Pending Approval")]
        PendingApproval = 509,
        [Description("Approved")]
        Approved = 510,
        [Description("Rejected")]
        Rejected = 511,
    }
    public enum MatterStatus {
        [Description("Active")]
        Active=601,
        [Description("Closed")]
        Closed=602,
        [Description("Dormant")]
        Dormant=603,
        [Description("Open For Billing")]
        OpenForBilling=604
    }
    public enum InvoiceType
    {
        [Description("Final Invoice")]
        FinalInvoice = 1
    }

    public enum InvoiceAudit
    {
        [Description("Rejected")]
        Rejected = 1,
        [Description("Approved")]
        Approved = 2
    }
}
