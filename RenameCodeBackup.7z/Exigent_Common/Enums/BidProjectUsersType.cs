﻿using System.ComponentModel;

namespace Azmbl.Common.Enums
{
    public enum BidProjectUsersType
    {
        [Description("Project Manager")]
        ProjectManager = 1,
        [Description("Associates Manager")]
        AssociatesManager = 2,
        [Description("Principal")]
        Principal = 3,
        [Description("Construction Manager")]
        ConstructionManager = 4,
        [Description("Client")]
        Client = 5,
        [Description("Architect Manager")]
        ArchitectManager = 6,
        [Description("AoR Manager")]
        AoRManager = 7,
    }
}
