﻿using System;

namespace Azmbl.Common.Enums
{

    [FlagsAttribute]
    public enum Meals
    {
        None = 0x0,
        Lunch =0x1,
        Dinner = 0x2,
        Breakfast = 0x3,
        LateNight = 0X4
    }
}
