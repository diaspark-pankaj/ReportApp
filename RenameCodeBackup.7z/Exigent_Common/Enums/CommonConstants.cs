﻿
namespace Exigent.Common.Enums
{
    public class CommonConstantsEnum
    {
        public const string RFIResponseURL = "/Bid/RFI/EditRFI?q=";
        public const string QSParameterEditRFIID = "rfiId";
        public const string FunctionalAreaImagePath = "~/Images/FunctionalDeptImages";
        public const string MessageConstant = "MessageConstant";
        public const string DefaultCalendarCountry = "DefaultCalendarCountry";
        public const string FuncionalAreaImageBlobPath = "FunctionalArea/{0}/Image/";
        public const string Admin = "Admin";
        public const string AMCDefaultTemplateID = "AMCDefaultTemplateID";
        public const string AMCEquipmentTypeID = "AMCEquipmentTypeID";
    }
}
