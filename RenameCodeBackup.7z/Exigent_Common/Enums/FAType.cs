﻿
namespace Azmbl.Common.Enums
{
    public enum FAType
    {
        NA = 0,
        Global = 1,
        Brand = 2,
        Client = 3
    }
}
