﻿using System.ComponentModel;

namespace Exigent.Common.Enums
{
    public enum ButtonType
    {
        [Description("None")]
        None = 0,

        [Description("Save")]
        Save = 1,

        [Description("Save Another")]
        SaveAnother = 2,

        [Description("Cancel")]
        Cancel = 3,

        [Description("Submit for Approval")]
        SubmitforApproval = 4,

        [Description("Save & Clone")]
        SaveClone = 5
    }
}