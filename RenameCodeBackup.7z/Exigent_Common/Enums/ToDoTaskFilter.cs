﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azmbl.Common.Enums
{
   public enum ToDoTaskPeriod
    {
       All=0,
       Today = 1,
       ThisWeek = 2,
       ThisMonth = 3

    }

   public enum TaskType
   {
       All = 0,
       ToDo = 1,
       ProjectTask = 2
   }
}
