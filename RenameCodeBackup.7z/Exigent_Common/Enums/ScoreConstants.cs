﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azmbl.Common.Enums
{
   public class ScoreConstants
    {

       public const string XPathUtilities = "ScoringMethod/Utilities/Fields/Field";
        public const string XPathSite = "ScoringMethod/Site/Fields/Field";
        public const string XPathSiteInline = "ScoringMethod/SiteInline/Fields/Field";
        public const string XPathStructure = "ScoringMethod/Structure/Fields/Field";
        public const string XPathDemolition = "ScoringMethod/Demolition/Fields/Field";
        public const string XPathSafetyAndSecurity = "ScoringMethod/SafetyAndSecurity/Fields/Field";
        public const string XPathSignage = "ScoringMethod/Signage/Fields/Field";
        public const string XPathCompressor = "ScoringMethod/Compressor/Fields/Field";
        public const string XPathDoorExterior = "ScoringMethod/DoorExterior/Fields/Field";
    }
}
