﻿
namespace Exigent.Common.Enums
{
    public class ChangesRealEstateField
    {

        public const string Score = "score";

        //For Unit Field
        public const string UnitUnittype = "unit_unittype";
        public const string UnitStateprovince = "unit_stateprovince";
        public const string UnitPsatargete = "unit_psatargete";
        public const string UnitProjectType = "unit_projecttype";
        public const string UnitIsNew = "unit_IsNew";
        public const string UnitIsGreenField = "unit_IsGreenField";
      
        //For Utility Fields
        public const string MepSewer = "mep_sewer";
        public const string MepSeptic = "mep_septic";
        public const string MepSepticCapacity = "mep_septiccapacity";
        public const string AddressState = "address_state";
        public const string ElectricPanelSize = "ElectricPanelSize";
        public const string MepKwRating = "mep_kwrating";
        public const string MepWaterHeaterSubType = "mep_waterheatersubType";
        public const string MepPanelSizeUnitChange = "mep_panelsizeunitchange";
        public const string MepElectricalPanelRating = "mep_electricalPanelrating";
        public const string MepMeasureVolumelableChange = "mep_measurevolumelablechange";
        public const string MEPHotwatercapacity = "mep_hotwatercapacity";
        public const string MEPWaterPanelSize = "mep_waterpanelsize";
        public const string MepPotable = "mep_potable";
        public const string MepSumpPump = "mep_sumppump";
        public const string MepEjectorPump = "mep_ejectorpump";
        public const string MepGasSettings = "mep_gassetting";
        public const string MepElectricPanelRatingText = "mep_electricpanelratingtext";
        public const string KfcCompareUnitInfo = "KFCCompare_UnitInfo";
        public const string SiteParkingOccupiedArea = "site_parkingoccupiedarea";
        public const string SignageExistingRemove = "signage_existing_remove";
        public const string IsNotes = "utitlity_note";
        public const string MepCapacityobcondition = "mep_capacityobcondition";
        public const string MepGreaseobcondition = "mep_greaseobcondition";
        public const string MepGreaseaval = "mep_greaseaval";
        public const string MepEquipmentventilation = "mep_equipmentventilation";
        public const string MepExhaustshaft = "mep_exhaustshaft";
        public const string MepSupplyairshaft = "mep_supplyairshaft";
        public const string MepExistingfan = "mep_existingfan";
        public const string MepFanrating = "mep_fanrating";
        public const string MepEquipobcondition = "mep_equipobcondition";

        //Compressor
        public const string LabelCompressorTitle = "LabelCompressorTitle";

        //For structure Fields
        public const string StructureAreaRentable = "structure_arearentable";
        public const string StructureWidthCurtainWall = "structure_widthcurtainwall";
        public const string StructureWidthNarroWest = "structure_widthnarrowest";
        public const string StructureFloore = "structure_floore";
        public const string StructureHeightStructure = "structure_heightstructure";
        public const string StructureRoof = "structure_roof";
        public const string StructureInteriorWidth = "structure_interiorwidth";
        public const string StructureDepth = "structure_depth";
        public const string StructureUnitType = "structure_unittype";
        public const string StructureCurtainWallWidth = "structure_curtainwallwidth";
        public const string StructureInteriorPartition = "structure_interiorpartition";
        public const string StructureOutdoor = "structure_outdoor";

        //For site Fileds
        public const string SiteParkingCapacity = "site_parkingcapacity";
        public const string site = "site";

        //For sitegreenfield Fileds
        public const string SiteGreenField = "sitegreenfield";
        public const string UnitSiteGreenField = "unit_Site";
        //For siteinline Fileds
        public const string SiteInline = "siteinline";
        public const string SiteParkingSpace = "site_ParkingSpace";
        public const string SiteDistanceFromEntrance = "site_DistanceFromEntrance";
        public const string SiteReceiveDirectToStore = "site_ReceiveDirectToStore";
        public const string SiteCommon = "site_Common";
        public const string SiteCNumberOfTruckBays = "site_CNumberOfTruckBays";
        public const string SiteHoursOfOperationStartTime = "site_HoursOfOperationStartTime";
        public const string SiteHoursOfOperationEndTime = "site_HoursOfOperationEndTime";
        public const string SiteReceivingStorage = "site_ReceivingStorage";
        public const string SiteArea = "site_Area";
        public const string SiteSecured = "site_Secured";
        public const string SiteReceivingAgent = "site_ReceivingAgent";
        public const string SiteDedicated = "site_Dedicated";
        public const string SiteDNumberOfTruckBays = "site_DNumberOfTruckBays";
        public const string SiteempDedicatedArea = "site_TempDedicatedArea";


        //For sitestandalone Fileds
        public const string SiteStandalone = "sitestandalone";


        public const string CompressorFloor = "compressor_floor";
        public const string CompressorPossibleUnits = "compressor_possibleunits";
        public const string CompressorExisting = "compressor_Existing";
        public const string CompressorHeaightFromSlab = "compressor_heaightfromslab";

        public const string VentilationVentilationType = "ventilation_ventilationType";
        public const string VentilationVentToRoof = "ventilation_VentToRoof";

        public const string AddressPostalCode = "AddressPostalCode";

        // Add New Constant for Planning Module
        public const string PcSquareArea = "PlanningCriteria_SquareArea";
        public const string PcBudget = "PlanningCriteria_Budget";
        public const string PcRealEstate = "PlanningCriteria_RealEstate";
        public const string PcSquareAreaBudget = "PlanningCriteria_SquareAreaBudget";
        public const string ExampleProjectName = "ExampleProjectName";
        public const string ExampleProjectDescription = "ExampleProjectDescription";

        //Catacity Screen
        public const string CapacityPageInfoText = "CapacityPageInfoText";
        public const string PeekHourText = "PeekHourText";
        public const string PeekHourSubText = "PeekHourSubText";
        public const string DailyPeeksText = "DailyPeeksText";
        public const string DailyPeeksSubText = "DailyPeeksSubText";
        public const string DeliveryDaysText = "DeliveryDaysText";
        public const string DeliveryDaysSubText = "DeliveryDaysSubText";
        public const string StartProjectDescription = "StartProjectDescription";
        public const string ChoosePresetText = "ChoosePresetText";
        public const string ChoosePresetSubText = "ChoosePresetSubText";
        public const string StartScratchText = "StartScratchText";

        //RE Review
        public const string ExistingCookingVentilationKey = "ExistingCookingVentilation";
        public const string CookingSiteAdapterKey = "CookingSiteAdapter";
        public const string BeginPlanKey = "BeginPlan";

        //Rule Management - Functional Area
        public const string FAQuntityRequiredUnder35 = "FAQuntityRequiredUnder35";
        public const string FAQuntityRequired3555 = "FAQuntityRequired3555";
        public const string FAQuntityRequired5565 = "FAQuntityRequired5565";
        public const string FAQuntityRequiredAbove65 = "FAQuntityRequiredAbove65";

        // Scoring
        public const string MEPScoringGas = "mep_scoring_gas";
        public const string MEPScoringGasSource = "mep_scoring_gassource";
        public const string StuScoringSlabToStrucure = "structure_scoring_slabtostructure";
        public const string StuScoringInderiorDepth = "structure_scoring_Interiordepth";
        public const string StuScoringStoreFrontWidth = "structure_scoring_storefrontwidth";
        public const string DemolitionScoExteriorGround = "demolition_scoring_exteriorground";
        public const string DemolitionScoWindows = "demolition_scoring_windows";
        public const string DemolitionScoSignage = "demolition_scoring_signage";
        public const string ScoreSite = "score_site";
        public const string CompressorCount = "score_Compressor";
        public const string CompareScoreCompressor = "Compare_score_Compressor";
        public const string CompareScoreSignage = "Compare_score_Signage";
        public const string CompareScoreExteriordoor = "Compare_score_Exteriordoor";

        //Property
        public const string Property_ArchitectofRecord = "property_architectofrecord";
        public const string Property_Adjacenttalents = "property_adjacenttalents";
    }
}
