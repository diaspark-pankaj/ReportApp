﻿
using System.ComponentModel;
namespace Exigent.Common.Enums
{
    public enum EmailCategoryEnum
    {
        [Description("CreateMatter")]
        CreateMatter = 1,
        [Description("ForgotPassword")]
        ForgotPassword = 4,
        [Description("InvoicePayment")]
        InvoicePayment = 6,
        [Description("InstructionToVendor")]
        InstructionToVendor = 5,
        [Description("UserRegistration")]
        UserRegistration = 7,
        [Description("InvoiceReject")]
        InvoiceReject = 8,
        [Description("InvoiceApprove")]
        InvoiceApprove = 9,
        [Description("PendingContact_GRV_Yes")]
        NewContact_PendingContacts = 10,
        [Description("NewInstruction_GRV_NO")]
        NewInstruction_GRV_NO = 11,
        [Description("Pending_Contacts_Reassign")]  //TODO: Ashish P. (Pending Implementation)
        Pending_Contacts_Reassign = 12,
        [Description("SendInstruction_Approval_DisciplineLead")]
        SendInstruction_Approval_DisciplineLead = 13,
        [Description("InstructionRejected")]
        InstructionRejected = 14,
        [Description("NewGrv")]
        NewGrv = 15,
        [Description("NewPOTask")]
        NewPOTask = 16,
        [Description("NewPO_NewPOTask_POContact")]
        NewPO_NewPOTask_POContact = 17,
        NewTimeSheetTask = 18,
        InvoiceSubmission = 19,
        CreditNoteSubmission = 20,
        [Description("IncreasePOStart")]
        IncreasePOStart = 21,
        RFQApproval = 22,
        RFQRejected = 23,
        RFQApproved = 24,
        TwoFactorAuthentication = 25,
        [Description("ReportableMatter_SentForUpdate")]
        ReportableMatter_SentForUpdate = 27,
        [Description("ReportableMatter_SentForApproval")]
        ReportableMatter_SentForApproval = 28,
        SendPOIncrease = 29,
        [Description("Reminder_InstructionApproval")]
        Reminder_InstructionApproval = 30,
        InvoiceAuditTask = 31,
        ReminderInvoiceApproval = 32,
        ReminderInvoiceAudit = 33,
        [Description("Reminder_NewGrv")]
        Reminder_NewGrv = 34,
        [Description("Reminder_NewPOTask")]
        Reminder_NewPOTask = 35,
        AmendPOTask = 36,
        [Description("AttorneyFeeIncreaseNotification")]
        AttorneyFeeIncreaseNotification = 37,
        NotifyLLOnPO = 39,
    }

    public enum KeywordObjectTypeEnum
    {
        [Description("Matter")]
        Matter = 1,
        [Description("Instruction")]
        Instruction = 2,
        [Description("ForgotPassword")]
        ForgotPassword = 3,
        [Description("InvoicePayment")]
        InvoicePayment = 4,
        [Description("InstructionToVendor")]
        InstructionToVendor = 5,
        [Description("UserRegistration")]
        UserRegistration = 6,
        [Description("InvoiceReject")]
        InvoiceReject = 7,
        [Description("InvoiceApprove")]
        InvoiceApprove = 8,
        [Description("NewInstruction_GRV_NO")]
        NewInstruction_GRV_NO = 9,
        [Description("PendingContact_GRV_Yes")]
        NewContact_PendingContacts = 10,
        [Description("Pending_Contacts_Reassign")]
        Pending_Contacts_Reassign = 12,
        [Description("SendInstruction_Approval_DisciplineLead")]
        SendInstruction_Approval_DisciplineLead = 13,
        [Description("InstructionRejected")]
        InstructionRejected = 14,
        [Description("NewGrv")]
        NewGrv = 15,
        [Description("NewPOTask")]
        NewPOTask = 16,
        [Description("NewPO_NewPOTask_POContact")]
        NewPO_NewPOTask_POContact = 17,
        NewTimeSheetTask = 19,
        InvoiceSubmission = 20,
        CreditNoteSubmission = 21,
        [Description("IncreasePOStart")]
        IncreasePOStart = 22,
        RFQApproval = 23,
        RFQRejected = 24,
        RFQApproved = 25,
        TwoFactorAuthentication = 26,
        [Description("ReportableMatter_SentForUpdate")]
        ReportableMatter_SentForUpdate = 27,
        [Description("ReportableMatter_SentForApproval")]
        ReportableMatter_SentForApproval = 28,
        SendPOIncrease = 29,
        [Description("Reminder_InstructionApproval")]
        Reminder_InstructionApproval = 30,
        InvoiceAuditTask = 31,
        ReminderInvoiceApproval = 32,
        ReminderInvoiceAudit = 33,
        [Description("Reminder_NewGrv")]
        Reminder_NewGrv = 34,
        [Description("Reminder_NewPOTask")]
        Reminder_NewPOTask = 35,
        AmendPOTask = 36,
        [Description("AttorneyFeeIncreaseNotification")]
        AttorneyFeeIncreaseNotification = 37,
        NotifyLLOnPO = 39,
    }

    public enum InvoiceButtonType
    {
        Approve = 1,
        Reject = 2,
        Reassign = 3
    }
    public enum InvoiceApproval
    {
        Rejected = 1,
        Approved = 2,
    }
    public enum RFQApprovalEnum
    {
        Rejected = 2,
        Approved = 1,
        Reassign = 3
    }
    public enum BUApprovalEnum
    {
        MainDashboard = 2,
        BUDashboard = 1,
        Instruction = 3
    }
    public enum MatterDescType
    {
        MatterDescription = 2,
        Context = 1,
        NatureIdentified = 3,
        RecommendedSteps = 4,
        ImpactGroup = 5,
        ProceduralStage = 6,
        ClientAction = 7
    }
}
