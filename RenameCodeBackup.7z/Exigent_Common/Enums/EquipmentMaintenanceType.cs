﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azmbl.Common.Enums
{
  public enum  EquipmentMaintenanceType
    {

       Warranty=4,
       Cleaning=1,
       TroubleShooting=5,
       DIY=2,
       Preventative=3 
    }
}
