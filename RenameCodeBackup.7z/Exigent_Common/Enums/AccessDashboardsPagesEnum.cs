﻿using System.ComponentModel;

namespace Exigent.Common.Enums
{
    public enum AccessDashboardsPagesEnum
    {
        [Description("Main Dashboard")]
        MainDashboard = 1,
        [Description("Inactive Matters")]
        InactiveMatters =2,
        [Description("Reports")]
        Reports = 3,
        [Description("HOD Dashboard")]
        HODDashboard = 4,
        [Description("Admin Dashboard")]
        AdminDashboard = 5,
        [Description("Reportable Matters")]
        ReportableMatters = 18,
        [Description("Invoices")]
        Invoices = 7,
        [Description("Instructions")]
        Instructions = 8,
        [Description("Timesheets")]
        Timesheets = 9,
        [Description("Business Unit Dashboard")]
        BusinessUnitDashboardIsDropdown = 11,
        [Description("Vendor Dashboard")]
        VendorDashboard = 12,
        [Description("Submit Invoice")]
        SubmitInvoice = 13,
        [Description("Submit Credit Note")]
        SubmitCreditNote = 14,
        [Description("User Management")]
        UserManagement = 15,
        [Description("Role Management")]
        RoleManagementIsDropdown = 16,
        [Description("Manage Login Page")]
        ManageLoginPageIsDropdown = 19,
        [Description("Manage Masters")]
        ManageMastersIsDropdown = 20,
    }
}
