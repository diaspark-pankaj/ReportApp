﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.Common.Enums
{
    public enum FileStoragePermissonEnum
    {
        [Description("None")]
        None = 0,

        [Description("RW")]
        RW = 1,

        [Description("R")]
        R = 2

       
    }
}
