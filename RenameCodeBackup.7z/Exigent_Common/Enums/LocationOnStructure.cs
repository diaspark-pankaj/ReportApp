﻿namespace Azmbl.Common.Enums
{
    public enum LocationOnStructure
    {
        Front = 0,
        Back = 1,
        Left = 2,
        Right = 3,
        Ceiling = 4,
        Floor = 5,
        Other = 6
    }
}