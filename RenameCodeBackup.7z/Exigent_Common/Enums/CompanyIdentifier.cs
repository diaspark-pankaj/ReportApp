﻿using System.ComponentModel;

namespace Exigent.Common.Enums
{
    public enum CompanyIdentifier
    {
        [Description("Franchisee")]
        F = 0,

        [Description("Manufacurer")]
        E = 1,

        [Description("Supplier")]
        S = 2,

        [Description("Vendor")]
        V = 3,

        [Description("Client")]
        C = 4,

        [Description("Internal")]
        _ = 5,

        [Description("General Contractor")]
        GC = 6
    }
}