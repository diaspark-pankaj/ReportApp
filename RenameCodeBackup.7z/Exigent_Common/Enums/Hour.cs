﻿using System;
using System.ComponentModel;

namespace Exigent.Common.Enums
{
    [Flags]
    public enum Hour
    {
        //[Description("None")]
        //None = 0x0,

        [Description("01:00")]
        Hr0100 = 1,

        [Description("02:00")]
        Hr0200 = 1 << 1,

        [Description("03:00")]
        Hr0300 = 1 << 2,

        [Description("04:00")]
        Hr0400 = 1 << 3,

        [Description("05:00")]
        Hr0500 = 1 << 4,

        [Description("06:00")]
        Hr0600 = 1 << 5,

        [Description("07:00")]
        Hr0700 = 1 << 6,

        [Description("08:00")]
        Hr0800 = 1 << 7,

        [Description("09:00")]
        Hr0900 = 1 << 8,

        [Description("10:00")]
        Hr1000 = 1 << 9,

        [Description("11:00")]
        Hr1100 = 1 << 10,

        [Description("12:00")]
        Hr1200 = 1 << 11,

        [Description("13:00")]
        Hr1300 = 1 << 12,

        [Description("14:00")]
        Hr1400 = 1 << 13,

        [Description("15:00")]
        Hr1500 = 1 << 14,

        [Description("16:00")]
        Hr1600 = 1 << 15,

        [Description("17:00")]
        Hr1700 = 1 << 16,

        [Description("18:00")]
        Hr1800 = 1 << 17,

        [Description("19:00")]
        Hr1900 = 1 << 18,

        [Description("20:00")]
        Hr2000 = 1 << 19,

        [Description("21:00")]
        Hr2100 = 1 << 20,

        [Description("22:00")]
        Hr2200 = 1 << 21,

        [Description("23:00")]
        Hr2300 = 1 << 22,

        [Description("00:00")]
        Hr2400 = 1 << 23
    }
}
