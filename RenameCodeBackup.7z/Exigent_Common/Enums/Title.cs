﻿
namespace Exigent.Common.Enums
{
    public enum Title
    {
        Mr = 0,
        Mrs = 1,
        Miss = 2
    }
}