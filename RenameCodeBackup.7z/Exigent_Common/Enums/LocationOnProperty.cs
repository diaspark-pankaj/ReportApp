﻿using System.ComponentModel;
namespace Azmbl.Common.Enums
{
    public enum LocationOnProperty
    {
        [Description("Front Wall")]
        FrontWall = 0,
        [Description("Back Wall")]
        BackWall = 1,
        [Description("Left Wall")]
        LeftWall = 2,
        [Description("RightWall")]
        RightWall = 3,
        [Description("Roof")]
        Roof = 4,
        [Description("Entrance")]
        Entrance = 5,
        [Description("Pole")]
        Pole = 6,
        [Description("Front, Property")]
        FrontProperty = 7,
        [Description("Back, Property")]
        BackProperty = 8,
        [Description("Leftside, Property")]
        LeftsideProperty = 9,
        [Description("Rightside, Property")]
        RightsideProperty = 10,
        [Description("Wall Other")]
        WallOther = 11,
        [Description("Property Other")]
        PropertyOther = 12
    }
}