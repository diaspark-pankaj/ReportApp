﻿using System.ComponentModel;

namespace Exigent.Common.Enums
{
    // Below enum is used for role verification 
    public enum SystemTypeEnum
    {
        //[Description("Accounts")]
        //Accounts = 1,
        //[Description("Exigent Admin")]
        //ExigentAdmin = 2,
        [Description("Exigent Admin")]
        ServiceProviderAdmin = 1,

        //[Description("BusinessUnit")]
        //BusinessUnit = 3,

        [Description("Business Unit")]
        AuthorisedBusinessStaff = 2,

        //[Description("Group Legal - Lead Lawyers")]
        //GroupLegalLeadLawyers = 4,

        [Description("Group Legal - Lead Lawyers")]
        LegalProfessionalStaff = 3,

        [Description("Report Admin Accounts GSS")]
        LegalAdminStaff = 4,

        //[Description("GSS")]
        //GSS = 5,
        //[Description("Vendor")]
        //Vendor = 6,
        //[Description("Guest")]
        //Guest = 7,

        //[Description("ReportAdminAccountsGSS")]
        //ReportAdminAccountsGSS = 9,

        //[Description("GeneralCounsel")]
        //GeneralCounsel = 10,

        [Description("General Counsel")]
        SeniorLegalLeadershipStaff = 5,

        [Description("Super Group Legal - Lead Lawyers")]
        SuperGroupLegal = 6,

        [Description("Special Group Legal - Lead Lawyers")]
        SpecialGroupLegal = 7
    }
    public enum MatterReferenceEnum
    {
        GroupLegal = 1,
        BusinessUnit = 2
    }
    public enum EnvironmentEnum
    {
        QA = 1,
        UAT = 2,
        Local = 3
    }

    public enum SystemTypes
    {
		GroupLegal = 1,
		BusinessUnit = 2
	}
}
