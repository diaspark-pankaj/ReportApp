﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azmbl.Common.Enums
{
    public enum EquipmentDocType
    {
        SpecsDocuments = 1,

        Regulations = 2,

        InstructionForUse = 3,

        PreconditionForUse = 4,

        CustomFields = 5,

        ManufacturerDrawing = 6
    }
}
