﻿
namespace Azmbl.Common.Enums
{
    public enum HotWaterCapacityType
    {
        Capacity = 1,
        RecovaryRate = 2
    }
}
