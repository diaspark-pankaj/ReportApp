﻿using System.ComponentModel;

namespace Exigent.Common.Enums
{
    public enum AppActivityEnum
    {
        [Description("None")]
        None = 0,

        [Description("AddMatter")]
        AddMatter = 1,

        [Description("UpdateMatter")]
        UpdateMatter = 2,

        [Description("AddInvoice")]
        AddInvoice = 3,

        [Description("UpdateInvoice")]
        UpdateInvoice = 4,

        [Description("AddCreditNote")]
        AddCreditNote = 5,

        [Description("AddUser")]
        AddUser = 6,

        [Description("UpdateUser")]
        UpdateUser = 7,

        [Description("AddRole")]
        AddRole = 8,

        [Description("ViewInvoices")]
        ViewInvoices = 9,

        [Description("ViewInstrutions")]
        ViewInstrutions = 10,

        [Description("AddTimeSheet")]
        AddTimeSheet = 11,

        [Description("ViewTimeSheet")]
        ViewTimeSheet = 12,

        [Description("Reportable Matters")]
        ReportableMatters = 13,

        [Description("AddLoginPage")]
        AddLoginPage = 14,

        [Description("Manage Masters")]
        ManageMasters = 15,

        [Description("InactiveMatters")]
        InactiveMatters = 16,

        [Description("Reports")]
        Reports = 17,

        [Description("Download")]
        Download = 18
    }
}