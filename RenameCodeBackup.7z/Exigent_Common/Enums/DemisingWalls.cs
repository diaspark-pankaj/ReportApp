﻿
using System.ComponentModel;
namespace Azmbl.Common.Enums
{
    public enum DemisingWalls
    {
        [Description("Exisitng")]
        Existing = 1,
        [Description("Property Owner to Build")]
        Property = 2,
        [Description("Both")]
        Both = 3
    }
}
