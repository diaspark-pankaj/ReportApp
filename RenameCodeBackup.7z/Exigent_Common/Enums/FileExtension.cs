﻿using System.ComponentModel;

namespace Exigent.Common.Enums
{
    public enum FileExtension
    {
        None = 0,

        Xls = 1,

        Doc = 2,

        Ppt = 3,

        Xlsx = 4,

        Docx = 5,

        Pptx = 6,

        Pdf = 7,

        Txt = 8,

        Gif = 9,

        Png = 10,

        Jpg = 11,

        Jpeg = 12,

        Bmp = 13
    }
}