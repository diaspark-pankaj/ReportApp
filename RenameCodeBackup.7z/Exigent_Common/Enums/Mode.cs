﻿
namespace Exigent.Common.Enums
{
    public enum Mode
    {
        Add = 1,
        Edit = 2,
        Delete = 3,
        Reset = 4,
        Unmark = 5,
        Compare = 6,
        AlreadyExists = 7,
        AddMore = 8,
        EditMore = 9,
        Linked = 10,
        View = 11,
    }
}