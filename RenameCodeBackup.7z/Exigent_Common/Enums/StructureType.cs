﻿

using System.ComponentModel;
namespace Azmbl.Common.Enums
{
    public enum StructureType
    {
        [Description("Greenfield")]
        Greenfield = 0,
        [Description("Inline Exterior")]
        InlineExterior = 1,
        [Description("Inline Interior")]
        InlineInterior = 2,
        [Description("Kiosk")]
        Kiosk = 3
    }
}
