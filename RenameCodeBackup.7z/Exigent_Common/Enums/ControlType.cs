﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Exigent.Common.Enums
{
    public enum ControlType
    {
        [Description("None")]
        [Display(Name = "None")]
        None = 0,

        [Description("Text Box")]
        [Display(Name = "Text Box")]
        TextBox = 1,

        [Description("Text Area")]
        [Display(Name = "Text Area")]
        TextArea = 2,

        [Description("Date Picker")]
        [Display(Name = "Date Picker")]
        DatePicker = 3,

        //[Description("Radio Button")]
        //[Display(Name = "Radio Button")]
        //RadioButton = 4, //Not in use

        [Description("Radio Button List")]
        [Display(Name = "Radio Button List")]
        RadioButtonList = 5,

        [Description("Drop Down")]
        [Display(Name = "Drop Down")]
        DropDown = 6,

        [Description("Check Box")]
        [Display(Name = "Check Box")]
        CheckBox = 7,

        [Description("Check Box List")]
        [Display(Name = "Check Box List")]
        CheckBoxList = 8,

        [Description("Single File Upload")]
        [Display(Name = "Single File Upload")]
        SingleFileUpload = 9,

        [Description("Multiple File Upload")]
        [Display(Name = "Multiple File Upload")]
        MultipleFileUpload = 10,

        [Description("HTML Line")]
        [Display(Name = "HTML Line")]
        HtmlLine = 11,

        [Description("Email Input")]
        [Display(Name = "Email Input")]
        EmailInput = 12
    }
}