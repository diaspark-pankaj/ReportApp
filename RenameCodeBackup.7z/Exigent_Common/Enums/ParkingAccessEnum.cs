﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Azmbl.Common.Enums
{
    public enum ParkingAccessEnum
    {
        [Description("Construction")]
        Construction = 1,
        [Description("Customer")]
        Customer = 2,
        [Description("Owner")]
        Owner = 3,
    }

    public enum StoreTypesEnum
    {
        [Description("Lease")]
        Lease = 1,

        [Description("Freestanding")]
        Freestanding = 2,

        [Description("Existing")]
        Existing = 3,

        [Description("Purchase")]
        Purchase = 4,

        [Description("In-Line")]
        InLine = 5,

        [Description("New")]
        New = 6
    }
}
