﻿
namespace Azmbl.Common.Enums
{
    public enum RuleEntityType
    {
        None = 0,

        ObjectRule = 1,
        FunctionalAreaRule = 2,
        RuleAtObject = 3,
        RuleAtFunctionalArea = 4
    }
}