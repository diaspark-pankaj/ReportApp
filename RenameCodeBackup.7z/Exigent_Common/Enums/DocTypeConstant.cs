﻿
namespace Exigent.Common.Enums
{
    public class DocTypeConstant
    {
        public const string utility = "utility";
        public const string propertyinformation = "propertyinformation";
        public const string structure = "structure";
        public const string site = "site";
        public const string siteinlinestore = "siteinlinestore";
        public const string sitegreenfield = "sitegreenfield";
        public const string safetyAndSecurity = "safetyAndSecurity";
        public const string ventilation = "ventilation";
        public const string compressor = "compressor";
        public const string doorexterior = "doorexterior";
        public const string windowexterior = "windowexterior";
        public const string signage = "signage";
        public const string room = "room";
        public const string roomcolumn = "roomcolumn";
        public const string roomdoors = "roomdoors";
        public const string envventilation = "envventilation";
        public const string sitemakedemolition = "sitemakedemolition";
        public const string ventilationsiteadapt = "ventilationsiteadapt";
        public const string sitestandalone = "sitestandalone";
    }
}
