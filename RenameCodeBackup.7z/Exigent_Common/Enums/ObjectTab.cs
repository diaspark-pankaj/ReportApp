﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azmbl.Common.Enums
{
    public enum ObjectTab
    {
        None = 0,
        
        ObjectDetail = 1,

        Documents = 2,
        
        CustomFields = 3,

        OptionList = 4,

        BuyOutComponent = 5,

        Substitution = 6,

        HistoryAndComment = 7
    }
}
