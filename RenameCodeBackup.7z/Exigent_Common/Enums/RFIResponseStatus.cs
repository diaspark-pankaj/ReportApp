﻿
namespace Azmbl.Common.Enums
{
    public enum RFIResponseStatus
    {
        READ = 1,
        UNREAD = 2
    }
}
