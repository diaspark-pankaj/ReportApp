﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Azmbl.Common.Enums
{
    public enum EquipmentStatus
    {
        [Description("Pending For Approval")]
        [Display(Name = "Pending For Approval")]
        Pending = 1,
        [Description("Approve For Global")]
        [Display(Name = "Approved")]
        ApprovedForGlobal = 2,
        [Description("Approve for Suppliers")]
        [Display(Name = "Approved for Suppliers")]
        ApprovedForSuppliers = 3,
        [Description("Approve for Manufacturer")]
        [Display(Name = "Approved for Manufacturer")]
        ApprovedForManufacturer = 4,
        [Description("Reject")]
        [Display(Name = "Rejected")]
        Rejected = 5,
        [Description("Approve for Client")]
        [Display(Name = "Approved for Client")]
        ApprovedForClient = 6,
        [Description("Draft")]
        [Display(Name = "Draft")]
        Draft = 7,
        [Description("Approve for AoR")]
        [Display(Name = "Approved for AoR")]
        ApprovedForAor = 8


    }


}
