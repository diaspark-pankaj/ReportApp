﻿using System;
using System.ComponentModel;

namespace Azmbl.Common.Enums
{
    public enum RuleType
    {
        [Description("None")]
        None = 0,

        [Description("All Rule")]
        AllRule = 1,

        [Description("Distance Rule")]
        DistanceRule = 2,

        [Description("Proximity Rule")]
        ProximityRule = 3,

        [Description("Required Rule")]
        RequiredRule = 4,

        [Description("Functional Rule")]
        FunctionalRule = 5
    }
}