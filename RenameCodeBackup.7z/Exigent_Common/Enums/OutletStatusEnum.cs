﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azmbl.Common.Enums
{
    public enum OutletStatusEnum
    {
        //[Description("NotStarted")]
        //NotStarted = 0,
        //[Description("ProcessUnderWay")]
        //ProcessUnderWay = 1,
        //[Description("Completed")]
        //Completed = 2

        [Description("Not Started")]
        NotStarted = 0,

        [Description("Site Visit Complete")]
        SiteVisitComplete = 1,

        [Description("Survey Completed")]
        SurveyCompleted = 2,

        [Description("SD Submitted")]
        SDSubmitted = 3,

        [Description("CD Completed")]
        CDCompleted = 4,

        [Description("Construction Started")]
        ConstructionStarted = 5,

        [Description("Construction Complete")]
        ConstructionComplete = 6,

        [Description("As-Builts Complete")]
        AsBuiltsComplete = 7

    }
}
