﻿using System.ComponentModel;

namespace Azmbl.Common.Enums
{
    public enum ProjectTeam
    {
        [Description("Azmbl")]
        Azmbl = 1,
        [Description("Client")]
        Client = 2,
        [Description("Architect Manager")]
        ArchitectManager = 3,
        [Description("AoR Manager")]
        AoRManager = 4
    }
}
