﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.Common.Enums
{
    public enum FieldType
    {
        [Description("None")]
        [Display(Name = "None")]
        None = 0,

        [Description("Text")]
        [Display(Name = "Text")]
        Text = 1,

        [Description("Large Text")]
        [Display(Name = "Large Text")]
        LargeText = 2,

        [Description("Date")]
        [Display(Name = "Date")]
        Date = 3,

        [Description("Boolean")]
        [Display(Name = "Boolean")]
        Boolean = 4,

        [Description("Single Option Selection")]
        [Display(Name = "Single Option Selection")]
        SingleOptionSelection = 5,

        [Description("Multiple Option Selection")]
        [Display(Name = "Multiple Option Selection")]
        MultipleOptionSelection = 6,

        [Description("File Upload")]
        [Display(Name = "File Upload")]
        FileUpload = 7,

        [Description("Section Divider")]
        [Display(Name = "Section Divider")]
        SectionDivider = 8

    }
}
