﻿
namespace Exigent.Common.Enums
{
    public class StoredProcedureConstant
    {
        public const string GetUserDetails = "[dbo].[GetUserDetails]";
        public const string ExigentGetActiveInstructions = "[dbo].[ExigentGetActiveInstructions]";
        public const string ExigentGetOutstandingInvoices = "[dbo].[ExigentGetOutstandingInvoices]";
        public const string ExigentGetInvoicesByInvoiceNumber = "[dbo].[ExigentGetInvoicesByInvoiceNumber]";
        public const string ExigentGetRejectedInvoices = "[dbo].[ExigentGetRejectedInvoices]";
        public const string ExigentGetInvoiceAuditTask = "[dbo].[ExigentGetInvoiceAuditTask]";
        public const string ExigentGetInvoiceApprovalTask = "[dbo].[ExigentGetInvoiceApprovalTask]";
        public const string ExigentGetGrvTasks = "[dbo].[ExigentGetGrvTasks]";
        public const string ExigentGetGrvTasksReminder = "[dbo].[ExigentGetGrvTasksReminder]";
        public const string ExigentGetPOTasks = "[dbo].[ExigentGetPOTasks]";
        public const string ExigentGetPOTasksReminder = "[dbo].[ExigentGetPOTasksReminder]";        
        public const string ExigentGetPOTasksByMatterRef = "[dbo].[ExigentGetPOTasksByMatterReference_PAGING_SORTING]";
        public const string ExigentGetGRVTasksByMatterRef = "[dbo].[ExigentGetGRVTasksByMatterReference_PAGING_SORTING]";
        public const string ExigentGetPOIncreaseRequiredList = "[dbo].[ExigentGetPOIncreaseRequired_PAGING_SORTING]";
		// removed RFQ Approval from system - CI-Global Requirement.,
        //public const string ExigentGetRFQTasks = "[dbo].[ExigentGetRFQTasks]";
        public const string ExigentIncreasePOStart = "[dbo].[IncreasePOStart]";
        public const string ExigentGetPOBalanceLowList = "[dbo].[ExigentGetPOBalanceLowList]";
        public const string GetHODTop10Matters = "[dbo].[GetHODTop10Matters]";
        public const string ExigentGetBUApprovalTasks = "[dbo].[ExigentGetBUApprovalTasks]";
        public const string GetSpendTrendChartData = "[dbo].[getSpendTrendChartData]";
        public const string GetInvoicesChartYTDData = "[dbo].[getInvoicesChartYTDData]";
        public const string ExigentGetInvoiceApprovalTaskWithJurisdictionFilter = "[dbo].[ExigentGetInvoiceApprovalTaskWithJurisdictionFilter]";

    }
}
