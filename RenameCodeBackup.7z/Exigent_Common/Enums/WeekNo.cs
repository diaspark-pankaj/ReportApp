﻿using System;
using System.ComponentModel;

namespace Exigent.Common.Enums
{
    [Flags]
    public enum WeekNo
    {
        //[Description("None")]
        //None = 0x0,

        [Description("Week 1")]
        Week1 = 1,

        [Description("Week 2")]
        Week2 = 1 << 1,

        [Description("Week 3")]
        Week3 = 1 << 2,

        [Description("Week 4")]
        Week4 = 1 << 3
    }
}
