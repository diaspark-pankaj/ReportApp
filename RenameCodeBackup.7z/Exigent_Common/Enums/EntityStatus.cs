﻿
namespace Exigent.Common.Enums
{
    public enum EntityStatus
    {
        Inactive = 0,
        Active = 9
    }
}
