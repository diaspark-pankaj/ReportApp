﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azmbl.Common.Enums
{
 public  enum ElectricPanelAssetType
    {
      [Description("Panel Door")]
     PanelDoor=1,
      [Description("Panel Schedule")]
    PanelSchedule=2,
      [Description("Panel Notes")]
     PanelNotes=3,
      [Description("Panel Breakers")]
      PanelBreakers=4

    }

 public enum ElectricPanelContentType
 {
     [Description("Video")]
     Video=1,
     [Description("Photo")]
     Image=2,
     [Description("Document")]
     Document=3

 }
}
