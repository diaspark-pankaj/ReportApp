﻿
namespace Azmbl.Common.Enums
{
    public enum BidStatus
    {
        INVITED = 1,
        SUBMITED = 2,
        APPROVED = 3,
        CANCELLED = 4
    }
}
