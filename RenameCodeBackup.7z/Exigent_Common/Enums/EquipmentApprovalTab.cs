﻿
namespace Azmbl.Common.Enums
{
    public enum EquipmentApprovalTab
    {
        admin = 1,
        manufacturer = 2,
        supplier = 3,
        client = 4,
        aor = 5

    }
}
