﻿
namespace Azmbl.Common.Enums
{
    public class OrganizationTypeConstant
    {
        public const string Franchise = "F";
        public const string Vendor = "V";

    }
}
