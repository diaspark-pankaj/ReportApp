﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azmbl.Common.Enums
{
    public enum ScheduleCategoryTypeEnum
    {
        [Description("#13d7f3:Cleaning")] // green
        [Display(Name = "Cleaning")]
        Cleaning = 1,
        [Description("#e8d501:DIY")] // orange
        [Display(Name = "DIY Maintenance")]
        DIY = 2,
        [Description("#32dcc1:PreventativeMaintenance")] // red
        [Display(Name = "Prof Preventative Maintenance")]
        PreventativeMaintenance = 3,
        [Description("#ff8e61:Warranty")] // red
        [Display(Name = "Warranty")]
        Warranty = 4
    }
}
