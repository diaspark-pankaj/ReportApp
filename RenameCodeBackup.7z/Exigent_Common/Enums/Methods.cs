﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.Common.Enums
{
   public enum Methods
    {
       Route=1,
       FunctionalFlow=2,
       MenuLine=3,
       
     
    }
}
