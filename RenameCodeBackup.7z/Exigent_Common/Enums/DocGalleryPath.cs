﻿
namespace Exigent.Common.Enums
{
    public class DocGalleryPath
    {

        public const string RealEstateDocsUtility = "realestate/[UNITID]/docs/utilities/";
        public const string RealEstateDocsPropertyInformation = "realestate/[UNITID]/docs/propertyinfo/";
        public const string RealEstateDocsSite = "realestate/[UNITID]/docs/site/";
        public const string RealEstateDocsStructure = "realestate/[UNITID]/docs/structure/";
        public const string RealEstateDocsDemolition = "realestate/[UNITID]/docs/demolition/";
        public const string RealEstateDocsCompressorLocation = "realestate/[UNITID]/docs/site/compressor/[COMPRESSORID]/";
        public const string RealEstateDocsSignage = "realestate/[UNITID]/docs/site/signage/[SIGNID]/";
        public const string RealEstateDocsExteriorDoors = "realestate/[UNITID]/docs/structure/doors/[EXTERIORDOORID]/";
        public const string RealEstateDocsExteriorWindows = "realestate/[UNITID]/docs/structure/windows/[EXTERIORWINDOWID]/";
        public const string RealEstateDocsVentilation = "realestate/[UNITID]/docs/structure/vents/[VENTILATIONID]/";
        public const string RealEstateDocsRoom = "realestate/[UNITID]/docs/structure/rooms/[ROOMID]/";
        public const string RealEstateDocsRoomColumn = "realestate/[UNITID]/docs/structure/rooms/[ROOMID]/columns/[COLUMNID]/";
        public const string RealEstateDocsRoomDoors = "realestate/[UNITID]/docs/structure/rooms /[ROOMID]/doors/[DOORID]/";
        public const string RealEstateDocsSafetyAndSecurity = "realestate/[UNITID]/docs/safetyandSecurity/";
        public const string EnvironmentalDocsVentilation = "realestate/[UNITID]/docs/structure/envvents/[VENTILATIONID]/";
        public const string RealEstateDocsVentilationSiteAdapt = "realestate/[UNITID]/docs/structure/ventsiteadapt/[VENTILATIONSITEADAPTID]/";
        public const string RealEstateDocsSiteStandAlone = "realestate/[UNITID]/docs/sitestandalone/";
        public const string RealEstateDocsSiteGreenField = "realestate/[UNITID]/docs/sitegreenfield/";
        public const string RealEstateDocsSiteInLineStore = "realestate/[UNITID]/docs/siteinlinestore/";
        public const string RealEstateDocsSpecification = "realestate/[UNITID]/docs/specification/";
        public const string RfiDocs = "rfi/[GUID]/docs/";
        public const string BidProjectDocs = "bid/[GUID]/[PATH]/docs/";
        public const string SITBuildingDetails = "bid/[SITID]/AutoCADDrawing";

    }
}
