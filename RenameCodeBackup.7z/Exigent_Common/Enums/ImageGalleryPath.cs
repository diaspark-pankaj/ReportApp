﻿using System.ComponentModel;
namespace Exigent.Common.Enums
{
    public enum GalleryRoutes
    {
        [Description("utilities")]
        RealEstateUtility = 1,
        [Description("site")]
        RealEstateSite = 2,
        [Description("structure")]
        RealEstateStructure = 3,
        [Description("demolition")]
        RealEstateDemolition = 4,
        [Description("compressor")]
        RealEstateCompressorLocation = 5,
        [Description("signage")]
        RealEstateSignage = 6,
        [Description("doors")]
        RealEstateExteriorDoors = 7,
        [Description("windows")]
        RealEstateExteriorWindows = 8,
        [Description("vents")]
        RealEstateVentilation = 9,
        [Description("rooms")]
        RealEstateRoom = 10,
        [Description("roomcolumns")]
        RealEstateRoomColumn = 11,
        [Description("roomdoors")]
        RealEstateRoomDoors = 12,
        [Description("drawimage")]
        RealEstateDrawimage = 13,
        [Description("safetyandSecurity")]
        RealEstateSafetyAndSecurity = 14,
        [Description("envvents")]
        EnvironmentalVentilation = 15,
        [Description("ventsiteadapt")]
        RealEstateVentilationSiteAdapt = 16,
        [Description("sitestandalone")]
        RealEstateSiteStandAlone = 17,
        [Description("sitegreenfield")]
        RealEstateSiteGreenField = 18,
        [Description("siteinlinestore")]
        RealEstateSiteInLineStore = 19,
        [Description("realestatespecification")]
        RealEstateSpecification = 20,
        [Description("equipmentcomment")]
        EquipmentComment = 21,
        [Description("equipmentcustomfile")]
        EquipmentCustomFiledFile = 22,
        [Description("propertyinformation")]
        RealEstatePropertyInformation = 23,

        //SIT
        [Description("PropertyLeaseInfo")]
        SITPropertyLeaseInfo = 24,
        [Description("ParkingandCommonAreas")]
        SITParkingandCommonAreas = 25,
        [Description("HandicapConsiderations")]
        SITHandicapConsiderations = 26,
        [Description("BuildingDetails")]
        SITBuildingDetails = 27,
        [Description("Dimension")]
        SITDimension = 28,
        [Description("StoreFront")]
        SITStoreFront = 29,
        [Description("RearDoorsandWindows")]
        SITRearDoorsandWindows = 30,
        [Description("ExteriorsandInteriorWalls")]
        SITExteriorsandInteriorWalls = 31,
        [Description("Ceilings")]
        SITCeilings = 32,
        [Description("Lighting")]
        SITLighting = 33,
        [Description("Floor")]
        SITFloor = 34,
        [Description("Demolition")]
        SITDemolition = 35,
        [Description("Electrical")]
        SITElectrical = 36,
        [Description("AirConditioningandHeatingEquipment")]
        SITAirConditioningandHeatingEquipment = 37,
        [Description("RestRoom")]
        SITRestRoom = 38,
        [Description("WaterProbleamandUtility")]
        SITWaterProbleamandUtility = 39,
        [Description("Signs")]
        SITSigns = 40,
        [Description("DigitalPhotograps")]
        SITDigitalPhotograps = 41,
        [Description("GeneralComments")]
        SITGeneralComments = 42,
        [Description("Room")]
        SITRoom = 43,
        [Description("Column")]
        SITColumn = 44,
        [Description("Door")]
        SITDoor = 45,
        [Description("SITDoorExterior")]
        SITDoorExterior = 46,
        [Description("SITWindowExterior")]
        SITWindowExterior = 47,
        [Description("DPExteriorFront")]
        DPExteriorFront = 48,
        [Description("DPRearDoor")]
        DPRearDoor = 49,
        [Description("DPExistingSigns")]
        DPExistingSigns = 50,
        [Description("DPInteriorSpace")]
        DPInteriorSpace = 51,
        [Description("DPOther")]
        DPOther = 52,
        [Description("sitdrawimage")]
        SITDrawimage = 53,
        [Description("buildingandfirecodeinfogeothech")]
        BuildingandFireCodeInfoGeoThech = 54,
        //PMR
        [Description("signordinanceapplication")]
        SignOrdinanceApplication = 55,
        [Description("healthdepartmentinfo")]
        HealthDepartmentInfo = 56,
        [Description("Site Make Ready")]
        SiteMakeReady = 57,
        [Description("Permit Process Summary")]
        PermitProcessSummary = 58,
        [Description("Permit Fee Summary")]
        PermitFeeSummary = 59,
        [Description("Site Zoning And Planning Dept Info")]
        SiteZoningAndPlanningDeptInfo = 60,
        [Description("SignOrdinance")]
        SignOrdinance = 61,
        [Description("Liquor Licensing")]
        LiquorLicensing = 62,
        [Description("Building And Fire Code Info")]
        BuildingAndFireCodeInfo = 63,
        [Description("Fire Department Info")]
        FireDepartmentInfo = 64,
        [Description("Trash Services")]
        TrashServices = 65,
        [Description("Grease Recycling")]
        GreaseRecycling = 66,
        [Description("Storm Water Management")]
        StormWaterManagement = 67,
        [Description("HVAC")]
        HVAC = 68,
        [Description("SanitarySewer")]
        SanitarySewer = 69,
        [Description("Water Domestic And Fire")]
        WaterDomesticAndFire = 70,
        [Description("Electric Service")]
        ElectricService = 71,
        [Description("Natural Gas Service")]
        NaturalGasService = 72,
        [Description("Telephone")]
        Telephone = 73,
        [Description("Real Estate Deal Review")]
        RealEstateDealReview = 74,
        [Description("ElectricPanelAsset")]
        ElectricPanelAsset = 75,
        [Description("Outlet")]
        Outlet = 76,
        [Description("OutletCommon")]
        OutletCommon = 77,
        [Description("Asset")]
        Asset = 78,
        [Description("OutletContent")]
        OutletContent = 79
    }

    public enum ExigentModules
    {
        [Description("realestate")]
        RealEstate = 1,
        [Description("odms")]
        ODMS = 2,
        [Description("SIT")]
        SIT = 3,
        [Description("pmr")]
        PMR = 4,
        [Description("amc")] // Added by suresh 
        AMC = 5
    }

    public class ImageGalleryPath
    {
        //Real Estate
        public const string RealEstateUtility = "realestate/[UNITID]/utilities/";
        public const string RealEstatePropertyInformation = "realestate/[UNITID]/propertyinfo/";
        public const string RealEstateSite = "realestate/[UNITID]/site/";
        public const string RealEstateStructure = "realestate/[UNITID]/structure/";
        public const string RealEstateDemolition = "realestate/[UNITID]/demolition/";
        public const string RealEstateCompressorLocation = "realestate/[UNITID]/site/compressor/[COMPRESSORID]/";
        public const string RealEstateSignage = "realestate/[UNITID]/site/signage/[SIGNID]/";
        public const string RealEstateExteriorDoors = "realestate/[UNITID]/structure/doors/[EXTERIORDOORID]/";
        public const string RealEstateExteriorWindows = "realestate/[UNITID]/structure/windows/[EXTERIORWINDOWID]/";
        public const string RealEstateVentilation = "realestate/[UNITID]/structure/vents/[VENTILATIONID]/";
        public const string RealEstateRoom = "realestate/[UNITID]/structure/rooms/[ROOMID]/";
        public const string RealEstateRoomColumn = "realestate/[UNITID]/structure/rooms/[ROOMID]/columns/[COLUMNID]/";
        public const string RealEstateRoomDoors = "realestate/[UNITID]/ structure/rooms /[ROOMID]/doors/[DOORID]/";
        public const string RealEstateDrawimage = "realestate/[UNITID]/drawimage/";
        public const string RealEstateSiteStandAlone = "realestate/[UNITID]/sitestandalone/";
        public const string RealEstateSiteGreenField = "realestate/[UNITID]/sitegreenfield/";
        public const string RealEstateSiteInLineStore = "realestate/[UNITID]/siteinlinestore/";
        public const string RealEstateSafetyAndSecurity = "realestate/[UNITID]/safetyandSecurity/";//Added By Ashok Solanki
        public const string EnvironmentalVentilation = "realestate/[UNITID]/structure/envvents/[VENTILATIONID]/";
        public const string RealEstateVentilationSiteAdapt = "realestate/[UNITID]/structure/ventsiteadapt/[VENTILATIONSITEADAPTID]/";

        public const string RealEstateDrawimageName = "DrawImage.png";
        public const string SITDrawimageName = "SITDrawImage.png";

        //SIT
        public const string SITPropertyLeaseInfo = "Project/[PId]/siteinvestigation/[SITID]/PropertyLeaseInfo/";
        public const string SITParkingandCommonAreas = "Project/[PId]/siteinvestigation/[SITID]/ParkingandCommonAreas/";
        public const string SITHandicapConsiderations = "Project/[PId]/siteinvestigation/[SITID]/HandicapConsiderations/";
        public const string SITBuildingDetails = "Project/[PId]/siteinvestigation/[SITID]/BuildingDetails/";
        public const string SITDimension = "Project/[PId]/siteinvestigation/[SITID]/Dimension/";
        public const string SITStoreFront = "Project/[PId]/siteinvestigation/[SITID]/StoreFront/";
        public const string SITRearDoorsandWindows = "Project/[PId]/siteinvestigation/[SITID]/RearDoorsandWindows/";
        public const string SITExteriorsandInteriorWalls = "Project/[PId]/siteinvestigation/[SITID]/ExteriorsandInteriorWalls/";
        public const string SITDemolition = "Project/[PId]/siteinvestigation/[SITID]/Demolition/";
        public const string SITElectrical = "Project/[PId]/siteinvestigation/[SITID]/Electrical/";
        public const string SITAirConditioningandHeatingEquipment = "Project/[PId]/siteinvestigation/[SITID]/AirConditioningandHeatingEquipment/";
        public const string SITRestRoom = "Project/[PId]/siteinvestigation/[SITID]/RestRoom/";
        public const string SITWaterProbleamandUtility = "Project/[PId]/siteinvestigation/[SITID]/WaterProbleamandUtility/";
        public const string SITSigns = "Project/[PId]/siteinvestigation/[SITID]/Signs/";
        public const string SITDigitalPhotograps = "Project/[PId]/siteinvestigation/[SITID]/DigitalPhotograps/";
        public const string SITGeneralComments = "Project/[PId]/siteinvestigation/[SITID]/GeneralComments/";

        public const string SITCeilings = "Project/[PId]/siteinvestigation/[SITID]/Ceilings/[CEILINGID]/";
        public const string SITLighting = "Project/[PId]/siteinvestigation/[SITID]/Lighting/[LIGHTNINGID]/";
        public const string SITFloor = "Project/[PId]/siteinvestigation/[SITID]/Floor/[FLOORID]/";
        public const string SITRoom = "Project/[PId]/siteinvestigation/[SITID]/rooms/[ROOMID]/";
        public const string SITColumn = "Project/[PId]/siteinvestigation/[SITID]/rooms/[ROOMID]/columns/[COLUMNID]/";
        public const string SITDoor = "Project/[PId]/siteinvestigation/[SITID]/rooms/[ROOMID]/doors/[DOORID]/";
        public const string SITDoorExterior = "Project/[PId]/siteinvestigation/[SITID]/exteriordoors/[EXTERIORDOORID]/";
        public const string SITWindowExterior = "Project/[PId]/siteinvestigation/[SITID]/exteriorwindow/[EXTERIORWINDOWID]/";
        // added for Digital Photographs screen.
        public const string SITDigitalPhotographs_ExteriorFront = "Project/[PId]/siteinvestigation/[SITID]/digitalphotographs/exteriorfront/";
        public const string SITDigitalPhotographs_RearDoor = "Project/[PId]/siteinvestigation/[SITID]/digitalphotographs/reardoor/";
        public const string SITDigitalPhotographs_ExistingSigns = "Project/[PId]/siteinvestigation/[SITID]/digitalphotographs/existingsigns/";
        public const string SITDigitalPhotographs_InteriorSpace = "Project/[PId]/siteinvestigation/[SITID]/digitalphotographs/interiorspace/";
        public const string SITDigitalPhotographs_Other = "Project/[PId]/siteinvestigation/[SITID]/digitalphotographs/other/";
        public const string SITDrawimage = "Project/[PId]/siteinvestigation/[SITID]/drawimage/";
        // PMR

        //AMC
        public const string ElectricPanelAsset = "Project/[PId]/ElectricPanel/[ID]/ElectricPanelAssetType/[TId]/ContentType/[CID]/"; // Added by Suresh 
        public const string Outlet = "Outlet/[PId]/ContentType/[CID]/";
        public const string OutletCommon = "Outlet/[PId]/OutletCommon/ContentType/[CID]/";
        public const string Asset = "OutletId/[PId]/Asset/[Id]/ContentType/[CID]/";
        public const string OutletContent = "Outlet/[PId]/[ContentType]/[FolderName]/";

        



        //public const string SignOrdinanceApplication = "Project/[PId]/projectmakeready/SignOrdinance/";
    }
}
