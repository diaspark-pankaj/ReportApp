﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.Common.Enums
{
    public enum CountryCode
    {
        //Dont change enum name for naming convention. Names are used in method 'GetMeasureSystem' of class 'Measurement'
        [Description("None")]
        None = 0,

        [Description("Korea")]
        kr = 1,

        [Description("United Kingdom")]
        uk = 2,

        [Description("Great Britain")]
        gb = 3,

        [Description("United States")]
        us = 4
    }
}
