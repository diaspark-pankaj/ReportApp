﻿using System.ComponentModel;

namespace Exigent.Common.Enums
{
    public enum ReportEnum
    {
        [Description("Weekly Matter Report")]
        Weekly_MatterReport = 1,
        [Description("Weekly Matter Report & Financial Reports")]
        Weekly_MatterReport_FY = 2,
        [Description("YTD Pre-VAT Attorney Fee Spend per ELF")]
        YTD_Pre_VAT_Attorney_Fee_Spend_per_ELF = 3,
        [Description("YTD Pre-VAT Spend by ELF per Business Unit")]
        YTD_Pre_VAT_Spend_by_ELF_per_Business_Unit = 4,
        [Description("YTD ELF Invoices by Status per Business Unit")]
        YTD_ELF_Invoices_by_Status_per_Business_Unit = 5,
        [Description("YTD Pre-VAT Attorney Fee Spend per ELF per Business Unit")]
        YTD_Pre_VAT_Attorney_Fee_Spend_per_ELF_per_Business_Unit = 6,
        [Description("Activity by Lead Lawyer")]
        Activity_by_Lead_Lawyer = 7,
        [Description("Activity Per Matter Per Lead Lawyer")]
        Activity_Per_Matter_Per_Lead_Lawyer = 8,
        [Description("Activity Report Per Lead Lawyer")]
        Activity_Report_Per_Lead_Lawyer = 9,
        [Description("Rebate Report")]
        Rebate_Report = 10,
        [Description("All Matters")]
        All_Matters = 11,
        [Description("All Invoices")]
        All_Invoices = 12,
        [Description("All Instructions")]
        All_Instructions = 13,
        InvoicesOutsideCI = 14
    }
}
