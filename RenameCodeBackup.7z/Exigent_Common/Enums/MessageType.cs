﻿
namespace Exigent.Common.Enums
{
    public enum MessageType
    {
        success,
        info,
        warning,
        danger,
        primary,
        copied
    }
}
