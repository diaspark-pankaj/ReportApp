﻿
namespace Exigent.Common.Enums
{
    public enum EmailType
    {
        REG = 1,
        RES = 2,
        PRST = 3,
        PEX = 4,
        BIDINV = 5,
        REDESIGN = 6,
        EquipStatus = 7,
        UpManufacture = 8,
        UpSupplier = 9,
        UpIndustry = 10,
        CreateCat = 11,
        InManufacture = 12,
        InSupplier = 13,
        InIndustry = 14,
        UpCategory = 16,
        CreateObj = 17,
        UpObj = 18,
        DelSupplier = 19,
        DelManufacture = 20,
        DelIndustry = 21,
        DelCategory = 22,
        DelObject = 23,
        CreateObjCM = 24,
        BidSub = 27
    }
}
