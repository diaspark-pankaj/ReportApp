﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azmbl.Common.Enums
{
    public enum RuleRestriction
    {
        
        [Category("")]
        [Display(Name = "")]
        [Description("")]
        None,


        [Category("DistanceRule")]
        [Display(Name = "Should Be")]
        [Description("SB")]
        ShouldBe,
        [Category("DistanceRule")]
        [Display(Name = "Should Not Be")]
        [Description("NSB")]
        ShouldNotBe,

        [Category("ProximityRule")]
        [Display(Name = "Adjacent")]
        [Description("AD")]
        Adjacent,
        //[Category("ProximityRule")]
        //[Display(Name = "Near From")]
        //[Description("NF")]
        //NearFrom,
        //[Category("ProximityRule")]
        //[Display(Name = "Away From")]
        //[Description("AF")]
        //AwayFrom,

        [Category("ProximityRule")]
        [Display(Name = "Positioned directly above ")]
        [Description("PDA")]
        DirectlyAbove,


        
        [Category("ProximityRule")]
        [Display(Name = "Not Adjacent")]
        [Description("NAD")]
        NotAdjacent,

        [Category("RequiredRule")]
        [Display(Name = "Required Associated Functional Areas")]
        [Description("RAFA")]
        RAFA,
        [Category("RequiredRule")]
        [Display(Name = "Not Required Associated Functional Areas")]
        [Description("NRAFA")]
        NRAFA,


        [Category("RequiredRule")]
        [Display(Name = "Required Associated Category")]
        [Description("RAC")]
        RAC,
        [Category("RequiredRule")]
        [Display(Name = "Not Required Associated Category")]
        [Description("NRAC")]
        NRAC,

        //[Category("FunctionalRule")]
        //[Display(Name = "Should Be In")]
        //[Description("SBI")]
        //ShouldBeIn,
        //[Category("FunctionalRule")]
        //[Display(Name = "Should Not Be Area")]
        //[Description("NSBA")]
        //ShouldNotBeArea,

        [Category("FunctionalRule")]
        [Display(Name = "Minimum Width")]
        [Description("MW")]
        DimensionWidth,

        [Category("FunctionalRule")]
        [Display(Name = "Minimum Length")]
        [Description("ML")]
        DimensionLength,
    }


    
}
