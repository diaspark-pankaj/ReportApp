﻿
namespace Exigent.Common.Enums
{
    public class TableConstant
    {
        public const string TableCompressorLocation = "[Unit].[CompressorLocation]";
        public const string TableDoorExterior = "[Unit].[DoorExterior]";
        public const string TableWindowExterior = "[Unit].[WindowExterior]";
        public const string TableDoorInterior = "[Unit].[DoorInterior]";
        public const string TableRoom = "[Unit].[Room]";
        public const string TableSignage = "[Unit].[Signage]";
        public const string TableEnvironmentalVentilation = "[Unit].[EnvironmentalVentilation]";
        public const string TableMenuItem = "[Process].[TYPE_MenuItem]";
        public const string TableRoute = "[Process].[Route]";
        public const string TableMenuLine = "[Process].[MenuLine]";
        public const string TableProjectUnit = "[Planning].[Unit]";
        public const string TableEntity = "[CRM].[Entity]";
        public const string TableConcept = "[SBR].[Concept]";
        public const string TableConceptVarient = "[SBR].[ConceptVariant]";
        public const string TableMarket = "[SBR].[Market]";
        public const string TableMarketVarient = "[SBR].[MarketVariant]";
        public const string TableREL_FunctionalArea2Market = "[Design].[REL_FunctionalArea2Market]";
        public const string TableFunctionalArea = "[Design].[FunctionalArea]";
        public const string TableVentilationSiteAdapt = "[Unit].[VentilationSiteAdapt]";
        public const string TableOrg2Geo = "[CRM].[REL_Org2Geo]";
        public const string ConceptControlsView = "[CRM].[ConceptControlsView]";
        public const string TableMenuSchedule = "[Operations].[MenuSchedule]";
        public const string TableID_Department = "[Design].[ID_Department]";
        public const string TableID_FunctionalAreaCategory = "[Design].[ID_FunctionalAreaCategory]";
        public const string TableID_StorageType = "[Design].[ID_StorageType]";
        public const string TableID_Grade = "[Design].[ID_Grade]";

        public const string TableTypeConceptVariant = "[SBR].[TYPE_ConceptVariant]";
        public const string TableStorageArea = "[Design].[StorageArea]";

        // Exigent Table Constants..., used in ODMS Excel Import Mapping Utility.., Vyom Dixit, 4-Aug-2014
        public const string Table_Exigent_ID_Industry = "[Core].[ID_Industry]";
        public const string Table_Exigent_ID_Category = "[Equipment].[ID_Category]";
        public const string Table_Exigent_Equipment = "[Equipment].[Equipment]";
        public const string Table_Exigent_Equipment_Substitution = "[Equipment].[Rel_SubstitutionEquipment]";
        public const string Table_Exigent_Equipment_Buyout = "[Equipment].[Rel_BuyoutEquipment]";
        public const string Table_Exigent_EquipmentSchema = "[Equipment].[EquipmentSchema]";
        public const string Table_Exigent_REL_EquipmentSchemaField = "[Equipment].[REL_EquipmentSchemaField]";
        public const string Table_Exigent_Rel_EquipmentFieldValue = "[Equipment].[Rel_EquipmentFieldValue]";
        public const string Table_Exigent_EquipmentType = "[Equipment].[EquipmentType]";
        public const string Table_Exigent_EquipmentAccess = "[Equipment].[EquipmentAccess]";
        public const string Table_Exigent_Geographies = "[Core].[Geographies]";
        public const string SITRoom = "[SIT].[Room]";
        public const string SITFloor = "[SIT].[Floor]";
        public const string SITDoorInterior = "[SIT].[DoorInterior]";
        public const string SITDoorExterior = "[SIT].[DoorExterior]";
        public const string SITWiondowExterior = "[SIT].[SITWindowExterior]";
    }
}
