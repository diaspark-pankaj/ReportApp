﻿
using System.ComponentModel;
namespace Azmbl.Common.Enums
{
    public enum FAObjectCategoryEnum
    {
        [Description("Single Source")]
            SingleSource = 1,
        [Description("Multiple-Source, Defined")]
            MultipleSourceDefined=2,
        [Description("Multiple-Source, Equal to Base Spec")]
            MultipleSourceEqualToBaseSpec = 3,
        [Description("Custom Fabricated")]
            CustomFabricated = 4
    }
}
