﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
namespace Exigent.Common.Enums
{
   public class EntityType
    {
       public enum EntityTypes
       {
           [Description("V")]
           VENDOR,
           [Description("S")]
           SUPPLIER,
           [Description("E")]
           MANUFACTURER,
       }
    }
}
