﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Azmbl.Common.Enums
{
    public enum GeneralConditionTypes
    {
        [Description("Good (No or minimum work required)")]
        Good =1,
        [Description("Fair (work required)")]
        Fair = 2,
        [Description("Poor (must be replaced)")]
        Poor = 3,
    }

    public enum FrontEntryDoorTypes
    {
        [Description("Plate Glass")]
        PlateGlass = 1,
        [Description("Glass Door")]
        GlassDoor = 2,
        [Description("Wood Door")]
        WoodDoor = 3
    }

    public enum GlassTypes
    { 
        [Description("Tinted")]
        Tinted=1,
        [Description("Clear")]
        Clear=2
    }
}
