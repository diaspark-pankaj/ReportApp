﻿using System.ComponentModel;
namespace Exigent.Common.Enums
{
    public enum UserFilePermissionEnum
    {
        [Description("Documents")]
        Documents = 1,
        [Description("Existing Conditions Report")]
        Reports = 2,
        [Description("Photos")]
        Photos = 3,
        [Description("Videos")]
        Videos = 4,
        [Description("Spec Sheets")]
        SpecSheets = 5,
        [Description("Drawings")]
        Drawings = 6,
        [Description("Additional Folder Create")]
        AdditionalFolderCreate = 29,
        [Description("Additional Folder View")]
        AdditionalFolderView = 30

    }
}
