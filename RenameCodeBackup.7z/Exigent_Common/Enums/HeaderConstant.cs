﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.Common.Enums
{
    public class HeaderConstant
    {
        public const string ExigentHeader = "ExigentHeader";
        public const string equipmentHeader = "equipmentHeader";
    }
}
