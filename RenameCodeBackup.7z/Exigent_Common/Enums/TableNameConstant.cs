﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.Common.Enums
{
    public class TableNameConstant
    {
         public const string TableZero = "Table";      
         public const string TableOne  = "Table1";  
         public const string TableFour  = "Table4";  
         public const string TableSix  = "Table6";  
         public const string TableFourteen  = "Table14";  
         public const string TableFifteen  = "Table15";
         public const string TableSixteen = "Table16";  
    }
}
