﻿
namespace Exigent.Common.Enums
{
    public enum CurrencyType
    {
        None = 0,

        usa = 1,

        local = 2
    }
}
