﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Azmbl.Common.Enums
{
   public enum EquipmentSchemaType
    {
       Industry=1,
       Category=2,
       EquipmentType=3,
       Default=4/*For import and default Equipment addition.*/
    }
}
