﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Azmbl.Common.Enums
{
    public enum LightingFixtureTypeEnum
    {
        [Description("Recessed 2 x 4 fixtures with acrylic lens")]
        [Display(Name = "Recessed 2 x 4 fixtures with acrylic lens")]
        AcrylicLens = 1,

        [Description("Recessed 2 x 4 fixtures with parabolic lens")]
        [Display(Name = "Recessed 2 x 4 fixtures with parabolic lens")]
        ParabolicLens = 2,

        [Description("Surface-mounted fixtures")]
        [Display(Name = "Surface-mounted fixtures")]
        SurfaceMounted = 3,

        [Description("Other")]
        [Display(Name = "Other")]
        Other=4,
    }

    public enum VoltageFixtureRange
    { 
        [Description("120")]
        Low=120,
        [Description("277")]
        High = 277,
    }
}
