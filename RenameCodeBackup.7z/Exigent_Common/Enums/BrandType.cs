﻿
namespace Azmbl.Common.Enums
{
    public enum BrandType
    {
        None = 0,

        C = 1,

        B = 2,

        F = 3,
    }
}
