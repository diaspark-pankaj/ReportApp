﻿using System;

namespace Exigent.Email.Configuration
{
    public class EmailDetails
    {
        public int EmailHistoryId { get; set; }
        public string EmailCC { get; set; }
        public string EmailTo { get; set; }
        public string EmailFrom { get; set; }
        public string EmailContent { get; set; }
        public string EmailTextContent { get; set; }
        public string EmailSubject { get; set; }
        public string Attachment { get; set; }
        public int RetryCount { get; set; }
        public bool EmailSentSuccessfully { get; set; }
        public string SystemError { get; set; }
        public int CreatedBy { get; set; }
        public int ModifiedBy { get; set; }
        public DateTime DateCreated { get; set; }
        public DateTime DateModified { get; set; }
        public string FromName { get; set; }
        public string Reference { get; set; }
        public int Id { get; set; }

        /// <summary>
        /// To check a reminder email (not in use for now).
        /// The job is being done using stand alone windows service.
        /// </summary>
        public bool IsAReminder { get; set; }
    }
}