﻿using System;
using System.Configuration;

namespace Exigent.Email.Configuration
{
    public class SmtpConfiguration
    {
        #region Constructor
        public SmtpConfiguration()
        {
            SMTPServer = string.IsNullOrEmpty(ConfigurationManager.AppSettings["smtpServer"]) ? string.Empty : ConfigurationManager.AppSettings["smtpServer"];
            SMTPUsername = string.IsNullOrEmpty(ConfigurationManager.AppSettings["smtpUsername"]) ? string.Empty : ConfigurationManager.AppSettings["smtpUsername"];
            SMTPPassword = string.IsNullOrEmpty(ConfigurationManager.AppSettings["smtpPassword"]) ? string.Empty : ConfigurationManager.AppSettings["smtpPassword"];
            SMTPBccUsername = string.IsNullOrEmpty(ConfigurationManager.AppSettings["smtpBccUsername"]) ? string.Empty : ConfigurationManager.AppSettings["smtpBccUsername"];
            NumberOfAttachment = Convert.ToInt32(ConfigurationManager.AppSettings["numberOfAttachment"]) == 0 ? 0 : Convert.ToInt32(ConfigurationManager.AppSettings["numberOfAttachment"]);
            SizeOfAttachment = Convert.ToInt32(ConfigurationManager.AppSettings["sizeOfAttachment"]) == 0 ? 0 : Convert.ToInt32(ConfigurationManager.AppSettings["sizeOfAttachment"]);
            SMTPPort = Convert.ToInt32(ConfigurationManager.AppSettings["smtpPort"]) == 0 ? 0 : Convert.ToInt32(ConfigurationManager.AppSettings["smtpPort"]);
        }
        #endregion

        #region Private Members
        private string SMTPServer;
        private int SMTPPort;
        private string SMTPUsername;
        private string SMTPPassword;
        private string SMTPBccUsername;
        private int NumberOfAttachment;
        private int SizeOfAttachment;
        #endregion

        #region Public Members
        public string smtpServer
        {
            get { return this.SMTPServer; }
            set { this.SMTPServer = value; }
        }
        public int smtpPort
        {
            get { return this.SMTPPort; }
            set { this.SMTPPort = value; }
        }
        public string smtpUsername
        {
            get { return this.SMTPUsername; }
            set { this.SMTPUsername = value; }
        }
        public string smtpPassword
        {
            get { return this.SMTPPassword; }
            set { this.SMTPPassword = value; }
        }
        public string smtpBccUsername
        {
            get { return this.SMTPBccUsername; }
            set { this.SMTPBccUsername = value; }
        }
        public int numberOfAttachment
        {
            get { return this.NumberOfAttachment; }
            set { this.NumberOfAttachment = value; }
        }
        public int sizeOfAttachment
        {
            get { return this.SizeOfAttachment; }
            set { this.SizeOfAttachment = value; }
        }
        #endregion
    }
}