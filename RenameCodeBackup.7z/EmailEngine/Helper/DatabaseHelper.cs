﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Exigent.Email.Helper
{
    public class DatabaseHelper
    {
        public static void ExecuteNonQuery(string commandText, params SqlParameter[] parameters)
        {
            try
            {
                string connString = ConfigurationManager.AppSettings["ExigentDBEntities"].ToString();
                using (var currsqlConnection = new SqlConnection(connString))
                {
                    currsqlConnection.Open();
                    var cmdExecuteSP = new SqlCommand
                    {
                        CommandText = commandText,
                        CommandType = CommandType.StoredProcedure,
                        Connection = currsqlConnection
                    };
                    foreach (var sqlParam in parameters)
                    {
                        cmdExecuteSP.Parameters.Add(sqlParam);
                    }
                    cmdExecuteSP.ExecuteNonQuery();
                }
            }
            catch (Exception ex) { throw ex; }
        }

        public static DataSet ExecuteReader(string spName, params SqlParameter[] parameters)
        {
            DataSet ds = new DataSet();
            string connString = ConfigurationManager.AppSettings["ExigentDBEntities"].ToString();
            using (var currsqlConnection = new SqlConnection(connString))
            {
                var cmdExecuteSP = new SqlCommand
                {
                    CommandText = spName,
                    CommandType = CommandType.StoredProcedure,
                    Connection = currsqlConnection
                };

                foreach (var sqlParam in parameters)
                {
                    cmdExecuteSP.Parameters.Add(sqlParam);
                }
                var da = new SqlDataAdapter
                {
                    SelectCommand = cmdExecuteSP
                };
                da.Fill(ds);
                return ds;
            }
        }

        public static int ExecuteNonQueryAsyn(string commandText, params SqlParameter[] parameters)
        {
            try
            {
                int retVal = 0;
                string connString = ConfigurationManager.AppSettings["ExigentDBEntities"].ToString();
                using (var currsqlConnection = new SqlConnection(connString))
                {
                    currsqlConnection.Open();
                    var cmdExecuteSP = new SqlCommand
                    {
                        CommandText = commandText,
                        CommandType = CommandType.StoredProcedure,
                        Connection = currsqlConnection
                    };

                    cmdExecuteSP.Parameters.AddRange(parameters);
                    cmdExecuteSP.ExecuteNonQueryAsync();
                }
                return retVal;
            }
            catch (Exception ex) { throw ex; }
        }
    }
}
