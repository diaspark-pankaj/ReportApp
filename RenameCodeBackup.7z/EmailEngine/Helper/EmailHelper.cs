﻿using Exigent.Email.Configuration;
using Exigent.Email.Constants;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.Email.Helper
{
    /// <summary>
    /// commmon mail sender class
    /// </summary>
    public class EmailHelper
    {
        #region object initializer
        private static SmtpConfiguration _smtpConfiguration = new SmtpConfiguration();
        private static SmtpClient _smtp = new SmtpClient();
        private static MailMessage _mail = new MailMessage();
        private static bool isMailSent = false;
        #endregion

        #region Public Methods

        public static bool SendEmail(EmailDetails emailingDetails, bool IsSecure=false)
        {
            _smtp.Credentials = new System.Net.NetworkCredential(_smtpConfiguration.smtpUsername, _smtpConfiguration.smtpPassword);
            _smtp.Host = _smtpConfiguration.smtpServer;
            _smtp.Port = _smtpConfiguration.smtpPort;

			if(IsSecure)
				_smtp.EnableSsl = true;

            if (emailingDetails != null)
            {
                if (!string.IsNullOrEmpty(emailingDetails.EmailTo) && !string.IsNullOrEmpty(emailingDetails.EmailFrom))
                {
                    try
                    {
                        _mail = new MailMessage();
                        _mail.Body = emailingDetails.EmailContent;
                        _mail = SetEmailingDetails(emailingDetails, _mail, out isMailSent);

                        //send actual mail on action
                        if (emailingDetails.EmailSentSuccessfully)
                            _smtp.Send(_mail);
                        else
                        {
                            //send actual mail using service
                            emailingDetails.SystemError = "Send email using service";
                            SaveEmailHistory(emailingDetails);
                        }
                    }
                    catch (Exception caughtEx)
                    {
                        emailingDetails.SystemError = "Unknown Exception Thrown from EmailHelper.SendMail: "
                                            + "\n  Type:    " + caughtEx.GetType().Name
                                            + "\n  Message: " + caughtEx.Message;
                        SaveEmailHistory(emailingDetails);
                        throw new Exception("Unknown Exception Thrown from EmailHelper.SendMail: "
                                            + "\n  Type:    " + caughtEx.GetType().Name
                                            + "\n  Message: " + caughtEx.Message);
                    }
                    finally
                    {
                    }
                }
                else
                {
                    emailingDetails.SystemError = "Email ID Required.";
                    SaveEmailHistory(emailingDetails);
                    throw new ArgumentNullException("Email ID Required.");
                }
            }
            return isMailSent;
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// To initiate a reminder email (not in use for now).
        /// The job is being done using stand alone windows service.
        /// </summary>
        /// <returns></returns>
        private static bool CreateReminderEmail()
        {

            //SENDING CALENDAR INVITES / MEETING / REMINDERS

            string startTime1 = DateTime.Now.AddHours(2).ToString("yyyyMMddTHHmmssZ");
            string endTime1 = DateTime.Now.AddHours(3).ToString("yyyyMMddTHHmmssZ");
            string dtStamp = DateTime.UtcNow.ToString("yyyyMMddTHHmmssZ");

            StringBuilder str = new StringBuilder();
            str.AppendLine("BEGIN:VCALENDAR");

            //PRODID: identifier for the product that created the Calendar object
            //str.AppendLine("PRODID:-//ABC Company//Outlook MIMEDIR//EN");
            str.AppendLine("PRODID: -//Microsoft Corporation//Outlook 12.0 MIMEDIR//EN");
            str.AppendLine("VERSION:2.0");
            str.AppendLine("METHOD:REQUEST");

            var guid = Guid.NewGuid();

            str.AppendLine("BEGIN:VEVENT");

            str.AppendLine(string.Format("DTSTART:{0:yyyyMMddTHHmmssZ}", startTime1));//TimeZoneInfo.ConvertTimeToUtc("BeginTime").ToString("yyyyMMddTHHmmssZ")));
            str.AppendLine(string.Format("DTSTAMP:{0:yyyyMMddTHHmmssZ}", dtStamp));
            str.AppendLine(string.Format("DTEND:{0:yyyyMMddTHHmmssZ}", endTime1));//TimeZoneInfo.ConvertTimeToUtc("EndTime").ToString("yyyyMMddTHHmmssZ")));
            str.AppendLine(string.Format("LOCATION: {0}", "Location"));

            // UID should be unique.
            str.AppendLine(string.Format("UID:{0}", guid));
            str.AppendLine(string.Format("DESCRIPTION:{0}", _mail.Body));
            str.AppendLine(string.Format("X-ALT-DESC;FMTTYPE=text/html:{0}", _mail.Body));
            str.AppendLine(string.Format("SUMMARY:{0}", _mail.Subject));

            str.AppendLine("STATUS:CONFIRMED");
            str.AppendLine("BEGIN:VALARM");
            str.AppendLine("TRIGGER:-PT15M");
            str.AppendLine("ACTION:Accept");
            str.AppendLine("DESCRIPTION:Reminder");
            str.AppendLine("X-MICROSOFT-CDO-BUSYSTATUS:BUSY");
            str.AppendLine("END:VALARM");
            str.AppendLine("END:VEVENT");

            str.AppendLine(string.Format("ORGANIZER:MAILTO:{0}", _mail.From.Address));
            str.AppendLine(string.Format("ATTENDEE;CN=\"{0}\";RSVP=TRUE:mailto:{1}", _mail.To[0].DisplayName, _mail.To[0].Address));

            str.AppendLine("END:VCALENDAR");

            System.Net.Mime.ContentType ct = new System.Net.Mime.ContentType("text/calendar");
            ct.Parameters.Add("method", "REQUEST");
            ct.Parameters.Add("name", "meeting.ics");

            AlternateView avCal = AlternateView.CreateAlternateViewFromString(str.ToString(), ct);
            _mail.AlternateViews.Add(avCal);

            return true;
        }

        private static bool SaveEmailHistory(EmailDetails objEmailDetails)
        {
            bool rethrow = false;
            try
            {
                objEmailDetails.EmailSentSuccessfully = false;
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("EmailTo", objEmailDetails.EmailTo));
                parameters.Add(new SqlParameter("Id", objEmailDetails.Id));
                parameters.Add(new SqlParameter("EmailCC", string.IsNullOrEmpty(objEmailDetails.EmailCC) ? " " : objEmailDetails.EmailCC));
                parameters.Add(new SqlParameter("EmailFrom", objEmailDetails.EmailFrom));
                parameters.Add(new SqlParameter("EmailSubject", objEmailDetails.EmailSubject));
                parameters.Add(new SqlParameter("EmailContent", objEmailDetails.EmailContent));
                parameters.Add(new SqlParameter("EmailTextContent", objEmailDetails.EmailContent));
                parameters.Add(new SqlParameter("RetryCount", objEmailDetails.RetryCount));
                parameters.Add(new SqlParameter("EmailSentSuccessfully", objEmailDetails.EmailSentSuccessfully));
                parameters.Add(new SqlParameter("SystemError", string.IsNullOrEmpty(objEmailDetails.SystemError) ? " " : objEmailDetails.SystemError));
                parameters.Add(new SqlParameter("FromName", string.IsNullOrEmpty(objEmailDetails.FromName) ? " " : objEmailDetails.FromName));
                DatabaseHelper.ExecuteNonQueryAsyn(VarConstants.SaveEmailQueue, parameters.ToArray());
            }
            catch { }
            return rethrow;        
        }
       
        private static string PopulateBody(string mailBody)
        {
            string body = mailBody;
            string userName = string.Empty;
            string title = string.Empty;
            string url = string.Empty;
            string description = string.Empty;
            body = body.Replace("{UserName}", userName);
            body = body.Replace("{Title}", title);
            body = body.Replace("{Url}", url);
            body = body.Replace("{Description}", description);
            return body;
        }

        private static MailMessage AddAttachement(MailMessage mail, string attachments)
        {
            //Validates number of attachments
            string[] attachmentArray = attachments.Split(';');
            if (attachmentArray != null && attachmentArray.Length > 0)
            {
                if (attachmentArray.Count() <= _smtpConfiguration.numberOfAttachment)
                {
                    foreach (string ma in attachmentArray)
                    {
                        string strExtension = Path.GetExtension(ma);
                        var bytes = System.IO.File.ReadAllBytes(ma);
                        MemoryStream ms = new MemoryStream(bytes);
                        var fileName = Path.GetFileName(ma);

                        Attachment mailAttachmentFinal = new Attachment(ms, fileName);
                        strExtension = strExtension.ToLower();
                        if (strExtension == VarConstants.CSV || strExtension == VarConstants.Xls || strExtension == VarConstants.Xlsx || strExtension == VarConstants.PDF || strExtension == VarConstants.Txt)
                        {
                            mail.Attachments.Add(mailAttachmentFinal);
                        }
                        else
                        {
                            throw new Exception("File format is not valid.");
                        }
                    }
                }
                else
                {
                    throw new Exception("Number of attachment exceeded.");
                }
            }

            return mail;
        }

        private static MailMessage SetEmailingDetails(EmailDetails emailingDetails, MailMessage mail, out bool isSave)
        {
            try
            {
                isSave = ValidationHelper.ValidateMessageObject(emailingDetails);
                if (!string.IsNullOrEmpty(emailingDetails.Attachment))
                {
                    mail = AddAttachement(mail, emailingDetails.Attachment);
                }               
            }
            catch (Exception ex)
            {
                isSave = false;
                throw new Exception("Unknown Exception Thrown from SetEmailingDetails: "
                                       + "\n  Type:    " + ex.GetType().Name
                                       + "\n  Message: " + ex.Message);
            }
            if (isSave)
            {
                mail.Subject = emailingDetails.EmailSubject;
                mail.SubjectEncoding = Encoding.UTF8;
                mail.From = new MailAddress(emailingDetails.EmailFrom, emailingDetails.FromName, Encoding.UTF8);
                mail.Body = PopulateBody(emailingDetails.EmailContent);

                mail.IsBodyHtml = true;

                if (!string.IsNullOrEmpty(emailingDetails.EmailTo))
                {
                    string[] toEmailArray = emailingDetails.EmailTo.Split(';');
                    if (toEmailArray != null && toEmailArray.Length > 0)
                    {
                        foreach (string toMailId in toEmailArray)
                        {
							if(!string.IsNullOrEmpty(toMailId))
								mail.To.Add(new MailAddress(toMailId));
                        }
                    }
                }

                if (!string.IsNullOrEmpty(emailingDetails.EmailCC))
                {
                    string[] ccEmailArray = emailingDetails.EmailCC.Split(';');
                    if (ccEmailArray != null && ccEmailArray.Length > 0)
                    {
                        foreach (string ccMailId in ccEmailArray)
                        {
							if (!string.IsNullOrEmpty(ccMailId))
								mail.CC.Add(new MailAddress(ccMailId));
                        }
                    }
                }

                mail.Priority = MailPriority.Normal;

                if (!string.IsNullOrEmpty(emailingDetails.EmailContent))
                {
                    var plainView = AlternateView.CreateAlternateViewFromString(emailingDetails.EmailContent, null, "text/html");
                    mail.AlternateViews.Add(plainView);
                }

                if (!string.IsNullOrEmpty(emailingDetails.EmailTextContent))
                {
                    var htmlView = AlternateView.CreateAlternateViewFromString(emailingDetails.EmailTextContent, null, "text/plain");
                    mail.AlternateViews.Add(htmlView);
                }

            }

            return mail;
        }

        private static List<EmailDetails> GetEmailQueueLog()
        {
            var lstEmailDetails = new List<EmailDetails>();
            DataSet ds = new DataSet();
            try
            {
                ds = DatabaseHelper.ExecuteReader(VarConstants.GetEmailQueue);
                if (ds != null && ds.Tables.Count > 0)
                    lstEmailDetails = ds.Tables[0].ToList<EmailDetails>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return lstEmailDetails;
        }

        public static void SendQueueMail()
        {
            var lstEmailDetails = GetEmailQueueLog();
            foreach (var email in lstEmailDetails)
            {
                email.EmailSentSuccessfully = true;
                SendEmail(email);
                SaveEmailHistory(email);
            }
        }

        #endregion
    }
}
