﻿using Exigent.Email.Configuration;
using System;
using System.Configuration;
using System.Linq;
using System.Net.Mail;

namespace Exigent.Email.Helper
{
    class ValidationHelper
    {
        private static RegularExpressionHelper regularExpresionHelper = new RegularExpressionHelper();

        #region ValidateMessageObject
       
        public static bool ValidateMessageObject(EmailDetails emailingDetails)
        {
            bool IsValidEmail = false;
            //From
            if (string.IsNullOrEmpty(emailingDetails.EmailFrom))
            {
                throw new ArgumentNullException("From or Sender field must have a email address.");
            }
            //To
            if (!string.IsNullOrEmpty(emailingDetails.EmailTo))
            {
                string[] toEmailIdArray = emailingDetails.EmailTo.Split(';');
                if (toEmailIdArray.Count() < 1)
                    throw new ArgumentNullException("There must be atleast one recipient.");
                //ToEmailIdValidation
                if (toEmailIdArray.Count() > 0)
                {
                    IsValidEmail = ValidateEmailID(toEmailIdArray);
                }
            }
           
            //CCEmailIdValidation
            if (!string.IsNullOrEmpty(emailingDetails.EmailCC))
            {
                string[] ccEmailIdArray = emailingDetails.EmailCC.Split(';');
                if (ccEmailIdArray.Count() > 0)
                {
                    IsValidEmail = ValidateEmailID(ccEmailIdArray);
                }
            }
            return IsValidEmail;
        }
      
        public static bool ValidateEmailID(string[] ccEmailIdArray)
        {
            bool IsValid = false;
            foreach (string emailId in ccEmailIdArray)
            {
				if (!string.IsNullOrEmpty(emailId))
				{
					string sendEmailID = emailId.TrimStart(' ');
					sendEmailID = sendEmailID.TrimEnd(' ');
					if (!(regularExpresionHelper.IsValidEmail(sendEmailID)))
						throw new ArgumentNullException("EmailId must be Valid.");
					else
						IsValid = true;
				}
            }
            return IsValid;
        }
      
        public static bool ValidateMailSize(MailMessage mail)
        {
            bool IsValidMailSize = false;
            string mailBody = mail.Body;
            var mailAttachment = mail.Attachments;
            int fileSize = 0;
            fileSize += System.Text.ASCIIEncoding.ASCII.GetByteCount(mailBody);
            foreach (Attachment a in mailAttachment)
            {
                byte[] fileBytes1 = new byte[a.ContentStream.Length];
                fileSize += fileBytes1.Length;
            }
            if ((fileSize < Convert.ToInt64(ConfigurationManager.AppSettings["messageSize"])))
            {
                IsValidMailSize = true;
            }
            else
            {
                throw new Exception("Message size is too long.");
            }
            return IsValidMailSize;
        }
        #endregion
    }
}
