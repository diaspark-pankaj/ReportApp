﻿
namespace Exigent.Email.Constants
{
    public class VarConstants
    {
        public const string Doc = ".doc";
        public const string Docx = ".docx";
        public const string Xls = ".xls";
        public const string Xlsx = ".xlsx";
        public const string CSV = ".csv";
        public const string PDF = ".pdf";
        public const string Txt = ".txt";
        public const string SaveEmailQueue = "ExigentSaveEmailQueueLog";
        public const string GetEmailQueue = "ExigentGetEmailQueueLog";
    }
}