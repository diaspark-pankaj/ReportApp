﻿using Exigent.Data;
using Exigent.DataLayer.DataModels;
using System.Data.SqlClient;

namespace Exigent.Data.SqlConnectionHelper
{
    public class SqlConnectionHelper
    {
        public static SqlConnection GetExigentConnection()
        {
            ExigentDBEntities ExigentEntitie = new ExigentDBEntities();
            return new SqlConnection((ExigentEntitie.Database.Connection).ConnectionString);                 
        }

        public static SqlConnection GetClientConnection()
        {
            //ClientEntities ClientEntitie = new ClientEntities();
            //return new SqlConnection((ClientEntitie.Database.Connection).ConnectionString);
            return new SqlConnection();
        }
    }   
}
