﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;
using System.Linq;

namespace Exigent.EF.Data.Repository
{
    public class CheckLoginRepository : AbstractRepository<CheckLogin>
    {
        public CheckLogin GetByUserId(int UserId)
        {
            return Context.Set<CheckLogin>().FirstOrDefault(p => p.User.Id == UserId);
        }


    }
}
