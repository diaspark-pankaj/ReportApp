﻿using Exigent.Data.AbstractRepository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exigent.Models;
namespace Exigent.DataLayer.Repository
{
    public class Matters_AssistingTeamMembersRepository : AbstractRepository<Matters_AssistingTeamMembers>
    {

    }
}
