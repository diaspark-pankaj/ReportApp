﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class CreditNoteRepository : AbstractRepository<Credit_Note>
    {
    }
}
