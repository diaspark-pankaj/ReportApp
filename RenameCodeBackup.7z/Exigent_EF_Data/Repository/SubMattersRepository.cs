﻿using Exigent.Models;
using Exigent.Data.AbstractRepository;
using System;


namespace Exigent.DataLayer.Repository
{
   public class SubMattersRepository: AbstractRepository<SubMatter>
    {
    }
}
