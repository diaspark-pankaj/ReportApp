﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class ExternalInstructionConfirmPORepository : AbstractRepository<External_Instructions_Confirm_PO>
    {
    }
}
