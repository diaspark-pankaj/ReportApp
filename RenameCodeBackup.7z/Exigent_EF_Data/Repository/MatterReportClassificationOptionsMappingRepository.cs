﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class MatterReportClassificationOptionsMappingRepository: AbstractRepository<MatterReportClassificationOptionsMapping>
    {
    }
}
