﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class TimesheetRepository: AbstractRepository<Invoice_Timesheet>
    {
    }
    public class TimesheetTaskRepository : AbstractRepository<Invoice_Timesheet_Task>
    {
    }
}
