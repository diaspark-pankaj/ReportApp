﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;
using System;

namespace Exigent.DataLayer.Repository
{
    public class EmailRepository : AbstractRepository<EmailTemplate>
    {
    }
    public class EmailCategoryRepository : AbstractRepository<EmailCategory>
    {
    }
}
