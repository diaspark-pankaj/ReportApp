﻿using System.Linq;
using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.EF.Data.Repository
{
    public partial class RolesRepository: AbstractRepository<Role>
    
    {
        public bool IsDuplicate(Role role)
        {
            bool retVal = false;

            var existingRoles = from n in Context.Set<Role>()
                                where n.Name == role.Name && n.Id != role.Id
                                select n;

            if (existingRoles.Count() > 0)
            {
                retVal = true;
            }
            return retVal;
        }

    }
}
