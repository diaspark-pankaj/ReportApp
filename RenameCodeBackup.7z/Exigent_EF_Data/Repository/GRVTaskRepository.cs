﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class GRVTaskRepository : AbstractRepository<GRV_Task>
    {
    }
}
