﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;
using System;


namespace Exigent.DataLayer.Repository
{
    public class KeyWorkStreamRepository : AbstractRepository<KeyWorkStream>
    {
    }
}
