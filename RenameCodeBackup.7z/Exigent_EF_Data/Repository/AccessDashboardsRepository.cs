﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;
namespace Exigent.DataLayer.Repository
{
    public partial class AccessDashboardsRepository : AbstractRepository<AccessDashboard>
    {

    }
}
