﻿using Exigent.Data.AbstractRepository;
using Exigent.DataLayer.DataModels;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class ExternalInstructionRepository : AbstractRepository<External_Instruction>
    {
    }
}
