﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.DataLayer.Repository
{
    public partial class SystemTypeRepository: AbstractRepository<SystemType>
    {
    }
}
