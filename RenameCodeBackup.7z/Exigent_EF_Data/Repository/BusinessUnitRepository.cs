﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class BusinessUnitRepository : AbstractRepository<Business_Unit>
    {
    }
}
