﻿
using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class InvoiceRepository : AbstractRepository<Invoice>
    {
    }
    public class InvoiceFeeDetailRepository : AbstractRepository<InvoiceFeeDetail>
    {
    }
    public class InvoicesOutsideCIRepository : AbstractRepository<InvoicesOutsideCI>
    {
    }
    public class VersionControlMatterRepository : AbstractRepository<VersionControlMatter>
    {
    }
}
