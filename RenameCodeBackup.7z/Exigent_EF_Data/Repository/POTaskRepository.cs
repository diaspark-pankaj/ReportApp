﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class POTaskRepository : AbstractRepository<PO_Task>
    {
    }
}
