﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    //public class InvoiceSubmissionRepository : AbstractRepository<Invoice_Submission>
    //{
    //}

    public class InvoiceTimesheetRepository : AbstractRepository<Invoice_Timesheet_Capture_Task>
    {
    }
}
