﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

using LinqKit;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
namespace Exigent.EF.Data.Repository
{
    public partial class UserRepository : AbstractRepository<User>
    {
        public Role GetUserRolesById(int roleId)
        {
            return Context.Set<Role>().FirstOrDefault(p => p.Id == roleId);
        }


        public List<Role> GetUserRoleListById(List<int> roleIds)
        {
            List<Role> roles = new List<Role>();
            foreach (var roleId in roleIds)
            {
                roles.Add(Context.Set<Role>().FirstOrDefault(p => p.Id == roleId));
            }

            return roles;
        }

        public IEnumerable<Role> GetAllRolesByUserId(int userId)
        {
            return Context.Set<Role>().Where(u => u.Users.Any(e => e.Id == userId)).ToList();
        }

        //public IEnumerable<UserAccess> GetAllUserAccessByUserId(int userId)
        //{
        //    return Context.Set<UserAccess>().Where(u => u.UserId == userId).ToList();
        //}

        //public void SaveuserAccess(IEnumerable<UserAccess> userAccessList)
        //{
        //    foreach (var userAccess in userAccessList)
        //    {
        //        Context.Set<UserAccess>().Add(userAccess);
        //        Context.SaveChanges();
        //    }
        //}

        public void DeleteuserAccess(int userId)
        {
            //var context = Context.Set<UserAccess>();
            //List<UserAccess> userAccessList = Context.Set<UserAccess>().AsExpandable().Where(q => q.UserId == userId).AsEnumerable().ToList();
            //foreach (var userAccess in userAccessList)
            //{
            //    context.Remove(userAccess);
            //}
            //Context.SaveChanges();
        }        
    }
}
