﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class InvoiceAuditRepository : AbstractRepository<Invoice_Audit>
    {
    }
}
