﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class MatterStatusRepository : AbstractRepository<Matter_Status>
    {
    }
}
