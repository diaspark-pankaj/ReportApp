﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Web;

namespace Exigent.EF.Data.Repository
{
    public class AppConfigRepository : AbstractRepository<AppConfig>, ICacheble<AppConfig>
    {
        public IEnumerable<AppConfig> GetAllCached()
        {
            Debug.Print("CachedAppConfigRepository:GetAllAppConfig");
            var result = HttpRuntime.Cache[typeof(AppConfig).FullName] as IEnumerable<AppConfig>;
            if (result == null)
            {
                result = base.GetAll();
                HttpRuntime.Cache.Insert(typeof(AppConfig).FullName, result, null, DateTime.Now.AddSeconds(60), TimeSpan.Zero);
            }
            return result;
        }
    }
}
