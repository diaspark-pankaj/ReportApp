﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    //public class ExternalInstructionApprovalRepository : AbstractRepository<External_Instructions_Approval>
    //{
    //}
}
