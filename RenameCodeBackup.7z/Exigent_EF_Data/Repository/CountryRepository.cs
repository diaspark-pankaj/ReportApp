﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.DataLayer.Repository
{
    public class CountryRepository : AbstractRepository<Country>
    {
    }
    public class KeyWorkStreamRepository : AbstractRepository<KeyWorkStream>
    {
    }
}
