﻿using Exigent.Data.AbstractRepository;
using Exigent.Models;

namespace Exigent.EF.Data.Repository
{
    public partial class AuditRepository : AbstractRepository<Audit>
    {

    }
}
