﻿using System;
using System.ServiceProcess;
using System.Timers;
using Exigent.BLL;
using Microsoft.Practices.EnterpriseLibrary.Logging;

namespace Exigent.WinServices
{
    public partial class AutoMailer : ServiceBase
    {
        private Timer _timerReminder;
        private int _iteration;

        public AutoMailer()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Service on start event procedure
        /// </summary>
        /// <param name="args"></param>
        protected override void OnStart(string[] args)
        {
            try
            {
                //Get the Scheduled Time from AppSettings.
                var environment = int.Parse(System.Configuration.ConfigurationManager.AppSettings["Environment"]);
                if (environment == 0)
                    System.Diagnostics.Debugger.Launch();

                CommonManager.GetSystemDetails();

                _iteration = 0;

                this.ScheduleReminder();
            }
            catch(Exception ex)
            {
                //add the exception logging mechanism for GetSystemDetails.
                var errString = CommonManager.GetErrorLogString(ex, "Error in OnStart");
                try
                {
                    CommonManager.SendErrorEmail(errString, "Error Occurred in AutoMailer Service");
                }
                catch (Exception)
                {
                }
                finally
                {
                    Logger.Write(errString, "Error in OnStart");
                }
            }
        }

        private void ScheduleReminder()
        {
            //Set the Default Time.
            DateTime scheduledTime = DateTime.MinValue;

            //Get the Scheduled Time from AppSettings.
            var environment = int.Parse(System.Configuration.ConfigurationManager.AppSettings["Environment"]);
            if (environment > 1 && _iteration > 0)
            {
                scheduledTime = DateTime.Parse(System.Configuration.ConfigurationManager.AppSettings["ReminderScheduledTime"]);
            }
            else
            {
                _iteration = 1;
                scheduledTime = DateTime.Now.AddSeconds(10);
            }

            if (DateTime.Now > scheduledTime)
            {
                //If Scheduled Time is passed set Schedule for the next day.
                scheduledTime = scheduledTime.AddDays(1);
            }

            TimeSpan timeSpan = scheduledTime.Subtract(DateTime.Now);

            //Get the difference in Minutes between the Scheduled and Current Time.
            int dueTime = Convert.ToInt32(timeSpan.TotalMilliseconds);

            //Change the Timer's Due Time.
            _timerReminder = new Timer(dueTime);  // 30 minutes expressed as milliseconds
            _timerReminder.Elapsed += new ElapsedEventHandler(OnReminderTimerElapsed);
            _timerReminder.AutoReset = true;
            _timerReminder.Start();
        }

        /// <summary>
        /// Service on stop event procedure
        /// </summary>
        protected override void OnStop()
        {
            _timerReminder.Stop();
            _timerReminder.Dispose();
        }

        /// <summary>
        /// Timer elapsed event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnReminderTimerElapsed(object sender, ElapsedEventArgs e)
        {
            _timerReminder.Stop();

            //Executing ordered tasks.
            ExecuteOrderedTasks();

            this.ScheduleReminder();
        }

        /// <summary>
        /// Executing ordered tasks.
        /// </summary>
        private void ExecuteOrderedTasks()
        {
            try
            {
                var tm = new TaskManager();

                //Try running an inbound process.
                foreach (ITask t in tm.Tasks)
                {
                    try
                    {
                        t.Execute();
                    }
                    catch (Exception ex)
                    {
                        var errString = CommonManager.GetErrorLogString(ex, t.TaskName);
                        try
                        {
                            CommonManager.SendErrorEmail(errString, "Error Occurred in AutoMailer Service");
                        }
                        catch (Exception)
                        {
                        }
                        finally
                        {
                            Logger.Write(errString, t.TaskName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //add the exception logging mechanism for global task loading.
                var errString = CommonManager.GetErrorLogString(ex, "Error in global task configuration loading");
                try
                {
                    CommonManager.SendErrorEmail(errString, "Error Occurred in AutoMailer Service");
                }
                catch (Exception)
                {
                }
                finally
                {
                    Logger.Write(errString, "Error in global task configuration loading");
                }
            }
        }
    }
}
