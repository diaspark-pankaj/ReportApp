﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;

namespace Exigent.WinServices
{
    public class TaskManager
    {
        private List<ITask> _tasksToExecute;

        public List<ITask> Tasks
        {
            get
            {
                return _tasksToExecute;
            }
        }

        /// <summary>
        /// Load all tasks configured under the config section TaskSettings 
        /// and sort them by TaskOrder. Also add any additional settings 
        /// that are found in the config file for the particular task
        /// </summary>
        public TaskManager()
        {
            //Get the tasks from application configuration file.
            var tasks = ConfigurationManager.GetSection("TaskConfiguration") as NameValueCollection;

            _tasksToExecute = new List<ITask>();

            if (tasks != null && tasks.Count > 0)
            {
                int taskOrder = 1;


                foreach (var tc in tasks)
                {
                    ITask t = Activator.CreateInstance(Type.GetType("Exigent.WinServices.Tasks." + tc.ToString())) as ITask;

                    t.TaskOrder = taskOrder;
                    t.Enabled = true;

                    if (t.Enabled)
                    {
                        var reminders = tasks[taskOrder - 1].Split(',');

                        t.Reminder1 = int.Parse(reminders[0].ToString());
                        t.Reminder2 = int.Parse(reminders[1].ToString());

                        _tasksToExecute.Add(t);
                    }

                    taskOrder++;
                }
            }
        }


        /// <summary>
        /// Sorts the tasks based on the taskorder (Always ascending)
        /// </summary>
        public class TaskPriorityComparer : IComparer<ITask>
        {
            int IComparer<ITask>.Compare(ITask x, ITask y)
            {
                return x.TaskOrder.CompareTo(y.TaskOrder);
            }
        }
    }
}
