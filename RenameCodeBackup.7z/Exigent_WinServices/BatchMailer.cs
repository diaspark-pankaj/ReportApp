﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using Exigent.BLL;
using Microsoft.Practices.EnterpriseLibrary.Logging;
using System.Timers;

namespace Exigent.WinServices
{
    public partial class BatchMailer : ServiceBase
    {
        private Timer _timerMailer;

        public BatchMailer()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                //Get the Scheduled Time from AppSettings.
                var environment = int.Parse(System.Configuration.ConfigurationManager.AppSettings["Environment"]);
                if (environment == 0)
                    System.Diagnostics.Debugger.Launch();

                CommonManager.GetSystemDetails();

                this.ScheduleMailer();
            }
            catch (Exception ex)
            {
                //add the exception logging mechanism for GetSystemDetails.
                var errString = CommonManager.GetErrorLogString(ex, "Error in OnStart");
                try
                {
                    CommonManager.SendErrorEmail(errString, "Error Occurred in BatchMailer Service OnStart Configuration");
                }
                catch (Exception)
                {
                }
                finally
                {
                    Logger.Write(errString, "Error in OnStart");
                }
            }
        }

        protected override void OnStop()
        {
            _timerMailer.Stop();
            _timerMailer.Dispose();
        }

        private void ScheduleMailer()
        {
            //Get the Scheduled Time from AppSettings.
            int scheduledTime = int.Parse(System.Configuration.ConfigurationManager.AppSettings["MailerScheduledTime"]);

            TimeSpan timeSpan = new TimeSpan(0, scheduledTime, 0);

            _timerMailer = new Timer(timeSpan.TotalMilliseconds);
            _timerMailer.Elapsed += new ElapsedEventHandler(OnMailerTimerElapsed);
            _timerMailer.AutoReset = true;
            _timerMailer.Start();
        }


        /// <summary>
        /// Timer elapsed event.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void OnMailerTimerElapsed(object sender, ElapsedEventArgs e)
        {
            _timerMailer.Stop();

            //Executing ordered tasks.
            ExecuteMailer();

            _timerMailer.Start();
        }

        /// <summary>
        /// Execute process to send emails from queue.
        /// </summary>
        private void ExecuteMailer()
        {
            try
            {
                EmailManager.SendQueueMail();
            }
            catch (Exception ex)
            {
                //add the exception logging mechanism for global task loading.
                var errString = CommonManager.GetErrorLogString(ex, "Error in BatchMailer Services");
                try
                {
                    CommonManager.SendErrorEmail(errString, "Error Occurred in BatchMailer Service");
                }
                catch (Exception)
                {
                }
                finally
                {
                    Logger.Write(errString, "Error in global task configuration loading");
                }
            }
        }
    }
}
