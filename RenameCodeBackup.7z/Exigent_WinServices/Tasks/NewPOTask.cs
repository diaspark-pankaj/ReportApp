﻿using Exigent.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.WinServices.Tasks
{
    public class NewPOTask : ITask
    {
        public bool Enabled { get; set; }
        public int TaskOrder { get; set; }
        public string TaskName { get; set; }
        public int Reminder1 { get; set; }
        public int Reminder2 { get; set; }

        public void Execute()
        {
            var poTasks = POManager.GetAllPOTasksReminder();

            foreach (var rec in poTasks)
            {
                if (rec.Days == this.Reminder1)
                {
                    rec.ReminderMessage = "Reminder #1";
                    POManager.SendReminderEMailOnPO(rec);
                }
                else if (rec.Days == this.Reminder2)
                {
                    rec.ReminderMessage = "Reminder #2";

                    //Sending escalation email to admin user.
                    var adminEmail = System.Configuration.ConfigurationManager.AppSettings["AdminUserEmail"].ToString();
                    POManager.SendReminderEMailOnPO(rec, adminEmail);
                }
                else
                    continue;
            }
        }
    }
}
