﻿using Exigent.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.WinServices.Tasks
{
    public class SendInstruction_Approval_DisciplineLead : ITask
    {
        public bool Enabled { get; set; }
        public int TaskOrder { get; set; }
        public string TaskName { get; set; }
        public int Reminder1 { get; set; }
        public int Reminder2 { get; set; }

        public void Execute()
        {
			/*
            var instructions = InstructionManager.GetAllInstructionsPendingForApproval();

            foreach (var rec in instructions)
            {
                if (rec.Days == this.Reminder1)
                    rec.ReminderMessage = "Reminder #1";
                else if (rec.Days == this.Reminder2)
                    rec.ReminderMessage = "Reminder #2";
                else
                    continue;

                InstructionManager.SendInstruction_Approval_DisciplineLead_Reminder(rec);
            }
			*/
		}

    }
}
