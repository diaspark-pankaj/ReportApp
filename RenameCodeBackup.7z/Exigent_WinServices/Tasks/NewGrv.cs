﻿using Exigent.BLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.WinServices.Tasks
{
    public class NewGrv : ITask
    {
        public bool Enabled { get; set; }
        public int TaskOrder { get; set; }
        public string TaskName { get; set; }
        public int Reminder1 { get; set; }
        public int Reminder2 { get; set; }

        public void Execute()
        {
            var grvTasks = POManager.GetAllGrvTasksReminder();

            foreach (var rec in grvTasks)
            {
                if (rec.Days == this.Reminder1)
                {
                    rec.ReminderMessage = "Reminder #1";
                    POManager.SendReminderEmailOnGrv(rec);
                }
                else if (rec.Days == this.Reminder2)
                {
                    rec.ReminderMessage = "Reminder #2";
                    //Sending escalation email to admin user.
                    var adminEmail = System.Configuration.ConfigurationManager.AppSettings["AdminUserEmail"].ToString();
                    POManager.SendReminderEmailOnGrv(rec, adminEmail);
                }
                else
                    continue;
            }
        }
    }
}
