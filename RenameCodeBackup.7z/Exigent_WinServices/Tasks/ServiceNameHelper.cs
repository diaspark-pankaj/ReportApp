﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.WinServices.Tasks
{
    public static class ServiceNameHelper
    {
        public static string GetAutoMailerServiceNameAppConfig(string serviceName)
        {
            var config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Reflection.Assembly.GetAssembly(typeof(ProjectInstaller)).Location);
            return config.AppSettings.Settings[serviceName].Value;
        }
        public static string GetBatchMailerServiceNameAppConfig(string serviceName)
        {
            var config = System.Configuration.ConfigurationManager.OpenExeConfiguration(System.Reflection.Assembly.GetAssembly(typeof(ProjectInstaller)).Location);
            return config.AppSettings.Settings[serviceName].Value;
        }
    }
}
