﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.WinServices.Tasks
{
    public class InvoiceAudit : ITask
    {
        public bool Enabled { get; set; }
        public int TaskOrder { get; set; }
        public string TaskName { get; set; }
        public int Reminder1 { get; set; }
        public int Reminder2 { get; set; }

        public void Execute()
        {
            var invoice = Exigent.BLL.TaskManager.GetInvoiceAuditTask();
            if (invoice != null && invoice.Count() > 0)
            {
                foreach (var inv in invoice)
                {
                    if(inv.Days == this.Reminder1)
                        inv.ReminderMessage = "Reminder #1"; 
                    else if(inv.Days == this.Reminder2)
                        inv.ReminderMessage = "Reminder #2";
                    else
                        continue;

                    Exigent.BLL.TaskManager.SendReminderAuditMail(inv);
                }
            }
        }
    }
}
