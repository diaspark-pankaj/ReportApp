﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exigent.WinServices
{
    public interface ITask
    {
        string TaskName { get; set; }
        bool Enabled { get; set; }
        int TaskOrder { get; set; }
        int Reminder1 { get; set; }
        int Reminder2 { get; set; }
        void Execute();
    }
}
